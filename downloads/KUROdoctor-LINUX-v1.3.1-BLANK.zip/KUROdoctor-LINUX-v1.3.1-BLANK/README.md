# KUROdoctor v1.3.2 — Linux / SteamOS (BLANK)

The Linux side of KUROdoctor, with nothing of the original owner's filled in. For a Steam Deck, or any Linux PC.

## What's in here
- `kuro-doctor-agent-linux-1.3.2.py` — the agent (stdlib-only Python 3). Runs from your home directory, phones your relay, sweeps first, then takes commands.
- `repair-linux.py` — the repair module (snapshot-first; dry-run never changes anything).
- `kurodoctor-start-1.3.2.sh` — the launcher. Run it in Desktop Mode from Konsole.
- `relay-config.json` — `{"relay_url": ""}` — blank until you fill in your own Cloudflare worker URL.
- `SETUP.md` — setup guide, written for another Muse to walk its owner through it.
- `TEST-PLAN.md` — the one-page test plan for the first run on the Deck.

## What it does
Blind diagnostic sweep first (drive health, disk space, startup, processes, temps, pending updates, boot time, malware scan), then it polls your relay for commands from your Muse: run commands, read files, screenshots, clean, repair, deep hardware exam, uninstall, install. Everything shown to you first, nothing runs without your ok. No system writes, no package installs, no sudo for its own operation.

## How it stays blank
The agent has no relay URL baked in anywhere. If `relay_url` is blank, it prints a plain message and stops — it never guesses an address. Put your own Cloudflare worker URL in `relay-config.json` and run the launcher.
