#!/usr/bin/env python3
"""KUROdoctor agent v1.3.2 -- Linux / SteamOS (Steam Deck).

A doctor for devices, running from the HOME directory only.

Steam Deck realities this agent is built for:
  * SteamOS is Arch-based. The root filesystem is READ-ONLY by default
    (steamos-readonly). This agent NEVER writes outside $HOME, NEVER
    installs packages on its own initiative, and NEVER uses sudo for
    its own operation. If a step would need a system write or sudo,
    the agent REFUSES LOUDLY with a plain-language message instead
    of attempting it. The exceptions are a pacman uninstall or
    install the owner explicitly asked for by name, and only when
    the root filesystem is writable AND sudo works without a
    password prompt -- both gates are checked first, and a refusal
    names which gate failed.
  * Run it in Desktop Mode, from Konsole. pacman is the package
    manager; sudo needs the owner to have set a password first
    (run `passwd` in Konsole). This agent never sets that password.
  * Screenshot / mouse / type depend on tools that may or may not be
    installed (grim, scrot, import, xwd, xdotool). The agent CHECKS
    for them and returns 'unavailable' loudly when one is missing --
    it never installs anything and never fails silently.

The doctor ALWAYS goes in blind: on first connect -- before any
command is polled and before the user is asked anything -- the agent
runs a full diagnostic sweep on its own (drive health, disk space,
startup items, running processes, temperatures, pending updates,
boot time, plus a background malware scan) and puts the results in
the boot report. The user's guess ("it's riddled with viruses") is
optional context only, never the diagnosis.

Stdlib only -- no pip dependencies. Python 3.

Relay base URL comes from relay-config.json next to this script, or
from the KURODOCTOR_RELAY environment variable (env wins). There is
NO hardcoded relay URL anywhere in this file. If the URL is blank or
missing, the agent prints a plain-language message telling the owner
to set it and exits cleanly (exit code 2, no traceback).

Shared relay contract v1.3.2 (same as the Windows / Mac agents):
    POST /doctor/report    boot / heartbeat report
    GET  /doctor/command   head of the queue, WITHOUT popping
    POST /doctor/received  {id} pops that id from the queue
    POST /doctor/ack       {id, done, at, result}
KV keys: doctor:latest (report), doctor:queue (FIFO, max 10),
doctor:ack (latest ack), doctor:screenshot. The old single-slot
doctor:command key is RETIRED.
The agent posts /doctor/received IMMEDIATELY after GETting a new
command, BEFORE executing it. A per-process seen-ids set stays as a
backstop against duplicates.

Polling: 1s while active (a command was seen recently or jobs are
pending), else 10s. Heartbeat report every ~60s.
Idle traffic is roughly 8,640 polls + 1,440 heartbeats = ~10,000
requests/day, against ~86,000/day if it polled every second nonstop.

Ack hygiene: every ack string field is sanitized to ASCII
(non-ASCII -> '?', control chars stripped except newline/tab/CR),
each string field is capped at 4096 chars (appended with
'... [truncated]'), and the whole ack JSON is capped at ~16KB. If a
full ack POST fails, the agent falls back to one minimal ack
{id, done, at, result:{error:'ack_content_rejected'}}.

Async commands (exec / repair / deep / uninstall / install) return a 'started'
ack immediately (done:true, started:true, status:'running') and a
completion ack when the job finishes -- including on timeout, with
any partial output. Any result carrying an 'error' key is acked
done:false. A job is never left silent.

Commands implemented:
    ping       no-op, ack done
    sysinfo    uname, CPU, RAM, disks, network interfaces
    smart      smartctl -a --json per disk; smartctl_missing if absent
    df         disk space
    ls         {"path": ...} directory listing
    cat        {"path": ...} file contents, base64; >100KB refused
    dmesg      last 100 lines of the kernel log
    exec       {"command": ..., "timeout_s": 1-300, "owner_override": bool}
               runs in a background job; blocklist-checked first
    screenshot capture via grim -> scrot -> import -> xwd (first one
               present); JPEG <=200KB when a converter is available
    mouse      {"action": "move"|"click"|"move_click", "x": int, "y": int,
               "button": 1|2|3} via xdotool, if present
    type       {"text": ...} (<=1000 chars) via xdotool, if present
    clean      Trash + /tmp + ~/.cache only, before/after MB
    deep       read-only deep diagnosis (async; every section
               independent, failure tolerated with an 'unavailable' note)
    repair     {"function": system_files|startup|temp|defender_scan,
               "names": [...]} -- snapshot-first via repair-linux.py;
               refuses loudly if the snapshot cannot be written
    uninstall  {"kind": flatpak|pacman|app, "name": ..., "appid": int}
               running-process precheck first; pacman gated on a
               writable root filesystem AND working sudo
    install    {"kind": brew|flatpak|pacman, "name": ...}
               tool-present + already-installed prechecks first;
               pacman gated on a writable root filesystem AND
               working sudo; verified installed afterwards

Usage:
    python3 kuro-doctor-agent-linux-1.3.2.py            # normal
    python3 kuro-doctor-agent-linux-1.3.2.py --once     # one poll cycle
    python3 kuro-doctor-agent-linux-1.3.2.py --report-only
    python3 kuro-doctor-agent-linux-1.3.2.py --sweep-only

Back-compat note: a v1.3.1-or-older agent against a v1.3.2 relay runs
only the first queued command (it never sends /doctor/received).
Agent and relay must move together.
"""

import argparse
import base64
import json
import os
import platform
import re
import shutil
import socket
import stat as statmod
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone

VERSION = "1.3.2"
AGENT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(AGENT_DIR, "relay-config.json")
REPAIR_MODULE = os.path.join(AGENT_DIR, "repair-linux.py")

POLL_ACTIVE_S = 1        # seconds between polls while active
POLL_IDLE_S = 10         # seconds between polls while idle
ACTIVE_WINDOW_S = 30     # a command seen within this window keeps polling fast
HEARTBEAT_INTERVAL = 60  # seconds between heartbeat reports
CAT_MAX_BYTES = 100 * 1024  # 100 KB cap on cat
SCREENSHOT_MAX_BYTES = 200 * 1024  # 200 KB cap on screenshot JPEG
EXEC_MAX_CHARS = 20000
EXEC_TIMEOUT_MIN_S = 1
EXEC_TIMEOUT_MAX_S = 300
ACK_STRING_CAP = 4096
ACK_JSON_CAP = 16 * 1024
TYPE_MAX_CHARS = 1000
SCAN_TIMEOUT_S = 1800  # 30 minutes max for the background malware scan


# ---------------------------------------------------------------- logging

def log(msg):
    """Timestamped log line to stderr (stdout stays clean for --sweep-only JSON)."""
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(f"[{ts}] {msg}", flush=True, file=sys.stderr)


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def audit_log(msg):
    """Append one audit line under $HOME only. Never raises, never
    blocks: if the audit file cannot be written, the line is dropped
    and the agent carries on (the stderr log still has it)."""
    try:
        audit_dir = os.path.join(os.path.expanduser("~"), ".cache",
                                 "kurodoctor")
        os.makedirs(audit_dir, exist_ok=True)
        with open(os.path.join(audit_dir, "audit.log"), "a",
                  encoding="utf-8") as fh:
            fh.write(f"{now_iso()} {msg}\n")
    except OSError:
        pass


# ---------------------------------------------------------------- relay config

def load_relay_url():
    """Relay base URL: KURODOCTOR_RELAY env var wins, else
    relay-config.json next to this script. Returns '' when blank or
    missing -- the caller turns that into the plain-language exit."""
    env_url = os.environ.get("KURODOCTOR_RELAY", "").strip()
    if env_url:
        return env_url
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as fh:
            cfg = json.load(fh)
        if isinstance(cfg, dict):
            url = cfg.get("relay_url", "")
            if isinstance(url, str):
                return url.strip()
    except (OSError, ValueError):
        pass
    return ""


RELAY = load_relay_url().rstrip("/")
BOOT_ID = str(uuid.uuid4())


def relay_missing_message():
    return (
        "KUROdoctor: no relay URL is set.\n"
        "Open relay-config.json next to the agent and put your Cloudflare\n"
        "worker URL in \"relay_url\" (the full https:// address of your\n"
        "doctor relay worker), then run the launcher again.\n"
        "Or set the KURODOCTOR_RELAY environment variable to the same URL.\n"
        "Nothing was sent anywhere, and no report was saved -- the agent\n"
        "cannot reach its relay without that address. Exiting."
    )


# ---------------------------------------------------------------- relay I/O

def relay_post(path, payload):
    """POST JSON to the relay. Returns parsed JSON (or {}), or None on error."""
    url = RELAY + path
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json",
                 "User-Agent": f"KUROdoctor/{VERSION}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", "replace")
            if not body.strip():
                return {}
            try:
                return json.loads(body)
            except json.JSONDecodeError:
                return {"_raw": body}
    except urllib.error.HTTPError as e:
        log(f"relay POST {path} -> HTTP {e.code}")
        return None
    except Exception as e:  # network down, DNS failure, relay unreachable...
        log(f"relay POST {path} failed: {e}")
        return None


def relay_get(path):
    """GET from the relay. Returns parsed JSON (or {}), or None on error."""
    url = RELAY + path
    req = urllib.request.Request(
        url, headers={"User-Agent": f"KUROdoctor/{VERSION}"}, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", "replace")
            if not body.strip():
                return {}
            try:
                return json.loads(body)
            except json.JSONDecodeError:
                return {"_raw": body}
    except urllib.error.HTTPError as e:
        # 204 / 404 with "no command waiting" is normal, not an error.
        if e.code in (204, 404):
            return {}
        log(f"relay GET {path} -> HTTP {e.code}")
        return None
    except Exception as e:
        log(f"relay GET {path} failed: {e}")
        return None


# ---------------------------------------------------------------- ack hygiene

def _sanitize_string(value):
    """ASCII-only, control chars stripped except newline/tab/CR,
    capped at ACK_STRING_CAP chars."""
    out = []
    for ch in value:
        o = ord(ch)
        if o > 127:
            out.append("?")
        elif o < 32 and ch not in ("\n", "\t", "\r"):
            continue
        else:
            out.append(ch)
    text = "".join(out)
    if len(text) > ACK_STRING_CAP:
        text = text[:ACK_STRING_CAP] + "... [truncated]"
    return text


def sanitize_result(value):
    """Recursively sanitize an ack result dict: every string field
    ASCII-only and capped. Lists/dicts/numbers pass through."""
    if isinstance(value, str):
        return _sanitize_string(value)
    if isinstance(value, dict):
        return {str(k): sanitize_result(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [sanitize_result(v) for v in value]
    return value


def build_ack(cmd_id, done, result):
    """Build a sanitized ack, capped at ~16KB of JSON. If the sanitized
    ack is still over the cap, progressively truncate the largest
    string fields until it fits (never silently drop the error key)."""
    result = sanitize_result(result if isinstance(result, dict)
                             else {"value": result})
    ack = {"id": cmd_id, "done": bool(done), "at": now_iso(),
           "result": result}
    encoded = json.dumps(ack).encode("utf-8")
    if len(encoded) <= ACK_JSON_CAP:
        return ack
    # Over cap: shrink string fields, largest first, keeping 'error'.
    flat = []

    def collect(obj, path):
        if isinstance(obj, str):
            flat.append((len(obj), path))
        elif isinstance(obj, dict):
            for k, v in obj.items():
                collect(v, path + [k])
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                collect(v, path + [i])

    collect(result, [])
    flat.sort(key=lambda item: item[0], reverse=True)
    for _length, path in flat:
        target = result
        for key in path[:-1]:
            target = target[key]
        leaf = path[-1]
        current = target[leaf]
        if isinstance(current, str) and len(current) > 200:
            target[leaf] = current[:200] + "... [truncated]"
        encoded = json.dumps(ack).encode("utf-8")
        if len(encoded) <= ACK_JSON_CAP:
            break
    if len(json.dumps(ack).encode("utf-8")) > ACK_JSON_CAP:
        # Last resort: keep only the error, if any, plus a note.
        slim = {}
        if isinstance(result, dict) and "error" in result:
            slim["error"] = result["error"]
        slim["note"] = "ack result was too large and was trimmed"
        ack["result"] = slim
    return ack


def post_ack(ack):
    """Post an ack, up to 3 attempts 2s apart. On total failure, try
    one minimal ack. Returns True if anything was delivered."""
    for attempt in range(1, 4):
        if relay_post("/doctor/ack", ack) is not None:
            log(f"acked id={ack.get('id')} done={ack.get('done')} "
                f"(attempt {attempt})")
            return True
        log(f"ack for id={ack.get('id')} NOT delivered "
            f"(attempt {attempt} of 3)")
        if attempt < 3:
            time.sleep(2)
    minimal = {"id": ack.get("id"), "done": False, "at": now_iso(),
               "result": {"error": "ack_content_rejected"}}
    if relay_post("/doctor/ack", minimal) is not None:
        log(f"minimal fallback ack delivered for id={ack.get('id')}")
        return True
    log(f"ack for id={ack.get('id')} FAILED after 3 attempts - "
        "the result may be lost at the relay")
    return False


# ---------------------------------------------------------------- SteamOS facts

def os_release():
    """Parsed /etc/os-release ({} when unreadable)."""
    info = {}
    try:
        with open("/etc/os-release", encoding="utf-8",
                  errors="replace") as fh:
            for line in fh:
                if "=" in line:
                    key, val = line.split("=", 1)
                    info[key.strip()] = val.strip().strip('"')
    except OSError:
        pass
    return info


def is_steamos():
    info = os_release()
    return (info.get("ID", "").lower() == "steamos"
            or "steamos" in info.get("NAME", "").lower()
            or "steam" in info.get("NAME", "").lower())


def root_readonly():
    """True when / is mounted read-only (the SteamOS default). Read
    from /proc/mounts -- no writes, no test file, no sudo."""
    try:
        with open("/proc/mounts", encoding="utf-8",
                  errors="replace") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) >= 4 and parts[1] == "/":
                    opts = parts[3].split(",")
                    return "ro" in opts
    except OSError:
        pass
    return None  # unknown -- callers treat unknown as "assume read-only"


def sudo_works():
    """True only when sudo runs non-interactively (no password prompt).
    `sudo -n true` never prompts; a failure means sudo is unavailable
    or needs a password the owner has not set yet."""
    if shutil.which("sudo") is None:
        return False
    try:
        proc = subprocess.run(["sudo", "-n", "true"],
                              capture_output=True, text=True, timeout=10)
        return proc.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


# ---------------------------------------------------------------- device info

def _read_file(path):
    try:
        with open(path, "r", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return ""


def device_model():
    """Best-effort device model string from DMI, else the machine arch."""
    for path in ("/sys/devices/virtual/dmi/id/product_name",
                 "/sys/devices/virtual/dmi/id/board_name"):
        val = _read_file(path)
        if val:
            vendor = _read_file("/sys/devices/virtual/dmi/id/sys_vendor")
            return f"{vendor} {val}".strip() if vendor else val
    return platform.machine()


def list_disks():
    """Whole-disk device paths, e.g. ['/dev/sda', '/dev/nvme0n1']."""
    disks = []
    try:
        out = subprocess.run(
            ["lsblk", "-J", "-d", "-o", "NAME,TYPE"],
            capture_output=True, text=True, timeout=10)
        if out.returncode == 0:
            data = json.loads(out.stdout)
            for dev in data.get("blockdevices", []):
                if dev.get("type") == "disk":
                    disks.append("/dev/" + dev["name"])
            if disks:
                return disks
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    try:
        with open("/proc/partitions") as f:
            for line in f:
                parts = line.split()
                if len(parts) == 4:
                    name = parts[3]
                    if name.startswith(("sd", "vd", "hd")) and name[-1].isalpha():
                        disks.append("/dev/" + name)
                    elif name.startswith("nvme") and name.endswith(
                            tuple(f"n{i}" for i in range(10))):
                        disks.append("/dev/" + name)
    except OSError:
        pass
    return sorted(set(disks))


def network_state():
    """Interfaces and addresses, best effort, no external tools required."""
    interfaces = {}
    try:
        for _idx, name in socket.if_nameindex():
            mac = _read_file(f"/sys/class/net/{name}/address")
            operstate = _read_file(f"/sys/class/net/{name}/operstate")
            interfaces[name] = {"mac": mac or None, "state": operstate or None,
                                "addresses": []}
    except OSError:
        pass
    try:
        out = subprocess.run(["ip", "-j", "addr"], capture_output=True,
                             text=True, timeout=10)
        if out.returncode == 0:
            for iface in json.loads(out.stdout):
                name = iface.get("ifname")
                if name not in interfaces:
                    interfaces[name] = {}
                interfaces[name]["addresses"] = [
                    a.get("local") for a in iface.get("addr_info", [])
                    if a.get("local")]
                interfaces[name]["state"] = iface.get("operstate")
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    hostname = socket.gethostname()
    return {"hostname": hostname, "interfaces": interfaces}


def smart_summary():
    """Short SMART summary per disk, or smartctl_missing."""
    if shutil.which("smartctl") is None:
        return {"status": "smartctl_missing",
                "summary": "smartctl is not installed on this machine, "
                           "so drive health could not be read."}
    results = []
    for disk in list_disks():
        try:
            out = subprocess.run(
                ["smartctl", "-a", "--json", disk],
                capture_output=True, text=True, timeout=30)
            try:
                data = json.loads(out.stdout)
            except json.JSONDecodeError:
                results.append({"disk": disk, "error": "unparsable_output"})
                continue
            status = "unknown"
            passed = None
            if isinstance(data.get("smart_status"), dict):
                passed = data["smart_status"].get("passed")
                status = "passed" if passed else "FAILED"
            temp = None
            if isinstance(data.get("temperature"), dict):
                temp = data["temperature"].get("current")
            results.append({
                "disk": disk,
                "model": data.get("model_name"),
                "serial": data.get("serial_number"),
                "status": status,
                "smart_passed": passed,
                "temperature_c": temp,
                "power_on_hours": (
                    data.get("power_on_time") or {}).get("hours"),
            })
        except (OSError, subprocess.SubprocessError) as e:
            results.append({"disk": disk, "error": str(e)})
    if not results:
        return {"status": "no_disks",
                "summary": "No disks found to check."}
    bad = [r["disk"] for r in results if r.get("status") == "FAILED"]
    if bad:
        summary = "WARNING: SMART reports a failing drive: " + ", ".join(bad)
    else:
        summary = "SMART: " + ", ".join(
            f"{r['disk']} {r.get('status', 'unknown')}" for r in results)
    return {"status": "ok", "summary": summary, "disks": results}


def build_report():
    """The boot / heartbeat report payload. The blind sweep runs here,
    on first connect, before any command is polled -- its results ride
    in the boot report. Later heartbeats reuse the cached sweep."""
    disks = list_disks()
    df = disk_space()
    ro = root_readonly()
    return {
        "agent": "kuro-doctor",
        "version": VERSION,
        "platform": "linux-steamos" if is_steamos() else "linux",
        "boot_id": BOOT_ID,
        "at": now_iso(),
        "device": {
            "model": device_model(),
            "hostname": socket.gethostname(),
            "os": f"{platform.system()} {platform.release()}",
            "kernel": platform.version(),
            "arch": platform.machine(),
            "os_release": os_release().get("PRETTY_NAME", ""),
            "steamos": is_steamos(),
            "root_readonly": ro,
        },
        "disks": disks,
        "disk_space": df,
        "smart": smart_summary(),
        "network": network_state(),
        "sweep": get_sweep(),
    }


def send_report():
    report = build_report()
    log(f"sending report: model={report['device']['model']} "
        f"steamos={report['device']['steamos']} "
        f"root_readonly={report['device']['root_readonly']} "
        f"disks={report['disks']} smart={report['smart'].get('status')}")
    result = relay_post("/doctor/report", report)
    if result is None:
        log("report NOT delivered (relay unreachable)")
        return False
    log("report delivered")
    return True

# ---------------------------------------------------------------- blind sweep
# The doctor ALWAYS goes in blind. On first connect -- before any command
# is polled and before the user is asked anything -- the agent runs a full
# diagnostic sweep on its own and reports what IT finds. The user's guess
# ("it's riddled with viruses") is optional context only, never the
# diagnosis. Fast sections run synchronously and go in the boot report;
# the malware scan is slow, so it runs in a background thread and its
# result arrives later as a follow-up POST /doctor/report with
# kind "sweep-scan-result". Every section is independent: one that cannot
# run reports {"status": "unavailable", "reason": ...} and never blocks
# the others or the boot report.
# The 8 sweep sections: smart, disk_space, startup_items, processes,
# temps, pending_updates, boot_time, malware_scan.

SWEEP_VERSION = 1
_SCAN = {"thread": None, "result": None, "started": False}
_SWEEP_CACHE = None


def _unavailable(reason):
    return {"status": "unavailable", "reason": reason}


def _run(cmd, timeout=15):
    """Run a command, return stdout on success, '' on any failure.

    Never raises. A nonzero exit counts as failure (no usable output).
    """
    try:
        out = subprocess.run(cmd, capture_output=True, text=True,
                             timeout=timeout)
        return out.stdout if out.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def sweep_smart():
    """Drive health (SMART) -- reuses smart_summary(), normalised."""
    s = smart_summary()
    if s.get("status") != "ok":
        return _unavailable(s.get("summary") or s.get("status")
                            or "unknown")
    return {"status": "ok", "summary": s.get("summary"),
            "disks": s.get("disks", [])}


def sweep_disk_space():
    """Disk space per mount, with use_pct added."""
    df = disk_space()
    if "error" in df:
        return _unavailable(df["error"])
    mounts = []
    for m in df.get("mounts", []):
        total = m.get("total_gb") or 0
        used = m.get("used_gb") or 0
        mounts.append({
            "mount": m["mount"],
            "total_gb": total,
            "used_gb": used,
            "free_gb": m.get("free_gb"),
            "use_pct": round(used / total * 100, 1) if total else 0,
        })
    return {"status": "ok", "mounts": mounts}


def sweep_startup():
    """Startup items: systemd user units + xdg autostart + user crontab."""
    items = []
    saw_source = False
    out = _run(["systemctl", "--user", "list-unit-files", "--type=service",
                "--state=enabled", "--no-legend", "--no-pager"], timeout=15)
    if out:
        saw_source = True
        for line in out.splitlines():
            parts = line.split()
            if parts and parts[0].endswith(".service"):
                items.append({"name": parts[0], "command": "",
                              "source": "systemd-user"})
    home = os.path.expanduser("~")
    for autostart_dir in (os.path.join(home, ".config", "autostart"),
                          "/etc/xdg/autostart"):
        if os.path.isdir(autostart_dir):
            saw_source = True
            try:
                for fname in sorted(os.listdir(autostart_dir)):
                    if not fname.endswith(".desktop"):
                        continue
                    cmd = ""
                    try:
                        with open(os.path.join(autostart_dir, fname),
                                  errors="replace") as f:
                            for line in f:
                                if line.startswith("Exec="):
                                    cmd = line[5:].strip()
                                    break
                    except OSError:
                        pass
                    items.append({"name": fname[:-len(".desktop")],
                                  "command": cmd, "source": "xdg-autostart"})
            except OSError:
                pass
    if shutil.which("crontab") is not None:
        saw_source = True
        out = _run(["crontab", "-l"], timeout=10)
        for line in out.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                items.append({"name": line[:80], "command": line,
                              "source": "crontab"})
    if not saw_source:
        return _unavailable("no startup sources readable "
                            "(no systemctl, no /etc/xdg/autostart, "
                            "no crontab)")
    return {"status": "ok", "count": len(items), "items": items[:50]}


def sweep_processes():
    """Process count + top 10 by CPU and by memory (via ps, else /proc).

    The /proc fallback has no CPU % -- top_cpu is [] there and top_memory
    is sorted by RSS.
    """
    procs = []
    out = _run(["ps", "-eo", "pid,comm,%cpu,rss", "--sort=-%cpu"],
               timeout=15)
    for line in out.splitlines()[1:]:  # skip the header
        parts = line.split()
        if len(parts) < 4:
            continue
        try:
            procs.append({
                "pid": int(parts[0]),
                "name": parts[1],
                "cpu_pct": float(parts[2]),
                "mem_mb": round(int(parts[3]) / 1024.0, 1),
            })
        except ValueError:
            continue
    if procs:
        top_cpu = procs[:10]
        top_mem = sorted(procs, key=lambda p: p["mem_mb"],
                         reverse=True)[:10]
        return {"status": "ok", "count": len(procs),
                "top_cpu": top_cpu, "top_memory": top_mem}
    try:
        pids = [d for d in os.listdir("/proc") if d.isdigit()]
    except OSError as e:
        return _unavailable(f"cannot list processes: {e}")
    for pid in pids:
        try:
            name = ""
            rss_kb = 0
            with open(f"/proc/{pid}/status") as f:
                for line in f:
                    if line.startswith("Name:"):
                        name = line.split(":", 1)[1].strip()
                    elif line.startswith("VmRSS:"):
                        rss_kb = int(line.split()[1])
            procs.append({"pid": int(pid), "name": name, "cpu_pct": None,
                          "mem_mb": round(rss_kb / 1024.0, 1)})
        except (OSError, ValueError):
            continue
    if not procs:
        return _unavailable("no processes visible in /proc")
    top_mem = sorted(procs, key=lambda p: p["mem_mb"], reverse=True)[:10]
    return {"status": "ok", "count": len(pids),
            "top_cpu": [], "top_memory": top_mem}


def sweep_temps():
    """Temperatures: /sys/class/thermal, else `sensors` if present."""
    sensors = []
    base = "/sys/class/thermal"
    try:
        for zone in sorted(os.listdir(base)):
            if not zone.startswith("thermal_zone"):
                continue
            temp = _read_file(os.path.join(base, zone, "temp"))
            typ = _read_file(os.path.join(base, zone, "type"))
            if temp:
                try:
                    sensors.append({
                        "name": typ or zone,
                        "temp_c": round(int(temp) / 1000.0, 1),
                    })
                except ValueError:
                    pass
    except OSError:
        pass
    if not sensors:
        out = _run(["sensors"], timeout=10)
        for line in out.splitlines():
            m = re.search(r"^([^:]+):\s+\+?([0-9.]+)°C", line)
            if m:
                sensors.append({"name": m.group(1).strip(),
                                "temp_c": float(m.group(2))})
    if not sensors:
        return _unavailable("no thermal zones in /sys/class/thermal "
                            "and no `sensors` output")
    return {"status": "ok", "sensors": sensors}


def sweep_pending_updates():
    """Pending updates. pacman first (Arch / SteamOS), apt as fallback.
    Read-only: nothing is ever installed or downloaded."""
    if shutil.which("pacman") is not None:
        out = _run(["pacman", "-Qu"], timeout=60)
        updates = []
        for line in out.splitlines():
            line = line.strip()
            if line:
                updates.append(line.split()[0])
        return {"status": "ok", "manager": "pacman",
                "count": len(updates), "updates": updates[:20],
                "reboot_required": False,
                "note": "SteamOS updates itself as a whole image; "
                        "pacman -Qu lists package updates only and this "
                        "agent never installs any of them."}
    if shutil.which("apt") is None and shutil.which("apt-get") is None:
        return _unavailable("no package manager found "
                            "(neither pacman nor apt/apt-get present)")
    out = _run(["apt", "list", "--upgradable"], timeout=30)
    updates = []
    for line in out.splitlines():
        if "/" in line and "upgradable" in line:
            updates.append(line.split("/")[0].strip())
    return {"status": "ok", "manager": "apt", "count": len(updates),
            "updates": updates[:20],
            "reboot_required": os.path.exists("/var/run/reboot-required")}


def sweep_boot_time():
    """Uptime always; last boot duration from systemd-analyze if present."""
    uptime_s = None
    try:
        with open("/proc/uptime") as f:
            uptime_s = round(float(f.read().split()[0]))
    except (OSError, ValueError):
        pass
    section = {"status": "ok", "uptime_s": uptime_s}
    out = _run(["systemd-analyze"], timeout=15)
    m = re.search(r"=\s*([0-9.]+)s", out)
    if m:
        section["last_boot_s"] = float(m.group(1))
        section["last_boot_source"] = "systemd-analyze"
    return section


def _scan_worker():
    """Background thread: run clamscan over the HOME directory only
    (the whole-filesystem scan of the rescue stick makes no sense on a
    Deck -- the system partition is read-only and owned by Valve).
    The result lands in _SCAN["result"]; the main loop picks it up and
    posts the follow-up report. Never raises."""
    started = time.monotonic()
    home = os.path.expanduser("~")
    try:
        out = subprocess.run(
            ["clamscan", "-r", "--infected", "--no-summary",
             "--exclude-dir=^/proc", "--exclude-dir=^/sys",
             "--exclude-dir=^/dev", home],
            capture_output=True, text=True, timeout=SCAN_TIMEOUT_S)
        infected = [line.strip() for line in out.stdout.splitlines()
                    if line.strip()]
        _SCAN["result"] = {
            "status": "ok",
            "scanner": "clamscan",
            "scope": home,
            "threats_found": len(infected),
            "infected_files": infected[:20],
            "duration_s": round(time.monotonic() - started, 1),
        }
    except subprocess.TimeoutExpired:
        _SCAN["result"] = {
            "status": "unavailable", "scanner": "clamscan",
            "reason": f"scan timed out after {SCAN_TIMEOUT_S}s"}
    except OSError as e:
        _SCAN["result"] = {
            "status": "unavailable", "scanner": "clamscan",
            "reason": str(e)}


def sweep_malware_scan(processes_section):
    """Malware scan section of the boot report. Slow, so it is kicked
    off in a background thread and the boot report carries status
    "pending". The result arrives later as a follow-up report. If no
    scanner is installed, the section is unavailable and carries a
    process-anomaly note instead."""
    if shutil.which("clamscan") is None:
        note = "no scanner installed; rely on the processes section"
        if isinstance(processes_section, dict) \
                and processes_section.get("status") == "ok":
            note += (f" -- {processes_section.get('count')} processes "
                     f"running")
            top = processes_section.get("top_cpu") or []
            if top:
                note += f", top CPU: {top[0].get('name')}"
        return {"status": "unavailable", "scanner": "clamscan",
                "reason": "scanner_missing: clamscan is not installed",
                "process_anomaly_note": note}
    if not _SCAN["started"]:
        _SCAN["started"] = True
        thread = threading.Thread(target=_scan_worker, daemon=True)
        thread.start()
        _SCAN["thread"] = thread
    return {"status": "pending", "scanner": "clamscan",
            "scope": os.path.expanduser("~"),
            "note": "scan started in the background; result arrives as a "
                    "follow-up report (kind sweep-scan-result)"}


def run_blind_sweep():
    """Run the blind sweep: the doctor diagnoses on its own, first thing
    on connect, before any command is polled and before the user is
    asked anything. Every section is independent."""
    processes = sweep_processes()
    return {
        "sweep_version": SWEEP_VERSION,
        "smart": sweep_smart(),
        "disk_space": sweep_disk_space(),
        "startup_items": sweep_startup(),
        "processes": processes,
        "temps": sweep_temps(),
        "pending_updates": sweep_pending_updates(),
        "boot_time": sweep_boot_time(),
        "malware_scan": sweep_malware_scan(processes),
    }


def get_sweep():
    """The cached blind sweep -- run once on first connect, reused by
    every later heartbeat report so the sweep never re-runs."""
    global _SWEEP_CACHE
    if _SWEEP_CACHE is None:
        _SWEEP_CACHE = run_blind_sweep()
    return _SWEEP_CACHE


def check_scan_followup():
    """If the background malware scan finished, post its follow-up
    report (kind "sweep-scan-result") and update the cached sweep so
    later heartbeat reports show the outcome. Delivers exactly once."""
    if not _SCAN["started"] or _SCAN["result"] is None:
        return
    result = _SCAN["result"]
    _SCAN["result"] = None  # deliver once
    if _SWEEP_CACHE is not None:
        _SWEEP_CACHE["malware_scan"] = result
    payload = {
        "agent": "kuro-doctor",
        "version": VERSION,
        "kind": "sweep-scan-result",
        "boot_id": BOOT_ID,
        "hostname": socket.gethostname(),
        "at": now_iso(),
        "sweep": {"malware_scan": result},
    }
    log(f"malware scan finished: status={result.get('status')} "
        f"threats={result.get('threats_found')}")
    delivered = relay_post("/doctor/report", payload)
    if delivered is None:
        log("scan follow-up report NOT delivered (relay unreachable)")
    else:
        log("scan follow-up report delivered")


# ---------------------------------------------------------------- basic commands

def disk_space():
    """Disk space for each mounted filesystem (df-style)."""
    mounts = []
    try:
        with open("/proc/mounts") as f:
            seen = set()
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    mount = parts[1]
                    if mount in seen or mount.startswith(("/proc", "/sys",
                                                          "/dev", "/run")):
                        continue
                    seen.add(mount)
                    try:
                        usage = shutil.disk_usage(mount)
                        mounts.append({
                            "mount": mount,
                            "total_gb": round(usage.total / 1e9, 2),
                            "used_gb": round(usage.used / 1e9, 2),
                            "free_gb": round(usage.free / 1e9, 2),
                        })
                    except OSError:
                        continue
    except OSError:
        pass
    if not mounts:  # fallback: just the root filesystem
        try:
            usage = shutil.disk_usage("/")
            mounts.append({"mount": "/", "total_gb": round(usage.total / 1e9, 2),
                           "used_gb": round(usage.used / 1e9, 2),
                           "free_gb": round(usage.free / 1e9, 2)})
        except OSError as e:
            return {"error": str(e)}
    return {"mounts": mounts}


def cmd_sysinfo(_args):
    uname = platform.uname()
    cpu_model = ""
    cpu_count = os.cpu_count() or 0
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    cpu_model = line.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    mem_total_mb = mem_free_mb = None
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    mem_total_mb = int(line.split()[1]) // 1024
                elif line.startswith("MemAvailable:"):
                    mem_free_mb = int(line.split()[1]) // 1024
    except (OSError, ValueError):
        pass
    return {
        "uname": {"system": uname.system, "node": uname.node,
                  "release": uname.release, "version": uname.version,
                  "machine": uname.machine},
        "cpu": {"model": cpu_model or "unknown", "count": cpu_count},
        "ram_mb": {"total": mem_total_mb, "available": mem_free_mb},
        "disks": list_disks(),
        "network": network_state(),
    }


def cmd_smart(_args):
    return smart_summary()


def cmd_df(_args):
    return disk_space()


def cmd_ls(args):
    path = args.get("path")
    if not path or not isinstance(path, str):
        return {"error": "bad_path", "detail": "ls needs a string 'path'"}
    if not os.path.isdir(path):
        return {"error": "bad_path", "detail": f"not a directory: {path}"}
    try:
        entries = []
        for name in sorted(os.listdir(path)):
            full = os.path.join(path, name)
            try:
                st = os.lstat(full)
                kind = ("dir" if statmod.S_ISDIR(st.st_mode)
                        else "link" if statmod.S_ISLNK(st.st_mode) else "file")
                entries.append({"name": name, "type": kind, "size": st.st_size})
            except OSError:
                entries.append({"name": name, "type": "unknown", "size": None})
        return {"path": path, "entries": entries}
    except OSError as e:
        return {"error": "bad_path", "detail": str(e)}


def cmd_cat(args):
    path = args.get("path")
    if not path or not isinstance(path, str):
        return {"error": "bad_path", "detail": "cat needs a string 'path'"}
    if not os.path.isfile(path):
        return {"error": "bad_path", "detail": f"no such file: {path}"}
    try:
        size = os.path.getsize(path)
    except OSError as e:
        return {"error": "bad_path", "detail": str(e)}
    if size > CAT_MAX_BYTES:
        return {"error": "file_too_large",
                "detail": f"{path} is {size} bytes, over the "
                          f"{CAT_MAX_BYTES}-byte limit"}
    try:
        with open(path, "rb") as f:
            data = f.read()
        return {"path": path, "size": size,
                "encoding": "base64",
                "content": base64.b64encode(data).decode("ascii")}
    except OSError as e:
        return {"error": "bad_path", "detail": str(e)}


def cmd_dmesg(args):
    lines = 100
    if isinstance(args.get("lines"), int):
        lines = max(1, min(args["lines"], 500))
    try:
        out = subprocess.run(["dmesg"], capture_output=True, text=True,
                             timeout=15)
        all_lines = out.stdout.splitlines()
        return {"lines": all_lines[-lines:], "total_lines": len(all_lines)}
    except OSError as e:
        return {"error": "dmesg_unavailable", "detail": str(e)}

# ---------------------------------------------------------------- exec blocklist
# Word-boundary matching for phrases and whole-token matching for
# bare command names -- never substring matching, so innocent words
# never false-positive (e.g. "shutdown" inside the hyphenated word
# "shutdown-the-server-notes" is not a shutdown command, and "format"
# inside "reformat-my-notes" is not a format command). Credential-
# dumping tool names are NOT listed here: that check lives in the
# relay only, by design -- this agent must never carry those names.
# Every rule below names a destructive action, not a tool for reading
# secrets.

def _wb(pattern):
    """Wrap a pattern in word boundaries (case-insensitive at use)."""
    return re.compile(r"\b" + pattern + r"\b", re.IGNORECASE)


def _rm_root_target(command):
    """True when an `rm` in the command recursively removes a root
    target: exactly /, ~, /home, /etc, /usr, /var, /boot (with an
    optional trailing slash) -- or a wildcard. Paths UNDER those
    roots (e.g. /tmp/foo, /home/deck/.cache/x) are NOT root targets
    and are not blocked by this rule."""
    root_targets = {"/", "~", "~/", "/home", "/home/", "/etc", "/etc/",
                    "/usr", "/usr/", "/var", "/var/", "/boot", "/boot/"}
    for segment in re.split(r"[|;&\n]", command):
        tokens = segment.split()
        if not tokens or tokens[0] != "rm":
            continue
        recursive = any(t.startswith("-") and "r" in t[1:]
                        for t in tokens[1:] if t.startswith("-"))
        if not recursive:
            continue
        for tok in tokens[1:]:
            if tok.startswith("-"):
                continue
            if "*" in tok or "?" in tok:
                return True
            if tok in root_targets:
                return True
    return False


EXEC_BLOCK_RULES = [
    (re.compile(r"--no-preserve-root", re.IGNORECASE),
     "blocked: rm --no-preserve-root"),
    (re.compile(r"\bdd\s+[^|;&\n]*of\s*=\s*/dev/", re.IGNORECASE),
     "blocked: writing raw data to a device"),
    (re.compile(r"\bdd\s+[^|;&\n]*if\s*=\s*/dev/(zero|random|urandom)\s+[^|;&\n]*of\s*=\s*/dev/",
                re.IGNORECASE),
     "blocked: writing raw data to a device"),
    (_wb(r"ddrescue|shred\s+[^|;&\n]*/dev/"), "blocked: destructive disk write"),
    (_wb(r"wipefs|sgdisk\s+[^|;&\n]*--zap-all|parted\s+[^|;&\n]*mklabel"),
     "blocked: partition-table destruction"),
    (re.compile(r"lock[\s\-]?screen[^|;&\n]*bypass|bypass[^|;&\n]*lock[\s\-]?screen",
                re.IGNORECASE),
     "blocked: lock-screen bypass"),
    (re.compile(r"flash[^|;&\n]*firmware|firmware[^|;&\n]*flash|bios[^|;&\n]*flash|uefi[^|;&\n]*flash",
                re.IGNORECASE),
     "blocked: flashing / firmware tool"),
    (_wb(r"steamos-readonly\s+disable"), "blocked: disabling the read-only root filesystem"),
]


# Whole-token command words: matched against shell tokens (letters,
# digits, _ . - + kept together), so a hyphenated innocent word such
# as "shutdown-the-server-notes" never false-positives -- the token
# is one word, not the bare command name. "mkfs.ext4" still matches
# via the part before the first dot.
_TOKEN_BLOCK_WORDS = {
    "shutdown": "blocked: shutdown / reboot / poweroff",
    "reboot": "blocked: shutdown / reboot / poweroff",
    "halt": "blocked: shutdown / reboot / poweroff",
    "poweroff": "blocked: shutdown / reboot / poweroff",
    "passwd": "blocked: password change (passwd)",
    "useradd": "blocked: account change (useradd / userdel / usermod)",
    "userdel": "blocked: account change (useradd / userdel / usermod)",
    "usermod": "blocked: account change (useradd / userdel / usermod)",
    "chpasswd": "blocked: password change (chpasswd)",
    "mkfs": "blocked: filesystem creation (mkfs)",
    "flashrom": "blocked: flashing / firmware tool",
}


def _token_block_reason(command):
    """Return the reason when a whole shell token is a blocked command
    word, else None."""
    for token in re.findall(r"[A-Za-z0-9_.\-+]+", command.lower()):
        base = token.split(".")[0]
        if base in _TOKEN_BLOCK_WORDS:
            return _TOKEN_BLOCK_WORDS[base]
        if token in _TOKEN_BLOCK_WORDS:
            return _TOKEN_BLOCK_WORDS[token]
    return None


def _is_desktop_shortcut_delete(command, owner_override):
    """Owner-override path (same narrow rule as the Windows agent):
    ONLY shortcut-file deletes under ~/Desktop -- on Linux that means
    .desktop shortcut files. The override lifts the Desktop refusal
    ONLY for .desktop files under ~/Desktop: no -Recurse, no wildcards,
    no Documents / Pictures / Downloads. Returns the matched .desktop
    path, or None when this is not a qualifying delete."""
    if not owner_override:
        return None
    home = os.path.expanduser("~")
    desktop = os.path.join(home, "Desktop")
    # rm [flags] <path> -- flags must be plain, no -r/-R, no * or ?.
    m = re.match(r"^\s*rm\s+(-[a-zA-Z]*\s+)?(\S+)\s*$", command)
    if not m:
        return None
    flags = (m.group(1) or "").strip()
    if "r" in flags or "R" in flags:
        return None
    target = m.group(2)
    if "*" in target or "?" in target:
        return None
    if not target.endswith(".desktop"):
        return None
    abs_target = os.path.abspath(os.path.expanduser(target))
    if os.path.dirname(abs_target) != desktop:
        return None
    return abs_target


def test_exec_blocked(command, owner_override=False):
    """Return None when the command may run, else a short reason string.

    Checks, in order: (1) the owner-override shortcut-delete path --
    a qualifying .desktop delete under ~/Desktop is allowed even
    though it names the Desktop; (2) deletion aimed at the user-profile
    Documents / Pictures / Desktop folders (temp / cache paths are
    allowed); (3) the destructive-action rule table above.
    """
    if not isinstance(command, str) or not command.strip():
        return "blocked: empty command"
    if _is_desktop_shortcut_delete(command, owner_override) is not None:
        return None
    if _rm_root_target(command):
        return ("blocked: recursive removal aimed at a system or home "
                "root (/, ~, /home, /etc, /usr, /var, /boot) or with a "
                "wildcard")
    token_reason = _token_block_reason(command)
    if token_reason is not None:
        return token_reason
    if re.search(r"\b(rm|del|delete|erase)\b", command, re.IGNORECASE):
        lowered = command.lower()
        home = os.path.expanduser("~").lower()
        for folder in ("documents", "pictures", "desktop"):
            if folder in lowered or os.path.join(home, folder) in lowered:
                return ("blocked: deletion under user-profile "
                        f"{folder.capitalize()} -- owner_override only "
                        "allows .desktop shortcut deletes under ~/Desktop")
    for pattern, reason in EXEC_BLOCK_RULES:
        if pattern.search(command):
            return reason
    return None


def run_exec_sync(command, timeout_s):
    """Run one shell command, capture stdout+stderr merged, enforce the
    timeout. Returns {output, exit_code, timed_out}. Never raises."""
    started = time.monotonic()
    try:
        proc = subprocess.run(
            command, shell=True, capture_output=True, text=True,
            timeout=timeout_s, executable="/bin/bash")
        return {"output": (proc.stdout or "") + (proc.stderr or ""),
                "exit_code": proc.returncode, "timed_out": False,
                "duration_s": round(time.monotonic() - started, 1)}
    except subprocess.TimeoutExpired as e:
        partial = ""
        if e.stdout:
            partial += e.stdout if isinstance(e.stdout, str) else e.stdout.decode("utf-8", "replace")
        if e.stderr:
            partial += e.stderr if isinstance(e.stderr, str) else e.stderr.decode("utf-8", "replace")
        return {"output": partial, "exit_code": None, "timed_out": True,
                "duration_s": round(time.monotonic() - started, 1),
                "detail": f"command timed out after {timeout_s}s; "
                          "partial output above, process stopped"}
    except OSError as e:
        return {"output": "", "exit_code": None, "timed_out": False,
                "duration_s": round(time.monotonic() - started, 1),
                "error": "exec_failed", "detail": str(e)}


# ---------------------------------------------------------------- screenshot / mouse / type
# Screenshot chain (first tool present wins): grim (Wayland) -> scrot
# (X11) -> import (ImageMagick) -> xwd (X11). SteamOS Desktop Mode is
# X11, so scrot / import are the likely ones on a Deck. The agent
# CHECKS for each tool and returns 'screenshot_unavailable' loudly
# when none is present -- it never installs anything. The capture is
# scaled / compressed to JPEG <=200KB when ImageMagick `convert` is
# available; otherwise the raw capture is returned with a note saying
# so. Pixels go in the ack result as image_b64, the same interface as
# the Windows agent. Mouse / type go through xdotool when present,
# else 'unavailable' loudly -- never installed, never silent.

SCREENSHOT_TOOLS = [
    ("grim", ["grim", "{path}"]),
    ("scrot", ["scrot", "{path}"]),
    ("import", ["import", "-window", "root", "{path}"]),
    ("xwd", ["xwd", "-root", "-out", "{path}"]),
]


def _capture_screenshot_file():
    """Try the screenshot chain. Returns (tool, path) or (None, reason)."""
    tmpdir = os.path.join(os.path.expanduser("~"), ".cache", "kurodoctor")
    try:
        os.makedirs(tmpdir, exist_ok=True)
    except OSError as e:
        return None, f"cannot create screenshot work dir: {e}"
    for tool, template in SCREENSHOT_TOOLS:
        if shutil.which(tool) is None:
            continue
        ext = ".png" if tool != "xwd" else ".xwd"
        path = os.path.join(tmpdir, f"screenshot-{int(time.time())}{ext}")
        cmd = [arg.format(path=path) for arg in template]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True,
                                  timeout=30)
        except (OSError, subprocess.SubprocessError):
            continue
        if proc.returncode == 0 and os.path.isfile(path) \
                and os.path.getsize(path) > 0:
            return tool, path
        try:
            os.remove(path)
        except OSError:
            pass
    present = [t for t, _ in SCREENSHOT_TOOLS if shutil.which(t)]
    if not present:
        return None, ("screenshot_unavailable: none of grim, scrot, "
                      "import, or xwd is installed on this machine. "
                      "Install one (for example scrot) and try again -- "
                      "this agent never installs anything itself.")
    return None, ("screenshot_unavailable: a screenshot tool is present "
                  f"({', '.join(present)}) but every capture attempt failed.")


def _jpeg_bytes(path):
    """Convert a capture to JPEG <=200KB when ImageMagick is available.
    Returns (bytes, format, note). Without a converter, returns the raw
    capture bytes with a note saying so."""
    try:
        with open(path, "rb") as fh:
            raw = fh.read()
    except OSError as e:
        return None, None, f"cannot read capture file: {e}"
    if shutil.which("convert") is not None:
        for quality in (70, 50, 30):
            out_path = path + ".jpg"
            try:
                proc = subprocess.run(
                    ["convert", path, "-resize", "1280x>",
                     "-quality", str(quality), out_path],
                    capture_output=True, text=True, timeout=30)
                if proc.returncode == 0 and os.path.isfile(out_path):
                    with open(out_path, "rb") as fh:
                        data = fh.read()
                    try:
                        os.remove(out_path)
                    except OSError:
                        pass
                    if len(data) <= SCREENSHOT_MAX_BYTES:
                        return data, "jpeg", (
                            f"converted with ImageMagick (quality {quality})")
                    # Too big even at this quality: try lower, else keep
                    # the smallest we produced.
                    if quality == 30:
                        return data, "jpeg", (
                            "converted with ImageMagick (quality 30) but "
                            f"still {len(data)} bytes, over the 200KB cap; "
                            "returned anyway so the screen is visible")
            except (OSError, subprocess.SubprocessError):
                pass
        return raw, "raw", ("ImageMagick convert failed; returning the raw "
                            "capture unconverted")
    return raw, "raw", ("no JPEG converter available (ImageMagick not "
                        "installed); returning the raw capture")


def cmd_screenshot(_args):
    tool, path_or_reason = _capture_screenshot_file()
    if tool is None:
        return {"error": "screenshot_unavailable",
                "detail": path_or_reason}
    try:
        data, fmt, note = _jpeg_bytes(path_or_reason)
    finally:
        try:
            os.remove(path_or_reason)
        except OSError:
            pass
    if data is None:
        return {"error": "screenshot_unavailable", "detail": note}
    relay_post("/doctor/report", {
        "agent": "kuro-doctor", "version": VERSION, "kind": "screenshot",
        "boot_id": BOOT_ID, "hostname": socket.gethostname(),
        "at": now_iso(), "tool": tool, "format": fmt})
    return {"tool": tool, "format": fmt, "size_bytes": len(data),
            "note": note,
            "image_b64": base64.b64encode(data).decode("ascii")}


def _xdotool_or_unavailable(what):
    if shutil.which("xdotool") is None:
        return {"error": "unavailable",
                "detail": f"{what} needs xdotool, which is not installed "
                          "on this machine. Install xdotool and try again "
                          "-- this agent never installs anything itself."}
    return None


def cmd_mouse(args):
    missing = _xdotool_or_unavailable("mouse control")
    if missing is not None:
        return missing
    action = args.get("action")
    if action not in ("move", "click", "move_click"):
        return {"error": "bad_action",
                "detail": "mouse needs action move|click|move_click"}
    try:
        x = int(args.get("x"))
        y = int(args.get("y"))
    except (TypeError, ValueError):
        return {"error": "bad_coords",
                "detail": "mouse needs integer x and y"}
    button = args.get("button", 1)
    if button not in (1, 2, 3):
        return {"error": "bad_button",
                "detail": "mouse button must be 1, 2, or 3"}
    try:
        if action in ("move", "move_click"):
            proc = subprocess.run(["xdotool", "mousemove", str(x), str(y)],
                                  capture_output=True, text=True, timeout=10)
            if proc.returncode != 0:
                return {"error": "mouse_failed",
                        "detail": (proc.stderr or proc.stdout).strip()}
        if action in ("click", "move_click"):
            proc = subprocess.run(["xdotool", "click", str(button)],
                                  capture_output=True, text=True, timeout=10)
            if proc.returncode != 0:
                return {"error": "mouse_failed",
                        "detail": (proc.stderr or proc.stdout).strip()}
    except (OSError, subprocess.SubprocessError) as e:
        return {"error": "mouse_failed", "detail": str(e)}
    return {"ok": True, "action": action, "x": x, "y": y, "button": button}


def cmd_type(args):
    missing = _xdotool_or_unavailable("typing")
    if missing is not None:
        return missing
    text = args.get("text")
    if not isinstance(text, str) or not text:
        return {"error": "bad_text",
                "detail": "type needs a non-empty string 'text'"}
    if len(text) > TYPE_MAX_CHARS:
        return {"error": "bad_text",
                "detail": f"text is {len(text)} chars, over the "
                          f"{TYPE_MAX_CHARS}-char limit"}
    try:
        proc = subprocess.run(["xdotool", "type", "--", text],
                              capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError) as e:
        return {"error": "type_failed", "detail": str(e)}
    if proc.returncode != 0:
        return {"error": "type_failed",
                "detail": (proc.stderr or proc.stdout).strip()}
    return {"ok": True, "typed_chars": len(text)}


# ---------------------------------------------------------------- clean

def _dir_size_bytes(root):
    total = 0
    count = 0
    for dirpath, _dirnames, filenames in os.walk(root, followlinks=False):
        for name in filenames:
            try:
                st = os.lstat(os.path.join(dirpath, name))
                total += st.st_size
                count += 1
            except OSError:
                continue
    return total, count


def _clean_one_dir(root, older_than_s):
    """Delete regular files older than older_than_s under root.
    Returns (removed_count, freed_bytes). Never raises."""
    now = time.time()
    removed = 0
    freed = 0
    for dirpath, dirnames, filenames in os.walk(root, topdown=True,
                                                followlinks=False):
        dirnames[:] = [d for d in dirnames
                       if not d.startswith("kurodoctor-repair-backup-")
                       and not d.startswith("kurodoctor-quarantine-")]
        for name in filenames:
            path = os.path.join(dirpath, name)
            try:
                st = os.lstat(path)
                if not statmod.S_ISREG(st.st_mode):
                    continue
                if now - st.st_mtime < older_than_s:
                    continue
                os.remove(path)
                removed += 1
                freed += st.st_size
            except OSError:
                continue
    return removed, freed


def cmd_clean(_args):
    """Trash + /tmp + ~/.cache only, before/after MB. Files changed in
    the last hour are left alone (treated as in use). Nothing else is
    ever touched -- never ~/Documents, ~/Pictures, ~/Downloads."""
    home = os.path.expanduser("~")
    roots = [
        ("trash", os.path.join(home, ".local", "share", "Trash")),
        ("tmp", "/tmp"),
        ("cache", os.path.join(home, ".cache")),
    ]
    before = {}
    for label, root in roots:
        if os.path.isdir(root):
            size, count = _dir_size_bytes(root)
            before[label] = {"bytes": size, "files": count,
                             "mb": round(size / 1e6, 1)}
        else:
            before[label] = {"bytes": 0, "files": 0, "mb": 0.0,
                             "note": "not present"}
    removed_total = 0
    freed_total = 0
    per_root = {}
    for label, root in roots:
        if not os.path.isdir(root):
            per_root[label] = {"removed": 0, "freed_mb": 0.0,
                               "note": "not present"}
            continue
        removed, freed = _clean_one_dir(root, older_than_s=3600)
        removed_total += removed
        freed_total += freed
        per_root[label] = {"removed": removed,
                           "freed_mb": round(freed / 1e6, 1)}
    after = {}
    for label, root in roots:
        if os.path.isdir(root):
            size, count = _dir_size_bytes(root)
            after[label] = {"bytes": size, "files": count,
                            "mb": round(size / 1e6, 1)}
        else:
            after[label] = {"bytes": 0, "files": 0, "mb": 0.0}
    return {"before": before, "after": after, "per_root": per_root,
            "removed_files": removed_total,
            "freed_mb": round(freed_total / 1e6, 1),
            "scope": "Trash + /tmp + ~/.cache only; files changed in "
                     "the last hour left alone"}


# ---------------------------------------------------------------- deep
# Read-only deep diagnosis. Every section is independent: a section
# that cannot run reports {"status": "unavailable", "reason": ...} and
# never blocks the others. Nothing here changes anything.

def deep_smart():
    s = smart_summary()
    if s.get("status") != "ok":
        return {"status": "unavailable",
                "reason": s.get("summary") or s.get("status") or "unknown"}
    return {"status": "ok", "summary": s.get("summary"),
            "disks": s.get("disks", [])}


def deep_disks():
    if shutil.which("lsblk") is not None:
        try:
            out = subprocess.run(["lsblk", "-J", "-o",
                                  "NAME,SIZE,TYPE,MOUNTPOINT,FSTYPE"],
                                 capture_output=True, text=True, timeout=15)
            if out.returncode == 0:
                return {"status": "ok", "source": "lsblk",
                        "devices": json.loads(out.stdout).get("blockdevices", [])}
        except (OSError, ValueError, subprocess.SubprocessError):
            pass
    return {"status": "unavailable",
            "reason": "lsblk not present or failed; disk list in the "
                      "boot report is the fallback"}


def deep_df():
    df = disk_space()
    if "error" in df:
        return {"status": "unavailable", "reason": df["error"]}
    return {"status": "ok", "mounts": df.get("mounts", [])}


def deep_uptime():
    section = {"status": "ok"}
    try:
        with open("/proc/uptime") as f:
            section["uptime_s"] = round(float(f.read().split()[0]))
    except (OSError, ValueError):
        section["uptime_s"] = None
    try:
        with open("/proc/loadavg") as f:
            section["loadavg"] = f.read().split()[:3]
    except OSError:
        pass
    return section


def deep_journal_errors():
    """Kernel + system error counts from journalctl, last 24h."""
    if shutil.which("journalctl") is None:
        return {"status": "unavailable",
                "reason": "journalctl not present on this machine"}
    try:
        out = subprocess.run(
            ["journalctl", "--since", "24 hours ago", "-p", "err",
             "--no-pager", "-o", "short"],
            capture_output=True, text=True, timeout=30)
        if out.returncode != 0:
            return {"status": "unavailable",
                    "reason": "journalctl failed: "
                              + (out.stderr or "").strip()[:200]}
        lines = [ln for ln in out.stdout.splitlines() if ln.strip()]
        return {"status": "ok", "window": "last 24h",
                "error_lines": len(lines),
                "sample": lines[-10:]}
    except (OSError, subprocess.SubprocessError) as e:
        return {"status": "unavailable", "reason": str(e)}


def deep_memory():
    section = {"status": "ok"}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith(("MemTotal:", "MemAvailable:",
                                    "SwapTotal:", "SwapFree:")):
                    key, val = line.split(":", 1)
                    section[key.strip()] = int(val.split()[0])
    except (OSError, ValueError):
        pass
    out = _run(["ps", "-eo", "pid,comm,%mem,rss", "--sort=-%mem"],
               timeout=15)
    top = []
    for line in out.splitlines()[1:11]:
        parts = line.split()
        if len(parts) >= 4:
            try:
                top.append({"pid": int(parts[0]), "name": parts[1],
                            "mem_pct": float(parts[2]),
                            "mem_mb": round(int(parts[3]) / 1024.0, 1)})
            except ValueError:
                continue
    section["top_memory"] = top
    if not top and "MemTotal" not in section:
        return {"status": "unavailable",
                "reason": "no memory info readable"}
    return section


def run_deep():
    """Run every deep section, independently. Returns the result dict."""
    return {
        "smart": deep_smart(),
        "disks": deep_disks(),
        "disk_space": deep_df(),
        "uptime": deep_uptime(),
        "journal_errors_24h": deep_journal_errors(),
        "memory": deep_memory(),
        "note": "read-only diagnosis; nothing was changed",
    }

# ---------------------------------------------------------------- repair
# Repair mapping (relay `repair` function -> Linux repair module):
#   system_files  -> repair-linux.py apt-repair (named packages only)
#   startup       -> repair-linux.py startup-cleanup (named items only)
#   temp          -> repair-linux.py temp-cleanup
#   defender_scan -> repair-linux.py malware-quarantine (clamscan; MOVE
#                    infected files to quarantine, never delete)
# Honest Arch / SteamOS note: repair-linux.py is apt-based. On Arch /
# SteamOS there is no apt, so system_files CANNOT install packages
# here -- the agent reports that plainly (pacman installs would need
# a writable root filesystem and sudo, which the Deck does not have
# by default) and runs only the read-only part: a list of upgradable
# packages via `pacman -Qu`. startup / temp / defender_scan work the
# same on Arch as anywhere else -- they touch only user-level files
# and the home directory. Snapshot-first always: the repair module
# takes its own snapshot (manifest + backup under /tmp) before any
# change, and if the snapshot cannot be written the repair refuses
# loudly -- the agent never silently proceeds and never finishes a
# repair with no effect and no error.

REPAIR_FUNCTIONS = ("system_files", "startup", "temp", "defender_scan")


def _run_repair_module(repair_name, extra_args, timeout_s):
    """Run repair-linux.py --go --repair <name> [extra args].
    Returns (exit_code, stdout_text, stderr_text). Never raises.
    The module lives next to this agent in the pack."""
    if not os.path.isfile(REPAIR_MODULE):
        return None, "", (f"repair module not found next to the agent: "
                          f"{REPAIR_MODULE}. The pack is incomplete -- "
                          "repair-linux.py must sit beside the agent.")
    cmd = [sys.executable, REPAIR_MODULE, "--go", "--repair", repair_name]
    cmd.extend(extra_args)
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout_s)
        return proc.returncode, proc.stdout or "", proc.stderr or ""
    except subprocess.TimeoutExpired:
        return None, "", f"repair module timed out after {timeout_s}s"
    except OSError as e:
        return None, "", f"repair module failed to start: {e}"


def run_repair_sync(cmd_obj, timeout_s):
    """Synchronous repair worker (runs inside an async job thread).
    Returns a result dict; an 'error' key means done:false."""
    function = cmd_obj.get("function")
    if function not in REPAIR_FUNCTIONS:
        return {"error": "bad_function",
                "detail": f"repair function must be one of "
                          f"{', '.join(REPAIR_FUNCTIONS)}"}
    names = cmd_obj.get("names") or []
    if not isinstance(names, list) or any(
            not isinstance(n, str) or len(n) > 50 or "*" in n or "?" in n
            for n in names):
        return {"error": "bad_names",
                "detail": "repair names must be an array of strings, "
                          "<=50 chars each, no * or ? wildcards"}
    # Snapshot FIRST, always, via the module itself. If the snapshot
    # cannot be written, refuse loudly -- never silently proceed.
    code, out, err = _run_repair_module("snapshot", [], timeout_s=120)
    if code != 0:
        return {"error": "snapshot_failed",
                "function": function,
                "detail": "The snapshot (manifest + backup) could not be "
                          "written, so NO repair ran. Nothing was changed. "
                          f"Module output: {(out + err).strip()[-500:]}",
                "module_exit": code}
    snapshot_note = "snapshot taken (manifest + backup under /tmp)"
    if function == "system_files":
        if shutil.which("apt-get") is None:
            # Arch / SteamOS: no apt. Read-only package listing only.
            upgradable = []
            if shutil.which("pacman") is not None:
                listing = _run(["pacman", "-Qu"], timeout=60)
                upgradable = [ln.split()[0] for ln in
                              listing.splitlines() if ln.strip()]
            return {"function": function, "status": "unavailable",
                    "snapshot": snapshot_note,
                    "detail": "system_files on Arch / SteamOS cannot "
                              "install packages: repair-linux.py is "
                              "apt-based and this machine has no apt. "
                              "Package installs would need a writable root "
                              "filesystem and sudo, which the Deck does "
                              "not have by default. Nothing was installed. "
                              "Upgradable packages (read-only listing): "
                              f"{len(upgradable)}",
                    "upgradable": upgradable[:20]}
        extra = []
        for pkg in names:
            extra.extend(["--package", pkg])
        code, out, err = _run_repair_module("apt-repair", extra,
                                            timeout_s=timeout_s)
        return {"function": function, "status": "ok" if code == 0 else "failed",
                "snapshot": snapshot_note, "module_exit": code,
                "module_output": (out + err).strip()[-2000:],
                "packages": names}
    if function == "startup":
        extra = []
        for name in names:
            extra.extend(["--target", name])
        code, out, err = _run_repair_module("startup-cleanup", extra,
                                            timeout_s=timeout_s)
        return {"function": function, "status": "ok" if code == 0 else "failed",
                "snapshot": snapshot_note, "module_exit": code,
                "module_output": (out + err).strip()[-2000:],
                "targets": names}
    if function == "temp":
        code, out, err = _run_repair_module("temp-cleanup", [],
                                            timeout_s=timeout_s)
        return {"function": function, "status": "ok" if code == 0 else "failed",
                "snapshot": snapshot_note, "module_exit": code,
                "module_output": (out + err).strip()[-2000:]}
    # defender_scan -> malware-quarantine (clamscan; MOVE, never delete).
    code, out, err = _run_repair_module("malware-quarantine", [],
                                        timeout_s=timeout_s)
    return {"function": function, "status": "ok" if code == 0 else "failed",
            "snapshot": snapshot_note, "module_exit": code,
            "module_output": (out + err).strip()[-2000:]}


# ---------------------------------------------------------------- uninstall
# Kinds accepted: flatpak | pacman | app. Any other kind -> ack error
# 'bad_kind', nothing executed. RUNNING-PROCESS PRECHECK FIRST: if a
# process is running whose path is under the target or whose name
# matches, refuse 'target_running', list the process names, delete
# nothing. flatpak = `flatpak uninstall -y <id>` when flatpak exists.
# pacman = refuse loudly on the Deck unless the root filesystem is
# writable AND sudo works -- both gates are checked and the refusal
# names the gate that failed. app = remove the user-level install
# (desktop file + home-dir folder) and verify it is gone.

UNINSTALL_KINDS = ("flatpak", "pacman", "app")
_NAME_RE = re.compile(r"^[A-Za-z0-9._\-+]+$")


def _validate_uninstall_target(cmd_obj):
    """Validate name/appid. Returns (kind, name, appid, error_dict)."""
    kind = cmd_obj.get("kind")
    if kind not in UNINSTALL_KINDS:
        return None, None, None, {
            "error": "bad_kind",
            "detail": f"uninstall kind must be one of "
                      f"{', '.join(UNINSTALL_KINDS)}; got {kind!r}"}
    name = cmd_obj.get("name")
    appid = cmd_obj.get("appid")
    if kind == "flatpak":
        if not isinstance(name, str) or not name:
            return None, None, None, {
                "error": "bad_name",
                "detail": "flatpak uninstall needs a string 'name' "
                          "(the flatpak application ID, e.g. "
                          "org.mozilla.firefox)"}
    elif kind == "pacman":
        if not isinstance(name, str) or not _NAME_RE.match(name):
            return None, None, None, {
                "error": "bad_name",
                "detail": "pacman uninstall needs a plain package name "
                          "(letters, digits, . _ - + only)"}
    else:  # app
        if not isinstance(name, str) or not name or len(name) > 200 \
                or "\\" in name or "/" in name or ".." in name:
            return None, None, None, {
                "error": "bad_name",
                "detail": "app uninstall needs a plain program name "
                          "(<=200 chars, no backslash, no slash, no '..')"}
    if appid is not None and not isinstance(appid, int):
        return None, None, None, {
            "error": "bad_appid",
            "detail": "appid must be an integer (steam only, not used "
                      "by this Linux agent)"}
    return kind, name, appid, None


def _running_processes():
    """List running processes: [{pid, name, exe}]. Never raises."""
    procs = []
    out = _run(["ps", "-eo", "pid,comm"], timeout=15)
    pid_to_name = {}
    for line in out.splitlines()[1:]:
        parts = line.split(None, 1)
        if len(parts) == 2:
            try:
                pid_to_name[int(parts[0])] = parts[1].strip()
            except ValueError:
                continue
    try:
        pids = [d for d in os.listdir("/proc") if d.isdigit()]
    except OSError:
        pids = []
    for pid in pids:
        try:
            name = pid_to_name.get(int(pid), "")
            exe = ""
            try:
                exe = os.readlink(f"/proc/{pid}/exe")
            except OSError:
                pass
            if not name:
                try:
                    with open(f"/proc/{pid}/comm") as fh:
                        name = fh.read().strip()
                except OSError:
                    pass
            procs.append({"pid": int(pid), "name": name, "exe": exe})
        except (OSError, ValueError):
            continue
    return procs


def _target_running_check(kind, name, app_paths):
    """Running-process precheck. Returns a list of matching process
    names (empty when nothing is running). A process matches when its
    name matches the target name (case-insensitive) or its executable
    path sits under one of the target paths."""
    matches = []
    needle = (name or "").lower()
    for proc in _running_processes():
        pname = (proc.get("name") or "").lower()
        exe = proc.get("exe") or ""
        hit = False
        if needle and (pname == needle or needle in pname
                       or pname in needle):
            hit = True
        for base in app_paths:
            if exe and base and exe.startswith(base):
                hit = True
        if hit:
            matches.append(proc.get("name") or f"pid {proc.get('pid')}")
    return sorted(set(matches))


def _app_locations(name):
    """User-level install locations for an app: desktop files and
    home-dir folders that look like this program."""
    home = os.path.expanduser("~")
    locations = []
    for base in (os.path.join(home, ".local", "share", "applications"),
                 os.path.join(home, ".local", "share", "flatpak"),
                 "/usr/share/applications"):
        try:
            for fname in sorted(os.listdir(base)):
                if fname.lower().startswith(name.lower()) \
                        and fname.endswith(".desktop"):
                    locations.append(os.path.join(base, fname))
        except OSError:
            pass
    for base in (os.path.join(home, ".local", "share"),
                 os.path.join(home, ".local", "opt"),
                 os.path.join(home, "Applications"),
                 os.path.join(home, ".var", "app")):
        candidate = os.path.join(base, name)
        if os.path.exists(candidate):
            locations.append(candidate)
    return locations


def run_uninstall_sync(cmd_obj, timeout_s):
    """Synchronous uninstall worker (runs inside an async job thread).
    Returns a result dict; an 'error' key means done:false."""
    kind, name, _appid, err = _validate_uninstall_target(cmd_obj)
    if err is not None:
        return err
    if kind == "flatpak":
        app_paths = [os.path.join(os.path.expanduser("~"), ".var", "app", name),
                     os.path.join("/var", "lib", "flatpak", "app", name)]
        running = _target_running_check(kind, name, app_paths)
        if running:
            return {"error": "target_running", "kind": kind, "name": name,
                    "detail": "The program is still running, so nothing "
                              "was deleted. Close it first and try again.",
                    "running_processes": running}
        if shutil.which("flatpak") is None:
            return {"error": "unavailable", "kind": kind, "name": name,
                    "detail": "flatpak is not installed on this machine, "
                              "so nothing was uninstalled."}
        try:
            proc = subprocess.run(
                ["flatpak", "uninstall", "-y", name],
                capture_output=True, text=True, timeout=timeout_s)
        except subprocess.TimeoutExpired:
            return {"error": "timeout", "kind": kind, "name": name,
                    "detail": f"flatpak uninstall timed out after "
                              f"{timeout_s}s; the program may be partly "
                              "removed -- check before retrying"}
        except OSError as e:
            return {"error": "uninstall_failed", "kind": kind, "name": name,
                    "detail": str(e)}
        if proc.returncode != 0:
            return {"error": "uninstall_failed", "kind": kind, "name": name,
                    "detail": (proc.stderr or proc.stdout).strip()[-1000:]}
        return {"kind": kind, "name": name, "status": "removed",
                "detail": f"flatpak {name} uninstalled",
                "output": (proc.stdout or "").strip()[-1000:]}
    if kind == "pacman":
        ro = root_readonly()
        if ro is not False:
            return {"error": "readonly_root", "kind": kind, "name": name,
                    "detail": "Refusing: the root filesystem is "
                              "read-only (SteamOS default"
                              + (" -- could not confirm it is writable"
                                 if ro is None else "")
                              + "). Pacman cannot remove a package while "
                              "the system partition is read-only. To allow "
                              "this, the owner must first run "
                              "`sudo steamos-readonly disable` in Konsole "
                              "-- and understand that disables SteamOS "
                              "system updates until it is re-enabled. "
                              "Nothing was removed."}
        if not sudo_works():
            return {"error": "sudo_unavailable", "kind": kind, "name": name,
                    "detail": "Refusing: sudo does not work without a "
                              "password prompt on this machine. Set a sudo "
                              "password first with `passwd` in Konsole, "
                              "then try again. Nothing was removed."}
        running = _target_running_check(kind, name, [])
        if running:
            return {"error": "target_running", "kind": kind, "name": name,
                    "detail": "The program is still running, so nothing "
                              "was removed. Close it first and try again.",
                    "running_processes": running}
        try:
            proc = subprocess.run(
                ["sudo", "-n", "pacman", "-Rns", "--noconfirm", name],
                capture_output=True, text=True, timeout=timeout_s)
        except subprocess.TimeoutExpired:
            return {"error": "timeout", "kind": kind, "name": name,
                    "detail": f"pacman removal timed out after "
                              f"{timeout_s}s; the package may be partly "
                              "removed -- check before retrying"}
        except OSError as e:
            return {"error": "uninstall_failed", "kind": kind, "name": name,
                    "detail": str(e)}
        if proc.returncode != 0:
            return {"error": "uninstall_failed", "kind": kind, "name": name,
                    "detail": (proc.stderr or proc.stdout).strip()[-1000:]}
        return {"kind": kind, "name": name, "status": "removed",
                "detail": f"pacman package {name} removed",
                "output": (proc.stdout or "").strip()[-1000:]}
    # app: user-level install only -- desktop file + home-dir folder.
    locations = _app_locations(name)
    if not locations:
        return {"error": "not_found", "kind": kind, "name": name,
                "detail": f"No user-level install of {name!r} was found "
                          "(no matching desktop file or home-dir folder). "
                          "Nothing was removed."}
    running = _target_running_check(kind, name, locations)
    if running:
        return {"error": "target_running", "kind": kind, "name": name,
                "detail": "The program is still running, so nothing was "
                          "deleted. Close it first and try again.",
                "running_processes": running}
    removed = []
    failed = []
    for path in locations:
        try:
            if os.path.isdir(path) and not os.path.islink(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
            removed.append(path)
        except OSError as e:
            failed.append(f"{path}: {e}")
    still_there = [p for p in locations if os.path.exists(p)]
    if still_there:
        return {"error": "uninstall_failed", "kind": kind, "name": name,
                "removed": removed, "failed": failed,
                "still_present": still_there,
                "detail": "Some parts could not be removed; the rest "
                          "were. See still_present."}
    return {"kind": kind, "name": name, "status": "removed",
            "removed": removed,
            "detail": f"User-level install of {name} removed "
                      f"({len(removed)} location(s)); verified gone."}


# ---------------------------------------------------------------- install
# Kinds accepted: brew | flatpak | pacman. Any other kind -> ack error
# 'bad_kind', nothing executed. PRECHECKS FIRST: the package manager
# must exist on PATH, and the package must not already be installed
# (brew: `brew list <name>`; flatpak: `flatpak list --app` matching
# the id; pacman: `pacman -Q <name>`). Already installed -> ack done
# with status 'already_installed' and nothing is run. pacman = refuse
# loudly on the Deck unless the root filesystem is writable AND sudo
# works -- both gates are checked and the refusal names the gate that
# failed (same gates as the pacman uninstall). The install is verified
# afterwards with the same list/query command: an exit code of 0 is
# never trusted on its own, and the completion ack carries
# 'verified': true/false. Steps are recorded as items in the same
# shape as the uninstall results (kind / name / status / detail,
# plus a 'steps' list).

INSTALL_KINDS = ("brew", "flatpak", "pacman")


def _validate_install_target(cmd_obj):
    """Validate kind/name. Returns (kind, name, error_dict)."""
    kind = cmd_obj.get("kind")
    if kind not in INSTALL_KINDS:
        return None, None, {
            "error": "bad_kind",
            "detail": f"install kind must be one of "
                      f"{', '.join(INSTALL_KINDS)}; got {kind!r}"}
    name = cmd_obj.get("name")
    if not isinstance(name, str) or not name or len(name) > 200 \
            or ".." in name or not _NAME_RE.match(name):
        return None, None, {
            "error": "bad_name",
            "detail": "install needs a plain package name (<=200 chars, "
                      "letters, digits, . _ - + only, no '..')"}
    return kind, name, None


def _query_installed(cmd, timeout=30):
    """Run a list/query command. Returns (returncode, stdout), or
    (None, '') when the tool cannot be run at all. Never raises."""
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout)
        return proc.returncode, (proc.stdout or "")
    except (OSError, subprocess.SubprocessError):
        return None, ""


def _is_installed(kind, name):
    """Already-installed precheck. Returns True/False, or None when
    the check itself could not run (caller treats None as 'unknown',
    never as installed)."""
    if kind == "brew":
        rc, _out = _query_installed(["brew", "list", name])
        return None if rc is None else rc == 0
    if kind == "flatpak":
        rc, out = _query_installed(["flatpak", "list", "--app"])
        if rc is None:
            return None
        if rc != 0:
            return False
        for line in out.splitlines():
            if name in line.split():
                return True
        return False
    # pacman
    rc, _out = _query_installed(["pacman", "-Q", name])
    return None if rc is None else rc == 0


def run_install_sync(cmd_obj, timeout_s):
    """Synchronous install worker (runs inside an async job thread).
    Returns a result dict; an 'error' key means done:false."""
    kind, name, err = _validate_install_target(cmd_obj)
    if err is not None:
        return err
    steps = []
    tool = {"brew": "brew", "flatpak": "flatpak",
            "pacman": "pacman"}[kind]
    if shutil.which(tool) is None:
        steps.append({"step": "tool_present", "ok": False,
                      "detail": f"{tool} is not installed on this machine"})
        return {"error": "unavailable", "kind": kind, "name": name,
                "steps": steps,
                "detail": f"{tool} is not installed on this machine, "
                          "so nothing was installed."}
    steps.append({"step": "tool_present", "ok": True,
                  "detail": f"{tool} is installed"})
    already = _is_installed(kind, name)
    if already:
        steps.append({"step": "already_installed", "ok": True,
                      "detail": f"{name} is already installed"})
        return {"kind": kind, "name": name, "status": "already_installed",
                "verified": True, "steps": steps,
                "detail": f"{name} is already installed; nothing was run."}
    steps.append({"step": "already_installed", "ok": False,
                  "detail": f"{name} is not installed yet"})
    if kind == "pacman":
        ro = root_readonly()
        if ro is not False:
            steps.append({"step": "deck_gates", "ok": False,
                          "detail": "root filesystem is read-only"})
            return {"error": "readonly_root", "kind": kind, "name": name,
                    "steps": steps,
                    "detail": "Refusing: the root filesystem is "
                              "read-only (SteamOS default"
                              + (" -- could not confirm it is writable"
                                 if ro is None else "")
                              + "). Pacman cannot install a package while "
                              "the system partition is read-only. To allow "
                              "this, the owner must first run "
                              "`sudo steamos-readonly disable` in Konsole "
                              "-- and understand that disables SteamOS "
                              "system updates until it is re-enabled. "
                              "Nothing was installed."}
        if not sudo_works():
            steps.append({"step": "deck_gates", "ok": False,
                          "detail": "passwordless sudo does not work"})
            return {"error": "sudo_unavailable", "kind": kind, "name": name,
                    "steps": steps,
                    "detail": "Refusing: sudo does not work without a "
                              "password prompt on this machine. Set a sudo "
                              "password first with `passwd` in Konsole, "
                              "then try again. Nothing was installed."}
        steps.append({"step": "deck_gates", "ok": True,
                      "detail": "root writable and passwordless sudo works"})
    if kind == "brew":
        argv = ["brew", "install", name]
    elif kind == "flatpak":
        argv = ["flatpak", "install", "-y", name]
    else:  # pacman
        argv = ["sudo", "-n", "pacman", "-S", "--noconfirm", name]
    try:
        proc = subprocess.run(argv, capture_output=True, text=True,
                              timeout=timeout_s)
    except subprocess.TimeoutExpired:
        steps.append({"step": "install", "ok": False,
                      "detail": f"install timed out after {timeout_s}s"})
        return {"error": "timeout", "kind": kind, "name": name,
                "steps": steps,
                "detail": f"{kind} install timed out after {timeout_s}s; "
                          "the package may be partly installed -- check "
                          "before retrying"}
    except OSError as e:
        steps.append({"step": "install", "ok": False, "detail": str(e)})
        return {"error": "install_failed", "kind": kind, "name": name,
                "steps": steps, "detail": str(e)}
    output = (proc.stdout or "").strip()[-1000:]
    if proc.returncode != 0:
        steps.append({"step": "install", "ok": False,
                      "detail": (proc.stderr or proc.stdout).strip()[-1000:]})
        return {"error": "install_failed", "kind": kind, "name": name,
                "steps": steps,
                "detail": (proc.stderr or proc.stdout).strip()[-1000:]}
    steps.append({"step": "install", "ok": True,
                  "detail": f"{kind} install exited 0"})
    # Never trust the exit code alone: verify with the same query.
    verified = _is_installed(kind, name)
    steps.append({"step": "verify", "ok": bool(verified),
                  "detail": f"verified installed: {bool(verified)}"})
    if not verified:
        return {"error": "install_failed", "kind": kind, "name": name,
                "verified": False, "steps": steps,
                "detail": f"{kind} install reported success but {name} "
                          "is still not listed as installed; check "
                          "before retrying",
                "output": output}
    return {"kind": kind, "name": name, "status": "installed",
            "verified": True, "steps": steps,
            "detail": f"{kind} package {name} installed (verified)",
            "output": output}


# ---------------------------------------------------------------- async jobs
# exec / repair / deep / uninstall / install run in daemon threads so the poll
# loop stays responsive. A handler returns a 'started' ack immediately
# and the main loop posts the completion ack when the job finishes --
# including on timeout, with any partial output. A job is never left
# silent. Implementation: threading.Thread per job (the sanest stdlib
# route -- no extra processes, shared state is a plain dict guarded by
# the GIL, and the thread's result is read by the main loop).

_PENDING_JOBS = []  # list of dicts: {id, kind, thread, result, started_at, timeout_s}
_JOBS_LOCK = threading.Lock()


def _job_runner(job):
    """Thread body: run the worker, store its result. Never raises --
    a worker crash becomes an error result, never silence."""
    try:
        job["result"] = job["worker"]()
    except Exception as e:  # noqa: BLE001 - a job must always ack
        log(f"job {job['id']} ({job['kind']}) raised: {e}")
        job["result"] = {"error": "job_failed", "detail": str(e)}


def start_async_job(cmd_id, kind, worker, timeout_s):
    """Start a job thread and return its 'started' ack result."""
    job = {"id": cmd_id, "kind": kind, "worker": worker,
           "result": None, "started_at": time.monotonic(),
           "timeout_s": timeout_s}
    thread = threading.Thread(target=_job_runner, args=(job,),
                              daemon=True)
    job["thread"] = thread
    with _JOBS_LOCK:
        _PENDING_JOBS.append(job)
    thread.start()
    log(f"job started: id={cmd_id} kind={kind} timeout_s={timeout_s}")
    return {"started": True, "status": "running", "kind": kind,
            "timeout_s": timeout_s}


def check_pending_jobs():
    """Poll finished jobs; post each completion ack exactly once.
    A job past its timeout is acked done:false with timed_out=true
    and whatever partial result exists (the thread is daemonised and
    abandoned -- it cannot be killed, so the ack says so plainly).
    Returns the number of jobs still pending."""
    finished = []
    with _JOBS_LOCK:
        snapshot = list(_PENDING_JOBS)
    for job in snapshot:
        timed_out = (time.monotonic() - job["started_at"]
                     > job["timeout_s"])
        if job["result"] is not None:
            result = job["result"]
            done = "error" not in result
            ack = build_ack(job["id"], done, result)
            post_ack(ack)
            finished.append(job)
        elif timed_out:
            result = {"error": "timeout", "kind": job["kind"],
                      "timed_out": True,
                      "detail": f"job timed out after {job['timeout_s']}s "
                                "and was abandoned (a running thread "
                                "cannot be stopped cleanly); the work may "
                                "still finish in the background -- check "
                                "before retrying"}
            ack = build_ack(job["id"], False, result)
            post_ack(ack)
            finished.append(job)
    if finished:
        with _JOBS_LOCK:
            for job in finished:
                if job in _PENDING_JOBS:
                    _PENDING_JOBS.remove(job)
    with _JOBS_LOCK:
        return len(_PENDING_JOBS)


# ---------------------------------------------------------------- dispatch

def _exec_timeout(cmd_obj):
    timeout_s = 60
    raw = cmd_obj.get("timeout_s")
    if isinstance(raw, (int, float)):
        timeout_s = int(raw)
    timeout_s = max(EXEC_TIMEOUT_MIN_S, min(EXEC_TIMEOUT_MAX_S, timeout_s))
    return timeout_s


def execute_command(cmd_obj):
    """Run one command object. Returns (cmd_id, ack_payload) for
    synchronous commands, or (cmd_id, 'started' ack) for async ones
    (the completion ack follows from check_pending_jobs)."""
    cmd_id = cmd_obj.get("id")
    name = cmd_obj.get("cmd")
    if not isinstance(name, str) or not name:
        return cmd_id, build_ack(cmd_id, False, {
            "error": "unknown_cmd",
            "detail": "command has no 'cmd' string"})
    if name == "ping":
        return cmd_id, build_ack(cmd_id, True, {"pong": True})
    if name == "sysinfo":
        return cmd_id, build_ack(cmd_id, True, cmd_sysinfo(cmd_obj))
    if name == "smart":
        return cmd_id, build_ack(cmd_id, True, cmd_smart(cmd_obj))
    if name == "df":
        return cmd_id, build_ack(cmd_id, True, cmd_df(cmd_obj))
    if name == "ls":
        result = cmd_ls(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "cat":
        result = cmd_cat(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "dmesg":
        result = cmd_dmesg(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "screenshot":
        result = cmd_screenshot(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "mouse":
        result = cmd_mouse(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "type":
        result = cmd_type(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "clean":
        return cmd_id, build_ack(cmd_id, True, cmd_clean(cmd_obj))
    if name == "exec":
        command = cmd_obj.get("command")
        if not isinstance(command, str) or not command.strip():
            return cmd_id, build_ack(cmd_id, False, {
                "error": "bad_command",
                "detail": "exec needs a non-empty string 'command'"})
        if len(command) > EXEC_MAX_CHARS:
            return cmd_id, build_ack(cmd_id, False, {
                "error": "bad_command",
                "detail": f"command is {len(command)} chars, over the "
                          f"{EXEC_MAX_CHARS}-char limit"})
        owner_override = bool(cmd_obj.get("owner_override", False))
        audit_log(f"exec id={cmd_id} owner_override={owner_override} "
                  f"command={command}")
        blocked = test_exec_blocked(command, owner_override)
        if blocked is not None:
            log(f"exec refused (id={cmd_id}): {blocked}")
            audit_log(f"exec id={cmd_id} refused: {blocked}")
            return cmd_id, build_ack(cmd_id, False, {
                "error": "blocked", "detail": blocked})
        timeout_s = _exec_timeout(cmd_obj)
        started = start_async_job(
            cmd_id, "exec",
            lambda: run_exec_sync(command, timeout_s), timeout_s)
        return cmd_id, build_ack(cmd_id, True, started)
    if name == "repair":
        timeout_s = _exec_timeout(cmd_obj)
        started = start_async_job(
            cmd_id, "repair",
            lambda: run_repair_sync(cmd_obj, timeout_s), timeout_s)
        return cmd_id, build_ack(cmd_id, True, started)
    if name == "deep":
        timeout_s = _exec_timeout(cmd_obj)
        started = start_async_job(
            cmd_id, "deep", run_deep, timeout_s)
        return cmd_id, build_ack(cmd_id, True, started)
    if name == "uninstall":
        timeout_s = _exec_timeout(cmd_obj)
        started = start_async_job(
            cmd_id, "uninstall",
            lambda: run_uninstall_sync(cmd_obj, timeout_s), timeout_s)
        return cmd_id, build_ack(cmd_id, True, started)
    if name == "install":
        timeout_s = _exec_timeout(cmd_obj)
        audit_log(f"install id={cmd_id} kind={cmd_obj.get('kind')} "
                  f"name={cmd_obj.get('name')}")
        started = start_async_job(
            cmd_id, "install",
            lambda: run_install_sync(cmd_obj, timeout_s), timeout_s)
        return cmd_id, build_ack(cmd_id, True, started)
    log(f"unknown command: {name!r} (id={cmd_id})")
    return cmd_id, build_ack(cmd_id, False, {
        "error": "unknown_cmd", "detail": f"no such command: {name}"})


def extract_commands(payload):
    """Normalise a GET /doctor/command response into a list of command dicts.

    Accepts a bare command {"cmd": ..., "id": ...}, {"command": {...}},
    {"commands": [...]}, or an empty / no-command body ({} / {"cmd": null}).
    """
    if not isinstance(payload, dict):
        return []
    if payload.get("commands") and isinstance(payload["commands"], list):
        return [c for c in payload["commands"] if isinstance(c, dict)]
    inner = payload.get("command")
    if isinstance(inner, dict):
        return [inner]
    if payload.get("cmd"):
        return [payload]
    return []


def poll_once(seen_ids):
    """One poll cycle: GET the head of the queue WITHOUT popping, then
    POST /doctor/received IMMEDIATELY for a new command id, BEFORE
    executing it. Returns the number of commands executed."""
    payload = relay_get("/doctor/command")
    if payload is None:
        return 0  # relay unreachable; logged inside relay_get
    commands = extract_commands(payload)
    executed = 0
    for cmd_obj in commands:
        cmd_id = cmd_obj.get("id")
        if cmd_id is not None and cmd_id in seen_ids:
            log(f"skipping duplicate command id={cmd_id}")
            continue
        if cmd_id is not None:
            seen_ids.add(cmd_id)
            received = relay_post("/doctor/received", {"id": cmd_id})
            if received is None:
                log(f"/doctor/received for id={cmd_id} NOT delivered "
                    "(relay unreachable) -- executing anyway; the queue "
                    "may re-deliver this command later and the seen-ids "
                    "backstop will dedup it")
            else:
                log(f"received id={cmd_id} (popped from the queue)")
        name = cmd_obj.get("cmd")
        log(f"executing command {name!r} (id={cmd_id})")
        _cid, ack = execute_command(cmd_obj)
        executed += 1
        post_ack(ack)
    return executed


# ---------------------------------------------------------------- main

def main(argv=None):
    parser = argparse.ArgumentParser(
        description="KUROdoctor agent v1.3.2 (Linux / SteamOS)")
    parser.add_argument("--once", action="store_true",
                        help="run one poll cycle and exit")
    parser.add_argument("--report-only", action="store_true",
                        help="send the boot report and exit")
    parser.add_argument("--sweep-only", action="store_true",
                        help="run the blind sweep, print the JSON, exit")
    args = parser.parse_args(argv)

    if args.sweep_only:
        # Test mode: the sweep, and nothing else -- no relay traffic
        # and no relay URL needed. (The background scan, if one
        # starts, is abandoned on exit; the printed malware_scan
        # section shows "pending".)
        print(json.dumps(run_blind_sweep(), indent=2))
        log("sweep-only mode: exiting")
        return 0

    if not RELAY:
        # Plain-language exit, no traceback, exit code 2. Nothing was
        # sent anywhere and no report was saved.
        print(relay_missing_message(), file=sys.stderr)
        return 2

    log(f"KUROdoctor agent v{VERSION} starting, relay={RELAY}")
    log(f"steamos={is_steamos()} root_readonly={root_readonly()} "
        f"home={os.path.expanduser('~')}")

    # Boot report first, always -- even if the relay is down we keep going
    # and retry it as a heartbeat later. The blind sweep runs inside
    # build_report, before any command is polled.
    send_report()

    if args.report_only:
        log("report-only mode: exiting")
        return 0

    seen_ids = set()
    last_heartbeat = time.monotonic()
    last_command_at = 0.0  # monotonic time of the last command seen

    if args.once:
        executed = poll_once(seen_ids)
        if executed:
            last_command_at = time.monotonic()
        # --once must not exit while an async job is still running:
        # a started ack with no completion ack is silence. Wait for
        # every pending job to finish (or time out and ack) before
        # exiting. Bounded so --once always terminates.
        wait_deadline = time.monotonic() + EXEC_TIMEOUT_MAX_S + 30
        while check_pending_jobs() > 0 \
                and time.monotonic() < wait_deadline:
            time.sleep(0.5)
        check_scan_followup()
        log("once mode: exiting")
        return 0

    log(f"polling {RELAY}/doctor/command -- 1s while active, 10s idle; "
        f"heartbeat every {HEARTBEAT_INTERVAL}s")
    while True:
        try:
            executed = poll_once(seen_ids)
            if executed:
                last_command_at = time.monotonic()
        except Exception as e:  # the loop itself must never die
            log(f"poll cycle raised (continuing): {e}")
        pending = check_pending_jobs()
        check_scan_followup()
        if time.monotonic() - last_heartbeat >= HEARTBEAT_INTERVAL:
            send_report()
            last_heartbeat = time.monotonic()
        active = (pending > 0
                  or time.monotonic() - last_command_at < ACTIVE_WINDOW_S)
        time.sleep(POLL_ACTIVE_S if active else POLL_IDLE_S)


if __name__ == "__main__":
    sys.exit(main())
