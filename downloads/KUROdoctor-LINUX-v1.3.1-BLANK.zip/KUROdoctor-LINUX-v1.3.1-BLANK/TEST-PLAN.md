# KUROdoctor v1.3.2 — Steam Deck TEST PLAN (one page, for the owner)

Run these in order, on the Deck, in **Desktop Mode → Konsole**.
Copy the agent's printed lines back exactly — that is the report.

## 0. Before you start

- The `linux/` folder is in your home directory (e.g. `~/kurodoctor/`)
  with all four files together: agent, `repair-linux.py`,
  `relay-config.json`, launcher.
- `relay-config.json` has your worker URL in `relay_url` (if it is
  still blank, the agent will say so plainly and stop — that is normal,
  just fill it in first).
- iPhones are not part of this test — this agent never touches one.

## 1. Run the launcher

```
cd ~/kurodoctor
chmod +x kurodoctor-start-1.3.2.sh
./kurodoctor-start-1.3.2.sh
```

**Success looks like:**

```
KUROdoctor agent v1.3.2 starting, relay=https://...
steamos=true root_readonly=true home=/home/deck
sending report: model=... steamos=true root_readonly=true disks=[...] smart=...
report delivered
polling https://.../doctor/command -- 1s while active, 10s idle; heartbeat every 60s
```

`report delivered` is the line that matters. Leave Konsole open —
the agent keeps running and polling.

## 2. Blind sweep returns

Muse checks the report on the relay side. **Success looks like:** the
report is there, version `1.3.2`, with a `sweep` holding all
**8 sections**: smart, disk_space, startup_items, processes, temps,
pending_updates, boot_time, malware_scan.

Note anything that says `unavailable` and **which tool it names**
(e.g. `smartctl_missing`, `screenshot_unavailable`, `xdotool`) —
that tells us what the Deck doesn't have installed.

## 3. One exec returns

Muse sends a harmless command from the relay side:

```
exec: uname -a        (timeout 30s)
```

**Success looks like:** a `started` ack first (`status: "running"`),
then a completion ack with the `uname -a` output (Linux, the Deck's
hostname, kernel version). If the completion ack never comes, copy
whatever the agent printed in Konsole after the command was sent.

## 4. One screenshot returns

Muse sends:

```
screenshot
```

**Success looks like:** an ack with `tool` naming what took it
(scrot or import are the likely ones on the Deck), `format: "jpeg"`,
and the picture visible on Muse's side.

If it comes back `screenshot_unavailable`, copy the `detail` line —
it names which tools are missing. The agent never installs one
itself; that is a "tell Muse what to install" answer, not a failure
of the agent.

## What to report back

1. The agent's printed lines from step 1 (copy them exactly).
2. Anything that said `unavailable` in step 2, and which tool it named.
3. Whether the `uname -a` output came back in step 3.
4. Whether the screenshot came back in step 4 (and which tool took it),
   or the exact `screenshot_unavailable` detail if it didn't.
5. Anything else the agent printed that looked wrong — copy it word
   for word, don't paraphrase.

Mouse control and typing are not in this test — they need `xdotool`,
and if it isn't installed the agent will say so loudly when Muse
tries. Repairs and uninstalls are not in this test either — those
only run after you say go for a specific one.
