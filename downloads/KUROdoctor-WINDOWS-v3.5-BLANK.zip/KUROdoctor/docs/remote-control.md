# KUROdoctor v5 — remote control

Remote control means Muse can drive your PC from chat — run a command,
take a screenshot, move the mouse, type — but only the way the doctor
works: **show first, ok second**. Nothing happens until you ok that
exact action.

## The show-first / ok flow

1. You run the agent on the PC (double-click `KUROdoctor-Start-v1.2.bat`
   in the `entry` folder). It phones home and waits. Closing that black
   window stops the doctor completely.
2. Muse proposes an action here in chat, in plain words: what it is,
   what it will touch, and what it will not touch.
3. You say go to that exact action — or no. Silence is not a go.
4. Only then does Muse send the command through the relay. The agent
   runs it, logs it, and reports the result back here.
5. Every action is written to an audit log on the PC
   (`kuro-doctor-audit.log` next to the agent, and
   `remote-screen-audit.log` for screen actions) — what was run, when,
   and what came back.

## The exact command list

These are the only commands the agent will ever run. Anything else is
refused by the relay with `unknown_cmd` and never reaches the PC.

| Command | What it does | Args |
| --- | --- | --- |
| `ping` | No-op liveness check | — |
| `sysinfo` | Host, OS, CPU, RAM, disks, network | — |
| `smart` | Drive health for one disk | `device` (optional) |
| `df` | Disk free on all mounts | — |
| `ls` | List a directory | `path` (optional) |
| `cat` | Read a text file, max 100 KB, base64 | `path` (required) |
| `dmesg` | Last lines of the System event log | `lines` (optional, 1–500) |
| `exec` | Run exactly one PowerShell command string | `command` (required), `timeout_s` (optional, default 60, max 300) |
| `screenshot` | Capture the whole primary screen as JPEG, max ~200 KB | — |
| `mouse` | Move the mouse or click at absolute screen pixels | `x`, `y`, `action` (`move`, `left_click`, `right_click`, `double_click`) |
| `type` | Type plain text, max 1000 chars | `text` (required) |

`exec` returns the command echo, exit code (null on timeout), whether
it timed out, and output capped at 20 KB. A screenshot's pixels travel
through `POST /doctor/screenshot`; its command ack carries only width,
height, and byte count.

## Regression note (v1.2.1) — the exec normalizer bug

Proven live on a Windows 10 PC, 2026-11-19 ~22:03Z: the v1.2 agent's
`Get-CommandsFromPayload` mistook an exec command's own `command`
field for a wrapper object. The relay stores exec as
`{"cmd":"exec","command":"<text>"}` — a string-valued `command`
field — and the old check returned that bare text as if it were a
command object. The agent then acked `unknown_cmd` ("command has no
'cmd' string", empty id) and exec never ran; nothing on the PC
changed. The screenshot command worked because it has no `command`
field. Fixed in v1.2.1: `.command` counts as a wrapper only when it
is an object carrying its own `cmd` property; a bare string is never
returned as a command object. The failed exec's id is already in the
live agent's SeenIds — re-send the scan as a NEW command (fresh relay
id), never a re-post of the same id.

## The hard limits

- **No lock-screen / password bypass.** Ever. Do not ask the doctor to
  type into a password or login field — `type` cannot tell what field
  is focused, so that is an operator rule, not a technical block.
- **No credential dumping.** The relay (v2.1 patch, once deployed)
  refuses any exec command naming credential-dumping tooling
  (mimikatz, sekurlsa, lsass, ntdsutil, ntds.dit) before it can reach
  the PC. The agent itself refuses credential-harvesting and SAM /
  SYSTEM hive dumps. Those tool names live only on the relay now —
  naming them in the agent script tripped Windows Defender's scanner
  (v1.2.1 fix).
- **No deleting your stuff.** `exec` refuses deletes under Documents,
  Pictures, or Desktop. Temp and cache paths are the only delete
  targets it allows, and only when the command names them.
- **No format, wipe, diskpart, or firmware tools.** Refused outright.
- **No reboot, shutdown, wipe, format, or reinstall** unless you
  explicitly ok that named step. There is no reboot or shutdown command
  in the agent at all.
- **No iPhones.** Ever.
- **Only while the agent runs.** The doctor can only act on a PC while
  its owner started the agent there. Close the window and it is gone.
- **Screenshots are capped** at ~200 KB so one picture cannot flood
  the relay. Mouse coordinates outside the real screen are refused.
- **`exec` is deliberately blunt about one word:** any command text
  containing "format" is refused — so `Format-Table` and
  `Get-Date -Format` are blocked too. That is the specified behavior;
  ask for the numbers another way.

## How to stop it

Close the black agent window on the PC. That is the whole off switch:
no agent running means no commands can land, no screenshots, no input.
The relay holds only the latest command, report, ack, and screenshot —
nothing else is stored, and nothing keeps running after the window
closes.

## How to run it (first-run flow)

1. On the PC, open this chat in the browser and download
   `KUROdoctor-WINDOWS-v3.3-BLANK.zip`. Unzip it to the Desktop. Keep the folder
   together — do not pull files out of it.
2. Open the folder, go into `entry`, double-click
   `KUROdoctor-Start-v1.2.1.bat`. If SmartScreen appears: More info,
   then Run anyway. Leave the black window open.
3. When it says `report delivered`, tell Muse here. The doctor will
   read the report and propose the first action. Nothing is fixed
   until you say go to that fix.

## Honest limits

- Nothing in v5 has run on a real Windows machine. The v1.2 agent and
  the screen file were verified by static scans only (ASCII / CRLF /
  BOM, quote and comment balance, forbidden-command scan). First live
  test needs a real PC and the owner's deploy go.
- The relay patch for v5 is **not deployed**. The live relay still
  allows only the v1 commands until the owner gives a separate go to deploy
  the v5 patch (`KURO_DOCTOR_REMOTE_DEPLOY_APPROVED=1`). Until then,
  `exec`, `screenshot`, `mouse`, and `type` are refused by the relay
  with `unknown_cmd`.
- Screen capture and mouse/keyboard input paths are unexecuted
  anywhere. Screen quality, click accuracy, and typing behavior on a
  real PC are unproven until the live run.

## v1.3 — speed, clean, repair, deep (2026-11-19)

### Why v1.3 exists
The owner, on the live PC run: "kind of slow huh?" and "i want you able to
work faster on my pc — FULL ACCESS." Speed is the acceptance
criterion for this version, not a side item.

### What changed
- **Poll 1s, not 3s.** The agent asks the relay for orders every
  second now (heartbeat stays 60s). It still does nothing until an
  order arrives.
- **Quiet duplicate logging.** The old agent printed "skipping
  duplicate command" on every single poll — the live screenshot
  showed the window flooded with those lines. It now logs a skip at
  most once per command id.
- **Async jobs + ALWAYS ACK.** `exec`, `repair`, and `deep` now run
  in background jobs. The agent answers immediately with a `started`
  ack, keeps polling (and keeps its heartbeat) while the job runs,
  and posts a completion ack when the job finishes — or on timeout,
  stops the job, captures any partial output, and acks
  `timed_out:true`. An ack is retried up to 3 times, so one failed
  post can no longer lose a result silently. The relay stores only
  the latest ack, so the completion ack overwriting the `started`
  ack is correct and expected.
- **The missing-ack bug (proven live 2026-11-19):** the IObit
  Uninstaller exec (id fd2d2c78, 240s timeout) never acked — the job
  hung past its timeout with no answer while the loop kept skipping
  it as a duplicate. The async design + ack retries close that hole.
  Residual risk: if all 3 ack attempts fail (relay down for the
  whole retry window), the failure is logged loudly but that one ack
  is lost. The retry bounds the loss; it does not eliminate it.

### New commands (v1.3)
| Command | What it does | Args |
| --- | --- | --- |
| `clean` | Trash only: Recycle Bin, $env:TEMP, C:\Windows\Temp, Prefetch, thumbnail cache. Before/after MB per location. Refuses everything else — never Documents, Pictures, Desktop, Downloads, never images or videos. | — |
| `repair` | One named repair from the repair module. Restore point runs FIRST; a failed restore point stops the run. | `function` (required: `system_files`, `startup`, `temp`, `defender_scan`), `names` (optional, startup only: exact names, no wildcards) |
| `deep` | Hardware deep exam, read-only: SMART counters, disks + volumes, fragmentation analysis, battery health, problem devices, DISM health check, last-24h error counts by provider, memory pressure + top processes, SysMain, Edge totals. | — |

### Update in place (no new Defender exclusion)
The Defender exclusion is on the FOLDER, not the file. Extract the
v1.3 pack into the SAME folder you already use (the one Defender
already ignores) and let it overwrite. Do NOT make a new folder.
Then run `entry\KUROdoctor-Start-v1.3.bat` as administrator
(right-click, Run as administrator). The pack carries
`UPDATE-IN-PLACE.txt` at its top level with the same words.

### What v1.3 does not change
- Show-first / ok gate: nothing runs until you ok that exact action.
- No lock-screen / password bypass, no credential dumping (the
  relay blocklist — mimikatz, sekurlsa, lsass, ntdsutil, ntds.dit —
  is carried forward into the v1.3 relay patch), never delete your
  documents/photos/images/videos, no reboot/shutdown/wipe command in
  the agent.
- The v1.3 relay patch is UNDEPLOYED until the owner gives a separate
  deploy go. Until then `clean`, `repair`, and `deep` are refused by
  the relay with `unknown_cmd`, and the credential blocklist still
  lives nowhere (the v2.1 patch carrying it never deployed either).

## v1.3.1 — queue, ack hygiene, uninstall, adaptive poll (2026-11-19/20)

### Why v1.3.1 exists
The v1.3.0 run on a Windows 10 PC on 2026-11-19 produced six live bugs, all
recorded in the project log. v1.3.1 fixes all of them. Built and verified on
disk only — nothing deployed, nothing run on a real PC.

### The queue / receipt contract (replaces the single-slot command)
- The relay holds a FIFO queue in KV key `doctor:queue` (JSON array,
  max 10). POST `/doctor/command` validates, appends, returns
  `{ok:true, id, position}`; at 10 it returns 400 `queue_full`.
- GET `/doctor/command` returns the HEAD of the queue WITHOUT
  popping it, or `{cmd:null}` when empty.
- POST `/doctor/received` `{id}` removes that id from the queue
  (400 `bad_id` if id is missing/not a string; 400 `unknown_id` if
  the id is not queued), returns `{ok:true}`.
- The agent MUST post `/doctor/received` immediately after GETting
  a new command, BEFORE executing it. If the receipt POST fails
  (retried once), the agent does NOT execute that cycle — it leaves
  the command queued and retries on the next poll. The id joins the
  agent's `SeenIds` only after a successful receipt, so a skipped
  id can never be treated as a duplicate forever.
- The old single-slot `doctor:command` KV key is RETIRED — the relay
  no longer writes it.
- Back-compat: a v1.3.0-or-older agent against the v1.3.1 relay runs
  only the first queued command (it never sends `/doctor/received`).
  Agent and relay must move together via the in-place pack update.

### The ack contract (never-400-on-content)
- POST `/doctor/ack` `{id, done, at, result}`: the relay reads the
  body as text first, then parses JSON. Bad JSON is salvaged: the id
  is pulled out with a regex and a minimal ack is stored
  (`{id, done:false, result:{error:'ack_unparseable'}}`) with a 200.
  A result over 16KB is truncated server-side (replaced with
  `{error:'ack_too_large'}`). A missing or non-object result
  defaults to `{}`. 400 only when the body is completely empty or
  unreadable.
- Agents sanitize ack strings to ASCII (non-ASCII → `?`, control
  chars stripped except newline/tab/CR), cap each string field at
  4096 chars (append `... [truncated]`), cap total ack JSON ~16KB,
  and fall back to a minimal ack `{error:'ack_content_rejected'}`
  if a full ack POST fails.
- Async commands (`exec`/`repair`/`deep`/`uninstall`) send a
  `started` ack (`{...started:true, status:'running'}`) then a
  completion ack. Any result with an `error` key → `done:false`.
- Root cause note: the lost v1.3 repair ack (400 three times) is
  believed to be non-ASCII (em-dash) text from the repair module
  reaching the ack, sent by PowerShell 5.1 in the local ANSI code
  page and rejected by Workers' UTF-8 JSON parser — but the exact
  ack bytes were never captured, so this is a hypothesis, not proven.
  The fix is belt-and-braces on both sides, and the repair module
  itself is now ASCII-only.

### New command: uninstall
- `{cmd:"uninstall", kind, name?, appid?}`. `kind` is required, one
  of `steam|msi|appx|app|brew|flatpak|pacman`. `name` ≤200 chars, no
  backslash, no slash, no `..`. `appid` is an integer, steam only.
  At least one of `name`/`appid` is required. Errors: `bad_kind`,
  `bad_target`.
- Each agent accepts its own kinds and returns `bad_kind` for the
  others: Windows `steam|msi|appx`, Mac `app|brew`, Linux
  `flatpak|pacman|app` (no `steam` on Linux — Steam games on the
  Deck are removed by hand, not by this command).
- Running-process precheck FIRST: if any process belonging to the
  target is running, the agent refuses cleanly (`target_running`,
  listing process names) and deletes nothing. Steam: delete the
  common folder + appmanifest, verify gone. MSI:
  Get-Package/Uninstall-Package, fallback winget, verify gone.
  AppX: Remove-AppxPackage + provisioned removal attempt, verify
  gone. Per-item results in the ack.
- Linux note: `pacman` uninstall runs `sudo -n pacman` only when
  BOTH gates pass (root filesystem writable AND working passwordless
  sudo). Both gates refuse by default on a stock Steam Deck — the
  single documented exception to "no sudo by the agent".

### Owner override (exec only)
- `exec` accepts an optional boolean `owner_override`. When true,
  the agent lifts the Desktop/Documents/Pictures removal refusal
  ONLY when every Remove-Item/del target ends in `.lnk` AND all
  paths are under a Desktop folder AND no Documents/Pictures/
  Downloads paths AND no `-Recurse` AND no wildcards. Anything else
  is still refused.
- The relay passes the flag through only on `exec` commands and only
  when it is a boolean; any other use returns 400 `bad_override`.
  The flag is never on by default.

### Adaptive polling (request math)
- 1s while active (a command seen in the last 2 min, or a job
  pending), 10s when idle. Heartbeat every ~60s.
- Idle: ~8,640 polls + 1,440 heartbeats ≈ 10,000 Cloudflare
  requests/day (vs ~86,400/day at a flat 1s poll). Active (command
  running): back to ~1s polling until the job finishes and 2 min
  pass with no new command.
- The ~60s heartbeat POSTs the report; the heartbeat KV write count
  (~1,440/day) is unchanged from v1.3.0.

### Exec blocklist (agent side)
- `format` and `wipe` now match as whole words (`\bformat\b`,
  `\bwipe\b`): "Information" passes, "Format-Volume" still refused.
  The relay-side credential blocklist (mimikatz, sekurlsa, lsass,
  ntdsutil, ntds.dit → 400 `blocked`) is unchanged and still
  enforced on the relay before anything is stored.

### Screenshot (v1.1)
- Windows capture is now raw Win32 GDI BitBlt via P/Invoke — no
  `CopyFromScreen` anywhere in the file. Same interface: JPEG
  ≤200 KB, `image_b64` in the ack. This removes the Defender false
  positive (HackTool:PowerShell/EmpireGetScreenshot.C).

### Repair (never silently no-ops)
- Windows: the repair module sets
  `SystemRestorePointCreationFrequency=0` before
  `Checkpoint-Computer`, and on checkpoint failure accepts a
  restore point created within the last 24h as the snapshot
  (status `ok`, detail names it). A repair must NEVER finish with
  no effect and no error.
- Mac: `tmutil snapshot` is attempted first; failure or missing
  tmutil → loud `status: refused`, `detail: snapshot_unavailable`,
  nothing runs.

### What v1.3.1 does not change
- Show-first / ok gate, no lock-screen / password bypass, no
  credential dumping, never delete documents/photos, no
  reboot/shutdown/wipe/format/reinstall command anywhere.
- The v1.3.1 relay patch is UNDEPLOYED until the owner gives a separate
  deploy go. Until then the queue, `uninstall`, and the ack-salvage
  behaviour do not exist on the live relay — the old single-slot
  command key and the v1 ack handler are still what is live.

### Phone commands (USB, v1.3.5)

The Windows agent drives a phone plugged in over USB with adb
(`phone_checkup`, `phone_repair`). Same queue, same ack rules as
every other command. Full setup + error table: SETUP.md, "USB phone
doctor" section.

- `phone_checkup` - no args. Returns model, Android version, SDK,
  storage (`/data`, total/available KB), battery (level, charging,
  temperature C), RAM (total/available KB), app count. No adb ->
  `adb_missing`; no phone -> `no_device`; not allowed yet ->
  `unauthorized` ("tap Allow on the phone").
- `phone_repair` - `{"kind", "package"}`. Kinds: `clear_cache`
  (`pm clear`), `disable` (`pm disable-user --user 0`),
  `force_stop` (`am force-stop`), `uninstall`
  (`pm uninstall --user 0`). Package: 1-200 chars, regex
  `^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)+$`. The protected set
  (`com.kuro.kurodoctor`, `android`, `com.android.systemui`,
  `com.android.phone`, `com.android.settings`,
  `com.android.packageinstaller`, `com.google.android.gms`,
  `com.google.android.gsf`) is refused with `protected_package`
  at the relay AND the agent. Before/after state (installed /
  disabled) is read back and reported in the ack. A failed `pm`
  command acks `repair_failed` with the phone's detail. Never
  touches documents or photos.
