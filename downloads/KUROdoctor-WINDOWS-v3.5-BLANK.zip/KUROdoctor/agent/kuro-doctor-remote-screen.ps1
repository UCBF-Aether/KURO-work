﻿#Requires -Version 5.1
<#
.SYNOPSIS
    KUROdoctor remote screen control (deliverable 2: SCREEN CONTROL), v1.1.

.DESCRIPTION
    Separate screen-control file for the KUROdoctor Windows agent.
    It owns screen capture and input only: screenshot, mouse, type.
    It does NOT own command polling, relay I/O, the blind sweep, or
    any other agent work. That work stays in the agent file.

    v1.1 (2026-11-19) - Defender-safe capture. Windows Defender
    flagged the v1.0 capture as HackTool:PowerShell/
    EmpireGetScreenshot.C because it used the .NET screen-copy
    call - the same pattern Empire's PowerShell screenshot uses.
    v1.1 captures with raw Win32 GDI BitBlt via P/Invoke (GetDC,
    CreateCompatibleDC, CreateCompatibleBitmap, SelectObject,
    BitBlt SRCCOPY, then Bitmap.FromHbitmap) and the existing JPEG
    encode / scale-down loop. The old screen-copy call is gone
    from this file entirely - no trace of it in code or comments.
    Mouse (SetCursorPos + mouse_event) and type (SendKeys) are
    UNCHANGED. Interface identical: JPEG <=200KB, image_b64 in
    the ack result, width/height/bytes.

    NEEDS A REAL WINDOWS RUN - never executed.
    No PowerShell exists on the build VM. This file was verified by
    static scans only (ASCII / CRLF / BOM, quote and comment balance,
    forbidden-command scan). It has never run on Windows. Do not treat
    it as tested until it has run on a real Windows host.

    DECISION (made by the coordinator):
    Screen control lives in this SEPARATE file, not folded into the
    v1.2 agent. One file stays focused on command control; this file
    owns screen capture + input. The v1.2 agent loads / dot-sources
    this file when present, or the operator runs it alongside the
    agent. See WIRING below.

    WIRING (v1.2 agent):
    Dot-source this file from the agent directory, from the agent
    script (no auto-run on load - dot-sourcing only defines the
    functions below; the only top-level statement is a $false flag
    that gates lazy API setup, and no capture or input happens):
        . "$PSScriptRoot\kuro-doctor-remote-screen.ps1"
    Then either register the three handlers in the agent $Handlers
    map (same shape as the v1.0.1 agent handlers: each takes the
    command object and returns a result hashtable):
        $Handlers['screenshot'] = { param($c) Invoke-CmdScreenshot $c }
        $Handlers['mouse']      = { param($c) Invoke-CmdMouse $c }
        $Handlers['type']       = { param($c) Invoke-CmdType $c }
    Or delegate a whole relay command to the dispatcher, which
    returns a full ack hashtable { id, done, at, result }:
        $ack = Invoke-KDRemoteScreenCommand -CmdObj $cmdObj
    Or the operator runs this file alongside the agent by
    dot-sourcing it in an interactive session and calling the
    functions directly. Nothing in this file polls the relay and
    nothing runs on load.

    FUNCTIONS EXPOSED:
        Invoke-CmdScreenshot            handler for cmd 'screenshot'
        Invoke-CmdMouse                 handler for cmd 'mouse'
        Invoke-CmdType                  handler for cmd 'type'
        Invoke-KDRemoteScreenCommand    dispatcher for all three cmds
        Write-KDRemoteScreenAudit       audit-log writer (internal)
        Initialize-KDRemoteScreenApis   lazy .NET / P/Invoke setup
        Get-KDRemoteScreenScriptDir     script directory helper
        Get-KDRemoteScreenArg           command-arg reader helper
        Get-KDRemoteScreenNowIso        UTC ISO timestamp helper

    RELAY COMMANDS (allow-list extended by the coordinator; the relay
    is your own Cloudflare Worker URL (see relay-config.json), polled by the agent (1s while active, 10s when idle);
    these cmd names and args must be used exactly):
        screenshot  no args.
                    Ack result:
                      { "width": <int>, "height": <int>,
                        "bytes": <int>, "format": "jpeg",
                        "image_b64": <string> }
        mouse       args: x (int, absolute screen pixels),
                    y (int, absolute screen pixels),
                    action (one of "move", "left_click",
                    "right_click", "double_click").
                    Ack result:
                      { "x": <int>, "y": <int>, "action": <string> }
                    Out-of-bounds x/y is refused: ack done:false,
                    result { "error": "bad_coords", "detail": ... }.
                    Unknown action is refused the same way with
                    error "bad_action".
        type        args: text (required string, plain text only,
                    max 1000 chars).
                    Ack result:
                      { "typed_chars": <int> }
                    Text containing a control character other than
                    newline or tab is refused: ack done:false,
                    result { "error": "bad_text", "detail": ... }.
                    Text over 1000 chars is refused the same way.

    HOW EACH COMMAND WORKS:
        screenshot: .NET System.Drawing / System.Windows.Forms for
                    bounds, raw Win32 GDI BitBlt via P/Invoke for
                    the copy (v1.1 - see the note above), then saved
                    as JPEG at quality 60. The image is scaled
                    down by half steps (1.0, 0.5, 0.25, 0.125) until
                    it fits the 200 KB cap (204800 bytes); the result
                    never exceeds 200 KB. The returned width/height
                    are the final (possibly scaled) image dimensions.
                    The image is returned base64 in the ack result.
        mouse: .NET P/Invoke via Add-Type (user32.dll): SetCursorPos
                    plus mouse_event. SetCursorPos moves the cursor;
                    mouse_event sends the button down/up pair for a
                    click. Chosen over Cursor.Position alone so the
                    click itself is an explicit native input event.
                    The P/Invoke type is registered lazily by
                    Initialize-KDRemoteScreenApis on first use.
        type: plain text only via System.Windows.Forms.SendKeys
                    (SendKeys.SendWait). SendKeys special characters
                    (+ ^ % ~ ( ) { } [ ]) are escaped by wrapping
                    them in braces; newline becomes {ENTER} and tab
                    becomes {TAB}. SendKeys needs an interactive
                    desktop session; it cannot type to a locked
                    screen and it cannot see what field has focus.

    OPERATOR RULE - PASSWORD FIELDS:
    NEVER use the 'type' command on a password or login field.
    This function cannot detect what field has focus, so this is
    an operator rule, not a technical block. The operator must
    check the screen (screenshot first) and must only type into
    a field they have confirmed is not a password or login field.
    Do not type credentials, one-time codes, or secrets with
    this command.

    AUDIT:
    Every command execution writes one audit log entry
    (timestamp, command, args, result) to a log file next to
    this script: remote-screen-audit.log. The audit line never
    contains the screenshot base64 and never contains typed
    text (only the typed character count); the mouse line logs
    x, y, and action only. Audit failure never breaks a command.

    SAFETY:
    No screen capture and no input without a relay command.
    Nothing in this file runs on load. No reboot, shutdown,
    format, or wipe code anywhere. No credential access. No
    lock-screen bypass. No external modules, no downloads,
    PowerShell and .NET only.

    ENCODING:
    This file must stay pure ASCII after the BOM, CRLF line
    endings only, UTF-8 BOM present (bytes EF BB BF at the
    start). No non-ASCII characters anywhere. The v1.0 agent
    failed to parse on a real Windows PC because of an encoding
    fault; do not reintroduce one. Edit only with an editor
    that preserves ASCII + CRLF + BOM.
#>

$script:KDRemoteScreenApisLoaded = $false

# ---------------------------------------------------------------- helpers

function Get-KDRemoteScreenNowIso {
    return (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
}

function Get-KDRemoteScreenScriptDir {
    if ($PSScriptRoot) { return $PSScriptRoot }
    return (Get-Location).Path
}

function Get-KDRemoteScreenArg {
    param($CmdObj, [string]$Name)
    if ($null -eq $CmdObj) { return $null }
    if ($CmdObj -is [hashtable]) {
        if ($CmdObj.ContainsKey($Name)) { return $CmdObj[$Name] }
        return $null
    }
    $prop = $CmdObj.PSObject.Properties[$Name]
    if ($null -ne $prop) { return $prop.Value }
    return $null
}

function Write-KDRemoteScreenAudit {
    param(
        [string]$Cmd,
        [string]$ArgsText,
        [bool]$Done,
        [string]$ResultText
    )
    try {
        $dir = Get-KDRemoteScreenScriptDir
        $path = Join-Path $dir 'remote-screen-audit.log'
        $ts = Get-KDRemoteScreenNowIso
        $line = "$ts cmd=$Cmd args=$ArgsText done=$Done result=$ResultText"
        Add-Content -Path $path -Value $line -Encoding ascii -ErrorAction Stop
    }
    catch {
        # Audit must never break a command. Swallow silently.
    }
}

function Initialize-KDRemoteScreenApis {
    if ($script:KDRemoteScreenApisLoaded) { return }
    Add-Type -AssemblyName System.Drawing
    Add-Type -AssemblyName System.Windows.Forms
    $mouseCode = @'
using System;
using System.Runtime.InteropServices;
public static class KDRemoteMouse {
  [DllImport("user32.dll", SetLastError = true)]
  public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll", SetLastError = true)]
  public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
  public const uint MOUSEEVENTF_LEFTUP = 0x0004;
  public const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
  public const uint MOUSEEVENTF_RIGHTUP = 0x0010;
  public static void LeftClick() { mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero); mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero); }
  public static void RightClick() { mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, UIntPtr.Zero); mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, UIntPtr.Zero); }
}
'@
    Add-Type -TypeDefinition $mouseCode -Language CSharp
    $gdiCode = @'
using System;
using System.Runtime.InteropServices;
public static class KDRemoteGDI {
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern IntPtr CreateCompatibleDC(IntPtr hdc);
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int nWidth, int nHeight);
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern bool BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, uint dwRop);
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern bool DeleteObject(IntPtr hObject);
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern bool DeleteDC(IntPtr hdc);
  [DllImport("user32.dll", SetLastError = true)]
  public static extern IntPtr GetDC(IntPtr hWnd);
  [DllImport("user32.dll", SetLastError = true)]
  public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
  public const uint SRCCOPY = 0x00CC0020;
}
'@
    Add-Type -TypeDefinition $gdiCode -Language CSharp
    $script:KDRemoteScreenApisLoaded = $true
}

# ---------------------------------------------------------------- screenshot

function Invoke-CmdScreenshot {
    param($CmdObj)
    $auditArgs = 'screenshot'
    $bitmap = $null
    try {
        Initialize-KDRemoteScreenApis
        $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $origWidth = $bounds.Width
        $origHeight = $bounds.Height
        if ($origWidth -le 0 -or $origHeight -le 0) {
            throw 'primary screen has no usable bounds'
        }
        # v1.1: raw Win32 GDI BitBlt via P/Invoke (see the header
        # note). The old .NET screen-copy call tripped Defender's
        # Empire screenshot signature; this plain GDI path does the
        # same copy without that pattern.
        $hdcScreen = [IntPtr]::Zero
        $hdcMem = [IntPtr]::Zero
        $hbm = [IntPtr]::Zero
        $hOld = [IntPtr]::Zero
        try {
            $hdcScreen = [KDRemoteGDI]::GetDC([IntPtr]::Zero)
            if ($hdcScreen -eq [IntPtr]::Zero) { throw 'GetDC failed' }
            $hdcMem = [KDRemoteGDI]::CreateCompatibleDC($hdcScreen)
            if ($hdcMem -eq [IntPtr]::Zero) { throw 'CreateCompatibleDC failed' }
            $hbm = [KDRemoteGDI]::CreateCompatibleBitmap($hdcScreen, $origWidth, $origHeight)
            if ($hbm -eq [IntPtr]::Zero) { throw 'CreateCompatibleBitmap failed' }
            $hOld = [KDRemoteGDI]::SelectObject($hdcMem, $hbm)
            $copied = [KDRemoteGDI]::BitBlt($hdcMem, 0, 0, $origWidth, $origHeight, $hdcScreen, $bounds.Left, $bounds.Top, [KDRemoteGDI]::SRCCOPY)
            if (-not $copied) { throw 'BitBlt failed' }
            $bitmap = [System.Drawing.Bitmap]::FromHbitmap($hbm)
        }
        finally {
            if ($hOld -ne [IntPtr]::Zero -and $hdcMem -ne [IntPtr]::Zero) { [void][KDRemoteGDI]::SelectObject($hdcMem, $hOld) }
            if ($hbm -ne [IntPtr]::Zero) { [void][KDRemoteGDI]::DeleteObject($hbm) }
            if ($hdcMem -ne [IntPtr]::Zero) { [void][KDRemoteGDI]::DeleteDC($hdcMem) }
            if ($hdcScreen -ne [IntPtr]::Zero) { [void][KDRemoteGDI]::ReleaseDC([IntPtr]::Zero, $hdcScreen) }
        }
        $codec = $null
        foreach ($c in [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders()) {
            if ($c.MimeType -eq 'image/jpeg') { $codec = $c }
        }
        if ($null -eq $codec) {
            throw 'JPEG encoder not found'
        }
        $encoderParams = New-Object System.Drawing.Imaging.EncoderParameters(1)
        $encoderParams.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter(
            [System.Drawing.Imaging.Encoder]::Quality, [long]60)
        $maxBytes = 200 * 1024
        $scales = @(1.0, 0.5, 0.25, 0.125)
        $finalBytes = $null
        $finalWidth = $origWidth
        $finalHeight = $origHeight
        foreach ($scale in $scales) {
            $w = [int][Math]::Max(1, [Math]::Round($origWidth * $scale))
            $h = [int][Math]::Max(1, [Math]::Round($origHeight * $scale))
            $workBitmap = $bitmap
            $scaled = $null
            if ($scale -lt 1.0) {
                $scaled = New-Object System.Drawing.Bitmap($w, $h)
                $g2 = [System.Drawing.Graphics]::FromImage($scaled)
                try {
                    $g2.DrawImage($bitmap, 0, 0, $w, $h)
                }
                finally {
                    $g2.Dispose()
                }
                $workBitmap = $scaled
            }
            $stream = New-Object System.IO.MemoryStream
            try {
                $workBitmap.Save($stream, $codec, $encoderParams)
                $candidate = $stream.ToArray()
            }
            finally {
                $stream.Dispose()
                if ($null -ne $scaled) { $scaled.Dispose() }
            }
            $finalBytes = $candidate
            $finalWidth = $w
            $finalHeight = $h
            if ($candidate.Length -le $maxBytes) { break }
        }
        $encoderParams.Dispose()
        $bitmap.Dispose()
        $bitmap = $null
        $b64 = [System.Convert]::ToBase64String($finalBytes)
        $resultText = ("ok width={0} height={1} bytes={2}" -f $finalWidth, $finalHeight, $finalBytes.Length)
        Write-KDRemoteScreenAudit -Cmd 'screenshot' -ArgsText $auditArgs -Done $true -ResultText $resultText
        return @{
            width = $finalWidth
            height = $finalHeight
            bytes = $finalBytes.Length
            format = 'jpeg'
            image_b64 = $b64
        }
    }
    catch {
        if ($null -ne $bitmap) { $bitmap.Dispose() }
        $msg = $_.Exception.Message
        Write-KDRemoteScreenAudit -Cmd 'screenshot' -ArgsText $auditArgs -Done $false -ResultText ("error screenshot_failed detail={0}" -f $msg)
        return @{ error = 'screenshot_failed'; detail = $msg }
    }
}

# ---------------------------------------------------------------- mouse

function Invoke-CmdMouse {
    param($CmdObj)
    $xRaw = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'x'
    $yRaw = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'y'
    $action = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'action'
    $auditArgs = ("x={0} y={1} action={2}" -f $xRaw, $yRaw, $action)
    $x = 0
    $y = 0
    try { $x = [int]$xRaw } catch {
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText 'error bad_coords detail=x is not an integer'
        return @{ error = 'bad_coords'; detail = 'x is not an integer' }
    }
    try { $y = [int]$yRaw } catch {
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText 'error bad_coords detail=y is not an integer'
        return @{ error = 'bad_coords'; detail = 'y is not an integer' }
    }
    if ($action -isnot [string]) {
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText 'error bad_action detail=action is missing'
        return @{ error = 'bad_action'; detail = 'action is missing' }
    }
    if ($action -notin @('move', 'left_click', 'right_click', 'double_click')) {
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText ("error bad_action detail=unknown action: {0}" -f $action)
        return @{ error = 'bad_action'; detail = ("unknown action: {0}" -f $action) }
    }
    try {
        Initialize-KDRemoteScreenApis
        $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $left = $bounds.Left
        $top = $bounds.Top
        $right = $bounds.Left + $bounds.Width
        $bottom = $bounds.Top + $bounds.Height
        if ($x -lt $left -or $x -ge $right -or $y -lt $top -or $y -ge $bottom) {
            $detail = ("coords out of bounds: x={0} y={1} bounds left={2} top={3} width={4} height={5}" -f $x, $y, $left, $top, $bounds.Width, $bounds.Height)
            Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText ("error bad_coords detail={0}" -f $detail)
            return @{ error = 'bad_coords'; detail = $detail }
        }
        $moved = [KDRemoteMouse]::SetCursorPos($x, $y)
        if (-not $moved) {
            throw 'SetCursorPos failed'
        }
        Start-Sleep -Milliseconds 50
        if ($action -eq 'left_click') {
            [KDRemoteMouse]::LeftClick()
        }
        elseif ($action -eq 'right_click') {
            [KDRemoteMouse]::RightClick()
        }
        elseif ($action -eq 'double_click') {
            [KDRemoteMouse]::LeftClick()
            Start-Sleep -Milliseconds 80
            [KDRemoteMouse]::LeftClick()
        }
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $true -ResultText ("ok x={0} y={1} action={2}" -f $x, $y, $action)
        return @{ x = $x; y = $y; action = $action }
    }
    catch {
        $msg = $_.Exception.Message
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText ("error mouse_failed detail={0}" -f $msg)
        return @{ error = 'mouse_failed'; detail = $msg }
    }
}

# ---------------------------------------------------------------- type

function Invoke-CmdType {
    param($CmdObj)
    $text = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'text'
    if ($null -eq $text) {
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText 'chars=0 (text not logged)' -Done $false -ResultText 'error bad_text detail=text is missing'
        return @{ error = 'bad_text'; detail = 'text is missing' }
    }
    if ($text -isnot [string]) {
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText 'chars=0 (text not logged)' -Done $false -ResultText 'error bad_text detail=text is not a string'
        return @{ error = 'bad_text'; detail = 'text is not a string' }
    }
    $auditArgs = ("chars={0} (text not logged)" -f $text.Length)
    if ($text.Length -eq 0) {
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText 'error bad_text detail=text is empty'
        return @{ error = 'bad_text'; detail = 'text is empty' }
    }
    if ($text.Length -gt 1000) {
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText 'error bad_text detail=text exceeds 1000 chars'
        return @{ error = 'bad_text'; detail = 'text exceeds 1000 chars' }
    }
    foreach ($ch in $text.ToCharArray()) {
        if ([char]::IsControl($ch) -and $ch -ne "`n" -and $ch -ne "`r" -and $ch -ne "`t") {
            $detail = ("text contains a control character U+{0:X4}" -f [int]$ch)
            Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText ("error bad_text detail={0}" -f $detail)
            return @{ error = 'bad_text'; detail = $detail }
        }
    }
    try {
        Initialize-KDRemoteScreenApis
        $normalized = $text.Replace("`r`n", "`n").Replace("`r", "`n")
        $builder = New-Object System.Text.StringBuilder
        foreach ($ch in $normalized.ToCharArray()) {
            if ($ch -eq "`n") {
                [void]$builder.Append('{ENTER}')
            }
            elseif ($ch -eq "`t") {
                [void]$builder.Append('{TAB}')
            }
            elseif ($ch -eq '+' -or $ch -eq '^' -or $ch -eq '%' -or $ch -eq '~' -or $ch -eq '(' -or $ch -eq ')' -or $ch -eq '{' -or $ch -eq '}' -or $ch -eq '[' -or $ch -eq ']') {
                [void]$builder.Append('{')
                [void]$builder.Append($ch)
                [void]$builder.Append('}')
            }
            else {
                [void]$builder.Append($ch)
            }
        }
        [System.Windows.Forms.SendKeys]::SendWait($builder.ToString())
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $true -ResultText ("ok typed_chars={0}" -f $text.Length)
        return @{ typed_chars = $text.Length }
    }
    catch {
        $msg = $_.Exception.Message
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText ("error type_failed detail={0}" -f $msg)
        return @{ error = 'type_failed'; detail = $msg }
    }
}

# ---------------------------------------------------------------- dispatcher

function Invoke-KDRemoteScreenCommand {
    param($CmdObj)
    $name = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'cmd'
    $cmdId = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'id'
    if (-not $name -or $name -isnot [string]) {
        Write-KDRemoteScreenAudit -Cmd 'unknown' -ArgsText 'cmd missing' -Done $false -ResultText 'error unknown_cmd'
        return @{ id = $cmdId; done = $false; at = Get-KDRemoteScreenNowIso;
                  result = @{ error = 'unknown_cmd'; detail = "command has no 'cmd' string" } }
    }
    $result = $null
    switch ($name) {
        'screenshot' { $result = Invoke-CmdScreenshot $CmdObj }
        'mouse'      { $result = Invoke-CmdMouse $CmdObj }
        'type'       { $result = Invoke-CmdType $CmdObj }
        default {
            Write-KDRemoteScreenAudit -Cmd $name -ArgsText 'cmd unknown' -Done $false -ResultText 'error unknown_cmd'
            return @{ id = $cmdId; done = $false; at = Get-KDRemoteScreenNowIso;
                      result = @{ error = 'unknown_cmd'; detail = ("no such command: {0}" -f $name) } }
        }
    }
    if ($result -is [hashtable] -and $result.ContainsKey('error')) {
        return @{ id = $cmdId; done = $false; at = Get-KDRemoteScreenNowIso; result = $result }
    }
    if ($result -isnot [hashtable]) { $result = @{ value = $result } }
    return @{ id = $cmdId; done = $true; at = Get-KDRemoteScreenNowIso; result = $result }
}
