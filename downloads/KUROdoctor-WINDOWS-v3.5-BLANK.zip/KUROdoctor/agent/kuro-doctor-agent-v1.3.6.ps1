﻿#Requires -Version 5.1
<#
.SYNOPSIS
    KUROdoctor agent v1.3.6 - a doctor for devices (Windows edition).

.DESCRIPTION
    Runs on a sick Windows PC. On start it phones home to the KUROdoctor
    relay, sends a boot report (device model, disks, SMART summary, network
    state, plus the blind sweep below), then polls for commands from Muse
    and executes them exactly once.

    The doctor ALWAYS goes in blind: on first connect - before any
    command is polled and before the user is asked anything - the agent
    runs a full diagnostic sweep on its own (drive health, disk space,
    startup items, running processes, temperatures, pending updates,
    boot time, plus a background Windows Defender QuickScan) and puts
    the results in the boot report. The user's guess ("it's riddled
    with viruses") is optional context only, never the diagnosis.

    Plug-in first: the PC gets online by USB tethering from the owner's phone
    (see docs/phone-tether.md). The agent only ever makes OUTBOUND calls
    to the relay - no inbound ports, no VPN, no accounts, nothing to
    configure on the PC.

    No external modules, no admin rights required for the basic path.
    Admin WOULD help with: full SMART counters - Get-StorageReliabilityCounter
    returns fewer counters (and can fail outright) for a non-admin user on
    some machines; the agent reports smart_unavailable / per-disk errors
    instead of crashing. Reading the System event log (dmesg) also returns
    more entries as admin, but works as a normal user.

    v1.2 adds the exec command: run exactly one PowerShell command
    string received via the relay, with a timeout, a hard blocklist
    (see Test-ExecBlocked), and a full audit log line written BEFORE
    the command runs. See the COMMANDS table below.

    v1.2 also loads the separate screen-control file
    kuro-doctor-remote-screen-v1.3.4.ps1 from the agent directory when it is
    present (dot-sourced, guarded - the agent still runs if the file
    is absent) and registers its screenshot, mouse, and type commands.
    The screen commands themselves live in that file, not here.

    v1.2.1 (2026-11-19) - Defender AMSI fix. The v1.2 agent was blocked
    at parse time on a Windows 10 PC by Windows Defender AMSI ("This script
    contains malicious content and has been blocked by your antivirus
    software", ScriptContainedMaliciousContent, line 1 char 1) before
    anything ran. Nothing on the PC changed. Likely trigger, not
    proven: this file used to name credential-theft tooling in the
    Test-ExecBlocked pattern table and in comments. The reason is plain:
    naming those tools in the script trips Defender's scanner. Those
    names are gone from this file entirely.
    The credential-tool blocklist moved to the relay, which refuses such
    commands server-side before one ever reaches the agent (relay patch
    v2.1, worker 2's deliverable - not in this file). Everything else in
    Test-ExecBlocked is unchanged:
    format / wipe / diskpart, cipher with /w, deletes under Documents
    / Pictures / Desktop, lock-screen bypass, net user password
    changes, reboot / power-off, disk format / partition,
    boot-configuration editing, flashing / firmware tools.

    v1.3.0 (2026-11-19) - SPEED. The owner asked for faster work with
    full access. Three fixes, all verifiable:
    (1) Poll interval 3s -> 1s (the 60s heartbeat then in place was removed in v1.3.6; reporting is on-demand now).
    (2) Quiet duplicate logging: the "skipping duplicate command"
    line is now logged at most ONCE per command id (a $LoggedSkips
    set, cleared when a new command id arrives) - the live run's
    screenshot showed the window flooded with those lines.
    (3) ALWAYS ACK, and stay responsive during long jobs. Live bug
    2026-11-19: an exec with a 240s timeout NEVER acked - the loop
    kept skipping it as a duplicate while the job hung, and the
    single-attempt ack post meant one failed POST lost the result
    forever. exec / repair / deep now run ASYNC: the handler starts
    a background job, registers it in $PendingJobs, and returns
    IMMEDIATELY with a 'started' ack (done:true, status 'running').
    Every poll Invoke-CheckPendingJobs checks
    the pending jobs: a finished job posts a COMPLETION ack with the
    real result; a job past its timeout is stopped and posts a
    completion ack done:false with timed_out=true and any partial
    output - never silence, never a bare timeout with no ack. The
    relay stores only the latest ack, so the completion ack
    overwriting the 'started' ack is correct and expected. Ack
    delivery itself is retried (Invoke-PostAck: up to 3 attempts,
    2s apart, each failure logged) - a failed ack post must never
    silently drop a completed job's result. The SeenIds dedup is
    unchanged: the loop skipping a still-stored command id is
    correct behaviour - only the log spam was quieted.
    New commands: clean (named trash clearing only, synchronous),
    repair (one named repair from repair/repair-windows.ps1, async),
    deep (read-only hardware deep exam, async). See COMMANDS below.
    Also fixed: the boot report now carries agent_version = $Version
    alongside version (v1.2.1 sent agent_version empty).

    v1.3.1 (2026-11-19) - QUEUE, ACK HYGIENE, UNINSTALL, ADAPTIVE POLL.
    Live bugs from the v1.3.0 run on a Windows 10 PC, 2026-11-19:
    (1) ADAPTIVE POLLING: v1.3 polled every 1s = ~86,400
    Cloudflare requests/day at 24/7, too close to the 100k free cap.
    v1.3.1 polls 1s while ACTIVE (a command seen in the last 2 min
    or a job pending) and 10s when IDLE. (v1.3.6 removed the
    ~60s heartbeat: idle cost is now ~8,640 poll GETs/day
    plus one boot report, and no periodic KV writes.)
    (2) QUEUE + RECEIPT: the relay now holds a FIFO queue
    (doctor:queue, max 10) instead of one single-slot command.
    On GETting a new command id the agent FIRST posts
    POST /doctor/received {id} (retry once on failure; if it
    still fails, execution is SKIPPED this cycle and retried on
    the next poll - never execute a command whose receipt was not
    recorded, matching the Mac agent), then executes. The id is
    added to SeenIds only after a successful receipt. SeenIds
    dedup stays as a backstop. The old single-slot doctor:command
    key is RETIRED.
    (3) BLOCKLIST: 'format' matched as a substring and
    false-positived on "Information" (in-FORMAT-ion) - proven live,
    it blocked a Copilot cleanup exec. 'format' and 'wipe' are now
    whole-word patterns (\bformat\b, \bwipe\b): "Information"
    passes, "Format-Volume" is still refused. OWNER OVERRIDE: a
    relay-validated owner_override=true lifts ONLY the Desktop
    removal refusal, and only for a command that contains only
    Remove-Item / del / erase statements, where every path target
    ends in .lnk (case-insensitive), every path is under a Desktop
    folder (user or public), and the command contains no
    'Documents' / 'Pictures' / 'Downloads', no -Recurse, and no
    wildcards (* or ?). All other deletes stay refused. The
    override is an owner decision, not an agent one: the relay
    passes owner_override through only on exec, only as a boolean,
    and refuses it on any other command (400 bad_override).
    See Test-DesktopLnkOverride for the exact rule.
    (4) ACK HYGIENE: every ack string field is sanitized to ASCII
    before JSON (non-ASCII -> '?', control chars stripped except
    newline/tab/CR) and capped at 4096 chars, so a repair-module
    detail can never again poison an ack the way the v1.3.0 repair
    completion ack was lost (started ack OK 23:56:02Z, completion
    ack 400 at 23:56:05/07/09Z, id
    67602c40-7c8b-49d9-892a-4aa5400f1401). The likely cause - NOT
    proven, the exact ack bytes were never captured - is non-ASCII
    (em-dash) text from repair-windows.ps1 reaching the ack, which
    PowerShell 5.1 sends in the local ANSI code page and
    Cloudflare's UTF-8 JSON parser rejects. The module is now
    pure ASCII too; the two fixes together close it. Invoke-PostAck
    also gains a last-resort fallback: after 3 failed attempts it
    posts ONE minimal ack {id, done, at, result:
    {error: 'ack_content_rejected'}} so a result is never silently
    lost. And the Invoke-CheckPendingJobs array bug is fixed: the
    old `$out = @($out | Where-Object ... | Select-Object -Last 1)`
    re-wrapped the hashtable in an array, so the `-is [hashtable]`
    branch never matched; the result is now unwrapped to the
    single hashtable ($null if none).
    (5) DUPLICATE-SKIP: the `$script:LoggedSkips.Clear()` call on
    every new command id is REMOVED - it re-armed logging for old
    ids, so one id could log its skip more than once. The set now
    lives for the process lifetime; a skip still logs at most once
    per id.
    (6) UNINSTALL: new async command (see COMMANDS). A running
    target is refused cleanly with error 'target_running' - never
    delete under a running game (the SCP uninstall failed halfway
    on a locked bass.dll because the game was RUNNING).
    (7) REPAIR JOB: the restore-point-first law stands, but a job
    must never finish with no effect and no error - any
    restore-point failure returns status 'failed' / 'refused'
    with a loud detail, and the ack now arrives (ack hygiene).

    v1.3.2 (2026-11-20) - INSTALL, STEAM REGISTRY FIX.
    (1) INSTALL: new async command (see COMMANDS). kind:
    winget | msi | exe, mirroring uninstall's structure
    (same validation, audit-before-run, $PendingJobs async
    with started + completion acks, @{step; ok; detail}
    items). Precheck: already installed acks done with
    status 'ok' and detail 'already installed' and runs
    nothing (winget list for winget, the Uninstall registry
    for msi; exe has no reliable precheck and skips it).
    Verification after the run never trusts the installer
    exit code alone: winget list / Uninstall registry must
    confirm the install, and a failed verification is
    status 'failed' even when the installer exited 0.
    (2) STEAM UNINSTALL REGISTRY FIX: the steam branch
    deleted the game folder and the appmanifest but left
    the Programs-and-Features registry entry behind, so
    Windows still listed the game as installed. It now
    also removes the matching Uninstall key (HKLM Uninstall
    and the Wow6432Node twin, matched by "Steam App
    <appid>" or by DisplayName) and verifies the entry is
    gone by reading the key back - if it is still present,
    that step is failed. MSI and AppX paths are unchanged
    (they already do proper removals).

    v1.3.4 (2026-11-20) - TYPE FOCUS + LIVE FEED.
    (1) TYPE FOCUS: the type command accepts an optional
    `process` field (e.g. "notepad++") and focuses that
    window first (SetForegroundWindow, SW_RESTORE if minimised,
    AttachThreadInput fallback). With no identifier it focuses
    the current foreground window unless that is the agent's own
    console, else the most recently started process with a
    visible main window (excluding the agent PID and console
    hosts). If no window can be focused the command returns an
    error and types NOTHING - never type blind again. Text
    validation (<=1000 chars, control-char rules, SendKeys
    escaping) is unchanged. The mouse command stays as the
    click-then-type fallback.
    (2) LIVE FEED: the main loop calls Send-KDDoctorFrameTick
    (screen file) once per poll iteration. It captures on the
    same GDI BitBlt path and posts change-only frames to POST
    /doctor/frame - hard cap 1 post per 5 seconds, 60s liveness
    re-post. The agent reaches OUT only. The still-screenshot
    command is unchanged (ack image_b64 path as before). The
    screen file is now kuro-doctor-remote-screen-v1.3.4.ps1.

    v1.3.6 (2026-11-22) - ON-DEMAND REPORTING (heartbeat removed).
    REAL DEFECT, NOT A FEATURE: the relay died because Cloudflare
    KV free tier allows only 1,000 writes/day and the agent's
    60-second heartbeat (a KV PUT on every /doctor/report) alone
    is 1,440/day. POST /doctor/command then returned 1101 while
    reads still worked, and a relay redeploy did not fix it. The
    relay is unchanged; the agent is fixed.
    (1) NO PERIODIC HEARTBEAT: the main loop no longer sends a
    report every 60s. $HeartbeatIntervalSeconds and $lastHeartbeat
    are gone. The agent reports exactly once at boot (same
    /doctor/report endpoint, same payload) and then only when
    commanded: ping / sysinfo acks carry live status.
    (2) BOOT-RETRY RULE: if the boot report fails to deliver
    (Send-Report returns false), the loop retries it once per
    poll iteration ONLY until it first succeeds, then never
    again - no steady-state write is created. A failed retry
    while the relay is down costs a failed POST, never a KV
    write; once delivered the flag stays set for the process
    lifetime. --once mode does not retry (it exits after one
    poll).
    (3) JOB CHECKING IS UNCHANGED: Invoke-CheckPendingJobs
    already runs at the end of every Invoke-PollOnce, so
    removing the heartbeat block (which also called it) loses
    no completion checking. Poll intervals are unchanged
    (1s active / 10s idle). The Defender scan follow-up
    report is unchanged: it posts once, only when a scan
    finishes. The live-feed frame tick is unchanged: it
    writes to the Durable Object frame room, not KV.
    Idle cost is now ~8,640 poll GETs/day (reads, not KV
    writes) plus one boot report - down from ~10k requests
    including 1,440 KV writes/day.

    v1.3.5 (2026-11-22) - USB PHONE DOCTOR.
    (1) NEW COMMANDS phone_checkup and phone_repair (see COMMANDS).
    The phone plugs into the Windows PC over USB and the agent
    drives it with adb: plug in, tap Allow once on the phone
    ("Always allow from this computer"), then plug-and-go. No
    pairing sheet, no 6-digit code, no wireless debugging anywhere
    in this flow. phone_checkup reads model, Android version, SDK,
    storage, battery, RAM, and app count over adb shell.
    phone_repair maps clear_cache / disable / force_stop /
    uninstall to pm clear / pm disable-user / am force-stop /
    pm uninstall --user 0. Both commands are synchronous and
    every adb call has a timeout, so a wedged adb can never hang
    the poll loop. The package is re-validated in the agent
    (same regex and limits as the relay) and the protected set
    is refused here too, defense in depth.
    (2) ADB: the agent finds adb on PATH first, then the usual
    platform-tools spots (Android SDK, C:\platform-tools).
    No adb -> error adb_missing with the install hint; the
    SETUP.md USB phone section has the one-path install steps
    (platform-tools zip from Google, no admin needed).
    (3) TEST STATUS: the phone driver was executed under
    PowerShell 7.4.6 on Linux against a fake adb shim covering
    device / unauthorized / no-device / adb-missing and all
    four repair kinds plus protected-set and bad-package
    refusals (see build-1.3.1/v135/TEST-RESULTS.md). It has
    NOT run on real Windows against a real phone yet - the
    owner tests that on the real PC + phone. The rest of
    this file is unchanged from v1.3.4 except the version
    number; the screen file stays
    kuro-doctor-remote-screen-v1.3.4.ps1.


    NEEDS A REAL WINDOWS RUN - never executed on real Windows.
    PowerShell 7.4.6 was installed on the build VM for v1.3.5 and
    the USB phone driver alone was executed there against a fake
    adb shim (see build-1.3.1/v135/TEST-RESULTS.md). The full
    agent has never run on a real Windows host. Do not treat it
    as tested until it has run on a real Windows host.

    EXEC BLOCKLIST (summary - the authoritative agent-side list is the
    pattern table inside Test-ExecBlocked, which the coordinator can
    audit; the credential-tool rules now live at the relay instead -
    see the v1.2.1 note above):
    refused are disk format / wipe tools, diskpart, cipher with /w,
    deleting files under the user-profile Documents, Pictures, or
    Desktop folders (temp and cache paths are allowed), lock-screen
    bypass, password
    changes via the net user command, reboot and power-off commands,
    disk format / partition commands, boot configuration editing,
    and flashing / firmware tools. A refused exec command is acked
    done:false with error "blocked" and is never run. There is no
    reboot or power-off command anywhere in this file.

    Relay base URL comes from relay-config.json next to this script
    (key "relay_url"), or from the KURODOCTOR_RELAY environment
    variable if that is set. If neither is set, the agent prints a
    plain-language message and exits (exit code 2). There is no
    default relay and no fallback to any other owner's worker.

    Endpoints used:
        POST /doctor/report    boot report (once) + scan follow-up (once, when a scan finishes)
        GET  /doctor/command   poll for the next command (queue head)
        POST /doctor/received queue receipt (pop a command id)
        POST /doctor/ack      acknowledge a completed command

    Command JSON: {"cmd": ..., "id": ..., ...args}
    Ack JSON:     {"id": ..., "done": true|false, "at": ..., "result": {...}}

.USAGE
    Right-click -> Run with PowerShell, or from PowerShell:
        powershell -ExecutionPolicy Bypass -File .\kuro-doctor-agent.ps1
    Optional switches:
        -Once        one poll cycle, then exit
        -ReportOnly send the boot report, then exit
        -SweepOnly  run the blind sweep, print the JSON, then exit

.COMMANDS
    ping    no-op, ack done
    sysinfo host, OS, CPU, RAM, disks, network adapters
    smart   Get-PhysicalDisk + Get-StorageReliabilityCounter per disk;
            smart_unavailable if the storage cmdlets are missing
    df      disk space (Get-PSDrive / Get-Volume)
    ls      {"path": ...} directory listing
    cat     {"path": ...} file contents, base64; >100KB refused
    dmesg   last 100 lines of the System event log (Windows has no kernel
            ring buffer; the result says so)
    exec    {"command": ..., "timeout_s": ...} run one PowerShell
            command string; timeout_s optional, default 60, clamped
            to 1-300. ASYNC: the handler validates, audits, and
            blocklist-checks exactly as before, then starts a
            background job and returns IMMEDIATELY with a 'started'
            ack (done:true):
              { "command": <echo>, "started": true,
                "status": "running", "timed_out": false,
                "output": "" }
            When the job finishes (or times out), a COMPLETION ack
            is posted for the same id with the real result:
              { "command": <echo of command>, "exit_code": <int or
                null on timeout>, "timed_out": <bool>,
                "output": <string, stdout+stderr capped at 20KB> }
            Timeout completion ack is done:false with exit_code null,
            timed_out true, and any partial output. Refused by the
            blocklist -> ack done:false, result
            { "error": "blocked", "detail": ... } (synchronous, no
            job started). The full command text is written to the
            audit log (kuro-doctor-audit.log, next to this script)
            BEFORE it runs. Missing or non-string command ->
            error bad_command.
            owner_override (bool, exec only): when true AND the owner
            has explicitly allowed it, the Desktop .lnk removal
            refusal is lifted (see Test-DesktopLnkOverride). The
            relay passes it through only on exec, only as a boolean.
    screenshot
            no args. Lives in kuro-doctor-remote-screen-v1.3.4.ps1; the
            agent dot-sources that file when present and registers
            this command. Ack result:
              { "width": <int>, "height": <int>, "bytes": <int>,
                "format": "jpeg", "image_b64": <string> }
    mouse   {"x": ..., "y": ..., "action": "move"|"left_click"|
            "right_click"|"double_click"} absolute screen pixels.
            Lives in kuro-doctor-remote-screen-v1.3.4.ps1. Ack result:
              { "x": <int>, "y": <int>, "action": <string> }
            Out-of-bounds coords -> error bad_coords; unknown
            action -> error bad_action (both ack done:false).
    type    {"text": ...} plain text only, max 1000 chars. Lives in
            kuro-doctor-remote-screen-v1.3.4.ps1. Ack result:
              { "typed_chars": <int> }
            Control characters (other than newline/tab) or text over
            1000 chars -> error bad_text (ack done:false). Never
            type into a password or login field.
    clean   no args. Named trash clearing ONLY, synchronous (fast).
            Allowed locations, and ONLY these: the Recycle Bin
            (Clear-RecycleBin -Force), $env:TEMP contents,
            C:\Windows\Temp contents, C:\Windows\Prefetch contents,
            thumbnail cache ($env:LOCALAPPDATA\Microsoft\Windows\
            Explorer\thumbcache_*.db). Anything outside the list is
            refused; Documents / Pictures / Desktop / Downloads are
            never matched, and nothing is ever deleted by image or
            video extension. Measured before/after per location
            (file count + MB). Ack result:
              { "before_mb": <number>, "after_mb": <number>,
                "freed_mb": <number>,
                "items": { <location>:
                  { "before_mb": <number>, "after_mb": <number> } } }
            Audit-log lines before and after.
    repair  {"function": ..., "names": [...], "timeout_s": ...} run
            ONE named repair from repair/repair-windows.ps1, ASYNC
            via the same $PendingJobs machinery as exec (sfc takes
            minutes; the loop stays responsive). Function names:
            system_files -> Repair-SystemFiles, startup ->
            Clear-StartupItems, temp -> Clear-TempCaches,
            defender_scan -> Start-DefenderScan. The job dot-sources
            the repair module itself, FIRST creates a System Restore
            point (New-KuroRestorePoint -ConfirmGo), and stops with
            status 'refused' / detail 'restore point failed' if the
            restore point's status is not 'ok' (the module's success
            status from New-KuroResult). Then it runs the named
            function with -ConfirmGo (plus -Names for startup).
            Startup names validation (agent-side): names must be an
            array of strings, each 1-50 chars, NO wildcard
            characters (* or ?) - any violation refuses the whole
            command with error 'bad_names'; an empty names list is
            refused with 'bad_names' too. 'started' ack (done:true):
              { "function": <name>, "started": true,
                "status": "running", "timed_out": false,
                "output": "" }
            Completion ack result carries the repair's own fields:
              { "function": <name>, "repair": <name>,
                "status": <ok|failed|skipped|refused|timeout>,
                "before": <string>, "after": <string>,
                "detail": <string> }
            done is true only when status is 'ok'. Unknown function
            -> error bad_function. No reboot command anywhere.
    deep    no args (optional "timeout_s", default 1800, clamped
            60-3600). Hardware deep exam, READ-ONLY, ASYNC via
            $PendingJobs (fragmentation analysis can take minutes on
            a large HDD). One result hashtable with sections: smart
            (full counters per disk), disks (Get-PhysicalDisk +
            Get-Volume), fragmentation (Optimize-Volume -Analyze
            on C: FragmentationPercentage + DefragRecommended;
            failure tolerated with an error note - a defrag is
            NEVER attempted), battery (DesignCapacity,
            FullChargeCapacity, EstimatedChargeRemaining, Status),
            problem_devices (Status Error/Degraded/Unknown, top 20),
            dism (DISM /Online /Cleanup-Image /CheckHealth output,
            capped), event_errors (System + Application error
            counts, last 24h, grouped by provider, top 10 each),
            memory (total/free MB + free pct + top 10 processes by
            WorkingSet64), sysmain (status + start type), edge
            (process count + total RAM). Nothing in deep writes,
            deletes, or changes anything. 'started' ack like exec;
            completion ack carries the sections.
    uninstall {"kind": ..., "name": ..., "appid": ..., "timeout_s": ...}
            Remove one installed game/app, ASYNC via $PendingJobs
            (same shapes as repair). kind: steam | msi | appx.
            steam: delete steamapps\common\<name> and its
            appmanifest_<appid>.acf (manifests are scanned for the
            name when appid is absent); also remove the
            Programs-and-Features registry key (HKLM Uninstall
            and Wow6432Node twin, matched by "Steam App <appid>"
            or DisplayName) and verify it is gone. msi:
            Get-Package | Uninstall-Package -Force, winget fallback
            when Get-Package finds nothing; verify Get-Package is
            empty. appx: Get-AppxPackage | Remove-AppxPackage plus
            a Remove-AppxProvisionedPackage -Online attempt;
            verify Get-AppxPackage is empty. RUNNING-PROCESS
            PRECHECK FIRST: if the target is running, the command
            is refused cleanly with error 'target_running' and
            detail listing the process names - nothing is deleted.
            Completion ack result:
              { "kind": <kind>, "target": <name>,
                "status": <ok|failed|refused|timeout>,
                "detail": <string>,
                "items": [ { "step": ..., "ok": <bool>,
                             "detail": ... } ] }
            done is true only when status is 'ok'. Unknown kind ->
            error bad_kind; bad name/appid -> error bad_target.
            Other kinds (app, brew, flatpak, pacman) are relay
            allow-listed for the Mac/Linux agents; this Windows
            agent refuses them with bad_kind.
    install {"kind": ..., "name": ..., "path": ..., "url": ...,
             "args": ..., "timeout_s": ...}
            Install one game/app, ASYNC via $PendingJobs
            (same shapes as uninstall). kind: winget | msi | exe.
            winget installs by name; msi installs an .msi file
            (path or url); exe runs an .exe installer (path or
            url; optional "args" string, e.g. "/S" - without args
            the installer runs as-is and may show its wizard).
            At least one of name / path / url is required; name
            is 1-200 chars with no backslash, slash, or '..';
            path / url must end in .msi (msi) or .exe (exe) with
            no '..'. Winget needs a name; msi/exe need a path
            or url to the installer file. PRECHECK FIRST: if already installed
            (winget list for winget, the Uninstall registry for
            msi; exe has no reliable precheck and skips it) the
            command acks done with status 'ok' and detail
            'already installed' and runs nothing. NEVER trust
            exit codes alone: the job verifies the install
            afterward (winget list / Uninstall registry) and
            reports verified true/false; a failed verification
            is status 'failed' even when the installer exited 0.
            Completion ack result:
              { "kind": <kind>, "target": <name>,
                "status": <ok|failed|refused|timeout>,
                "verified": <bool>, "detail": <string>,
                "items": [ { "step": ..., "ok": <bool>,
                             "detail": ... } ] }
            done is true only when status is 'ok'. Unknown kind ->
            error bad_kind; bad name/path/url -> error bad_target.
    phone_checkup
            no args. USB phone checkup via adb (see the USB PHONE
            DRIVER section). The phone must be plugged in over USB
            with USB debugging on, and the "Allow USB debugging?"
            prompt allowed once (tick "Always allow from this
            computer"). Synchronous. Ack result:
              { "serial": <string>, "model": <string>,
                "android_version": <string>, "sdk": <int>,
                "storage_total_kb": <int>,
                "storage_available_kb": <int>,
                "battery_level": <int>, "charging": <bool>,
                "battery_temp_c": <number>,
                "ram_total_kb": <int>, "ram_available_kb": <int>,
                "app_count": <int> }
            No adb -> error adb_missing (with the install hint);
            no phone -> error no_device; phone not allowed yet ->
            error unauthorized ("tap Allow on the phone").
    phone_repair
            {"kind": ..., "package": ...} Android repair on the
            phone over USB via adb shell pm / am. kind:
            clear_cache -> pm clear <pkg>; disable ->
            pm disable-user --user 0 <pkg>; force_stop ->
            am force-stop <pkg>; uninstall ->
            pm uninstall --user 0 <pkg>. Package must match
            ^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)+$ (1-200
            chars) and must not be in the protected set
            (com.kuro.kurodoctor, android, com.android.systemui,
            com.android.phone, com.android.settings,
            com.android.packageinstaller, com.google.android.gms,
            com.google.android.gsf) - protected -> error
            protected_package. Before/after state (installed,
            disabled) is read back with pm path and
            pm list packages -d and reported in the ack.
            A failed pm command -> error repair_failed with
            the pm detail. Synchronous. Never touches
            documents or photos: these four pm/am commands
            cannot delete user files.
    Unknown cmd -> ack done:false, error unknown_cmd.
    Any result carrying an "error" key is acked done:false, so a
    refusal (bad_path, file_too_large, blocked, bad_coords,
    bad_action, bad_text, ...) is reported as not done while the
    agent stays healthy.
#>

param(
    [switch]$Once,
    [switch]$ReportOnly,
    [switch]$SweepOnly
)

$Version                  = "1.3.6"
$PollIntervalSeconds      = 1
$IdlePollIntervalSeconds  = 10
$CatMaxBytes              = 100 * 1024  # 100 KB cap on cat
$ExecMaxOutputBytes = 20 * 1024  # 20 KB cap on exec output (stdout+stderr)
$ExecDefaultTimeoutSeconds = 60  # default exec timeout in seconds
$ExecMaxTimeoutSeconds = 300  # exec timeout clamp: 1-300 s
$ScanTimeoutSeconds       = 1800        # 30 min max for the background Defender scan

$script:SweepCache    = $null   # the blind sweep, run once on first connect
$script:ScanJob       = $null   # background Defender QuickScan job
$script:ScanStartedAt = $null
$script:ScanResult    = $null   # set once the scan finishes (delivered once)

# v1.3.1 BLANK variant: the relay URL is NOT hardcoded. It comes from
# relay-config.json next to this script (key "relay_url"), or from the
# KURODOCTOR_RELAY environment variable. If neither is set, the agent
# prints a plain-language message and exits cleanly (exit code 2).
# There is no default relay and no fallback to any other owner's worker.
$Relay = $env:KURODOCTOR_RELAY
if ([string]::IsNullOrWhiteSpace($Relay)) {
    $ConfigPath = Join-Path $PSScriptRoot 'relay-config.json'
    if (Test-Path -LiteralPath $ConfigPath) {
        try {
            $Config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
            if ($null -ne $Config.relay_url) { $Relay = "$($Config.relay_url)".Trim() }
        } catch {
            Write-Host "KUROdoctor: relay-config.json could not be read ($($_.Exception.Message))."
        }
    }
}
if ([string]::IsNullOrWhiteSpace($Relay)) {
    Write-Host 'KUROdoctor: no relay URL is set.'
    Write-Host 'Open relay-config.json next to this script and put your own Cloudflare Worker URL in relay_url,'
    Write-Host 'for example: https://kurodoctor.<your-subdomain>.workers.dev'
    Write-Host 'Then run the launcher again. See SETUP.md for the full steps.'
    exit 2
}
$Relay = $Relay.TrimEnd('/')

$BootId    = [guid]::NewGuid().ToString()
$StartTime = Get-Date
$script:LastCommandAt = $StartTime  # last time a command id was seen (adaptive polling)
$SeenIds   = New-Object System.Collections.Generic.HashSet[string]

$script:PendingJobs = @{}   # command id -> pending async job (exec / repair / deep); see Invoke-CheckPendingJobs
$script:LoggedSkips = New-Object System.Collections.Generic.HashSet[string]  # duplicate-skip ids already logged once

# ---------------------------------------------------------------- logging

function Write-Log {
    param([string]$Message)
    $ts = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
    Write-Host "[$ts] $Message"
}

function Get-NowIso {
    return (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
}

# ---------------------------------------------------------------- audit log
# The exec audit log lives next to this script (kuro-doctor-audit.log).
# Every exec attempt - allowed or refused - is written there in full
# BEFORE the command runs. Audit failure never breaks a command.

function Get-ScriptDir {
    if ($PSScriptRoot) { return $PSScriptRoot }
    return (Get-Location).Path
}

function Write-AuditLog {
    param([string]$Message)
    try {
        $path = Join-Path (Get-ScriptDir) 'kuro-doctor-audit.log'
        $ts = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
        Add-Content -Path $path -Value "[$ts] $Message" -Encoding ascii -ErrorAction Stop
    }
    catch {
        # Audit must never break a command. Swallow silently.
    }
}

# ---------------------------------------------------------------- screen control
# Deliverable 2 (SCREEN CONTROL) lives in a separate file,
# kuro-doctor-remote-screen-v1.3.4.ps1, in this same directory. Dot-source it
# when present so the agent can register its screenshot, mouse, and
# type commands. Guarded: if the file is absent or fails to load, the
# agent logs it and keeps running without screen commands.

$script:RemoteScreenLoaded = $false
try {
    $screenPath = Join-Path (Get-ScriptDir) 'kuro-doctor-remote-screen-v1.3.4.ps1'
    if (Test-Path -LiteralPath $screenPath) {
        . $screenPath
        $script:RemoteScreenLoaded = $true
        Write-Log 'remote screen file loaded (screenshot, mouse, type, live feed available)'
    }
    else {
        Write-Log 'remote screen file not present - running without screen commands'
    }
}
catch {
    Write-Log "remote screen file failed to load: $($_.Exception.Message)"
}

# ---------------------------------------------------------------- relay I/O

function Invoke-RelayPost {
    param(
        [string]$Path,
        [hashtable]$Payload
    )
    $url  = $Relay + $Path
    $body = $Payload | ConvertTo-Json -Depth 10 -Compress
    try {
        $resp = Invoke-RestMethod -Uri $url -Method Post -Body $body `
            -ContentType 'application/json' `
            -Headers @{ 'User-Agent' = "KUROdoctor/$Version" } -TimeoutSec 10
        return $resp
    }
    catch {
        Write-Log "relay POST $Path failed: $($_.Exception.Message)"
        return $null
    }
}

function Invoke-RelayGet {
    param([string]$Path)
    $url = $Relay + $Path
    try {
        $resp = Invoke-RestMethod -Uri $url -Method Get `
            -Headers @{ 'User-Agent' = "KUROdoctor/$Version" } -TimeoutSec 10
        return $resp
    }
    catch {
        Write-Log "relay GET $Path failed: $($_.Exception.Message)"
        return $null
    }
}

# ---------------------------------------------------------------- async jobs
# v1.3.0 - ALWAYS ACK. exec / repair / deep / uninstall / install run as background jobs so
# the poll loop stays responsive during long jobs (an exec with a 240s
# timeout used to block the loop and NEVER ack). A handler starts its
# job, registers it in $PendingJobs, and returns IMMEDIATELY with a
# 'started' ack (done:true, status 'running'). Invoke-CheckPendingJobs
# runs every poll iteration: a finished job posts
# a COMPLETION ack with the real result; a job past its timeout is
# stopped and posts a completion ack done:false with timed_out=true
# and any partial output - never silence, never a bare timeout with
# no ack. The relay stores only the latest ack, so the completion ack
# overwriting the 'started' ack is correct and expected.
# Ack delivery itself is retried: Invoke-PostAck tries up to 3 times,
# 2s apart, logging each failure. A failed ack post must never
# silently drop a completed job's result.
# $PendingJobs entries: @{ Job; Id; Kind ('exec'|'repair'|'deep'|'uninstall'|'install');
#   Command; Function; Target; Names; StartedAt; TimeoutS }

# ---------------------------------------------------------------- ack hygiene
# v1.3.1 ACK HYGIENE. Every ack string field is sanitized to ASCII
# before JSON: non-ASCII chars become '?', control chars are
# stripped except newline/tab/CR, and each string field is capped
# at 4096 chars (appending '... [truncated]'). Base64 payloads
# (screenshot image_b64, cat content) are pure ASCII already and
# must NOT be capped - truncating one corrupts it. This closes the
# v1.3.0 live bug where a repair completion ack was rejected by
# the relay with 400 three times and the result was lost; the
# likely cause (NOT proven - the exact ack bytes were never
# captured) is non-ASCII text from the repair module reaching the
# ack, which PowerShell 5.1 sends in the local ANSI code page and
# Cloudflare's UTF-8 JSON parser rejects.

function ConvertTo-AckSafeValue {
    param($Value, [string]$Key = '')
    if ($null -eq $Value) { return $null }
    if ($Value -is [string]) {
        if ($Key -eq 'image_b64' -or $Key -eq 'content') { return $Value }
        $chars = @()
        foreach ($ch in $Value.ToCharArray()) {
            $code = [int]$ch
            if ($code -gt 127) { $chars += '?' }
            elseif ($code -lt 32 -and $ch -ne "`n" -and $ch -ne "`r" -and $ch -ne "`t") { continue }
            else { $chars += $ch }
        }
        $clean = -join $chars
        if ($clean.Length -gt 4096) { $clean = $clean.Substring(0, 4096) + '... [truncated]' }
        return $clean
    }
    if ($Value -is [hashtable]) {
        $out = @{}
        foreach ($k in $Value.Keys) { $out[$k] = ConvertTo-AckSafeValue -Value $Value[$k] -Key "$k" }
        return $out
    }
    if ($Value -is [System.Array]) {
        $out = @()
        foreach ($item in $Value) { $out += ConvertTo-AckSafeValue -Value $item -Key $Key }
        return $out
    }
    if ($Value -is [pscustomobject]) {
        $out = @{}
        foreach ($prop in $Value.PSObject.Properties) { $out[$prop.Name] = ConvertTo-AckSafeValue -Value $prop.Value -Key $prop.Name }
        return $out
    }
    return $Value
}

function Invoke-PostAck {
    param([hashtable]$Ack)
    $safeAck = ConvertTo-AckSafeValue -Value $Ack
    if ($safeAck -isnot [hashtable]) { $safeAck = $Ack }
    $attempt = 0
    $delivered = $false
    while ($attempt -lt 3) {
        $attempt++
        $result = Invoke-RelayPost -Path '/doctor/ack' -Payload $safeAck
        if ($null -ne $result) {
            Write-Log "acked id=$($safeAck.id) done=$($safeAck.done) (attempt $attempt)"
            $delivered = $true
            break
        }
        Write-Log "ack for id=$($safeAck.id) NOT delivered (attempt $attempt of 3)"
        if ($attempt -lt 3) { Start-Sleep -Seconds 2 }
    }
    if ($delivered) { return $true }
    # Last resort (v1.3.1): after 3 failed attempts, post ONE minimal
    # ack so the result is never silently lost. If even the relay
    # cannot take a minimal ack, the failure is logged and the
    # command id is on the record in the audit log.
    Write-Log "ack for id=$($safeAck.id) FAILED after 3 attempts - posting minimal fallback ack"
    try {
        $fallback = @{ id = $safeAck.id; done = $safeAck.done; at = Get-NowIso;
                       result = @{ error = 'ack_content_rejected' } }
        $fb = Invoke-RelayPost -Path '/doctor/ack' -Payload $fallback
        if ($null -ne $fb) {
            Write-Log "minimal fallback ack delivered for id=$($safeAck.id)"
            return $true
        }
    }
    catch { }
    Write-Log "minimal fallback ack also FAILED for id=$($safeAck.id) - the result may be lost at the relay"
    return $false
}


function Register-PendingJob {
    param([hashtable]$Entry)
    $key = $Entry.Id
    if ($script:PendingJobs.ContainsKey($key)) {
        # Same id already pending (should not happen - ids are unique
        # per command). Stop and drop the stale job, never leak it.
        $old = $script:PendingJobs[$key]
        if ($null -ne $old.Job) {
            Stop-Job -Job $old.Job -ErrorAction SilentlyContinue
            Remove-Job -Job $old.Job -Force -ErrorAction SilentlyContinue
        }
    }
    $script:PendingJobs[$key] = $Entry
}

function Invoke-CheckPendingJobs {
    if ($script:PendingJobs.Count -eq 0) { return }
    $finishedIds = @()
    foreach ($id in @($script:PendingJobs.Keys)) {
        $entry = $script:PendingJobs[$id]
        $job = $entry.Job
        if ($null -eq $job) { $finishedIds += $id; continue }
        $elapsedS = ((Get-Date) - $entry.StartedAt).TotalSeconds
        if ($job.State -eq 'Completed') {
            $out = Receive-Job -Job $job -ErrorAction SilentlyContinue
            Remove-Job -Job $job -ErrorAction SilentlyContinue
            $finishedIds += $id
            if ($out -is [System.Array]) {
                # v1.3.1 fix: NO @() wrapper here. The old
                # `$out = @($out | ... | Select-Object -Last 1)`
                # re-wrapped the hashtable in an array, so the
                # `-is [hashtable]` branch below never matched and
                # every completed job looked result-less. Unwrap to
                # the single hashtable ($null if none).
                $out = $out | Where-Object { $_ -is [hashtable] } | Select-Object -Last 1
            }
            $ack = $null
            if ($entry.Kind -eq 'exec') {
                $exitCode = 0
                $output = ''
                if ($out -is [hashtable]) {
                    if ($null -ne $out.output) { $output = "$($out.output)" }
                    if ($null -ne $out.exit_code) { $exitCode = [int]$out.exit_code }
                }
                if ($output.Length -gt $ExecMaxOutputBytes) {
                    $output = $output.Substring(0, $ExecMaxOutputBytes)
                }
                Write-AuditLog ("exec id={0} done timed_out={1} exit_code={2} output_chars={3}" -f $id, $false, $exitCode, $output.Length)
                $ack = @{ id = $id; done = $true; at = Get-NowIso;
                          result = @{ command = $entry.Command; exit_code = $exitCode;
                                      timed_out = $false; output = $output } }
            }
            elseif ($entry.Kind -eq 'repair') {
                $status = 'failed'; $before = ''; $after = ''; $detail = ''
                if ($out -is [hashtable]) {
                    if ($null -ne $out.status) { $status = "$($out.status)" }
                    if ($null -ne $out.before) { $before = "$($out.before)" }
                    if ($null -ne $out.after) { $after = "$($out.after)" }
                    if ($null -ne $out.detail) { $detail = "$($out.detail)" }
                }
                elseif ($null -ne $out) {
                    $detail = "$out"
                }
                Write-AuditLog ("repair id={0} function={1} done status={2}" -f $id, $entry.Function, $status)
                $ack = @{ id = $id; done = ($status -eq 'ok'); at = Get-NowIso;
                          result = @{ function = $entry.Function; repair = $entry.Target;
                                      status = $status; before = $before;
                                      after = $after; detail = $detail } }
            }
            elseif ($entry.Kind -eq 'uninstall') {
                $status = 'failed'; $kind = ''; $target = ''; $detail = ''; $items = @()
                $errCode = $null
                if ($out -is [hashtable]) {
                    if ($null -ne $out.status) { $status = "$($out.status)" }
                    if ($null -ne $out.kind) { $kind = "$($out.kind)" }
                    if ($null -ne $out.target) { $target = "$($out.target)" }
                    if ($null -ne $out.detail) { $detail = "$($out.detail)" }
                    if ($null -ne $out.items) { $items = @($out.items) }
                    if ($null -ne $out.error) { $errCode = "$($out.error)" }
                }
                elseif ($null -ne $out) {
                    $detail = "$out"
                }
                Write-AuditLog ("uninstall id={0} kind={1} target={2} done status={3}" -f $id, $kind, $target, $status)
                $resultHash = @{ kind = $kind; target = $target; status = $status; detail = $detail; items = $items }
                if ($null -ne $errCode) { $resultHash['error'] = $errCode }
                $ack = @{ id = $id; done = ($status -eq 'ok'); at = Get-NowIso; result = $resultHash }
            }
            elseif ($entry.Kind -eq 'install') {
                $status = 'failed'; $kind = ''; $target = ''; $detail = ''; $items = @()
                $verified = $false; $errCode = $null
                if ($out -is [hashtable]) {
                    if ($null -ne $out.status) { $status = "$($out.status)" }
                    if ($null -ne $out.kind) { $kind = "$($out.kind)" }
                    if ($null -ne $out.target) { $target = "$($out.target)" }
                    if ($null -ne $out.detail) { $detail = "$($out.detail)" }
                    if ($null -ne $out.items) { $items = @($out.items) }
                    if ($null -ne $out.verified) { $verified = [bool]$out.verified }
                    if ($null -ne $out.error) { $errCode = "$($out.error)" }
                }
                elseif ($null -ne $out) {
                    $detail = "$out"
                }
                Write-AuditLog ("install id={0} kind={1} target={2} done status={3} verified={4}" -f $id, $kind, $target, $status, $verified)
                $resultHash = @{ kind = $kind; target = $target; status = $status; verified = $verified; detail = $detail; items = $items }
                if ($null -ne $errCode) { $resultHash['error'] = $errCode }
                $ack = @{ id = $id; done = ($status -eq 'ok'); at = Get-NowIso; result = $resultHash }
            }
            elseif ($entry.Kind -eq 'deep') {
                if ($out -is [hashtable]) {
                    $result = $out
                }
                else {
                    $result = @{ status = 'failed'; detail = 'deep exam job completed but returned no result' }
                }
                Write-AuditLog ("deep id={0} done status={1}" -f $id, $result.status)
                $ack = @{ id = $id; done = ($result.status -ne 'failed'); at = Get-NowIso; result = $result }
            }
            if ($null -ne $ack) { [void](Invoke-PostAck -Ack $ack) }
        }
        elseif ($job.State -eq 'Failed') {
            $errText = ''
            try {
                if ($null -ne $job.JobStateInfo.Reason) {
                    $errText = "$($job.JobStateInfo.Reason.Message)"
                }
            }
            catch { }
            if (-not $errText) { $errText = 'background job failed' }
            Remove-Job -Job $job -ErrorAction SilentlyContinue
            $finishedIds += $id
            if ($entry.Kind -eq 'exec') {
                Write-AuditLog ("exec id={0} done timed_out={1} exit_code={2} output_chars={3}" -f $id, $false, $null, 0)
                $ack = @{ id = $id; done = $false; at = Get-NowIso;
                          result = @{ command = $entry.Command; exit_code = $null;
                                      timed_out = $false; output = $errText } }
            }
            elseif ($entry.Kind -eq 'repair') {
                $ack = @{ id = $id; done = $false; at = Get-NowIso;
                          result = @{ function = $entry.Function; repair = $entry.Target;
                                      status = 'failed'; before = ''; after = '';
                                      detail = $errText } }
            }
            elseif ($entry.Kind -eq 'uninstall') {
                $ack = @{ id = $id; done = $false; at = Get-NowIso;
                          result = @{ kind = $entry.Function; target = $entry.Target;
                                      status = 'failed'; detail = $errText; items = @() } }
            }
            elseif ($entry.Kind -eq 'install') {
                $ack = @{ id = $id; done = $false; at = Get-NowIso;
                          result = @{ kind = $entry.Function; target = $entry.Target;
                                      status = 'failed'; verified = $false; detail = $errText; items = @() } }
            }
            else {
                $ack = @{ id = $id; done = $false; at = Get-NowIso;
                          result = @{ status = 'failed'; detail = $errText } }
            }
            [void](Invoke-PostAck -Ack $ack)
        }
        elseif ($job.State -eq 'Running' -and $elapsedS -gt $entry.TimeoutS) {
            # Timed out: stop it, take any partial output, remove it,
            # and ALWAYS ack - never silence, never a bare timeout.
            Stop-Job -Job $job -ErrorAction SilentlyContinue
            $partial = $null
            try {
                $partial = Receive-Job -Job $job -ErrorAction SilentlyContinue
            }
            catch { }
            Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
            $finishedIds += $id
            if ($entry.Kind -eq 'exec') {
                $partialText = ''
                if ($partial -is [hashtable] -and $null -ne $partial.output) {
                    $partialText = "$($partial.output)"
                }
                if ($partialText.Length -gt $ExecMaxOutputBytes) {
                    $partialText = $partialText.Substring(0, $ExecMaxOutputBytes)
                }
                Write-AuditLog ("exec id={0} done timed_out={1} exit_code={2} output_chars={3}" -f $id, $true, $null, $partialText.Length)
                $ack = @{ id = $id; done = $false; at = Get-NowIso;
                          result = @{ command = $entry.Command; exit_code = $null;
                                      timed_out = $true; output = $partialText } }
            }
            elseif ($entry.Kind -eq 'repair') {
                $ack = @{ id = $id; done = $false; at = Get-NowIso;
                          result = @{ function = $entry.Function; repair = $entry.Target;
                                      status = 'timeout'; before = ''; after = '';
                                      detail = "repair timed out after $($entry.TimeoutS)s" } }
            }
            elseif ($entry.Kind -eq 'uninstall') {
                $ack = @{ id = $id; done = $false; at = Get-NowIso;
                          result = @{ kind = $entry.Function; target = $entry.Target;
                                      status = 'timeout'; timed_out = $true;
                                      detail = "uninstall timed out after $($entry.TimeoutS)s"; items = @() } }
            }
            elseif ($entry.Kind -eq 'install') {
                $ack = @{ id = $id; done = $false; at = Get-NowIso;
                          result = @{ kind = $entry.Function; target = $entry.Target;
                                      status = 'timeout'; timed_out = $true; verified = $false;
                                      detail = "install timed out after $($entry.TimeoutS)s"; items = @() } }
            }
            else {
                $ack = @{ id = $id; done = $false; at = Get-NowIso;
                          result = @{ status = 'timeout'; timed_out = $true;
                                      detail = "deep exam timed out after $($entry.TimeoutS)s" } }
            }
            [void](Invoke-PostAck -Ack $ack)
        }
    }
    foreach ($id in $finishedIds) { $script:PendingJobs.Remove($id) }
}

# ---------------------------------------------------------------- device info

function Get-DeviceModel {
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        $model = "$($cs.Manufacturer) $($cs.Model)".Trim()
        if ($model) { return $model }
    }
    catch { }
    return $env:COMPUTERNAME
}

function Get-DiskList {
    $disks = @()
    try {
        $physical = Get-PhysicalDisk -ErrorAction Stop
        foreach ($d in $physical) {
            $disks += [string]$d.FriendlyName
        }
        if ($disks.Count -gt 0) { return $disks }
    }
    catch { }
    try {
        $volumes = Get-Volume -ErrorAction Stop | Where-Object { $_.DriveLetter }
        foreach ($v in $volumes) {
            $disks += "$($v.DriveLetter):"
        }
    }
    catch { }
    return $disks
}

function Get-NetworkState {
    $adapters = @()
    try {
        $nets = Get-NetAdapter -ErrorAction Stop
        foreach ($a in $nets) {
            $adapters += @{
                name       = $a.Name
                status     = $a.Status.ToString()
                mac        = $a.MacAddress
                link_speed = $a.LinkSpeed
            }
        }
    }
    catch { }
    $addresses = @()
    try {
        $ips = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object { $_.IPAddress -ne '127.0.0.1' }
        foreach ($ip in $ips) {
            $addresses += $ip.IPAddress
        }
    }
    catch { }
    return @{
        hostname   = $env:COMPUTERNAME
        adapters   = $adapters
        addresses  = $addresses
    }
}

function Get-SmartSummary {
    # Get-PhysicalDisk / Get-StorageReliabilityCounter are built into
    # Windows 8+ / Server 2012+. No smartctl needed on Windows.
    try {
        $physical = Get-PhysicalDisk -ErrorAction Stop
    }
    catch {
        return @{
            status  = 'smart_unavailable'
            summary = 'Get-PhysicalDisk is not available on this machine, so drive health could not be read.'
        }
    }
    if (-not $physical -or $physical.Count -eq 0) {
        return @{ status = 'no_disks'; summary = 'No disks found to check.' }
    }
    $results = @()
    foreach ($d in $physical) {
        $entry = @{
            disk        = $d.FriendlyName
            device_id   = "$($d.DeviceId)"
            model       = $d.Model
            serial      = $d.SerialNumber
            media_type  = $d.MediaType.ToString()
            health      = $d.HealthStatus.ToString()
            size_gb     = [math]::Round($d.Size / 1GB, 2)
        }
        try {
            # Full counters may need admin on some machines; a failure here
            # is per-disk, never fatal to the agent.
            $counter = Get-StorageReliabilityCounter -PhysicalDisk $d -ErrorAction Stop
            $entry['temperature_c']     = $counter.Temperature
            $entry['power_on_hours']    = $counter.PowerOnHours
            $entry['read_errors']       = $counter.ReadErrorsTotal
            $entry['write_errors']      = $counter.WriteErrorsTotal
            $entry['wear_pct']          = $counter.Wear
        }
        catch {
            $entry['counter_error'] = $_.Exception.Message
        }
        $results += $entry
    }
    $bad = @($results | Where-Object { $_.health -eq 'Unhealthy' })
    if ($bad.Count -gt 0) {
        $summary = 'WARNING: SMART reports a failing drive: ' +
            (($bad | ForEach-Object { $_.disk }) -join ', ')
    }
    else {
        $summary = 'SMART: ' +
            (($results | ForEach-Object { "$($_.disk) $($_.health)" }) -join ', ')
    }
    return @{ status = 'ok'; summary = $summary; disks = $results }
}

function Get-DiskSpace {
    $mounts = @()
    try {
        $drives = Get-PSDrive -PSProvider FileSystem -ErrorAction Stop |
            Where-Object { $null -ne $_.Used -and $null -ne $_.Free }
        foreach ($d in $drives) {
            $total = $d.Used + $d.Free
            $pct = 0
            if ($total -gt 0) { $pct = [math]::Round($d.Used / $total * 100, 1) }
            $mounts += @{
                mount   = $d.Root
                size_kb = [math]::Round($total / 1KB)
                used_kb = [math]::Round($d.Used / 1KB)
                avail_kb = [math]::Round($d.Free / 1KB)
                use_pct = $pct
            }
        }
        if ($mounts.Count -gt 0) { return @{ filesystems = $mounts } }
    }
    catch { }
    # Fallback: Get-Volume
    try {
        $volumes = Get-Volume -ErrorAction Stop |
            Where-Object { $_.DriveLetter -and $_.Size -gt 0 }
        foreach ($v in $volumes) {
            $used = $v.Size - $v.SizeRemaining
            $pct = 0
            if ($v.Size -gt 0) { $pct = [math]::Round($used / $v.Size * 100, 1) }
            $mounts += @{
                mount    = "$($v.DriveLetter):\"
                size_kb  = [math]::Round($v.Size / 1KB)
                used_kb  = [math]::Round($used / 1KB)
                avail_kb = [math]::Round($v.SizeRemaining / 1KB)
                use_pct  = $pct
            }
        }
    }
    catch {
        return @{ error = $_.Exception.Message }
    }
    return @{ filesystems = $mounts }
}

# ---------------------------------------------------------------- blind sweep
# The doctor ALWAYS goes in blind. On first connect - before any command
# is polled and before the user is asked anything - the agent runs a full
# diagnostic sweep on its own and reports what IT finds. The user's guess
# ("it's riddled with viruses") is optional context only, never the
# diagnosis. Fast sections run synchronously and go in the boot report;
# the Defender QuickScan is slow, so it runs as a background job and its
# result arrives later as a follow-up POST /doctor/report with
# kind "sweep-scan-result". Every section is independent: one that cannot
# run reports @{ status = 'unavailable'; reason = ... } and never blocks
# the others or the boot report.

$SweepVersion = 1

function Get-SweepSmart {
    # Drive health (SMART) - reuses Get-SmartSummary, normalised.
    $s = Get-SmartSummary
    if ($s.status -ne 'ok') {
        return @{ status = 'unavailable'; reason = $s.summary }
    }
    return @{ status = 'ok'; summary = $s.summary; disks = $s.disks }
}

function Get-SweepDiskSpace {
    # Disk space per mount, normalised to GB mounts with use_pct.
    $df = Get-DiskSpace
    if ($df.error) {
        return @{ status = 'unavailable'; reason = $df.error }
    }
    $mounts = @()
    foreach ($fs in $df.filesystems) {
        $totalGb = [math]::Round($fs.size_kb / 1MB, 2)
        $usedGb  = [math]::Round($fs.used_kb / 1MB, 2)
        $freeGb  = [math]::Round($fs.avail_kb / 1MB, 2)
        $pct = 0
        if ($totalGb -gt 0) { $pct = [math]::Round($usedGb / $totalGb * 100, 1) }
        $mounts += @{
            mount    = $fs.mount
            total_gb = $totalGb
            used_gb  = $usedGb
            free_gb  = $freeGb
            use_pct  = $pct
        }
    }
    return @{ status = 'ok'; mounts = $mounts }
}

function Get-SweepStartupItems {
    # Startup items: Win32_StartupCommand + the Run / RunOnce keys.
    $items = @()
    $sawSource = $false
    try {
        $cmds = Get-CimInstance Win32_StartupCommand -ErrorAction Stop
        $sawSource = $true
        foreach ($c in $cmds) {
            $items += @{ name = $c.Name; command = $c.Command;
                         source = 'Win32_StartupCommand' }
        }
    }
    catch { }
    foreach ($root in @(
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
            'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce',
            'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce')) {
        try {
            $key = Get-Item -Path $root -ErrorAction Stop
            $sawSource = $true
            foreach ($prop in $key.Property) {
                $items += @{ name = $prop; command = "$($key.GetValue($prop))";
                             source = $root }
            }
        }
        catch { }
    }
    if (-not $sawSource) {
        return @{ status = 'unavailable';
                  reason = 'Win32_StartupCommand and the Run registry keys could not be read' }
    }
    return @{ status = 'ok'; count = $items.Count;
             items = @($items | Select-Object -First 50) }
}

function Get-SweepProcesses {
    # Process count + top 10 by CPU and by memory.
    # cpu_pct is an instantaneous % from the performance counters; if
    # that read fails, top_cpu falls back to total CPU seconds (cpu_s)
    # and cpu_pct is $null.
    try {
        $procs = @(Get-Process -ErrorAction Stop)
    }
    catch {
        return @{ status = 'unavailable'; reason = $_.Exception.Message }
    }
    if ($procs.Count -eq 0) {
        return @{ status = 'ok'; count = 0; top_cpu = @(); top_memory = @() }
    }
    $cpuByPid = @{}
    $counterOk = $false
    try {
        $cpuSamples = Get-Counter '\Process(*)\% Processor Time' -ErrorAction Stop
        $idSamples  = Get-Counter '\Process(*)\ID Process' -ErrorAction Stop
        $ids = @{}
        foreach ($s in $idSamples.CounterSamples) {
            $ids[$s.InstanceName] = [int]$s.CookedValue
        }
        foreach ($s in $cpuSamples.CounterSamples) {
            # NB: never name this $pid - $PID is PowerShell's own
            # read-only automatic variable (current process id) and
            # assigning to it throws.
            $procId = $ids[$s.InstanceName]
            if ($null -ne $procId) {
                $cpuByPid[$procId] = [math]::Round($s.CookedValue, 1)
            }
        }
        $counterOk = $true
    }
    catch { }
    $entries = @()
    foreach ($p in $procs) {
        $cpuPct = $null
        if ($counterOk -and $cpuByPid.ContainsKey($p.Id)) {
            $cpuPct = $cpuByPid[$p.Id]
        }
        $entries += @{
            pid    = $p.Id
            name   = $p.ProcessName
            cpu_pct = $cpuPct
            cpu_s  = [math]::Round($p.CPU, 1)
            mem_mb = [math]::Round($p.WorkingSet64 / 1MB, 1)
        }
    }
    if ($counterOk) {
        $topCpu = @($entries | Sort-Object cpu_pct -Descending |
            Select-Object -First 10)
    }
    else {
        $topCpu = @($entries | Sort-Object cpu_s -Descending |
            Select-Object -First 10)
    }
    $topMem = @($entries | Sort-Object mem_mb -Descending |
        Select-Object -First 10)
    return @{ status = 'ok'; count = $procs.Count;
             top_cpu = $topCpu; top_memory = $topMem }
}

function Get-SweepTemps {
    # Temperatures: WMI thermal zone if available, else unavailable.
    $sensors = @()
    try {
        $zones = Get-CimInstance -Namespace root/wmi `
            -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop
        foreach ($z in $zones) {
            # WMI reports tenths of Kelvin: (K - 273.2) = Celsius.
            $c = [math]::Round(($z.CurrentTemperature - 2732) / 10.0, 1)
            $sensors += @{ name = $z.InstanceName; temp_c = $c }
        }
    }
    catch { }
    if ($sensors.Count -eq 0) {
        return @{ status = 'unavailable';
                  reason = 'no WMI thermal zone (MSAcpi_ThermalZoneTemperature) data on this machine' }
    }
    return @{ status = 'ok'; sensors = $sensors }
}

function Get-SweepPendingUpdates {
    # Pending updates: Windows Update history + pending-reboot check.
    # History only - nothing is installed or downloaded by this check.
    $pendingReboot = $false
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') {
        $pendingReboot = $true
    }
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') {
        $pendingReboot = $true
    }
    try {
        $pfro = Get-ItemProperty `
            'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' `
            -Name PendingFileRenameOperations -ErrorAction Stop
        if ($pfro.PendingFileRenameOperations) { $pendingReboot = $true }
    }
    catch { }
    $count = 0
    $last = $null
    try {
        $fixes = @(Get-CimInstance Win32_QuickFixEngineering -ErrorAction Stop)
        $count = $fixes.Count
        $dates = @($fixes | Where-Object { $_.InstalledOn } | ForEach-Object {
            try { ([datetime]$_.InstalledOn).ToString('yyyy-MM-dd') }
            catch { "$($_.InstalledOn)" }
        } | Sort-Object -Descending)
        if ($dates.Count -gt 0) { $last = $dates[0] }
    }
    catch { }
    return @{ status = 'ok'; pending_reboot = $pendingReboot;
             updates_installed = $count; last_update = $last;
             note = 'history only - nothing was installed or downloaded by this check' }
}

function Get-SweepBootTime {
    # Uptime always; last boot duration from Diagnostics-Performance
    # event 100 if the log is readable.
    $uptimeS = 0
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $uptimeS = [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalSeconds)
    }
    catch { }
    $section = @{ status = 'ok'; uptime_s = $uptimeS }
    try {
        $ev = Get-WinEvent -FilterHashtable @{
            LogName = 'Microsoft-Windows-Diagnostics-Performance/Operational'
            Id = 100 } -MaxEvents 1 -ErrorAction Stop
        $xml = $ev.ToXml()
        # <Data Name="BootDuration">12345</Data> - milliseconds.
        if ($xml -match 'BootDuration">([0-9]+)<') {
            $section['last_boot_s'] = [math]::Round([double]$Matches[1] / 1000, 1)
            $section['last_boot_source'] = 'Diagnostics-Performance event 100'
        }
    }
    catch { }
    return $section
}

function Get-SweepMalwareScan {
    param($ProcessesSection)
    # Malware scan section of the boot report. Windows Defender only:
    # status via Get-MpComputerStatus, actual scan via Start-MpScan
    # QuickScan in a background job. The boot report carries status
    # "pending"; the result arrives later as a follow-up report
    # (see Test-ScanFollowup). If Defender is absent or off, the
    # section is unavailable and carries a process-anomaly note instead
    # - the running-processes section is the fallback evidence.
    $note = 'no scanner installed; rely on the processes section'
    if ($ProcessesSection -and $ProcessesSection.status -eq 'ok') {
        $note += " - $($ProcessesSection.count) processes running"
        if ($ProcessesSection.top_cpu -and $ProcessesSection.top_cpu.Count -gt 0) {
            $note += ", top CPU: $($ProcessesSection.top_cpu[0].name)"
        }
    }
    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
    }
    catch {
        return @{ status = 'unavailable'; scanner = 'Windows Defender';
                  reason = 'scanner_unavailable: Get-MpComputerStatus failed - Windows Defender is absent or not accessible';
                  process_anomaly_note = $note }
    }
    $threatsKnown = 0
    try { $threatsKnown = @(Get-MpThreat -ErrorAction Stop).Count } catch { }
    if (-not $mp.AntivirusEnabled) {
        return @{ status = 'unavailable'; scanner = 'Windows Defender';
                  reason = 'Windows Defender is present but antivirus is disabled';
                  process_anomaly_note = $note }
    }
    if ($null -eq $script:ScanJob) {
        $script:ScanJob = Start-Job -ScriptBlock {
            $t0 = Get-Date
            Start-MpScan -ScanType QuickScan
            $threats = @(Get-MpThreat -ErrorAction SilentlyContinue |
                ForEach-Object {
                    @{ name = $_.ThreatName
                       severity = "$($_.SeverityID)"
                       category = "$($_.CategoryID)"
                       detected = "$($_.InitialDetectionTime)" }
                })
            @{ threats_found = $threats.Count
               threats = $threats
               duration_s = [math]::Round(((Get-Date) - $t0).TotalSeconds, 1) }
        }
        $script:ScanStartedAt = Get-Date
    }
    return @{ status = 'pending'; scanner = 'Windows Defender';
             scan_type = 'QuickScan';
             antivirus_enabled = [bool]$mp.AntivirusEnabled;
             real_time_protection = [bool]$mp.RealTimeProtectionEnabled;
             quick_scan_age_days = $mp.QuickScanAge;
             threats_known = $threatsKnown;
             note = 'QuickScan started in the background; result arrives as a follow-up report (kind sweep-scan-result)' }
}

function Invoke-BlindSweep {
    # Run the blind sweep: the doctor diagnoses on its own, first thing
    # on connect, before any command is polled and before the user is
    # asked anything. Every section is independent - a section that
    # cannot run reports unavailable and never blocks the others or the
    # boot report.
    $processes = Get-SweepProcesses
    return @{
        sweep_version   = $SweepVersion
        smart           = Get-SweepSmart
        disk_space      = Get-SweepDiskSpace
        startup_items   = Get-SweepStartupItems
        processes       = $processes
        temps           = Get-SweepTemps
        pending_updates = Get-SweepPendingUpdates
        boot_time       = Get-SweepBootTime
        malware_scan    = Get-SweepMalwareScan -ProcessesSection $processes
    }
}

function Get-Sweep {
    # The cached blind sweep - run once on first connect, reused by
    # every later report (boot retry, scan follow-up) so the sweep never re-runs.
    if ($null -eq $script:SweepCache) { $script:SweepCache = Invoke-BlindSweep }
    return $script:SweepCache
}

function Send-ScanFollowup {
    # Post the finished malware scan as a follow-up report
    # (kind "sweep-scan-result") and update the cached sweep so later
    # later reports show the outcome.
    $payload = @{
        agent    = 'kuro-doctor'
        version  = $Version
        agent_version = $Version
        kind     = 'sweep-scan-result'
        boot_id  = $BootId
        hostname = $env:COMPUTERNAME
        at       = Get-NowIso
        sweep    = @{ malware_scan = $script:ScanResult }
    }
    if ($null -ne $script:SweepCache) {
        $script:SweepCache['malware_scan'] = $script:ScanResult
    }
    Write-Log ("malware scan finished: status={0} threats={1}" -f `
        $script:ScanResult.status, $script:ScanResult.threats_found)
    $result = Invoke-RelayPost -Path '/doctor/report' -Payload $payload
    if ($null -eq $result) {
        Write-Log 'scan follow-up report NOT delivered (relay unreachable)'
    }
    else {
        Write-Log 'scan follow-up report delivered'
    }
}

function Test-ScanFollowup {
    # If the background Defender scan finished (or failed / timed out),
    # post its follow-up report. Delivers exactly once.
    if ($null -eq $script:ScanJob) { return }
    if ($null -ne $script:ScanResult) { return }  # already delivered
    $job = $script:ScanJob
    if ($job.State -eq 'Completed') {
        $out = Receive-Job -Job $job -ErrorAction SilentlyContinue
        Remove-Job -Job $job -ErrorAction SilentlyContinue
        if ($out -is [hashtable]) {
            $script:ScanResult = @{
                status = 'ok'; scanner = 'Windows Defender';
                scan_type = 'QuickScan';
                threats_found = $out.threats_found;
                threats = $out.threats; duration_s = $out.duration_s }
        }
        else {
            $script:ScanResult = @{ status = 'unavailable';
                scanner = 'Windows Defender';
                reason = 'scan job completed but returned no result' }
        }
        Send-ScanFollowup
    }
    elseif ($job.State -eq 'Failed') {
        Remove-Job -Job $job -ErrorAction SilentlyContinue
        $script:ScanResult = @{ status = 'unavailable';
            scanner = 'Windows Defender'; reason = 'scan job failed' }
        Send-ScanFollowup
    }
    elseif ($job.State -eq 'Running' -and $null -ne $script:ScanStartedAt -and
            ((Get-Date) - $script:ScanStartedAt).TotalSeconds -gt $ScanTimeoutSeconds) {
        Stop-Job -Job $job -ErrorAction SilentlyContinue
        Remove-Job -Job $job -ErrorAction SilentlyContinue
        $script:ScanResult = @{ status = 'unavailable';
            scanner = 'Windows Defender';
            reason = "scan timed out after ${ScanTimeoutSeconds}s" }
        Send-ScanFollowup
    }
}

function New-Report {
    # The blind sweep runs here, on first connect, before any command is
    # polled - its results ride in the boot report. Later reports
    # reuse the cached sweep (Get-Sweep), so the sweep never re-runs.
    $os = $null
    try { $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch { }
    $osString = 'Windows'
    $kernel   = ''
    if ($os) {
        $osString = "$($os.Caption) $($os.Version)".Trim()
        $kernel   = "$($os.Version) Build $($os.BuildNumber)"
    }
    return @{
        agent    = 'kuro-doctor'
        version  = $Version
        agent_version = $Version
        boot_id  = $BootId
        uptime_s = [math]::Round(((Get-Date) - $StartTime).TotalSeconds)
        at       = Get-NowIso
        device  = @{
            model    = Get-DeviceModel
            hostname = $env:COMPUTERNAME
            os       = $osString
            kernel   = $kernel
            arch     = $env:PROCESSOR_ARCHITECTURE
        }
        disks      = Get-DiskList
        disk_space = Get-DiskSpace
        smart      = Get-SmartSummary
        network    = Get-NetworkState
        sweep      = Get-Sweep
    }
}

function Send-Report {
    $report = New-Report
    Write-Log ("sending report: model={0} disks={1} smart={2}" -f `
        $report.device.model, ($report.disks -join ', '), $report.smart.status)
    $result = Invoke-RelayPost -Path '/doctor/report' -Payload $report
    if ($null -eq $result) {
        Write-Log 'report NOT delivered (relay unreachable)'
        return $false
    }
    Write-Log 'report delivered'
    return $true
}

# ---------------------------------------------------------------- commands

function Invoke-CmdPing {
    param($CmdObj)
    return @{ pong = $true }
}

function Invoke-CmdSysinfo {
    param($CmdObj)
    # Get-ComputerInfo returns this same WMI data but is slow to enumerate;
    # the agent reads the underlying CIM classes directly.
    $os  = $null
    $cpu = $null
    try { $os  = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch { }
    try { $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop |
                 Select-Object -First 1 } catch { }
    $memTotalKb = $null
    $memFreeKb  = $null
    $uptimeS    = 0
    if ($os) {
        $memTotalKb = $os.TotalVisibleMemorySize
        $memFreeKb  = $os.FreePhysicalMemory
        $uptimeS    = [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalSeconds)
    }
    $cpuName  = 'unknown'
    $cpuCount = 0
    if ($cpu) {
        $cpuName  = $cpu.Name
        $cpuCount = $cpu.NumberOfCores
    }
    $ramTotalMb = $null
    $ramFreeMb  = $null
    if ($null -ne $memTotalKb) { $ramTotalMb = [math]::Round($memTotalKb / 1KB) }
    if ($null -ne $memFreeKb)  { $ramFreeMb  = [math]::Round($memFreeKb / 1KB) }
    $kernelString = ''
    $osString     = 'Windows'
    if ($os) {
        $kernelString = "$($os.Version) Build $($os.BuildNumber)"
        $osString     = "$($os.Caption) $($os.Version)".Trim()
    }
    return @{
        hostname     = $env:COMPUTERNAME
        kernel       = $kernelString
        os           = $osString
        cpu          = @{ model = $cpuName; count = $cpuCount }
        mem_total_kb = $memTotalKb
        mem_free_kb  = $memFreeKb
        ram_mb       = @{ total = $ramTotalMb; available = $ramFreeMb }
        uptime_s     = $uptimeS
        disks        = Get-DiskList
        network      = Get-NetworkState
    }
}

function Invoke-CmdSmart {
    param($CmdObj)
    $summary = Get-SmartSummary
    $device = $CmdObj.device
    if ($device -and $summary.disks) {
        $match = @($summary.disks | Where-Object {
            $_.disk -eq $device -or $_.device_id -eq "$device" -or $_.model -eq $device
        })
        if ($match.Count -eq 0) {
            return @{ error = 'bad_device'; detail = "no such disk: $device" }
        }
        $summary.disks = $match
    }
    return $summary
}

function Invoke-CmdDf {
    param($CmdObj)
    return Get-DiskSpace
}

function Invoke-CmdLs {
    param($CmdObj)
    $path = $CmdObj.path
    if (-not $path -or $path -isnot [string]) {
        # Windows default: root of the current drive.
        $path = '\'
    }
    if (-not (Test-Path -LiteralPath $path -PathType Container)) {
        return @{ error = 'bad_path'; detail = "not a directory: $path" }
    }
    try {
        $entries = @()
        foreach ($item in (Get-ChildItem -LiteralPath $path -Force -ErrorAction Stop)) {
            $kind = 'file'
            if ($item.PSIsContainer) { $kind = 'dir' }
            elseif ($item.LinkType)  { $kind = 'link' }
            $size = $null
            if (-not $item.PSIsContainer) { $size = $item.Length }
            $entries += @{ name = $item.Name; type = $kind; size = $size }
        }
        return @{ path = $path; entries = $entries }
    }
    catch {
        return @{ error = 'bad_path'; detail = $_.Exception.Message }
    }
}

function Invoke-CmdCat {
    param($CmdObj)
    $path = $CmdObj.path
    if (-not $path -or $path -isnot [string]) {
        return @{ error = 'bad_path'; detail = "cat needs a string 'path'" }
    }
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        if (Test-Path -LiteralPath $path -PathType Container) {
            return @{ error = 'bad_path'; detail = "not a file: $path" }
        }
        return @{ error = 'bad_path'; detail = "no such file: $path" }
    }
    try {
        $info = Get-Item -LiteralPath $path -ErrorAction Stop
        $size = $info.Length
    }
    catch {
        return @{ error = 'bad_path'; detail = $_.Exception.Message }
    }
    if ($size -gt $CatMaxBytes) {
        return @{ error = 'file_too_large';
                  detail = "$path is $size bytes, over the $CatMaxBytes-byte limit" }
    }
    try {
        $bytes = [System.IO.File]::ReadAllBytes($path)
        return @{ path = $path; size = $size; encoding = 'base64';
                  content = [Convert]::ToBase64String($bytes) }
    }
    catch [System.UnauthorizedAccessException] {
        return @{ error = 'permission_denied'; detail = $_.Exception.Message }
    }
    catch {
        return @{ error = 'bad_path'; detail = $_.Exception.Message }
    }
}

function Invoke-CmdDmesg {
    param($CmdObj)
    # Windows has no kernel ring buffer. Closest equivalent: the System
    # event log, newest first - return its last N lines.
    $lines = 100
    if ($CmdObj.lines) {
        try { $lines = [int]$CmdObj.lines } catch { $lines = 100 }
    }
    if ($lines -lt 1)   { $lines = 1 }
    if ($lines -gt 500) { $lines = 500 }
    $allLines = @()
    try {
        $events = Get-WinEvent -LogName System -MaxEvents $lines -ErrorAction Stop
        foreach ($ev in $events) {
            $stamp = $ev.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss')
            $text  = "$stamp [$($ev.LevelDisplayName)] $($ev.Id) $($ev.Message)"
            $allLines += ($text -split '\r?\n')
        }
    }
    catch {
        # Fallback for older hosts: Get-EventLog.
        try {
            $events = Get-EventLog -LogName System -Newest $lines -ErrorAction Stop
            foreach ($ev in $events) {
                $stamp = $ev.TimeGenerated.ToString('yyyy-MM-dd HH:mm:ss')
                $text  = "$stamp [$($ev.EntryType)] $($ev.EventID) $($ev.Message)"
                $allLines += ($text -split '\r?\n')
            }
        }
        catch {
            return @{ error = 'dmesg_unavailable'; detail = $_.Exception.Message }
        }
    }
    $tail = @($allLines | Select-Object -Last $lines)
    return @{
        lines  = $tail
        total_lines = $allLines.Count
        source = 'System event log (Windows has no kernel ring buffer; these are the last lines of the System event log)'
    }
}

# ---------------------------------------------------------------- exec blocklist
# Test-ExecBlocked is the authoritative exec blocklist. It returns $null
# when a command string is allowed, or a short reason string naming the
# matched rule when it must be refused. Matching is case-insensitive
# (PowerShell -match is case-insensitive by default). The coordinator
# can audit the blocklist by reading this one pattern table.
#   - disk format / wipe tools, diskpart, cipher with /w
#     ('format' / 'wipe' match as WHOLE WORDS only - v1.3.1:
#     "Information" must pass, "Format-Volume" must still refuse)
#   - Remove-Item / del / rm aimed at the user-profile Documents,
#     Pictures, or Desktop folders (temp / cache paths are allowed).
#     v1.3.1 owner override: with owner_override=true the Desktop
#     refusal is lifted ONLY for Desktop .lnk cleanup (see
#     Test-DesktopLnkOverride); Documents / Pictures stay refused.
#   - named credential-theft tooling (enforced at the relay now, not
#     here - see the v1.2.1 note in the file header)
#   - lock-screen bypass
#   - password changes via the net user command
#   - reboot / power-off commands, disk format / partition commands,
#     boot configuration editing, flashing / firmware tools
# NOTE: the reboot / power-off / disk-format cmdlet names in the table
# below appear ONLY in this function. No such command exists anywhere
# else in this file, and exec can never run one - the blocklist
# refuses it before anything runs.

function Test-DesktopLnkOverride {
    # v1.3.1 OWNER OVERRIDE (Desktop .lnk cleanup only). Returns $true
    # ONLY when every condition holds:
    #   - the command contains only Remove-Item / del / erase
    #     statements (split on ';' / newlines; no pipelines)
    #   - every path target ends in .lnk (case-insensitive)
    #   - every path is under a Desktop folder (user or public)
    #   - the command contains no 'Documents' / 'Pictures' /
    #     'Downloads', no -Recurse, and no wildcards (* or ?)
    # Anything else returns $false and the normal Desktop refusal
    # stands. All other deletes stay refused. This is an owner
    # decision carried by the relay (owner_override, exec only);
    # the agent never grants it on its own.
    param([string]$CommandText)
    if ([string]::IsNullOrWhiteSpace($CommandText)) { return $false }
    if ($CommandText -match '(?i)documents|pictures|downloads') { return $false }
    if ($CommandText -match '(?i)-recurse') { return $false }
    if ($CommandText -match '[*?]') { return $false }
    if ($CommandText -match '\|') { return $false }
    $statements = @($CommandText -split '[;\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
    if ($statements.Count -eq 0) { return $false }
    $paths = @()
    foreach ($st in $statements) {
        if ($st -notmatch '^(?i)(remove-item|del|erase)\b') { return $false }
        foreach ($m in [regex]::Matches($st, '"([^"]+)"')) { $paths += $m.Groups[1].Value }
        foreach ($m in [regex]::Matches($st, "'([^']+)'")) { $paths += $m.Groups[1].Value }
        foreach ($m in [regex]::Matches($st, '(?i)(?:-path|-literalpath)\s+([^\s;]+)')) { $paths += $m.Groups[1].Value }
        foreach ($tok in ($st -split '\s+')) {
            if ($tok -match '(?i)\.lnk$') { $paths += $tok }
        }
    }
    if ($paths.Count -eq 0) { return $false }
    foreach ($p in $paths) {
        if ($p -notmatch '(?i)\.lnk$') { return $false }
        if ($p -notmatch '(?i)desktop[\\/]') { return $false }
    }
    return $true
}

function Test-ExecBlocked {
    param([string]$CommandText, [bool]$OwnerOverride = $false)
    if ([string]::IsNullOrWhiteSpace($CommandText)) { return $null }
    $rules = @(
        @{ Pattern = '\bformat\b'; Reason = 'blocked: disk format / wipe tool' }
        @{ Pattern = '\bwipe\b'; Reason = 'blocked: wipe tool' }
        @{ Pattern = 'diskpart'; Reason = 'blocked: diskpart' }
        @{ Pattern = 'cipher\b[^\r\n]*/w'; Reason = 'blocked: cipher with /w (secure wipe)' }
        @{ Pattern = 'credential harvesting'; Reason = 'blocked: credential harvesting' }
        @{ Pattern = 'dump[^\r\n]*\bsam\b'; Reason = 'blocked: dumping SAM' }
        @{ Pattern = '\bsam\b[^\r\n]*dump'; Reason = 'blocked: dumping SAM' }
        @{ Pattern = 'config\\sam'; Reason = 'blocked: dumping SAM hive' }
        @{ Pattern = 'config\\system'; Reason = 'blocked: dumping SYSTEM hive' }
        @{ Pattern = 'lock.?screen[^\r\n]*bypass'; Reason = 'blocked: lock-screen bypass' }
        @{ Pattern = 'bypass[^\r\n]*lock.?screen'; Reason = 'blocked: lock-screen bypass' }
        @{ Pattern = 'net\s+user\s+\S+\s+\S+'; Reason = 'blocked: net user password change' }
        @{ Pattern = '\bshutdown\b'; Reason = 'blocked: shutdown' }
        @{ Pattern = 'restart-computer'; Reason = 'blocked: reboot (Restart-Computer)' }
        @{ Pattern = 'stop-computer'; Reason = 'blocked: shutdown (Stop-Computer)' }
        @{ Pattern = 'format-volume'; Reason = 'blocked: disk format (Format-Volume)' }
        @{ Pattern = 'clear-disk'; Reason = 'blocked: disk wipe (Clear-Disk)' }
        @{ Pattern = 'remove-partition'; Reason = 'blocked: disk partition removal (Remove-Partition)' }
        @{ Pattern = 'bcdedit'; Reason = 'blocked: boot configuration editing (bcdedit)' }
        @{ Pattern = 'flashrom'; Reason = 'blocked: flashing / firmware tool (flashrom)' }
        @{ Pattern = 'flash[^\r\n]*firmware'; Reason = 'blocked: flashing / firmware tool' }
        @{ Pattern = 'firmware[^\r\n]*flash'; Reason = 'blocked: flashing / firmware tool' }
        @{ Pattern = 'bios[^\r\n]*flash'; Reason = 'blocked: flashing / firmware tool (BIOS flash)' }
        @{ Pattern = 'uefi[^\r\n]*flash'; Reason = 'blocked: flashing / firmware tool (UEFI flash)' }
    )
    foreach ($rule in $rules) {
        if ($CommandText -match $rule.Pattern) { return $rule.Reason }
    }
    # Removal commands aimed at user-profile folders. Temp / cache
    # paths are allowed; only Documents, Pictures, or Desktop under
    # the user profile are refused.
    if ($CommandText -match '\b(remove-item|del|delete|rm|erase)\b') {
        if ($CommandText -match 'documents|pictures|desktop') {
            if ($OwnerOverride -and (Test-DesktopLnkOverride -CommandText $CommandText)) {
                # Owner override: Desktop .lnk cleanup only. Every
                # other rule above has already run, and this is the
                # last check in the function, so lifting this one
                # refusal here cannot lift any other.
                return $null
            }
            return 'blocked: deletion under user-profile Documents, Pictures, or Desktop'
        }
    }
    return $null
}

function Invoke-CmdExec {
    param($CmdObj)
    $command = $CmdObj.command
    if (-not $command -or $command -isnot [string]) {
        return @{ error = 'bad_command'; detail = "exec needs a string 'command'" }
    }
    if ([string]::IsNullOrWhiteSpace($command)) {
        return @{ error = 'bad_command'; detail = "exec needs a non-empty string 'command'" }
    }
    $timeoutS = $ExecDefaultTimeoutSeconds
    if ($null -ne $CmdObj.timeout_s) {
        try { $timeoutS = [int]$CmdObj.timeout_s } catch { $timeoutS = $ExecDefaultTimeoutSeconds }
    }
    if ($timeoutS -lt 1) { $timeoutS = 1 }
    if ($timeoutS -gt $ExecMaxTimeoutSeconds) { $timeoutS = $ExecMaxTimeoutSeconds }
    $cmdId = $CmdObj.id
    # Audit FIRST: the full command text goes to the audit log BEFORE
    # the blocklist check and BEFORE anything runs, so a refused
    # command is on the record too.
    $ownerOverride = $false
    if ($null -ne $CmdObj.owner_override -and $CmdObj.owner_override -is [bool]) {
        $ownerOverride = $CmdObj.owner_override
    }
    Write-AuditLog ("exec id={0} timeout_s={1} owner_override={2} command={3}" -f $cmdId, $timeoutS, $ownerOverride, $command)
    Write-Log ("exec requested (id={0} timeout_s={1} owner_override={2})" -f $cmdId, $timeoutS, $ownerOverride)
    $blocked = Test-ExecBlocked -CommandText $command -OwnerOverride $ownerOverride
    if ($null -ne $blocked) {
        Write-Log ("exec refused (id={0}): {1}" -f $cmdId, $blocked)
        Write-AuditLog ("exec id={0} refused: {1}" -f $cmdId, $blocked)
        return @{ error = 'blocked'; detail = $blocked }
    }
    # v1.3.0 ASYNC: start the job and return IMMEDIATELY. The poll
    # loop stays responsive and the completion ack is posted by
    # Invoke-CheckPendingJobs when the job finishes or times out.
    # The job ScriptBlock keeps the v1.2.1 shape (Invoke-Expression
    # $cmd 2>&1 | Out-String, LASTEXITCODE capture, try/catch
    # returning @{ output; exit_code }).
    try {
        $job = Start-Job -ScriptBlock {
            param($cmd)
            $text = ''
            $code = 0
            try {
                $captured = Invoke-Expression $cmd 2>&1 | Out-String
                if ($null -ne $captured) { $text = $captured }
                if ($null -ne $LASTEXITCODE) { $code = [int]$LASTEXITCODE }
            }
            catch {
                $text = $_.Exception.Message
                $code = 1
            }
            @{ output = $text; exit_code = $code }
        } -ArgumentList $command
    }
    catch {
        Write-Log ("exec failed to start (id={0}): {1}" -f $cmdId, $_.Exception.Message)
        return @{ error = 'exec_failed'; detail = $_.Exception.Message }
    }
    Register-PendingJob -Entry @{
        Job = $job; Id = "$cmdId"; Kind = 'exec'; Command = $command;
        Function = ''; Target = ''; Names = @();
        StartedAt = (Get-Date); TimeoutS = $timeoutS
    }
    Write-Log ("exec started (id={0} timeout_s={1}) - completion ack follows" -f $cmdId, $timeoutS)
    return @{
        command   = $command
        started   = $true
        status    = 'running'
        timed_out = $false
        output    = ''
    }
}
# ---------------------------------------------------------------- clean
# clean: named trash clearing ONLY. The allowed locations are this
# fixed list and nothing else. There are no path arguments: clean
# takes no args, so no caller can aim it anywhere else. It never
# matches Documents, Pictures, Desktop, or Downloads, and nothing is
# ever deleted by file extension. Only the CONTENTS of the three temp
# folders are removed - the folders themselves stay.

function Measure-CleanDir {
    # Measure one folder's CONTENTS (files only, recursive): count + bytes.
    param([string]$Path)
    $bytes = 0; $count = 0
    if (-not (Test-Path -LiteralPath $Path)) { return @{ Count = 0; Bytes = 0; Exists = $false } }
    try {
        $files = Get-ChildItem -LiteralPath $Path -Recurse -File -Force -ErrorAction SilentlyContinue
        foreach ($f in $files) { $bytes += $f.Length; $count += 1 }
    }
    catch { }
    return @{ Count = $count; Bytes = $bytes; Exists = $true }
}

function Clear-CleanDirContents {
    # Delete the CONTENTS of one folder only - never the folder itself.
    # Locked / in-use items are skipped, never forced past a failure.
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return }
    try {
        $items = Get-ChildItem -LiteralPath $Path -Force -ErrorAction SilentlyContinue
        foreach ($item in $items) {
            try {
                Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction Stop
            }
            catch { }
        }
    }
    catch { }
}

function Measure-CleanLocation {
    param($Location)
    if ($Location.Kind -eq 'recycle_bin') {
        $bytes = 0; $count = 0
        try {
            $shell = New-Object -ComObject Shell.Application
            $bin = $shell.NameSpace(10)
            if ($null -ne $bin) {
                foreach ($item in $bin.Items()) {
                    $count += 1
                    try { $bytes += [long]$item.Size } catch { }
                }
            }
        }
        catch { }
        return @{ Count = $count; Bytes = $bytes }
    }
    if ($Location.Kind -eq 'thumbcache') {
        $bytes = 0; $count = 0
        try {
            $files = Get-ChildItem -LiteralPath $Location.Path -Filter 'thumbcache_*.db' -File -Force -ErrorAction SilentlyContinue
            foreach ($f in $files) { $bytes += $f.Length; $count += 1 }
        }
        catch { }
        return @{ Count = $count; Bytes = $bytes }
    }
    return (Measure-CleanDir -Path $Location.Path)
}

function Clear-CleanLocation {
    param($Location)
    if ($Location.Kind -eq 'recycle_bin') {
        try { Clear-RecycleBin -Force -ErrorAction SilentlyContinue } catch { }
        return
    }
    if ($Location.Kind -eq 'thumbcache') {
        try {
            $files = Get-ChildItem -LiteralPath $Location.Path -Filter 'thumbcache_*.db' -File -Force -ErrorAction SilentlyContinue
            foreach ($f in $files) {
                try { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop } catch { }
            }
        }
        catch { }
        return
    }
    Clear-CleanDirContents -Path $Location.Path
}

function Invoke-CmdClean {
    param($CmdObj)
    $cmdId = $CmdObj.id
    $thumbDir = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer'
    $locations = @(
        @{ Key = 'recycle_bin'; Kind = 'recycle_bin'; Path = '' },
        @{ Key = 'user_temp'; Kind = 'dir'; Path = $env:TEMP },
        @{ Key = 'windows_temp'; Kind = 'dir'; Path = 'C:\Windows\Temp' },
        @{ Key = 'prefetch'; Kind = 'dir'; Path = 'C:\Windows\Prefetch' },
        @{ Key = 'thumbcache'; Kind = 'thumbcache'; Path = $thumbDir }
    )
    $before = @{}
    $beforeBytes = 0
    foreach ($loc in $locations) {
        $m = Measure-CleanLocation -Location $loc
        $before[$loc.Key] = $m
        $beforeBytes += $m.Bytes
    }
    $beforeMb = [math]::Round($beforeBytes / 1MB, 1)
    Write-AuditLog ("clean id={0} before_mb={1}" -f $cmdId, $beforeMb)
    Write-Log ("clean requested (id={0} before_mb={1})" -f $cmdId, $beforeMb)
    foreach ($loc in $locations) {
        Clear-CleanLocation -Location $loc
    }
    $after = @{}
    $afterBytes = 0
    foreach ($loc in $locations) {
        $m = Measure-CleanLocation -Location $loc
        $after[$loc.Key] = $m
        $afterBytes += $m.Bytes
    }
    $afterMb = [math]::Round($afterBytes / 1MB, 1)
    $freedMb = [math]::Round(($beforeBytes - $afterBytes) / 1MB, 1)
    Write-AuditLog ("clean id={0} done before_mb={1} after_mb={2} freed_mb={3}" -f $cmdId, $beforeMb, $afterMb, $freedMb)
    $items = @{}
    foreach ($loc in $locations) {
        $items[$loc.Key] = @{
            before_mb = [math]::Round($before[$loc.Key].Bytes / 1MB, 1)
            after_mb  = [math]::Round($after[$loc.Key].Bytes / 1MB, 1)
        }
    }
    return @{
        before_mb = $beforeMb
        after_mb  = $afterMb
        freed_mb  = $freedMb
        items     = $items
    }
}

# ---------------------------------------------------------------- repair
# repair: run ONE named repair from repair/repair-windows.ps1, ASYNC via
# the same $PendingJobs machinery as exec (sfc /scannow takes minutes;
# the loop must stay responsive). The job runs in a separate process,
# so the module path is passed in as an argument and dot-sourced
# inside the job. The job FIRST creates a System Restore point; if its
# status is not 'ok' (New-KuroResult's success status - its ValidateSet
# is ok / failed / dry_run / skipped, and Test-KuroRestorePointOk
# refuses later repairs only when the session state is 'failed'), the
# job stops with status 'refused' and detail 'restore point failed'
# and no repair runs. No reboot command anywhere.

function Invoke-CmdRepair {
    param($CmdObj)
    $fn = $CmdObj.function
    $map = @{
        'system_files'  = 'Repair-SystemFiles'
        'startup'       = 'Clear-StartupItems'
        'temp'          = 'Clear-TempCaches'
        'defender_scan' = 'Start-DefenderScan'
    }
    if (-not $fn -or $fn -isnot [string] -or -not $map.ContainsKey($fn)) {
        return @{ error = 'bad_function'; detail = "repair needs 'function' of: system_files, startup, temp, defender_scan" }
    }
    $target = $map[$fn]
    $names = @()
    if ($fn -eq 'startup') {
        $rawNames = $CmdObj.names
        if ($null -eq $rawNames -or $rawNames -isnot [System.Array] -or $rawNames.Count -eq 0) {
            return @{ error = 'bad_names'; detail = "startup repair needs a non-empty 'names' array" }
        }
        foreach ($n in $rawNames) {
            if ($n -isnot [string] -or $n.Length -eq 0 -or $n.Length -gt 50 -or
                $n.Contains('*') -or $n.Contains('?')) {
                return @{ error = 'bad_names'; detail = 'startup names must be strings of 1-50 chars with no wildcards (* or ?)' }
            }
        }
        $names = @($rawNames)
    }
    $timeoutS = 1800
    if ($null -ne $CmdObj.timeout_s) {
        try { $timeoutS = [int]$CmdObj.timeout_s } catch { $timeoutS = 1800 }
    }
    if ($timeoutS -lt 60) { $timeoutS = 60 }
    if ($timeoutS -gt 3600) { $timeoutS = 3600 }
    $cmdId = $CmdObj.id
    $modulePath = Join-Path $PSScriptRoot '..\repair\repair-windows.ps1'
    Write-AuditLog ("repair id={0} function={1} names={2} timeout_s={3}" -f $cmdId, $fn, ($names -join ', '), $timeoutS)
    Write-Log ("repair requested (id={0} function={1})" -f $cmdId, $fn)
    if (-not (Test-Path -LiteralPath $modulePath)) {
        return @{ error = 'repair_unavailable'; detail = "repair module not found: $modulePath" }
    }
    try {
        $job = Start-Job -ScriptBlock {
            param($modulePath, $target, $names)
            if ($names -isnot [System.Array]) { $names = @($names) }
            try {
                . $modulePath
                # Restore point FIRST. See the header comment above
                # Invoke-CmdRepair for the exact success check.
                $rp = New-KuroRestorePoint -ConfirmGo
                if ($null -eq $rp -or "$($rp.status)" -ne 'ok') {
                    return @{ repair = $target; status = 'refused'; before = ''; after = '';
                              detail = 'restore point failed' }
                }
                $res = $null
                if ($target -eq 'Clear-StartupItems') {
                    $res = Clear-StartupItems -Names $names -ConfirmGo
                }
                else {
                    $res = & $target -ConfirmGo
                }
                if ($null -eq $res) {
                    return @{ repair = $target; status = 'failed'; before = ''; after = '';
                              detail = 'repair function returned no result' }
                }
                return @{ repair = $target; status = "$($res.status)";
                          before = "$($res.before)"; after = "$($res.after)";
                          detail = "$($res.detail)" }
            }
            catch {
                return @{ repair = $target; status = 'failed'; before = ''; after = '';
                          detail = "repair job raised: $($_.Exception.Message)" }
            }
        } -ArgumentList @($modulePath, $target, (, $names))
    }
    catch {
        Write-Log ("repair failed to start (id={0}): {1}" -f $cmdId, $_.Exception.Message)
        return @{ error = 'repair_failed'; detail = $_.Exception.Message }
    }
    Register-PendingJob -Entry @{
        Job = $job; Id = "$cmdId"; Kind = 'repair'; Command = 'repair';
        Function = $fn; Target = $target; Names = $names;
        StartedAt = (Get-Date); TimeoutS = $timeoutS
    }
    Write-Log ("repair started (id={0} function={1} timeout_s={2}) - completion ack follows" -f $cmdId, $fn, $timeoutS)
    return @{ function = $fn; started = $true; status = 'running'; timed_out = $false; output = '' }
}

# ---------------------------------------------------------------- deep
# deep: hardware deep exam, READ-ONLY, ASYNC via $PendingJobs
# (fragmentation analysis can take minutes on a large HDD). Nothing in
# here writes, deletes, or changes anything. Jobs run in a separate
# process, so the parent's Get-SmartSummary is not available inside
# the job - the same SMART logic is inlined below. Every section is
# independent: one that cannot run reports unavailable and never
# kills the exam.

function Invoke-CmdDeep {
    param($CmdObj)
    $cmdId = $CmdObj.id
    $timeoutS = 1800
    if ($null -ne $CmdObj.timeout_s) {
        try { $timeoutS = [int]$CmdObj.timeout_s } catch { $timeoutS = 1800 }
    }
    if ($timeoutS -lt 60) { $timeoutS = 60 }
    if ($timeoutS -gt 3600) { $timeoutS = 3600 }
    Write-AuditLog ("deep id={0} timeout_s={1}" -f $cmdId, $timeoutS)
    Write-Log ("deep exam requested (id={0} timeout_s={1})" -f $cmdId, $timeoutS)
    try {
        $job = Start-Job -ScriptBlock {
            $result = @{ status = 'ok' }
            try {
                # SMART: full counters per disk.
                try {
                    $physical = Get-PhysicalDisk -ErrorAction Stop
                    $disks = @()
                    foreach ($d in $physical) {
                        $entry = @{
                            disk = $d.FriendlyName
                            device_id = "$($d.DeviceId)"
                            model = $d.Model
                            serial = $d.SerialNumber
                            media_type = $d.MediaType.ToString()
                            health = $d.HealthStatus.ToString()
                            size_gb = [math]::Round($d.Size / 1GB, 2)
                        }
                        try {
                            $counter = Get-StorageReliabilityCounter -PhysicalDisk $d -ErrorAction Stop
                            $entry['temperature_c'] = $counter.Temperature
                            $entry['power_on_hours'] = $counter.PowerOnHours
                            $entry['read_errors'] = $counter.ReadErrorsTotal
                            $entry['write_errors'] = $counter.WriteErrorsTotal
                            $entry['wear_pct'] = $counter.Wear
                        }
                        catch {
                            $entry['counter_error'] = $_.Exception.Message
                        }
                        $disks += $entry
                    }
                    $result['smart'] = @{ status = 'ok'; disks = $disks }
                }
                catch {
                    $result['smart'] = @{ status = 'unavailable'; detail = $_.Exception.Message }
                }
                # Disks + volumes.
                try {
                    $pd = @()
                    foreach ($d in (Get-PhysicalDisk -ErrorAction Stop)) {
                        $pd += @{ friendly_name = $d.FriendlyName; model = $d.Model;
                                  serial = $d.SerialNumber; media_type = $d.MediaType.ToString();
                                  health = $d.HealthStatus.ToString();
                                  size_gb = [math]::Round($d.Size / 1GB, 2) }
                    }
                    $vols = @()
                    foreach ($v in (Get-Volume -ErrorAction Stop | Where-Object { $_.DriveLetter })) {
                        $vols += @{ drive = "$($v.DriveLetter):"; label = $v.FileSystemLabel;
                                    fs = $v.FileSystem; health = $v.HealthStatus.ToString();
                                    size_gb = [math]::Round($v.Size / 1GB, 2);
                                    free_gb = [math]::Round($v.SizeRemaining / 1GB, 2) }
                    }
                    $result['disks'] = @{ status = 'ok'; physical = $pd; volumes = $vols }
                }
                catch {
                    $result['disks'] = @{ status = 'unavailable'; detail = $_.Exception.Message }
                }
                # Fragmentation analysis ONLY - a defrag is NEVER attempted.
                try {
                    $frag = Optimize-Volume -Analyze -DriveLetter C -ErrorAction Stop
                    $result['fragmentation'] = @{ status = 'ok'; drive = 'C:';
                        fragmentation_pct = $frag.FragmentationPercentage;
                        defrag_recommended = [bool]$frag.DefragRecommended }
                }
                catch {
                    $result['fragmentation'] = @{ status = 'unavailable';
                        detail = $_.Exception.Message;
                        note = 'analysis failed; no defrag was attempted' }
                }
                # Battery health.
                try {
                    $bats = @(Get-CimInstance Win32_Battery -ErrorAction Stop)
                    if ($bats.Count -eq 0) {
                        $result['battery'] = @{ status = 'ok'; detail = 'no battery found (desktop or no battery reported)' }
                    }
                    else {
                        $list = @()
                        foreach ($b in $bats) {
                            $list += @{ name = $b.Name;
                                design_capacity = $b.DesignCapacity;
                                full_charge_capacity = $b.FullChargeCapacity;
                                charge_remaining_pct = $b.EstimatedChargeRemaining;
                                status = $b.Status }
                        }
                        $result['battery'] = @{ status = 'ok'; batteries = $list }
                    }
                }
                catch {
                    $result['battery'] = @{ status = 'unavailable'; detail = $_.Exception.Message }
                }
                # Problem devices.
                try {
                    $bad = @(Get-PnpDevice -ErrorAction Stop | Where-Object { $_.Status -in 'Error', 'Degraded', 'Unknown' } | Select-Object -First 20)
                    $list = @()
                    foreach ($dev in $bad) {
                        $list += @{ class = $dev.Class; name = $dev.FriendlyName; status = $dev.Status.ToString() }
                    }
                    $result['problem_devices'] = @{ status = 'ok'; count = $list.Count; devices = $list }
                }
                catch {
                    $result['problem_devices'] = @{ status = 'unavailable'; detail = $_.Exception.Message }
                }
                # DISM health check (read-only check, no repair).
                try {
                    $dismOut = (& DISM.exe /Online /Cleanup-Image /CheckHealth 2>&1 | Out-String)
                    if ($null -eq $dismOut) { $dismOut = '' }
                    if ($dismOut.Length -gt 4096) { $dismOut = $dismOut.Substring(0, 4096) }
                    $result['dism'] = @{ status = 'ok'; output = $dismOut }
                }
                catch {
                    $result['dism'] = @{ status = 'unavailable'; detail = $_.Exception.Message }
                }
                # Event-log error counts, last 24h, grouped by provider, top 10.
                foreach ($logName in @('System', 'Application')) {
                    $key = 'event_errors_' + $logName.ToLower()
                    try {
                        $since = (Get-Date).AddHours(-24)
                        $events = Get-WinEvent -FilterHashtable @{ LogName = $logName; Level = 2; StartTime = $since } -ErrorAction Stop
                        $groups = @($events | Group-Object ProviderName | Sort-Object Count -Descending | Select-Object -First 10)
                        $list = @()
                        foreach ($g in $groups) {
                            $list += @{ provider = $g.Name; count = $g.Count }
                        }
                        $result[$key] = @{ status = 'ok'; total = $events.Count; top = $list }
                    }
                    catch {
                        $result[$key] = @{ status = 'unavailable'; detail = $_.Exception.Message }
                    }
                }
                # Memory pressure.
                try {
                    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
                    $totalMb = [math]::Round($os.TotalVisibleMemorySize / 1KB)
                    $freeMb = [math]::Round($os.FreePhysicalMemory / 1KB)
                    $freePct = 0
                    if ($totalMb -gt 0) { $freePct = [math]::Round($freeMb / $totalMb * 100, 1) }
                    $top = @()
                    foreach ($p in (Get-Process -ErrorAction Stop | Sort-Object WorkingSet64 -Descending | Select-Object -First 10)) {
                        $top += @{ name = $p.ProcessName; pid = $p.Id; mem_mb = [math]::Round($p.WorkingSet64 / 1MB, 1) }
                    }
                    $result['memory'] = @{ status = 'ok'; total_mb = $totalMb; free_mb = $freeMb;
                        free_pct = $freePct; top_processes = $top }
                }
                catch {
                    $result['memory'] = @{ status = 'unavailable'; detail = $_.Exception.Message }
                }
                # SysMain.
                try {
                    $svc = Get-Service -Name 'SysMain' -ErrorAction Stop
                    $result['sysmain'] = @{ status = 'ok'; service_status = $svc.Status.ToString(); start_type = $svc.StartType.ToString() }
                }
                catch {
                    $result['sysmain'] = @{ status = 'unavailable'; detail = $_.Exception.Message }
                }
                # Edge processes.
                try {
                    $edge = @(Get-Process -Name 'msedge' -ErrorAction SilentlyContinue)
                    $ramMb = 0
                    foreach ($p in $edge) { $ramMb += $p.WorkingSet64 }
                    $result['edge'] = @{ status = 'ok'; process_count = $edge.Count; total_ram_mb = [math]::Round($ramMb / 1MB, 1) }
                }
                catch {
                    $result['edge'] = @{ status = 'unavailable'; detail = $_.Exception.Message }
                }
            }
            catch {
                $result = @{ status = 'failed'; detail = $_.Exception.Message }
            }
            $result
        }
    }
    catch {
        Write-Log ("deep failed to start (id={0}): {1}" -f $cmdId, $_.Exception.Message)
        return @{ error = 'deep_failed'; detail = $_.Exception.Message }
    }
    Register-PendingJob -Entry @{
        Job = $job; Id = "$cmdId"; Kind = 'deep'; Command = 'deep';
        Function = ''; Target = ''; Names = @();
        StartedAt = (Get-Date); TimeoutS = $timeoutS
    }
    Write-Log ("deep exam started (id={0} timeout_s={1}) - completion ack follows" -f $cmdId, $timeoutS)
    return @{ started = $true; status = 'running'; timed_out = $false; output = '' }
}

# ---------------------------------------------------------------- uninstall
# uninstall: remove one installed game/app, ASYNC via $PendingJobs
# (same shapes as repair). kind: steam | msi | appx. The
# RUNNING-PROCESS PRECHECK runs FIRST, inside the job, before
# anything is deleted: if the target is running, the job returns
# status 'refused' with error 'target_running' and detail listing
# the process names - nothing is deleted. (Live lesson: the SCP
# uninstall failed halfway on a locked bass.dll because the game
# was RUNNING.) steam resolves steamapps\common\<name> and the
# appmanifest_<appid>.acf (manifests are scanned for the name when
# appid is absent; installdir is read from the manifest when the
# folder was not found by name). msi uses Get-Package /
# Uninstall-Package -Force, with a winget fallback when
# Get-Package finds nothing. appx uses Get-AppxPackage /
# Remove-AppxPackage plus a Remove-AppxProvisionedPackage -Online
# attempt for the linger case. Every branch verifies the target
# is gone before reporting 'ok'; steam also removes the
# Programs-and-Features registry entry and verifies it is gone.
# No reboot anywhere.

function Invoke-CmdUninstall {
    param($CmdObj)
    $kind = $CmdObj.kind
    $name = $CmdObj.name
    $appid = $CmdObj.appid
    $validKinds = @('steam', 'msi', 'appx')
    if (-not $kind -or $kind -isnot [string] -or $kind -notin $validKinds) {
        return @{ error = 'bad_kind'; detail = "uninstall needs 'kind' of: steam, msi, appx" }
    }
    if ($null -ne $name) {
        if ($name -isnot [string] -or $name.Length -eq 0 -or $name.Length -gt 200 -or
            $name.Contains('\') -or $name.Contains('/') -or $name.Contains('..')) {
            return @{ error = 'bad_target'; detail = "uninstall 'name' must be a string of 1-200 chars with no backslash, slash, or '..'" }
        }
    }
    if ($null -ne $appid) {
        if ($kind -ne 'steam') {
            return @{ error = 'bad_target'; detail = "uninstall 'appid' is steam only" }
        }
        try { $appid = [int]$appid } catch {
            return @{ error = 'bad_target'; detail = "uninstall 'appid' must be an integer" }
        }
    }
    if ($null -eq $name -and $null -eq $appid) {
        return @{ error = 'bad_target'; detail = "uninstall needs a 'name' or (for steam) an 'appid'" }
    }
    $target = "$name"
    if ([string]::IsNullOrWhiteSpace($target)) { $target = "appid $appid" }
    $timeoutS = 600
    if ($null -ne $CmdObj.timeout_s) {
        try { $timeoutS = [int]$CmdObj.timeout_s } catch { $timeoutS = 600 }
    }
    if ($timeoutS -lt 60) { $timeoutS = 60 }
    if ($timeoutS -gt 1800) { $timeoutS = 1800 }
    $cmdId = $CmdObj.id
    Write-AuditLog ("uninstall id={0} kind={1} target={2} appid={3} timeout_s={4}" -f $cmdId, $kind, $target, $appid, $timeoutS)
    Write-Log ("uninstall requested (id={0} kind={1} target={2})" -f $cmdId, $kind, $target)
    try {
        $job = Start-Job -ScriptBlock {
            param($kind, $name, $appid)
            $items = @()
            $target = "$name"
            if ([string]::IsNullOrWhiteSpace($target)) { $target = "appid $appid" }
            # RUNNING-PROCESS PRECHECK FIRST. Never delete under a
            # running target: a locked file fails halfway and leaves
            # a half-deleted install.
            $running = @()
            try {
                $procs = @(Get-Process -ErrorAction Stop)
                $normTarget = (($target -replace '[^a-zA-Z0-9]', '').ToLower())
                foreach ($p in $procs) {
                    $match = $false
                    $pNorm = (($p.ProcessName -replace '[^a-zA-Z0-9]', '').ToLower())
                    if ($normTarget -and $pNorm -eq $normTarget) { $match = $true }
                    if ($kind -eq 'steam' -and $null -ne $name) {
                        try {
                            $exePath = $p.Path
                            if ($exePath -and $exePath -like "*\steamapps\common\$name\*") { $match = $true }
                        }
                        catch { }
                    }
                    if ($match) { $running += $p.ProcessName }
                }
            }
            catch { }
            $running = @($running | Select-Object -Unique)
            if ($running.Count -gt 0) {
                $detail = "target is running ($($running -join ', ')) - close it first; nothing was deleted"
                return @{ kind = $kind; target = $target; status = 'refused'; error = 'target_running'; detail = $detail;
                          items = @(@{ step = 'precheck_running_processes'; ok = $false; detail = $detail }) }
            }
            $items += @{ step = 'precheck_running_processes'; ok = $true; detail = 'no matching process is running' }
            if ($kind -eq 'steam') {
                $steamRoots = @()
                foreach ($pf in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
                    if ($pf) { $steamRoots += (Join-Path $pf 'Steam\steamapps') }
                }
                try {
                    $regPath = Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -Name 'InstallPath' -ErrorAction Stop
                    if ($regPath.InstallPath) { $steamRoots += (Join-Path $regPath.InstallPath 'steamapps') }
                }
                catch { }
                $steamRoots = @($steamRoots | Select-Object -Unique)
                $gameFolder = $null
                $manifestPath = $null
                if ($null -ne $appid) {
                    foreach ($root in $steamRoots) {
                        $cand = Join-Path $root ("appmanifest_$appid.acf")
                        if (Test-Path -LiteralPath $cand) { $manifestPath = $cand; break }
                    }
                }
                if ($null -ne $name) {
                    foreach ($root in $steamRoots) {
                        $cand = Join-Path $root ("common\$name")
                        if (Test-Path -LiteralPath $cand) { $gameFolder = $cand; break }
                    }
                    if ($null -eq $manifestPath) {
                        foreach ($root in $steamRoots) {
                            foreach ($mf in (Get-ChildItem -LiteralPath $root -Filter 'appmanifest_*.acf' -File -ErrorAction SilentlyContinue)) {
                                try {
                                    $text = [System.IO.File]::ReadAllText($mf.FullName)
                                    if ($text -match ('"name"\s+"' + [regex]::Escape($name) + '"')) { $manifestPath = $mf.FullName; break }
                                }
                                catch { }
                            }
                            if ($null -ne $manifestPath) { break }
                        }
                    }
                }
                if ($null -eq $gameFolder -and $null -ne $manifestPath) {
                    try {
                        $mtext = [System.IO.File]::ReadAllText($manifestPath)
                        if ($mtext -match '"installdir"\s+"([^"]+)"') {
                            $installDir = $Matches[1]
                            foreach ($root in $steamRoots) {
                                $cand = Join-Path $root ("common\$installDir")
                                if (Test-Path -LiteralPath $cand) { $gameFolder = $cand; break }
                            }
                        }
                    }
                    catch { }
                }
                if ($null -eq $gameFolder -and $null -eq $manifestPath) {
                    return @{ kind = $kind; target = $target; status = 'failed';
                              detail = "steam target not found (no common folder and no manifest for '$target')"; items = $items }
                }
                if ($null -ne $gameFolder) {
                    try {
                        Remove-Item -LiteralPath $gameFolder -Recurse -Force -ErrorAction Stop
                        $items += @{ step = 'delete_game_folder'; ok = $true; detail = "deleted $gameFolder" }
                    }
                    catch {
                        $items += @{ step = 'delete_game_folder'; ok = $false; detail = $_.Exception.Message }
                        return @{ kind = $kind; target = $target; status = 'failed';
                                  detail = "could not delete game folder: $($_.Exception.Message)"; items = $items }
                    }
                }
                if ($null -ne $manifestPath) {
                    try {
                        Remove-Item -LiteralPath $manifestPath -Force -ErrorAction Stop
                        $items += @{ step = 'delete_manifest'; ok = $true; detail = "deleted $manifestPath" }
                    }
                    catch {
                        $items += @{ step = 'delete_manifest'; ok = $false; detail = $_.Exception.Message }
                        return @{ kind = $kind; target = $target; status = 'failed';
                                  detail = "could not delete manifest: $($_.Exception.Message)"; items = $items }
                    }
                }
                # v1.3.2 STEAM REGISTRY FIX: Steam also registers the
                # game in Programs and Features (an Uninstall key,
                # usually "Steam App <appid>"). Deleting the folder
                # and the manifest left that entry behind, so Windows
                # still listed the game as installed. Remove the
                # matching key (by "Steam App <appid>" when appid is
                # known, or by DisplayName matching the game name)
                # from both the 64-bit and Wow6432Node Uninstall
                # roots, then verify it is gone by reading the key
                # back. (MSI and AppX need no such fix: they already
                # do proper removals.)
                $regRoots = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                              'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')
                $regKeysFound = @()
                foreach ($root in $regRoots) {
                    try {
                        foreach ($key in (Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
                            $isMatch = $false
                            if ($null -ne $appid -and $key.PSChildName -eq "Steam App $appid") { $isMatch = $true }
                            if (-not $isMatch -and $null -ne $name) {
                                try {
                                    $props = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
                                    if ($null -ne $props.DisplayName -and "$($props.DisplayName)" -eq "$name") { $isMatch = $true }
                                }
                                catch { }
                            }
                            if ($isMatch) { $regKeysFound += $key.PSPath }
                        }
                    }
                    catch { }
                }
                if ($regKeysFound.Count -eq 0) {
                    $items += @{ step = 'remove_registry_entry'; ok = $true; detail = 'no Programs-and-Features entry found for this game' }
                }
                else {
                    foreach ($regKey in $regKeysFound) {
                        try {
                            Remove-Item -LiteralPath $regKey -Recurse -Force -ErrorAction Stop
                            $items += @{ step = 'remove_registry_entry'; ok = $true; detail = "removed $regKey" }
                        }
                        catch {
                            $items += @{ step = 'remove_registry_entry'; ok = $false; detail = $_.Exception.Message }
                        }
                    }
                }
                $registryGone = $true
                foreach ($root in $regRoots) {
                    try {
                        foreach ($key in (Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
                            if ($null -ne $appid -and $key.PSChildName -eq "Steam App $appid") { $registryGone = $false }
                            if ($null -ne $name) {
                                try {
                                    $props = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
                                    if ($null -ne $props.DisplayName -and "$($props.DisplayName)" -eq "$name") { $registryGone = $false }
                                }
                                catch { }
                            }
                        }
                    }
                    catch { }
                }
                $items += @{ step = 'verify_registry_gone'; ok = $registryGone; detail = $(if ($registryGone) { 'Programs-and-Features entry is gone' } else { 'Programs-and-Features entry is still present' }) }
                $folderGone = ($null -eq $gameFolder) -or (-not (Test-Path -LiteralPath $gameFolder))
                $manifestGone = ($null -eq $manifestPath) -or (-not (Test-Path -LiteralPath $manifestPath))
                if ($folderGone -and $manifestGone -and $registryGone) {
                    return @{ kind = $kind; target = $target; status = 'ok';
                              detail = "steam target '$target' removed"; items = $items }
                }
                return @{ kind = $kind; target = $target; status = 'failed';
                          detail = 'steam target still present after delete (folder, manifest, or registry entry remains)'; items = $items }
            }
            elseif ($kind -eq 'msi') {
                $pkgs = @()
                try { $pkgs = @(Get-Package -Name $name -ErrorAction SilentlyContinue) } catch { }
                if ($pkgs.Count -eq 0) {
                    try {
                        $winget = Get-Command winget -ErrorAction Stop
                        $wout = (& winget uninstall --name "$name" --silent --accept-source-agreements 2>&1 | Out-String)
                        if ($null -eq $wout) { $wout = '' }
                        $items += @{ step = 'winget_uninstall'; ok = ($LASTEXITCODE -eq 0); detail = "$wout" }
                    }
                    catch {
                        $items += @{ step = 'winget_uninstall'; ok = $false; detail = 'winget is not available on this PC' }
                    }
                }
                else {
                    foreach ($pkg in $pkgs) {
                        try {
                            Uninstall-Package -InputObject $pkg -Force -ErrorAction Stop
                            $items += @{ step = 'uninstall_package'; ok = $true; detail = "uninstalled $($pkg.Name)" }
                        }
                        catch {
                            $items += @{ step = 'uninstall_package'; ok = $false; detail = $_.Exception.Message }
                        }
                    }
                }
                $remaining = @()
                try { $remaining = @(Get-Package -Name $name -ErrorAction SilentlyContinue) } catch { }
                if ($remaining.Count -eq 0) {
                    return @{ kind = $kind; target = $target; status = 'ok';
                              detail = "package '$target' removed"; items = $items }
                }
                return @{ kind = $kind; target = $target; status = 'failed';
                          detail = "package '$target' is still installed"; items = $items }
            }
            elseif ($kind -eq 'appx') {
                $pkgs = @()
                try { $pkgs = @(Get-AppxPackage -Name "*$name*" -ErrorAction SilentlyContinue) } catch { }
                if ($pkgs.Count -eq 0) {
                    return @{ kind = $kind; target = $target; status = 'failed';
                              detail = "no installed AppX package matches '$target'"; items = $items }
                }
                foreach ($pkg in $pkgs) {
                    try {
                        Remove-AppxPackage -Package $pkg.PackageFullName -ErrorAction Stop
                        $items += @{ step = 'remove_appx_package'; ok = $true; detail = "removed $($pkg.PackageFullName)" }
                    }
                    catch {
                        $items += @{ step = 'remove_appx_package'; ok = $false; detail = $_.Exception.Message }
                    }
                    try {
                        Remove-AppxProvisionedPackage -Online -PackageName $pkg.PackageFullName -ErrorAction Stop
                        $items += @{ step = 'remove_appx_provisioned'; ok = $true; detail = "deprovisioned $($pkg.PackageFullName)" }
                    }
                    catch {
                        $items += @{ step = 'remove_appx_provisioned'; ok = $false; detail = "provisioned removal skipped: $($_.Exception.Message)" }
                    }
                }
                $remaining = @()
                try { $remaining = @(Get-AppxPackage -Name "*$name*" -ErrorAction SilentlyContinue) } catch { }
                if ($remaining.Count -eq 0) {
                    return @{ kind = $kind; target = $target; status = 'ok';
                              detail = "AppX package '$target' removed"; items = $items }
                }
                return @{ kind = $kind; target = $target; status = 'failed';
                          detail = "AppX package '$target' is still installed"; items = $items }
            }
            return @{ kind = $kind; target = $target; status = 'failed';
                      detail = "uninstall kind '$kind' is not handled by this agent"; items = $items }
        } -ArgumentList @($kind, $name, $appid)
    }
    catch {
        Write-Log ("uninstall failed to start (id={0}): {1}" -f $cmdId, $_.Exception.Message)
        return @{ error = 'uninstall_failed'; detail = $_.Exception.Message }
    }
    Register-PendingJob -Entry @{
        Job = $job; Id = "$cmdId"; Kind = 'uninstall'; Command = 'uninstall';
        Function = $kind; Target = $target; Names = @();
        StartedAt = (Get-Date); TimeoutS = $timeoutS
    }
    Write-Log ("uninstall started (id={0} kind={1} target={2}) - completion ack follows" -f $cmdId, $kind, $target)
    return @{ kind = $kind; target = $target; started = $true; status = 'running'; timed_out = $false; output = '' }
}

# ---------------------------------------------------------------- install
# install: install one game/app, ASYNC via $PendingJobs (same shapes
# as uninstall). kind: winget | msi | exe. The ALREADY-INSTALLED
# PRECHECK runs FIRST, inside the job, before anything is installed:
# if the target is already present, the job returns status 'ok' with
# detail 'already installed' and runs nothing. winget checks
# `winget list --name <name>`; msi checks the Uninstall registry for
# a matching DisplayName; exe has no reliable precheck and skips it
# (said plainly in the items, never invented). winget installs by
# name; msi installs an .msi file (path or url); exe runs an .exe
# installer (path or url; optional "args" string, e.g. "/S" - without
# args the installer runs as-is and may show its wizard). NEVER trust
# the installer exit code alone: every branch verifies the install
# afterward (winget list / Uninstall registry) and reports verified
# true/false - a failed verification is status 'failed' even when
# the installer exited 0. No reboot anywhere.

function Invoke-CmdInstall {
    param($CmdObj)
    $kind = $CmdObj.kind
    $name = $CmdObj.name
    $path = $CmdObj.path
    $url = $CmdObj.url
    $installArgs = $CmdObj.args
    $validKinds = @('winget', 'msi', 'exe')
    if (-not $kind -or $kind -isnot [string] -or $kind -notin $validKinds) {
        return @{ error = 'bad_kind'; detail = "install needs 'kind' of: winget, msi, exe" }
    }
    if ($null -ne $name) {
        if ($name -isnot [string] -or $name.Length -eq 0 -or $name.Length -gt 200 -or
            $name.Contains('\') -or $name.Contains('/') -or $name.Contains('..')) {
            return @{ error = 'bad_target'; detail = "install 'name' must be a string of 1-200 chars with no backslash, slash, or '..'" }
        }
    }
    if ($null -ne $path) {
        if ($path -isnot [string] -or $path.Length -eq 0 -or $path.Length -gt 500 -or
            $path.Contains('..')) {
            return @{ error = 'bad_target'; detail = "install 'path' must be a string of 1-500 chars with no '..'" }
        }
        if ($kind -eq 'winget') {
            return @{ error = 'bad_target'; detail = "install 'path' is msi/exe only, not winget" }
        }
        if ($kind -eq 'msi' -and -not $path.ToLower().EndsWith('.msi')) {
            return @{ error = 'bad_target'; detail = "install 'path' for kind msi must end in .msi" }
        }
        if ($kind -eq 'exe' -and -not $path.ToLower().EndsWith('.exe')) {
            return @{ error = 'bad_target'; detail = "install 'path' for kind exe must end in .exe" }
        }
    }
    if ($null -ne $url) {
        if ($url -isnot [string] -or $url.Length -eq 0 -or $url.Length -gt 500 -or
            $url.Contains('..')) {
            return @{ error = 'bad_target'; detail = "install 'url' must be a string of 1-500 chars with no '..'" }
        }
        if ($kind -eq 'winget') {
            return @{ error = 'bad_target'; detail = "install 'url' is msi/exe only, not winget" }
        }
        if ($kind -eq 'msi' -and -not $url.ToLower().EndsWith('.msi')) {
            return @{ error = 'bad_target'; detail = "install 'url' for kind msi must end in .msi" }
        }
        if ($kind -eq 'exe' -and -not $url.ToLower().EndsWith('.exe')) {
            return @{ error = 'bad_target'; detail = "install 'url' for kind exe must end in .exe" }
        }
    }
    if ($null -ne $installArgs) {
        if ($installArgs -isnot [string] -or $installArgs.Length -gt 500 -or
            $installArgs.Contains("`n") -or $installArgs.Contains("`r")) {
            return @{ error = 'bad_target'; detail = "install 'args' must be a string of at most 500 chars with no newlines" }
        }
        if ($kind -ne 'exe') {
            return @{ error = 'bad_target'; detail = "install 'args' is exe only" }
        }
    }
    if ($null -eq $name -and $null -eq $path -and $null -eq $url) {
        return @{ error = 'bad_target'; detail = "install needs a 'name' or (for msi/exe) a 'path' or 'url'" }
    }
    if ($kind -eq 'winget' -and $null -eq $name) {
        return @{ error = 'bad_target'; detail = "install kind winget needs a 'name'" }
    }
    if (($kind -eq 'msi' -or $kind -eq 'exe') -and $null -eq $path -and $null -eq $url) {
        return @{ error = 'bad_target'; detail = "install kind $kind needs a 'path' or 'url' to the installer file" }
    }
    $target = "$name"
    if ([string]::IsNullOrWhiteSpace($target)) {
        if ($null -ne $path) { $target = [System.IO.Path]::GetFileName("$path") }
        elseif ($null -ne $url) { $target = [System.IO.Path]::GetFileName("$url") }
    }
    $source = "$path"
    if ([string]::IsNullOrWhiteSpace($source)) { $source = "$url" }
    $timeoutS = 600
    if ($null -ne $CmdObj.timeout_s) {
        try { $timeoutS = [int]$CmdObj.timeout_s } catch { $timeoutS = 600 }
    }
    if ($timeoutS -lt 60) { $timeoutS = 60 }
    if ($timeoutS -gt 1800) { $timeoutS = 1800 }
    $cmdId = $CmdObj.id
    Write-AuditLog ("install id={0} kind={1} target={2} source={3} timeout_s={4}" -f $cmdId, $kind, $target, $source, $timeoutS)
    Write-Log ("install requested (id={0} kind={1} target={2})" -f $cmdId, $kind, $target)
    try {
        $job = Start-Job -ScriptBlock {
            param($kind, $name, $path, $url, $installArgs)
            $items = @()
            $target = "$name"
            if ([string]::IsNullOrWhiteSpace($target)) {
                if ($null -ne $path) { $target = [System.IO.Path]::GetFileName("$path") }
                elseif ($null -ne $url) { $target = [System.IO.Path]::GetFileName("$url") }
            }
            # Helpers, defined inside the job (a background job has no
            # access to the agent's functions).
            function Test-WingetInstalled {
                param([string]$AppName)
                try {
                    $wout = (& winget list --name "$AppName" --accept-source-agreements 2>&1 | Out-String)
                    if ($null -eq $wout) { return $false }
                    if ($wout -match 'No installed package found') { return $false }
                    return ($LASTEXITCODE -eq 0)
                }
                catch { return $false }
            }
            function Test-RegistryInstalled {
                param([string]$AppName)
                foreach ($root in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                                    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
                    try {
                        foreach ($key in (Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
                            try {
                                $props = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
                                if ($null -ne $props.DisplayName -and "$($props.DisplayName)" -like "*$AppName*") { return $true }
                            }
                            catch { }
                        }
                    }
                    catch { }
                }
                return $false
            }
            function Get-MsiProductCode {
                param([string]$MsiPath)
                try {
                    $wi = New-Object -ComObject WindowsInstaller.Installer
                    $db = $wi.OpenDatabase($MsiPath, 0)
                    $view = $db.OpenView("SELECT Value FROM Property WHERE Property = 'ProductCode'")
                    $view.Execute()
                    $rec = $view.Fetch()
                    if ($null -eq $rec) { return $null }
                    return $rec.StringData(1)
                }
                catch { return $null }
            }
            # ALREADY-INSTALLED PRECHECK FIRST. Run nothing when the
            # target is already present.
            if ($kind -eq 'winget') {
                if (Test-WingetInstalled -AppName $name) {
                    $detail = "already installed: '$target' (winget list)"
                    $items += @{ step = 'precheck_already_installed'; ok = $true; detail = $detail }
                    return @{ kind = $kind; target = $target; status = 'ok'; verified = $true; detail = $detail; items = $items }
                }
                $items += @{ step = 'precheck_already_installed'; ok = $true; detail = 'not installed (winget list)' }
            }
            elseif ($kind -eq 'msi') {
                if ($null -ne $name -and (Test-RegistryInstalled -AppName $name)) {
                    $detail = "already installed: '$target' (Uninstall registry)"
                    $items += @{ step = 'precheck_already_installed'; ok = $true; detail = $detail }
                    return @{ kind = $kind; target = $target; status = 'ok'; verified = $true; detail = $detail; items = $items }
                }
                if ($null -eq $name) {
                    $items += @{ step = 'precheck_already_installed'; ok = $true; detail = 'no name given - registry precheck skipped' }
                }
                else {
                    $items += @{ step = 'precheck_already_installed'; ok = $true; detail = 'not installed (Uninstall registry)' }
                }
            }
            else {
                $items += @{ step = 'precheck_already_installed'; ok = $true; detail = 'no reliable precheck for exe - proceeding' }
            }
            if ($kind -eq 'winget') {
                try {
                    $wout = (& winget install --name "$name" --silent --accept-source-agreements --accept-package-agreements 2>&1 | Out-String)
                    if ($null -eq $wout) { $wout = '' }
                    $items += @{ step = 'winget_install'; ok = ($LASTEXITCODE -eq 0); detail = "$wout" }
                }
                catch {
                    $items += @{ step = 'winget_install'; ok = $false; detail = $_.Exception.Message }
                    return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                              detail = "winget install failed: $($_.Exception.Message)"; items = $items }
                }
                $verified = Test-WingetInstalled -AppName $name
                if ($verified) {
                    $items += @{ step = 'verify_installed'; ok = $true; detail = "'$target' found in winget list" }
                    return @{ kind = $kind; target = $target; status = 'ok'; verified = $true;
                              detail = "installed '$target' (winget, verified)"; items = $items }
                }
                $items += @{ step = 'verify_installed'; ok = $false; detail = "'$target' NOT found in winget list after install" }
                return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                          detail = "winget install finished but '$target' is not in winget list - install unverified"; items = $items }
            }
            elseif ($kind -eq 'msi') {
                $installerPath = "$path"
                if ($null -ne $url) {
                    $fileName = [System.IO.Path]::GetFileName("$url")
                    $installerPath = Join-Path $env:TEMP $fileName
                    try {
                        Invoke-WebRequest -Uri "$url" -OutFile $installerPath -UseBasicParsing -ErrorAction Stop
                        $items += @{ step = 'download_installer'; ok = $true; detail = "downloaded $url to $installerPath" }
                    }
                    catch {
                        $items += @{ step = 'download_installer'; ok = $false; detail = $_.Exception.Message }
                        return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                                  detail = "could not download installer: $($_.Exception.Message)"; items = $items }
                    }
                }
                if (-not (Test-Path -LiteralPath $installerPath)) {
                    return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                              detail = "installer file not found: $installerPath"; items = $items }
                }
                try {
                    $proc = Start-Process -FilePath 'msiexec.exe' -ArgumentList @('/i', "`"$installerPath`"", '/qn', '/norestart') -Wait -PassThru -ErrorAction Stop
                    $exitCode = $proc.ExitCode
                    $items += @{ step = 'msiexec_install'; ok = ($exitCode -eq 0); detail = "msiexec exited $exitCode" }
                }
                catch {
                    $items += @{ step = 'msiexec_install'; ok = $false; detail = $_.Exception.Message }
                    return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                              detail = "msiexec failed: $($_.Exception.Message)"; items = $items }
                }
                $verified = $false
                $verifyDetail = ''
                if ($null -ne $name) {
                    $verified = Test-RegistryInstalled -AppName $name
                    if ($verified) { $verifyDetail = "'$target' found in Uninstall registry" }
                    else { $verifyDetail = "'$target' NOT found in Uninstall registry after install" }
                }
                else {
                    $productCode = Get-MsiProductCode -MsiPath $installerPath
                    if ($null -ne $productCode) {
                        foreach ($root in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                                            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
                            if (Test-Path -LiteralPath (Join-Path $root $productCode)) { $verified = $true }
                        }
                        if ($verified) { $verifyDetail = "product $productCode found in Uninstall registry" }
                        else { $verifyDetail = "product $productCode NOT found in Uninstall registry after install" }
                    }
                    else {
                        $verifyDetail = 'could not read ProductCode from the .msi - install cannot be verified'
                    }
                }
                $items += @{ step = 'verify_installed'; ok = $verified; detail = $verifyDetail }
                if ($verified) {
                    return @{ kind = $kind; target = $target; status = 'ok'; verified = $true;
                              detail = "installed '$target' (msi, verified)"; items = $items }
                }
                return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                          detail = "msi install finished but could not be verified: $verifyDetail"; items = $items }
            }
            elseif ($kind -eq 'exe') {
                $installerPath = "$path"
                if ($null -ne $url) {
                    $fileName = [System.IO.Path]::GetFileName("$url")
                    $installerPath = Join-Path $env:TEMP $fileName
                    try {
                        Invoke-WebRequest -Uri "$url" -OutFile $installerPath -UseBasicParsing -ErrorAction Stop
                        $items += @{ step = 'download_installer'; ok = $true; detail = "downloaded $url to $installerPath" }
                    }
                    catch {
                        $items += @{ step = 'download_installer'; ok = $false; detail = $_.Exception.Message }
                        return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                                  detail = "could not download installer: $($_.Exception.Message)"; items = $items }
                    }
                }
                if (-not (Test-Path -LiteralPath $installerPath)) {
                    return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                              detail = "installer file not found: $installerPath"; items = $items }
                }
                try {
                    if ([string]::IsNullOrWhiteSpace($installArgs)) {
                        $proc = Start-Process -FilePath $installerPath -Wait -PassThru -ErrorAction Stop
                    }
                    else {
                        $proc = Start-Process -FilePath $installerPath -ArgumentList $installArgs -Wait -PassThru -ErrorAction Stop
                    }
                    $exitCode = $proc.ExitCode
                    $items += @{ step = 'exe_install'; ok = ($exitCode -eq 0); detail = "installer exited $exitCode" }
                }
                catch {
                    $items += @{ step = 'exe_install'; ok = $false; detail = $_.Exception.Message }
                    return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                              detail = "exe installer failed: $($_.Exception.Message)"; items = $items }
                }
                $verified = $false
                $verifyDetail = ''
                if ($null -ne $name) {
                    $verified = Test-RegistryInstalled -AppName $name
                    if ($verified) { $verifyDetail = "'$target' found in Uninstall registry" }
                    else { $verifyDetail = "'$target' NOT found in Uninstall registry after install" }
                }
                else {
                    $verifyDetail = 'no name given - exe install cannot be verified against the Uninstall registry'
                }
                $items += @{ step = 'verify_installed'; ok = $verified; detail = $verifyDetail }
                if ($verified) {
                    return @{ kind = $kind; target = $target; status = 'ok'; verified = $true;
                              detail = "installed '$target' (exe, verified)"; items = $items }
                }
                return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                          detail = "exe install finished but could not be verified: $verifyDetail"; items = $items }
            }
            return @{ kind = $kind; target = $target; status = 'failed'; verified = $false;
                      detail = "install kind '$kind' is not handled by this agent"; items = $items }
        } -ArgumentList @($kind, $name, $path, $url, $installArgs)
    }
    catch {
        Write-Log ("install failed to start (id={0}): {1}" -f $cmdId, $_.Exception.Message)
        return @{ error = 'install_failed'; detail = $_.Exception.Message }
    }
    Register-PendingJob -Entry @{
        Job = $job; Id = "$cmdId"; Kind = 'install'; Command = 'install';
        Function = $kind; Target = $target; Names = @();
        StartedAt = (Get-Date); TimeoutS = $timeoutS
    }
    Write-Log ("install started (id={0} kind={1} target={2}) - completion ack follows" -f $cmdId, $kind, $target)
    return @{ kind = $kind; target = $target; started = $true; status = 'running'; timed_out = $false; output = '' }
}

# BEGIN USB PHONE DRIVER (v1.3.5)
# ---------------------------------------------------------------- usb phone
# USB PHONE DOCTOR: the phone plugs into this PC over USB and the
# agent drives it with adb. Plug in, tap Allow once on the phone
# ("Always allow from this computer"), then plug-and-go forever.
# No pairing sheet, no 6-digit code, no wireless debugging anywhere
# in this flow. One driver, one command set - the same behaviour
# on every host by design.
#
# Commands: phone_checkup (no args) and phone_repair
# (kind + package). Both are SYNCHRONOUS: every adb call carries
# its own timeout, so a wedged adb can never hang the poll loop.
#
# Safety: the package comes from a relay-validated command, but it
# is re-validated here anyway (same regex and limits as the relay),
# and the protected set is refused here too (defense in depth).
# Arguments are passed to adb as an array - never through a shell
# string - so no relay value can ever inject a second command.
# The four repair commands (pm clear / pm disable-user /
# am force-stop / pm uninstall --user 0) cannot delete documents
# or photos.
#
# adb discovery: $env:KURODOCTOR_ADB first (explicit override),
# then adb on PATH, then the usual platform-tools spots
# (Android SDK, C:\platform-tools, Program Files). No adb at all
# -> error adb_missing with the install hint (see SETUP.md).

$script:AdbPath = $null
$script:AdbDefaultTimeoutSeconds = 20
$script:PhonePackageRegex = '^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)+$'
$script:PhoneProtectedPackages = @(
    'com.kuro.kurodoctor',
    'android',
    'com.android.systemui',
    'com.android.phone',
    'com.android.settings',
    'com.android.packageinstaller',
    'com.google.android.gms',
    'com.google.android.gsf'
)

function Get-AdbPath {
    if ($script:AdbPath) { return $script:AdbPath }
    if (-not [string]::IsNullOrWhiteSpace($env:KURODOCTOR_ADB)) {
        $override = $env:KURODOCTOR_ADB.Trim()
        if (Test-Path -LiteralPath $override) {
            $script:AdbPath = $override
            return $script:AdbPath
        }
    }
    $cmd = Get-Command adb -ErrorAction SilentlyContinue
    if ($null -ne $cmd -and $cmd.Source -and (Test-Path -LiteralPath $cmd.Source)) {
        $script:AdbPath = $cmd.Source
        return $script:AdbPath
    }
    $candidates = @()
    if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
        $candidates += (Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe')
    }
    $candidates += 'C:\platform-tools\adb.exe'
    if (-not [string]::IsNullOrWhiteSpace($env:ProgramFiles)) {
        $candidates += (Join-Path $env:ProgramFiles 'platform-tools\adb.exe')
    }
    foreach ($c in $candidates) {
        if (Test-Path -LiteralPath $c) {
            $script:AdbPath = $c
            return $script:AdbPath
        }
    }
    return $null
}

# Run adb once, with a hard timeout. Arguments are passed as an
# array (no shell), each one allow-listed to plain token characters
# before use. Returns @{ ok; timed_out; output; exit_code; error; detail }.
# The job wrapper keeps a chatty adb (pm list packages) from ever
# deadlocking the agent on a full output pipe.
function Invoke-Adb {
    param(
        [string[]]$Arguments,
        [int]$TimeoutSeconds = 20
    )
    if ($TimeoutSeconds -lt 5) { $TimeoutSeconds = 5 }
    if ($TimeoutSeconds -gt 60) { $TimeoutSeconds = 60 }
    $adbPath = Get-AdbPath
    if (-not $adbPath) {
        return @{ ok = $false; timed_out = $false; output = ''; exit_code = $null;
                  error = 'adb_missing';
                  detail = 'adb was not found. Install platform-tools: download the platform-tools zip from Google, unzip it to C:\platform-tools, and add C:\platform-tools to PATH (see SETUP.md, USB phone section). Then run the agent again.' }
    }
    foreach ($a in $Arguments) {
        if ($a -notmatch '^[A-Za-z0-9._\-/:=+]+$') {
            return @{ ok = $false; timed_out = $false; output = ''; exit_code = $null;
                      error = 'bad_adb_arg'; detail = "refused unsafe adb argument: $a" }
        }
    }
    $job = $null
    try {
        $job = Start-Job -ScriptBlock {
            param($AdbPath, $ArgArray)
            $text = ''
            $code = $null
            try {
                $out = & $AdbPath @ArgArray 2>&1
                $code = $LASTEXITCODE
                $text = ($out | Out-String)
            }
            catch {
                $text = "adb launch failed: $($_.Exception.Message)"
            }
            return @{ output = "$text"; exit_code = $code }
        } -ArgumentList @($adbPath, (, $Arguments))
    }
    catch {
        return @{ ok = $false; timed_out = $false; output = ''; exit_code = $null;
                  error = 'adb_failed'; detail = "could not start adb: $($_.Exception.Message)" }
    }
    try {
        Wait-Job $job -Timeout $TimeoutSeconds | Out-Null
    }
    catch {
        # Wait-Job timeout is reported via job state, not an exception;
        # anything else here is treated as a timeout too.
    }
    if ($job.State -ne 'Completed') {
        try { Stop-Job $job -ErrorAction SilentlyContinue } catch { }
        try { Remove-Job $job -Force -ErrorAction SilentlyContinue } catch { }
        return @{ ok = $false; timed_out = $true; output = ''; exit_code = $null;
                  error = 'adb_timeout';
                  detail = "adb did not answer within $TimeoutSeconds seconds." }
    }
    $res = $null
    try { $res = Receive-Job $job -ErrorAction Stop } catch { $res = $null }
    try { Remove-Job $job -Force -ErrorAction SilentlyContinue } catch { }
    if ($null -eq $res) {
        return @{ ok = $false; timed_out = $false; output = ''; exit_code = $null;
                  error = 'adb_failed'; detail = 'adb returned no output.' }
    }
    return @{ ok = $true; timed_out = $false; output = "$($res.output)";
              exit_code = $res.exit_code; error = $null; detail = '' }
}

# Find the phone. Returns @{ serial; state; devices } on success, or
# @{ error; detail } (adb_missing / adb_timeout / adb_failed /
# unauthorized / device_offline / adb_no_permissions / no_device).
# When several phones are plugged in, the FIRST one in state
# 'device' wins and its serial is named in the result.
function Get-PhoneDevice {
    $adb = Get-AdbPath
    if (-not $adb) {
        return @{ error = 'adb_missing';
                  detail = 'adb was not found. Install platform-tools: download the platform-tools zip from Google, unzip it to C:\platform-tools, and add C:\platform-tools to PATH (see SETUP.md, USB phone section). Then run the agent again.';
                  hint = 'install platform-tools' }
    }
    $r = Invoke-Adb -Arguments @('devices') -TimeoutSeconds 15
    if ($r.timed_out) {
        return @{ error = 'adb_timeout';
                  detail = 'adb devices did not answer within 15 seconds. Unplug the phone, plug it back in, and try again.' }
    }
    if (-not $r.ok) {
        return @{ error = "$($r.error)"; detail = "$($r.detail)" }
    }
    $devices = @()
    foreach ($line in ($r.output -split "`n")) {
        $t = $line.Trim()
        if (-not $t -or $t.StartsWith('List of devices')) { continue }
        $parts = ($t -split '\s+')
        if ($parts.Count -lt 2) { continue }
        $serial = $parts[0]
        $state = $parts[1]
        if ($state -eq 'no' -and $parts.Count -ge 3 -and $parts[2] -eq 'permissions') {
            $state = 'no_permissions'
        }
        if ($serial -notmatch '^[A-Za-z0-9._:-]+$') { continue }
        $devices += @{ serial = $serial; state = $state }
    }
    $ready = $null
    foreach ($d in $devices) {
        if ($d.state -eq 'device') { $ready = $d; break }
    }
    if ($null -ne $ready) {
        $summary = @()
        foreach ($d in $devices) { $summary += "$($d.serial) ($($d.state))" }
        return @{ serial = $ready.serial; state = 'device';
                  device_count = $devices.Count; devices = $summary }
    }
    foreach ($d in $devices) {
        if ($d.state -eq 'unauthorized') {
            return @{ error = 'unauthorized';
                      detail = 'The phone is plugged in but has not allowed this computer yet. On the phone, tap Allow on the "Allow USB debugging?" prompt (tick "Always allow from this computer" so it never asks again), then run the command again. If no prompt appeared, unplug the phone, plug it back in, and watch the phone screen.' }
        }
    }
    foreach ($d in $devices) {
        if ($d.state -eq 'no_permissions') {
            return @{ error = 'adb_no_permissions';
                      detail = 'adb sees the phone but has no permission to talk to it. Unplug the phone, plug it back in, tap Allow if the phone asks, and try again. If it keeps happening, the USB driver for the phone may be missing - see SETUP.md, USB phone section.' }
        }
    }
    foreach ($d in $devices) {
        if ($d.state -eq 'offline') {
            return @{ error = 'device_offline';
                      detail = 'The phone is plugged in but offline to adb. Unplug it, plug it back in, and try again.' }
        }
    }
    return @{ error = 'no_device';
              detail = 'No Android phone was found over USB. Plug the phone in with a data cable (not a charge-only cable), turn on USB debugging (Settings > Developer options > USB debugging), and try again.' }
}

# One adb shell call against the ready phone. Returns the Invoke-Adb
# result hashtable.
function Invoke-AdbShell {
    param(
        [string]$Serial,
        [string[]]$ShellArgs,
        [int]$TimeoutSeconds = 10
    )
    $args = @('-s', $Serial, 'shell') + $ShellArgs
    return Invoke-Adb -Arguments $args -TimeoutSeconds $TimeoutSeconds
}

# One adb shell call, trimmed text only, '' on any failure.
# Never throws: a failed field is an empty field, not a dead checkup.
function Get-PhoneShellText {
    param(
        [string]$Serial,
        [string[]]$ShellArgs
    )
    try {
        $r = Invoke-AdbShell -Serial $Serial -ShellArgs $ShellArgs -TimeoutSeconds 10
        if ($null -eq $r -or -not $r.ok) { return '' }
        return "$($r.output)".Trim()
    }
    catch {
        return ''
    }
}

function Test-PhonePackage {
    param($Package)
    if ($null -eq $Package -or $Package -isnot [string]) { return $false }
    if ($Package.Length -eq 0 -or $Package.Length -gt 200) { return $false }
    return ($Package -match $script:PhonePackageRegex)
}

function Test-PhoneProtected {
    param([string]$Package)
    return ($script:PhoneProtectedPackages -contains $Package)
}

# installed / disabled state for one package, read back from the
# phone. Never throws; unknown means 'could not read', not 'gone'.
function Get-PhonePackageState {
    param(
        [string]$Serial,
        [string]$Package
    )
    $pathOut = Get-PhoneShellText $Serial @('pm', 'path', $Package)
    $installed = ($pathOut -match 'package:')
    $disabledOut = Get-PhoneShellText $Serial @('pm', 'list', 'packages', '-d')
    $disabled = $false
    foreach ($line in ($disabledOut -split "`n")) {
        if ($line.Trim() -eq "package:$Package") { $disabled = $true; break }
    }
    return @{ installed = [bool]$installed; disabled = [bool]$disabled }
}

function Invoke-CmdPhoneCheckup {
    param($CmdObj)
    $dev = Get-PhoneDevice
    if ($dev.ContainsKey('error')) { return $dev }
    $serial = $dev.serial
    $model = Get-PhoneShellText $serial @('getprop', 'ro.product.model')
    $android = Get-PhoneShellText $serial @('getprop', 'ro.build.version.release')
    $sdkRaw = Get-PhoneShellText $serial @('getprop', 'ro.build.version.sdk')
    $sdk = 0
    try { $sdk = [int]$sdkRaw.Trim() } catch { $sdk = 0 }
    $storageTotalKb = 0
    $storageAvailKb = 0
    $dfOut = Get-PhoneShellText $serial @('df', '-k', '/data')
    if (-not $dfOut) { $dfOut = Get-PhoneShellText $serial @('df', '-k', '/storage/emulated/0') }
    foreach ($line in ($dfOut -split "`n")) {
        $t = $line.Trim()
        if (-not $t -or $t.StartsWith('Filesystem')) { continue }
        $parts = ($t -split '\s+')
        if ($parts.Count -ge 4) {
            try {
                $storageTotalKb = [int64]$parts[1]
                $storageAvailKb = [int64]$parts[3]
            }
            catch { $storageTotalKb = 0; $storageAvailKb = 0 }
            break
        }
    }
    $batteryLevel = 0
    $charging = $false
    $batteryTempC = 0
    $battOut = Get-PhoneShellText $serial @('dumpsys', 'battery')
    if ($battOut) {
        $m = [regex]::Match($battOut, 'level:\s*(\d+)')
        if ($m.Success) { try { $batteryLevel = [int]$m.Groups[1].Value } catch { } }
        $m = [regex]::Match($battOut, 'status:\s*(\d+)')
        if ($m.Success) {
            $status = 0
            try { $status = [int]$m.Groups[1].Value } catch { }
            if ($status -eq 2 -or $status -eq 5) { $charging = $true }
        }
        if (-not $charging) {
            if ($battOut -match 'AC powered:\s*true' -or $battOut -match 'USB powered:\s*true') {
                $charging = $true
            }
        }
        $m = [regex]::Match($battOut, 'temperature:\s*(\d+)')
        if ($m.Success) {
            try { $batteryTempC = [math]::Round([int]$m.Groups[1].Value / 10.0, 1) } catch { }
        }
    }
    $ramTotalKb = 0
    $ramAvailKb = 0
    $memOut = Get-PhoneShellText $serial @('cat', '/proc/meminfo')
    if ($memOut) {
        $m = [regex]::Match($memOut, 'MemTotal:\s*(\d+)')
        if ($m.Success) { try { $ramTotalKb = [int64]$m.Groups[1].Value } catch { } }
        $m = [regex]::Match($memOut, 'MemAvailable:\s*(\d+)')
        if ($m.Success) { try { $ramAvailKb = [int64]$m.Groups[1].Value } catch { } }
    }
    $appCount = 0
    $pmOut = Get-PhoneShellText $serial @('pm', 'list', 'packages')
    if ($pmOut) {
        foreach ($line in ($pmOut -split "`n")) {
            if ($line.Trim().StartsWith('package:')) { $appCount++ }
        }
    }
    if (-not $model -and -not $android -and $appCount -eq 0 -and $storageTotalKb -eq 0) {
        return @{ error = 'phone_unreadable'; serial = $serial;
                  detail = 'The phone answered adb but none of its details could be read. Unplug the phone, plug it back in, tap Allow if it asks, and try again.' }
    }
    if ($model.Length -gt 100) { $model = $model.Substring(0, 100) }
    if ($android.Length -gt 50) { $android = $android.Substring(0, 50) }
    return @{
        serial = $serial
        model = $model
        android_version = $android
        sdk = $sdk
        storage_total_kb = $storageTotalKb
        storage_available_kb = $storageAvailKb
        battery_level = $batteryLevel
        charging = [bool]$charging
        battery_temp_c = $batteryTempC
        ram_total_kb = $ramTotalKb
        ram_available_kb = $ramAvailKb
        app_count = $appCount
    }
}

function Invoke-CmdPhoneRepair {
    param($CmdObj)
    $kind = $CmdObj.kind
    $pkg = $CmdObj.package
    $kinds = @('clear_cache', 'disable', 'force_stop', 'uninstall')
    if (-not $kind -or $kind -isnot [string] -or ($kinds -notcontains $kind)) {
        return @{ error = 'bad_kind';
                  detail = "phone_repair needs 'kind' of: clear_cache, disable, force_stop, uninstall" }
    }
    # Protected-set check FIRST, before the regex: the bare name
    # 'android' is in the protected set but has no dot, so it fails
    # the regex - it must still be refused as protected, not merely
    # as a bad package. (The relay checks the regex first and so
    # answers bad_package for 'android'; either way it is refused
    # before it can ever reach the phone. The agent names the
    # refusal correctly.)
    if ($pkg -is [string] -and (Test-PhoneProtected $pkg)) {
        return @{ error = 'protected_package';
                  detail = "package $pkg is protected and is never repaired by the phone doctor" }
    }
    if (-not (Test-PhonePackage $pkg)) {
        return @{ error = 'bad_package';
                  detail = 'phone_repair needs a real package name (1-200 chars, letters/digits/underscore/dots, at least two dot-separated parts, first part starting with a letter)' }
    }
    $dev = Get-PhoneDevice
    if ($dev.ContainsKey('error')) { return $dev }
    $serial = $dev.serial
    $cmdId = $CmdObj.id
    Write-AuditLog ("phone_repair id={0} kind={1} package={2} serial={3}" -f $cmdId, $kind, $pkg, $serial)
    Write-Log ("phone_repair requested (id={0} kind={1} package={2} serial={3})" -f $cmdId, $kind, $pkg, $serial)
    $before = Get-PhonePackageState -Serial $serial -Package $pkg
    $shellArgs = @()
    if ($kind -eq 'clear_cache') { $shellArgs = @('pm', 'clear', $pkg) }
    elseif ($kind -eq 'disable') { $shellArgs = @('pm', 'disable-user', '--user', '0', $pkg) }
    elseif ($kind -eq 'force_stop') { $shellArgs = @('am', 'force-stop', $pkg) }
    elseif ($kind -eq 'uninstall') { $shellArgs = @('pm', 'uninstall', '--user', '0', $pkg) }
    $r = Invoke-AdbShell -Serial $serial -ShellArgs $shellArgs -TimeoutSeconds 20
    $after = Get-PhonePackageState -Serial $serial -Package $pkg
    $detail = ''
    if ($null -ne $r -and $r.output) {
        foreach ($line in ("$($r.output)" -split "`n")) {
            $t = $line.Trim()
            if ($t) { $detail = $t; break }
        }
    }
    if ($detail.Length -gt 200) { $detail = $detail.Substring(0, 200) }
    $success = $false
    if ($null -ne $r -and $r.ok -and -not $r.timed_out) {
        if ($r.output -match 'Success') { $success = $true }
        elseif ($kind -eq 'uninstall' -and -not $after.installed) { $success = $true }
        elseif ($kind -eq 'disable' -and $after.disabled) { $success = $true }
        elseif ($kind -eq 'force_stop' -and ($r.output -notmatch 'Failure|Error')) { $success = $true }
    }
    if ($r.timed_out) {
        return @{ error = 'repair_failed'; kind = $kind; package = $pkg; serial = $serial;
                  before = $before; after = $after;
                  detail = 'adb timed out while running the repair.' }
    }
    if (-not $success) {
        if (-not $detail) { $detail = 'the phone refused the repair (no detail from adb).' }
        return @{ error = 'repair_failed'; kind = $kind; package = $pkg; serial = $serial;
                  before = $before; after = $after; detail = $detail }
    }
    return @{ kind = $kind; package = $pkg; serial = $serial;
              before = $before; after = $after;
              success = $true; detail = $detail }
}
# END USB PHONE DRIVER (v1.3.5)

# Map of command name -> handler. Handlers take the command object and
# return a result hashtable. They must never throw: Invoke-Command wraps
# them.
$Handlers = @{
    'ping'    = { param($c) Invoke-CmdPing $c }
    'sysinfo' = { param($c) Invoke-CmdSysinfo $c }
    'smart'   = { param($c) Invoke-CmdSmart $c }
    'df'      = { param($c) Invoke-CmdDf $c }
    'ls'      = { param($c) Invoke-CmdLs $c }
    'cat'     = { param($c) Invoke-CmdCat $c }
    'dmesg'   = { param($c) Invoke-CmdDmesg $c }
    'exec'    = { param($c) Invoke-CmdExec $c }
    'clean'   = { param($c) Invoke-CmdClean $c }
    'repair'  = { param($c) Invoke-CmdRepair $c }
    'deep'    = { param($c) Invoke-CmdDeep $c }
    'uninstall' = { param($c) Invoke-CmdUninstall $c }
    'install' = { param($c) Invoke-CmdInstall $c }
    'phone_checkup' = { param($c) Invoke-CmdPhoneCheckup $c }
    'phone_repair' = { param($c) Invoke-CmdPhoneRepair $c }
}

# Screen commands live in kuro-doctor-remote-screen-v1.3.4.ps1 (deliverable 2).
# They are registered only when that file loaded above; without it the
# agent simply has no screenshot / mouse / type commands.
if ($script:RemoteScreenLoaded) {
    $Handlers['screenshot'] = { param($c) Invoke-CmdScreenshot $c }
    $Handlers['mouse']      = { param($c) Invoke-CmdMouse $c }
    $Handlers['type']       = { param($c) Invoke-CmdType $c }
}

function Invoke-Command {
    param($CmdObj)
    $cmdId = $CmdObj.id
    $name  = $CmdObj.cmd
    if (-not $name -or $name -isnot [string]) {
        return @{ id = $cmdId; done = $false; at = Get-NowIso;
                  result = @{ error = 'unknown_cmd';
                              detail = "command has no 'cmd' string" } }
    }
    $handler = $Handlers[$name]
    if ($null -eq $handler) {
        Write-Log "unknown command: $name (id=$cmdId)"
        return @{ id = $cmdId; done = $false; at = Get-NowIso;
                  result = @{ error = 'unknown_cmd';
                              detail = "no such command: $name" } }
    }
    try {
        $result = & $handler $CmdObj
    }
    catch {
        Write-Log "command '$name' (id=$cmdId) raised: $($_.Exception.Message)"
        return @{ id = $cmdId; done = $false; at = Get-NowIso;
                  result = @{ error = 'handler_error';
                              detail = $_.Exception.Message } }
    }
    if ($result -is [hashtable] -and $result.ContainsKey('error')) {
        # Any error-bearing result is a deliberate, reported outcome -
        # ack done:false so the operator sees the refusal (bad_path,
        # file_too_large, blocked, bad_coords, bad_action, bad_text,
        # and any other error code), but the agent stays healthy.
        return @{ id = $cmdId; done = $false; at = Get-NowIso; result = $result }
    }
    if ($result -isnot [hashtable]) { $result = @{ value = $result } }
    return @{ id = $cmdId; done = $true; at = Get-NowIso; result = $result }
}

function Get-CommandsFromPayload {
    param($Payload)
    # Normalise a GET /doctor/command response into a list of command
    # objects. Accepts a bare command {"cmd": ..., "id": ...},
    # {"command": {...}}, {"commands": [...]}, or an empty / no-command
    # body ({} / {"cmd": null}).
    if ($null -eq $Payload) { return @() }
    if ($Payload.commands -and $Payload.commands -is [System.Array]) {
        return @($Payload.commands)
    }
    # v1.2.1 fix (2026-11-19, proven live): `.command` is a wrapper ONLY
    # when it is an OBJECT carrying its own `cmd` property. The relay
    # stores an exec command as {"cmd":"exec", "command":"<text>"} - a
    # STRING-valued `command` field - and the old check
    # ($null -ne $Payload.command) returned that bare text string as if
    # it were a command object. Invoke-Command then saw no `cmd` and
    # acked unknown_cmd "command has no 'cmd' string" with an empty id
    # (live ack 2026-11-19T22:03:40Z) - exec was simply broken in v1.2.
    # Invoke-RestMethod materialises JSON objects as [pscustomobject]
    # (strings stay [string]); the hashtable arm is belt-and-braces for
    # any -AsHashtable parse path. A bare string must NEVER be returned
    # as a command object.
    if ($null -ne $Payload.command -and
        ($Payload.command -is [pscustomobject] -or $Payload.command -is [hashtable]) -and
        $null -ne $Payload.command.cmd) {
        return @($Payload.command)
    }
    if ($Payload.cmd) {
        return @($Payload)
    }
    return @()
}

function Invoke-PollOnce {
    $payload = Invoke-RelayGet -Path '/doctor/command'
    if ($null -eq $payload) { return 0 }  # relay unreachable; logged inside
    $commands = Get-CommandsFromPayload -Payload $payload
    $executed = 0
    foreach ($cmdObj in $commands) {
        $cmdId = $cmdObj.id
        if ($null -ne $cmdId) { $script:LastCommandAt = Get-Date }
        if ($null -ne $cmdId -and $SeenIds.Contains("$cmdId")) {
            # v1.3.0 quiet duplicates: log the skip at most ONCE per
            # command id - the live agent window was flooded with these.
            if (-not $script:LoggedSkips.Contains("$cmdId")) {
                Write-Log "skipping duplicate command id=$cmdId"
                [void]$script:LoggedSkips.Add("$cmdId")
            }
            continue
        }
        # v1.3.1 QUEUE RECEIPT: tell the relay this command is taken
        # BEFORE executing it, so the queue head pops and the next
        # queued command can follow. Retry once on failure; if the
        # receipt still fails, SKIP execution this cycle - do not
        # execute a command whose receipt was not recorded (a
        # restart before the receipt lands could double-execute
        # it). The id is NOT added to SeenIds until the receipt
        # succeeds, so the next poll retries the receipt and then
        # executes. Costs one poll cycle of latency; matches the
        # Mac agent.
        if ($null -ne $cmdId) {
            $receipt = Invoke-RelayPost -Path '/doctor/received' -Payload @{ id = "$cmdId" }
            if ($null -eq $receipt) {
                Write-Log "receipt for id=$cmdId NOT delivered (retrying once)"
                $receipt = Invoke-RelayPost -Path '/doctor/received' -Payload @{ id = "$cmdId" }
            }
            if ($null -eq $receipt) {
                Write-Log "receipt for id=$cmdId FAILED after retry - skipping execution this cycle, will retry on the next poll"
                continue
            }
            [void]$SeenIds.Add("$cmdId")
            # v1.3.1: NO LoggedSkips.Clear() here. Clearing the set on
            # every new command id re-armed logging for old ids, so
            # one id could log its duplicate skip more than once.
            # The set lives for the process lifetime; a skip still
            # logs at most once per id.
        }
        $name = $cmdObj.cmd
        Write-Log "executing command '$name' (id=$cmdId)"
        $ack = Invoke-Command -CmdObj $cmdObj
        $executed++
        # Acks are retried (up to 3 attempts, 2s apart) - a failed
        # ack post must never silently drop a result.
        [void](Invoke-PostAck -Ack $ack)
    }
    # Every poll: check pending async jobs (exec / repair / deep / uninstall / install) for
    # completions and timeouts, and post their completion acks.
    Invoke-CheckPendingJobs
    return $executed
}

# ---------------------------------------------------------------- adaptive polling
# v1.3.1 ADAPTIVE POLLING: 1s while active (a command seen in the
# last 2 min, or a job pending), 10s when idle. v1.3.6 removed the
# ~60s heartbeat (it alone wrote 1,440 KV entries/day against a
# 1,000/day free cap): idle cost is now ~8,640 poll GETs/day
# (reads, not KV writes) plus one boot report, down from ~86k
# requests/day at a flat 1s poll.

function Get-PollIntervalSeconds {
    if ($script:PendingJobs.Count -gt 0) { return $PollIntervalSeconds }
    if ($null -ne $script:LastCommandAt -and ((Get-Date) - $script:LastCommandAt).TotalSeconds -lt 120) {
        return $PollIntervalSeconds
    }
    return $IdlePollIntervalSeconds
}

# ---------------------------------------------------------------- main

Write-Log "KUROdoctor agent v$Version starting, relay=$Relay"

if ($SweepOnly) {
    # Test mode: the sweep, and nothing else - no relay traffic.
    # (The background scan, if one starts, is abandoned on exit;
    # the printed malware_scan section shows "pending".)
    $sweep = Invoke-BlindSweep
    $sweep | ConvertTo-Json -Depth 10
    Write-Log 'sweep-only mode: exiting'
    exit 0
}

# Boot report first, always - even if the relay is down we keep going.
# v1.3.6 BOOT-RETRY: if this first report fails to deliver, the main
# loop retries it once per poll iteration ONLY until it first succeeds,
# then never again (see $script:BootReportDelivered). The blind sweep
# runs inside New-Report, before any command is polled.
$script:BootReportDelivered = Send-Report

if ($ReportOnly) {
    Write-Log 'report-only mode: exiting'
    exit 0
}

if ($Once) {
    Invoke-PollOnce | Out-Null
    Test-ScanFollowup
    Write-Log 'once mode: exiting'
    exit 0
}

Write-Log "polling $Relay/doctor/command: ${PollIntervalSeconds}s while active, ${IdlePollIntervalSeconds}s when idle (no periodic heartbeat - boot report once, then acks only)"
Write-Log 'live feed: change-only frames to /doctor/frame (max 1 per 5s, 60s liveness) when the screen file is loaded'
while ($true) {
    try {
        Invoke-PollOnce | Out-Null
    }
    catch {
        Write-Log "poll cycle raised (continuing): $($_.Exception.Message)"
    }
    Test-ScanFollowup
    # v1.3.4 live feed: one tick per poll iteration, when the
    # screen file loaded. The tick itself rate-limits (max 1
    # post per 5s) and never throws into this loop.
    if ($script:RemoteScreenLoaded) {
        Send-KDDoctorFrameTick -Relay $Relay -Version $Version
    }
    if (-not $script:BootReportDelivered) {
        # v1.3.6 BOOT-RETRY (bounded): the boot report has not delivered
        # yet, so retry it once per poll iteration - ONLY until it first
        # succeeds, then never again. No steady-state write is created:
        # once $script:BootReportDelivered is true this block never runs.
        $script:BootReportDelivered = Send-Report
    }
    Start-Sleep -Seconds (Get-PollIntervalSeconds)
}
