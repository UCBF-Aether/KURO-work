﻿#Requires -Version 5.1
<#
.SYNOPSIS
    KUROdoctor remote screen control (deliverable 2: SCREEN CONTROL),
    v1.3.4 screen file (capture v1.1 + type focus + live feed).

.DESCRIPTION
    Separate screen-control file for the KUROdoctor Windows agent.
    It owns screen capture and input only: screenshot, mouse, type.
    It does NOT own command polling, relay I/O, the blind sweep, or
    any other agent work. That work stays in the agent file.

    v1.1 (2026-11-19) - Defender-safe capture. Windows Defender
    flagged the v1.0 capture as HackTool:PowerShell/
    EmpireGetScreenshot.C because it used the .NET screen-copy
    call - the same pattern Empire's PowerShell screenshot uses.
    v1.1 captures with raw Win32 GDI BitBlt via P/Invoke (GetDC,
    CreateCompatibleDC, CreateCompatibleBitmap, SelectObject,
    BitBlt SRCCOPY, then Bitmap.FromHbitmap) and the existing JPEG
    encode / scale-down loop. The old screen-copy call is gone
    from this file entirely - no trace of it in code or comments.
    Mouse (SetCursorPos + mouse_event) and type (SendKeys) are
    UNCHANGED. Interface identical: JPEG <=200KB, image_b64 in
    the ack result, width/height/bytes.

    v1.3.4 (2026-11-20) - TYPE FOCUS + LIVE FEED. Two changes.
    (1) Invoke-CmdType accepts an optional `process` field and
    focuses that window first (SetForegroundWindow, SW_RESTORE
    if minimised, AttachThreadInput fallback). With no
    identifier it focuses the current foreground window unless
    that is the agent's own console, else the most recently
    started process with a visible main window (excluding the
    agent PID and console-host processes). If no window can be
    focused it returns an error and types NOTHING - never type
    blind again. Text validation is unchanged.
    (2) Send-KDDoctorFrameTick posts change-only live-feed
    frames to POST /doctor/frame (same GDI BitBlt capture,
    JPEG q40, 40KB cap, hard cap 1 post/5s, 60s liveness
    re-post). The agent main loop calls it once per poll
    iteration. It never throws into the agent loop.
    NEEDS A REAL WINDOWS RUN - the focus and feed paths have
    never executed. The screenshot/mouse paths are the proven
    v1.1 code, unchanged except for the shared capture helper.

    NEEDS A REAL WINDOWS RUN - never executed.
    No PowerShell exists on the build VM. This file was verified by
    static scans only (ASCII / CRLF / BOM, quote and comment balance,
    forbidden-command scan). It has never run on Windows. Do not treat
    it as tested until it has run on a real Windows host.

    DECISION (made by the coordinator):
    Screen control lives in this SEPARATE file, not folded into the
    v1.2 agent. One file stays focused on command control; this file
    owns screen capture + input. The v1.2 agent loads / dot-sources
    this file when present, or the operator runs it alongside the
    agent. See WIRING below.

    WIRING (v1.2 agent):
    Dot-source this file from the agent directory, from the agent
    script (no auto-run on load - dot-sourcing only defines the
    functions below; the only top-level statement is a $false flag
    that gates lazy API setup, and no capture or input happens):
        . "$PSScriptRoot\kuro-doctor-remote-screen.ps1"
    Then either register the three handlers in the agent $Handlers
    map (same shape as the v1.0.1 agent handlers: each takes the
    command object and returns a result hashtable):
        $Handlers['screenshot'] = { param($c) Invoke-CmdScreenshot $c }
        $Handlers['mouse']      = { param($c) Invoke-CmdMouse $c }
        $Handlers['type']       = { param($c) Invoke-CmdType $c }
    Or delegate a whole relay command to the dispatcher, which
    returns a full ack hashtable { id, done, at, result }:
        $ack = Invoke-KDRemoteScreenCommand -CmdObj $cmdObj
    Or the operator runs this file alongside the agent by
    dot-sourcing it in an interactive session and calling the
    functions directly. Nothing in this file polls the relay and
    nothing runs on load.

    FUNCTIONS EXPOSED:
        Invoke-CmdScreenshot            handler for cmd 'screenshot'
        Invoke-CmdMouse                 handler for cmd 'mouse'
        Invoke-CmdType                  handler for cmd 'type'
        Get-KDRemoteScreenCapture       shared GDI BitBlt capture (internal)
        Set-KDRemoteScreenFocus         focus a window before typing (internal)
        Send-KDDoctorFrameTick          live-feed sender, called by the agent loop
        Invoke-KDRemoteScreenCommand    dispatcher for all three cmds
        Write-KDRemoteScreenAudit       audit-log writer (internal)
        Initialize-KDRemoteScreenApis   lazy .NET / P/Invoke setup
        Get-KDRemoteScreenScriptDir     script directory helper
        Get-KDRemoteScreenArg           command-arg reader helper
        Get-KDRemoteScreenNowIso        UTC ISO timestamp helper

    RELAY COMMANDS (allow-list extended by the coordinator; the relay
    is your own Cloudflare Worker URL (see relay-config.json), polled by the agent (1s while active, 10s when idle);
    these cmd names and args must be used exactly):
        screenshot  no args.
                    Ack result:
                      { "width": <int>, "height": <int>,
                        "bytes": <int>, "format": "jpeg",
                        "image_b64": <string> }
        mouse       args: x (int, absolute screen pixels),
                    y (int, absolute screen pixels),
                    action (one of "move", "left_click",
                    "right_click", "double_click").
                    Ack result:
                      { "x": <int>, "y": <int>, "action": <string> }
                    Out-of-bounds x/y is refused: ack done:false,
                    result { "error": "bad_coords", "detail": ... }.
                    Unknown action is refused the same way with
                    error "bad_action".
        type        args: text (required string, plain text only,
                    max 1000 chars); process (optional string,
                    e.g. "notepad++" - the window to focus first).
                    Ack result:
                      { "typed_chars": <int>,
                        "process": <string>,
                        "focused_process": <string>,
                        "focused_pid": <int> }
                    If no window can be focused the command is
                    refused (error no_window / focus_failed) and
                    NOTHING is typed.
                    Text containing a control character other than
                    newline or tab is refused: ack done:false,
                    result { "error": "bad_text", "detail": ... }.
                    Text over 1000 chars is refused the same way.

    HOW EACH COMMAND WORKS:
        screenshot: .NET System.Drawing / System.Windows.Forms for
                    bounds, raw Win32 GDI BitBlt via P/Invoke for
                    the copy (v1.1 - see the note above), then saved
                    as JPEG at quality 60. The image is scaled
                    down by half steps (1.0, 0.5, 0.25, 0.125) until
                    it fits the 200 KB cap (204800 bytes); the result
                    never exceeds 200 KB. The returned width/height
                    are the final (possibly scaled) image dimensions.
                    The image is returned base64 in the ack result.
        mouse: .NET P/Invoke via Add-Type (user32.dll): SetCursorPos
                    plus mouse_event. SetCursorPos moves the cursor;
                    mouse_event sends the button down/up pair for a
                    click. Chosen over Cursor.Position alone so the
                    click itself is an explicit native input event.
                    The P/Invoke type is registered lazily by
                    Initialize-KDRemoteScreenApis on first use.
        type: the target window is focused FIRST (see v1.3.4
                    note above); then plain text only via
                    System.Windows.Forms.SendKeys
                    (SendKeys.SendWait). SendKeys special characters
                    (+ ^ % ~ ( ) { } [ ]) are escaped by wrapping
                    them in braces; newline becomes {ENTER} and tab
                    becomes {TAB}. SendKeys needs an interactive
                    desktop session; it cannot type to a locked
                    screen and it cannot see what field has focus.

    OPERATOR RULE - PASSWORD FIELDS:
    NEVER use the 'type' command on a password or login field.
    This function cannot detect what field has focus, so this is
    an operator rule, not a technical block. The operator must
    check the screen (screenshot first) and must only type into
    a field they have confirmed is not a password or login field.
    Do not type credentials, one-time codes, or secrets with
    this command.

    AUDIT:
    Every command execution writes one audit log entry
    (timestamp, command, args, result) to a log file next to
    this script: remote-screen-audit.log. The audit line never
    contains the screenshot base64 and never contains typed
    text (only the typed character count); the mouse line logs
    x, y, and action only. Audit failure never breaks a command.
    The live feed logs only its first successful post and any
    failure (cmd=frame) - never one line per frame.

    SAFETY:
    No screen capture and no input without a relay command.
    Nothing in this file runs on load. No reboot, shutdown,
    format, or wipe code anywhere. No credential access. No
    lock-screen bypass. No external modules, no downloads,
    PowerShell and .NET only.

    ENCODING:
    This file must stay pure ASCII after the BOM, CRLF line
    endings only, UTF-8 BOM present (bytes EF BB BF at the
    start). No non-ASCII characters anywhere. The v1.0 agent
    failed to parse on a real Windows PC because of an encoding
    fault; do not reintroduce one. Edit only with an editor
    that preserves ASCII + CRLF + BOM.
#>

$script:KDRemoteScreenApisLoaded = $false

# ---------------------------------------------------------------- helpers

function Get-KDRemoteScreenNowIso {
    return (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
}

function Get-KDRemoteScreenScriptDir {
    if ($PSScriptRoot) { return $PSScriptRoot }
    return (Get-Location).Path
}

function Get-KDRemoteScreenArg {
    param($CmdObj, [string]$Name)
    if ($null -eq $CmdObj) { return $null }
    if ($CmdObj -is [hashtable]) {
        if ($CmdObj.ContainsKey($Name)) { return $CmdObj[$Name] }
        return $null
    }
    $prop = $CmdObj.PSObject.Properties[$Name]
    if ($null -ne $prop) { return $prop.Value }
    return $null
}

function Write-KDRemoteScreenAudit {
    param(
        [string]$Cmd,
        [string]$ArgsText,
        [bool]$Done,
        [string]$ResultText
    )
    try {
        $dir = Get-KDRemoteScreenScriptDir
        $path = Join-Path $dir 'remote-screen-audit.log'
        $ts = Get-KDRemoteScreenNowIso
        $line = "$ts cmd=$Cmd args=$ArgsText done=$Done result=$ResultText"
        Add-Content -Path $path -Value $line -Encoding ascii -ErrorAction Stop
    }
    catch {
        # Audit must never break a command. Swallow silently.
    }
}

function Initialize-KDRemoteScreenApis {
    if ($script:KDRemoteScreenApisLoaded) { return }
    Add-Type -AssemblyName System.Drawing
    Add-Type -AssemblyName System.Windows.Forms
    $mouseCode = @'
using System;
using System.Runtime.InteropServices;
public static class KDRemoteMouse {
  [DllImport("user32.dll", SetLastError = true)]
  public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll", SetLastError = true)]
  public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
  public const uint MOUSEEVENTF_LEFTUP = 0x0004;
  public const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
  public const uint MOUSEEVENTF_RIGHTUP = 0x0010;
  public static void LeftClick() { mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero); mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero); }
  public static void RightClick() { mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, UIntPtr.Zero); mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, UIntPtr.Zero); }
}
'@
    Add-Type -TypeDefinition $mouseCode -Language CSharp
    $gdiCode = @'
using System;
using System.Runtime.InteropServices;
public static class KDRemoteGDI {
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern IntPtr CreateCompatibleDC(IntPtr hdc);
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int nWidth, int nHeight);
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern bool BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, uint dwRop);
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern bool DeleteObject(IntPtr hObject);
  [DllImport("gdi32.dll", SetLastError = true)]
  public static extern bool DeleteDC(IntPtr hdc);
  [DllImport("user32.dll", SetLastError = true)]
  public static extern IntPtr GetDC(IntPtr hWnd);
  [DllImport("user32.dll", SetLastError = true)]
  public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
  public const uint SRCCOPY = 0x00CC0020;
}
'@
    Add-Type -TypeDefinition $gdiCode -Language CSharp
    $focusCode = @'
using System;
using System.Runtime.InteropServices;
public static class KDRemoteFocus {
  [DllImport("user32.dll", SetLastError = true)]
  public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll", SetLastError = true)]
  public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll", SetLastError = true)]
  public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll", SetLastError = true)]
  public static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll", SetLastError = true)]
  public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
  [DllImport("user32.dll", SetLastError = true)]
  public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
  [DllImport("kernel32.dll")]
  public static extern uint GetCurrentThreadId();
  public const int SW_RESTORE = 9;
}
'@
    Add-Type -TypeDefinition $focusCode -Language CSharp
    $script:KDRemoteScreenApisLoaded = $true
}

# ---------------------------------------------------------------- screenshot

# ---------------------------------------------------------------- capture
# Shared capture: raw Win32 GDI BitBlt via P/Invoke, then JPEG encode
# with a scale-down loop. This is the proven v1.1 capture path, moved
# here verbatim and parameterised so the screenshot command and the
# live-feed sender share it. Returns @{ Bytes; Width; Height } or
# @{ error = 'screenshot_failed'; detail = ... }.

function Get-KDRemoteScreenCapture {
    param(
        [int]$Quality,
        [int]$MaxBytes,
        [array]$Scales
    )
    $bitmap = $null
    try {
        Initialize-KDRemoteScreenApis
        $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $origWidth = $bounds.Width
        $origHeight = $bounds.Height
        if ($origWidth -le 0 -or $origHeight -le 0) {
            throw 'primary screen has no usable bounds'
        }
        # v1.1: raw Win32 GDI BitBlt via P/Invoke (see the header
        # note). The old .NET screen-copy call tripped Defender's
        # Empire screenshot signature; this plain GDI path does the
        # same copy without that pattern.
        $hdcScreen = [IntPtr]::Zero
        $hdcMem = [IntPtr]::Zero
        $hbm = [IntPtr]::Zero
        $hOld = [IntPtr]::Zero
        try {
            $hdcScreen = [KDRemoteGDI]::GetDC([IntPtr]::Zero)
            if ($hdcScreen -eq [IntPtr]::Zero) { throw 'GetDC failed' }
            $hdcMem = [KDRemoteGDI]::CreateCompatibleDC($hdcScreen)
            if ($hdcMem -eq [IntPtr]::Zero) { throw 'CreateCompatibleDC failed' }
            $hbm = [KDRemoteGDI]::CreateCompatibleBitmap($hdcScreen, $origWidth, $origHeight)
            if ($hbm -eq [IntPtr]::Zero) { throw 'CreateCompatibleBitmap failed' }
            $hOld = [KDRemoteGDI]::SelectObject($hdcMem, $hbm)
            $copied = [KDRemoteGDI]::BitBlt($hdcMem, 0, 0, $origWidth, $origHeight, $hdcScreen, $bounds.Left, $bounds.Top, [KDRemoteGDI]::SRCCOPY)
            if (-not $copied) { throw 'BitBlt failed' }
            $bitmap = [System.Drawing.Bitmap]::FromHbitmap($hbm)
        }
        finally {
            if ($hOld -ne [IntPtr]::Zero -and $hdcMem -ne [IntPtr]::Zero) { [void][KDRemoteGDI]::SelectObject($hdcMem, $hOld) }
            if ($hbm -ne [IntPtr]::Zero) { [void][KDRemoteGDI]::DeleteObject($hbm) }
            if ($hdcMem -ne [IntPtr]::Zero) { [void][KDRemoteGDI]::DeleteDC($hdcMem) }
            if ($hdcScreen -ne [IntPtr]::Zero) { [void][KDRemoteGDI]::ReleaseDC([IntPtr]::Zero, $hdcScreen) }
        }
        $codec = $null
        foreach ($c in [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders()) {
            if ($c.MimeType -eq 'image/jpeg') { $codec = $c }
        }
        if ($null -eq $codec) {
            throw 'JPEG encoder not found'
        }
        $encoderParams = New-Object System.Drawing.Imaging.EncoderParameters(1)
        $encoderParams.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter(
            [System.Drawing.Imaging.Encoder]::Quality, [long]$Quality)
        $finalBytes = $null
        $finalWidth = $origWidth
        $finalHeight = $origHeight
        foreach ($scale in $Scales) {
            $w = [int][Math]::Max(1, [Math]::Round($origWidth * $scale))
            $h = [int][Math]::Max(1, [Math]::Round($origHeight * $scale))
            $workBitmap = $bitmap
            $scaled = $null
            if ($scale -lt 1.0) {
                $scaled = New-Object System.Drawing.Bitmap($w, $h)
                $g2 = [System.Drawing.Graphics]::FromImage($scaled)
                try {
                    $g2.DrawImage($bitmap, 0, 0, $w, $h)
                }
                finally {
                    $g2.Dispose()
                }
                $workBitmap = $scaled
            }
            $stream = New-Object System.IO.MemoryStream
            try {
                $workBitmap.Save($stream, $codec, $encoderParams)
                $candidate = $stream.ToArray()
            }
            finally {
                $stream.Dispose()
                if ($null -ne $scaled) { $scaled.Dispose() }
            }
            $finalBytes = $candidate
            $finalWidth = $w
            $finalHeight = $h
            if ($candidate.Length -le $MaxBytes) { break }
        }
        $encoderParams.Dispose()
        $bitmap.Dispose()
        $bitmap = $null
        return @{
            Bytes = $finalBytes
            Width = $finalWidth
            Height = $finalHeight
        }
    }
    catch {
        if ($null -ne $bitmap) { $bitmap.Dispose() }
        return @{ error = 'screenshot_failed'; detail = $_.Exception.Message }
    }
}

# ---------------------------------------------------------------- screenshot

function Invoke-CmdScreenshot {
    param($CmdObj)
    $auditArgs = 'screenshot'
    # Same settings as v1.1: JPEG quality 60, 200KB cap, scales
    # 1.0 / 0.5 / 0.25 / 0.125. Behaviour identical; the capture
    # itself now lives in Get-KDRemoteScreenCapture above.
    $cap = Get-KDRemoteScreenCapture -Quality 60 -MaxBytes (200 * 1024) -Scales @(1.0, 0.5, 0.25, 0.125)
    if ($cap -is [hashtable] -and $cap.ContainsKey('error')) {
        Write-KDRemoteScreenAudit -Cmd 'screenshot' -ArgsText $auditArgs -Done $false -ResultText ("error screenshot_failed detail={0}" -f $cap.detail)
        return @{ error = 'screenshot_failed'; detail = $cap.detail }
    }
    $b64 = [System.Convert]::ToBase64String($cap.Bytes)
    $resultText = ("ok width={0} height={1} bytes={2}" -f $cap.Width, $cap.Height, $cap.Bytes.Length)
    Write-KDRemoteScreenAudit -Cmd 'screenshot' -ArgsText $auditArgs -Done $true -ResultText $resultText
    return @{
        width = $cap.Width
        height = $cap.Height
        bytes = $cap.Bytes.Length
        format = 'jpeg'
        image_b64 = $b64
    }
}

# ---------------------------------------------------------------- mouse

function Invoke-CmdMouse {
    param($CmdObj)
    $xRaw = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'x'
    $yRaw = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'y'
    $action = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'action'
    $auditArgs = ("x={0} y={1} action={2}" -f $xRaw, $yRaw, $action)
    $x = 0
    $y = 0
    try { $x = [int]$xRaw } catch {
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText 'error bad_coords detail=x is not an integer'
        return @{ error = 'bad_coords'; detail = 'x is not an integer' }
    }
    try { $y = [int]$yRaw } catch {
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText 'error bad_coords detail=y is not an integer'
        return @{ error = 'bad_coords'; detail = 'y is not an integer' }
    }
    if ($action -isnot [string]) {
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText 'error bad_action detail=action is missing'
        return @{ error = 'bad_action'; detail = 'action is missing' }
    }
    if ($action -notin @('move', 'left_click', 'right_click', 'double_click')) {
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText ("error bad_action detail=unknown action: {0}" -f $action)
        return @{ error = 'bad_action'; detail = ("unknown action: {0}" -f $action) }
    }
    try {
        Initialize-KDRemoteScreenApis
        $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $left = $bounds.Left
        $top = $bounds.Top
        $right = $bounds.Left + $bounds.Width
        $bottom = $bounds.Top + $bounds.Height
        if ($x -lt $left -or $x -ge $right -or $y -lt $top -or $y -ge $bottom) {
            $detail = ("coords out of bounds: x={0} y={1} bounds left={2} top={3} width={4} height={5}" -f $x, $y, $left, $top, $bounds.Width, $bounds.Height)
            Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText ("error bad_coords detail={0}" -f $detail)
            return @{ error = 'bad_coords'; detail = $detail }
        }
        $moved = [KDRemoteMouse]::SetCursorPos($x, $y)
        if (-not $moved) {
            throw 'SetCursorPos failed'
        }
        Start-Sleep -Milliseconds 50
        if ($action -eq 'left_click') {
            [KDRemoteMouse]::LeftClick()
        }
        elseif ($action -eq 'right_click') {
            [KDRemoteMouse]::RightClick()
        }
        elseif ($action -eq 'double_click') {
            [KDRemoteMouse]::LeftClick()
            Start-Sleep -Milliseconds 80
            [KDRemoteMouse]::LeftClick()
        }
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $true -ResultText ("ok x={0} y={1} action={2}" -f $x, $y, $action)
        return @{ x = $x; y = $y; action = $action }
    }
    catch {
        $msg = $_.Exception.Message
        Write-KDRemoteScreenAudit -Cmd 'mouse' -ArgsText $auditArgs -Done $false -ResultText ("error mouse_failed detail={0}" -f $msg)
        return @{ error = 'mouse_failed'; detail = $msg }
    }
}

# ---------------------------------------------------------------- type

# ---------------------------------------------------------------- type

function Invoke-CmdType {
    param($CmdObj)
    $text = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'text'
    if ($null -eq $text) {
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText 'chars=0 (text not logged)' -Done $false -ResultText 'error bad_text detail=text is missing'
        return @{ error = 'bad_text'; detail = 'text is missing' }
    }
    if ($text -isnot [string]) {
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText 'chars=0 (text not logged)' -Done $false -ResultText 'error bad_text detail=text is not a string'
        return @{ error = 'bad_text'; detail = 'text is not a string' }
    }
    $auditArgs = ("chars={0} (text not logged)" -f $text.Length)
    if ($text.Length -eq 0) {
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText 'error bad_text detail=text is empty'
        return @{ error = 'bad_text'; detail = 'text is empty' }
    }
    if ($text.Length -gt 1000) {
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText 'error bad_text detail=text exceeds 1000 chars'
        return @{ error = 'bad_text'; detail = 'text exceeds 1000 chars' }
    }
    foreach ($ch in $text.ToCharArray()) {
        if ([char]::IsControl($ch) -and $ch -ne "`n" -and $ch -ne "`r" -and $ch -ne "`t") {
            $detail = ("text contains a control character U+{0:X4}" -f [int]$ch)
            Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText ("error bad_text detail={0}" -f $detail)
            return @{ error = 'bad_text'; detail = $detail }
        }
    }
    # v1.3.4: optional `process` field (e.g. "notepad++"). Validated
    # here; the window is focused before any key is sent.
    $process = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'process'
    $processLabel = '(auto)'
    if ($null -ne $process) {
        if ($process -isnot [string]) {
            Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText 'error bad_process detail=process is not a string'
            return @{ error = 'bad_process'; detail = 'process is not a string' }
        }
        if ($process.Length -eq 0 -or $process.Length -gt 200) {
            Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText 'error bad_process detail=process must be 1-200 chars'
            return @{ error = 'bad_process'; detail = 'process must be 1-200 chars' }
        }
        foreach ($ch in $process.ToCharArray()) {
            if ([char]::IsControl($ch)) {
                Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText 'error bad_process detail=process contains a control character'
                return @{ error = 'bad_process'; detail = 'process contains a control character' }
            }
        }
        $processLabel = $process
    }
    $auditArgs = ("chars={0} process={1} (text not logged)" -f $text.Length, $processLabel)
    try {
        Initialize-KDRemoteScreenApis
        # Focus FIRST. If no window can be focused, type NOTHING.
        $focus = Set-KDRemoteScreenFocus -ProcessName $process
        if ($focus -is [hashtable] -and $focus.ContainsKey('error')) {
            Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText ("error {0} detail={1}" -f $focus.error, $focus.detail)
            return @{ error = $focus.error; detail = $focus.detail }
        }
        $normalized = $text.Replace("`r`n", "`n").Replace("`r", "`n")
        $builder = New-Object System.Text.StringBuilder
        foreach ($ch in $normalized.ToCharArray()) {
            if ($ch -eq "`n") {
                [void]$builder.Append('{ENTER}')
            }
            elseif ($ch -eq "`t") {
                [void]$builder.Append('{TAB}')
            }
            elseif ($ch -eq '+' -or $ch -eq '^' -or $ch -eq '%' -or $ch -eq '~' -or $ch -eq '(' -or $ch -eq ')' -or $ch -eq '{' -or $ch -eq '}' -or $ch -eq '[' -or $ch -eq ']') {
                [void]$builder.Append('{')
                [void]$builder.Append($ch)
                [void]$builder.Append('}')
            }
            else {
                [void]$builder.Append($ch)
            }
        }
        [System.Windows.Forms.SendKeys]::SendWait($builder.ToString())
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $true -ResultText ("ok typed_chars={0} process={1} focused={2}" -f $text.Length, $processLabel, $focus.ProcessName)
        return @{ typed_chars = $text.Length; process = $processLabel; focused_process = $focus.ProcessName; focused_pid = $focus.ProcessId }
    }
    catch {
        $msg = $_.Exception.Message
        Write-KDRemoteScreenAudit -Cmd 'type' -ArgsText $auditArgs -Done $false -ResultText ("error type_failed detail={0}" -f $msg)
        return @{ error = 'type_failed'; detail = $msg }
    }
}

# ---------------------------------------------------------------- focus
# v1.3.4 - focus the window keys will land in, BEFORE SendKeys.
# Returns @{ Handle; ProcessId; ProcessName } or
# @{ error = 'no_window' | 'focus_failed'; detail = ... }.
#   -ProcessName given: the (most recently started) process with
#    that name and a visible main window. A ".exe" suffix is
#    accepted and stripped. No match -> no_window.
#   -ProcessName absent: the current foreground window, unless it
#    is the agent's own console (its PID, or a console-host process
#    name); then the most recently started process with a visible
#    main window, excluding the agent PID and console hosts.
#    Nothing suitable -> no_window.
# Focus attempt: restore if minimised, SetForegroundWindow, with an
# AttachThreadInput fallback when the plain call fails. The caller
# verifies the foreground window afterwards; a mismatch is
# focus_failed. Never types blind: on any error the caller returns
# without sending keys.

function Set-KDRemoteScreenFocus {
    param([string]$ProcessName)
    try {
        Initialize-KDRemoteScreenApis
        $consoleNames = @('conhost', 'powershell', 'pwsh', 'cmd', 'WindowsTerminal', 'wt')
        $target = $null
        if (-not [string]::IsNullOrWhiteSpace($ProcessName)) {
            $want = $ProcessName.Trim()
            if ($want.ToLower().EndsWith('.exe')) { $want = $want.Substring(0, $want.Length - 4) }
            $cands = @()
            foreach ($p in (Get-Process)) {
                try {
                    if ($p.ProcessName -ieq $want -and $p.MainWindowHandle -ne 0) { $cands += $p }
                }
                catch { }
            }
            if ($cands.Count -eq 0) {
                return @{ error = 'no_window'; detail = ("no visible window for process: {0}" -f $ProcessName) }
            }
            $target = $cands | Sort-Object { try { $_.StartTime } catch { [datetime]::MinValue } } -Descending | Select-Object -First 1
        }
        else {
            $fg = [KDRemoteFocus]::GetForegroundWindow()
            $fgPid = [uint32]0
            if ($fg -ne [IntPtr]::Zero) {
                [void][KDRemoteFocus]::GetWindowThreadProcessId($fg, [ref]$fgPid)
            }
            $fgProc = $null
            if ($fgPid -ne 0) {
                try { $fgProc = Get-Process -Id $fgPid -ErrorAction Stop } catch { }
            }
            $fgIsConsole = ($fgPid -eq $PID) -or ($null -ne $fgProc -and $fgProc.ProcessName -in $consoleNames)
            if ($fg -ne [IntPtr]::Zero -and -not $fgIsConsole) {
                $fgName = ''
                if ($null -ne $fgProc) { $fgName = $fgProc.ProcessName }
                return @{ Handle = $fg; ProcessId = [int]$fgPid; ProcessName = $fgName }
            }
            $cands = @()
            foreach ($p in (Get-Process)) {
                try {
                    if ($p.Id -eq $PID) { continue }
                    if ($p.ProcessName -in $consoleNames) { continue }
                    if ($p.MainWindowHandle -ne 0) { $cands += $p }
                }
                catch { }
            }
            if ($cands.Count -eq 0) {
                return @{ error = 'no_window'; detail = 'no suitable window to focus' }
            }
            $target = $cands | Sort-Object { try { $_.StartTime } catch { [datetime]::MinValue } } -Descending | Select-Object -First 1
        }
        if ($null -eq $target) {
            return @{ error = 'no_window'; detail = 'no suitable window to focus' }
        }
        $hWnd = $target.MainWindowHandle
        if ([KDRemoteFocus]::IsIconic($hWnd)) {
            [void][KDRemoteFocus]::ShowWindow($hWnd, [KDRemoteFocus]::SW_RESTORE)
        }
        $ok = [KDRemoteFocus]::SetForegroundWindow($hWnd)
        if (-not $ok) {
            $fgNow = [KDRemoteFocus]::GetForegroundWindow()
            $fgPidOut = [uint32]0
            $fgThread = [KDRemoteFocus]::GetWindowThreadProcessId($fgNow, [ref]$fgPidOut)
            $myThread = [KDRemoteFocus]::GetCurrentThreadId()
            [void][KDRemoteFocus]::AttachThreadInput($myThread, $fgThread, $true)
            $ok = [KDRemoteFocus]::SetForegroundWindow($hWnd)
            [void][KDRemoteFocus]::AttachThreadInput($myThread, $fgThread, $false)
        }
        Start-Sleep -Milliseconds 250
        $nowFg = [KDRemoteFocus]::GetForegroundWindow()
        if ($nowFg -ne $hWnd) {
            return @{ error = 'focus_failed'; detail = ("could not bring to front: {0} (pid {1})" -f $target.ProcessName, $target.Id) }
        }
        return @{ Handle = $hWnd; ProcessId = $target.Id; ProcessName = $target.ProcessName }
    }
    catch {
        return @{ error = 'focus_failed'; detail = $_.Exception.Message }
    }
}

# ---------------------------------------------------------------- live feed
# v1.3.4 - live-feed sender. The agent main loop calls
# Send-KDDoctorFrameTick once per poll iteration. It captures on the
# same GDI BitBlt path (JPEG q40, 40KB cap, scales 0.5/0.25/0.125),
# and posts change-only frames to POST /doctor/frame:
# hard cap 1 post per 5 seconds even when the screen keeps changing,
# plus a liveness re-post every 60 seconds when nothing changed.
# Budget (free tier): at most 17,280 frame posts/day + the eye's
# 17,280 frame reads/day + ~10,000 existing requests/day = ~45,000
# requests/day, inside the 100k/day Workers and DO caps. The agent
# reaches OUT only - the relay never calls back into the PC.
# This function NEVER throws into the agent loop: every failure is
# swallowed after one audit line (first post + failures only).

$script:KDDoctorFeedEnabled = $true
$script:KDDoctorFeedLastHash = $null
$script:KDDoctorFeedLastPostAt = $null
$script:KDDoctorFeedPostCount = 0
$script:KDDoctorFeedLastErrorAt = $null

function Send-KDDoctorFrameTick {
    param(
        [string]$Relay,
        [string]$Version
    )
    if (-not $script:KDDoctorFeedEnabled) { return }
    if ([string]::IsNullOrWhiteSpace($Relay)) { return }
    try {
        $now = Get-Date
        $dueLiveness = $true
        if ($null -ne $script:KDDoctorFeedLastPostAt) {
            $sincePost = ($now - $script:KDDoctorFeedLastPostAt).TotalSeconds
            if ($sincePost -lt 5) { return }
            $dueLiveness = $sincePost -ge 60
        }
        # Capture only when a post may be due (at most one capture
        # per 5 seconds); the change check happens after the hash.
        $cap = Get-KDRemoteScreenCapture -Quality 40 -MaxBytes (40 * 1024) -Scales @(0.5, 0.25, 0.125)
        if ($cap -is [hashtable] -and $cap.ContainsKey('error')) {
            Write-KDRemoteScreenAudit -Cmd 'frame' -ArgsText 'capture' -Done $false -ResultText ("error frame_failed detail={0}" -f $cap.detail)
            return
        }
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try {
            $hashBytes = $sha.ComputeHash($cap.Bytes)
        }
        finally {
            $sha.Dispose()
        }
        $hash = [System.BitConverter]::ToString($hashBytes).Replace('-', '').ToLower()
        if ($hash -eq $script:KDDoctorFeedLastHash -and -not $dueLiveness) { return }
        $b64 = [System.Convert]::ToBase64String($cap.Bytes)
        $payload = @{ image_b64 = $b64; width = $cap.Width; height = $cap.Height; bytes = $cap.Bytes.Length }
        $body = $payload | ConvertTo-Json -Depth 5 -Compress
        $url = $Relay.TrimEnd('/') + '/doctor/frame'
        try {
            $null = Invoke-RestMethod -Uri $url -Method Post -Body $body `
                -ContentType 'application/json' `
                -Headers @{ 'User-Agent' = "KUROdoctor/$Version" } -TimeoutSec 10
        }
        catch {
            Write-KDRemoteScreenAudit -Cmd 'frame' -ArgsText 'post' -Done $false -ResultText ("error frame_failed detail={0}" -f $_.Exception.Message)
            return
        }
        $script:KDDoctorFeedLastHash = $hash
        $script:KDDoctorFeedLastPostAt = $now
        $script:KDDoctorFeedPostCount++
        if ($script:KDDoctorFeedPostCount -eq 1) {
            Write-KDRemoteScreenAudit -Cmd 'frame' -ArgsText 'post' -Done $true -ResultText ("ok first frame bytes={0}" -f $cap.Bytes.Length)
        }
    }
    catch {
        # Never break the agent loop. One audit line per minute max.
        $nowErr = Get-Date
        if ($null -eq $script:KDDoctorFeedLastErrorAt -or ($nowErr - $script:KDDoctorFeedLastErrorAt).TotalSeconds -ge 60) {
            $script:KDDoctorFeedLastErrorAt = $nowErr
            Write-KDRemoteScreenAudit -Cmd 'frame' -ArgsText 'tick' -Done $false -ResultText ("error frame_failed detail={0}" -f $_.Exception.Message)
        }
    }
}

# ---------------------------------------------------------------- dispatcher# ---------------------------------------------------------------- dispatcher

function Invoke-KDRemoteScreenCommand {
    param($CmdObj)
    $name = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'cmd'
    $cmdId = Get-KDRemoteScreenArg -CmdObj $CmdObj -Name 'id'
    if (-not $name -or $name -isnot [string]) {
        Write-KDRemoteScreenAudit -Cmd 'unknown' -ArgsText 'cmd missing' -Done $false -ResultText 'error unknown_cmd'
        return @{ id = $cmdId; done = $false; at = Get-KDRemoteScreenNowIso;
                  result = @{ error = 'unknown_cmd'; detail = "command has no 'cmd' string" } }
    }
    $result = $null
    switch ($name) {
        'screenshot' { $result = Invoke-CmdScreenshot $CmdObj }
        'mouse'      { $result = Invoke-CmdMouse $CmdObj }
        'type'       { $result = Invoke-CmdType $CmdObj }
        default {
            Write-KDRemoteScreenAudit -Cmd $name -ArgsText 'cmd unknown' -Done $false -ResultText 'error unknown_cmd'
            return @{ id = $cmdId; done = $false; at = Get-KDRemoteScreenNowIso;
                      result = @{ error = 'unknown_cmd'; detail = ("no such command: {0}" -f $name) } }
        }
    }
    if ($result -is [hashtable] -and $result.ContainsKey('error')) {
        return @{ id = $cmdId; done = $false; at = Get-KDRemoteScreenNowIso; result = $result }
    }
    if ($result -isnot [hashtable]) { $result = @{ value = $result } }
    return @{ id = $cmdId; done = $true; at = Get-KDRemoteScreenNowIso; result = $result }
}
