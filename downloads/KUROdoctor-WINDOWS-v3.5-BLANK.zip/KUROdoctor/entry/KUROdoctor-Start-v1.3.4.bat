@echo off
REM KUROdoctor-Start-v1.3.4.bat - easy entry for Windows (v5 remote control).
REM Double-click to run the KUROdoctor agent v1.3.4. It downloads nothing,
REM changes no system settings, and needs no admin rights.
REM The agent phones home to the doctor; nothing is fixed until the
REM owner says go to that fix. Remote control is show-first / ok-gated:
REM every action is proposed in chat first and runs only after the
REM owner oks that exact action. Closing this window stops the doctor.

REM If run with any argument, just show the 3 steps and stop.
if not "%~1"=="" goto :steps

echo KUROdoctor is starting...
echo.

REM PowerShell must be present.
where powershell >nul 2>nul
if errorlevel 1 (
    echo PowerShell was not found on this computer.
    echo KUROdoctor needs PowerShell to run. It comes with Windows,
    echo so if this message appears, ask the doctor for help.
    echo.
    pause
    exit /b 1
)

REM The agent file must sit next to this launcher, in the agent folder.
if not exist "%~dp0..\agent\kuro-doctor-agent-v1.3.4.ps1" (
    echo The KUROdoctor agent file was not found.
    echo Expected: %~dp0..\agent\kuro-doctor-agent-v1.3.4.ps1
    echo Put this launcher back in its KUROdoctor folder and try again.
    echo.
    pause
    exit /b 1
)

echo Connecting to the doctor...
echo The doctor will run a checkup first, then tell you what it found.
echo Nothing is fixed until you say go to that fix.
echo Remote control is show-first: every action is shown to you first,
echo and runs only after you ok that exact action.
echo.
echo Leave this window open while the doctor works.
echo Closing this window stops the doctor.
echo.

REM Run the agent for this run only. -ExecutionPolicy Bypass applies
REM to this one command, not to the computer.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\agent\kuro-doctor-agent-v1.3.4.ps1"

echo.
echo KUROdoctor has stopped.
echo If the doctor is not reachable yet, check your internet.
echo Your report was NOT saved - it lives only in this window. Do not close it.
echo.
pause
exit /b 0

:steps
echo KUROdoctor - 3 steps:
echo.
echo 1. Run this file. Double-click it.
echo 2. Wait for the report. The doctor checks your computer first
echo    and tells you what it found, in plain words.
echo 3. Say go to each fix. Nothing is fixed until you say go to
echo    that fix. The doctor never changes anything on its own.
echo.
echo Remote control: every action is shown to you first and runs
echo only after you ok that exact action. Closing the window stops it.
echo.
echo If it says the doctor is not reachable yet, check your internet
echo and run this file again. A report that did not reach the doctor is lost.
echo.
pause
exit /b 0
