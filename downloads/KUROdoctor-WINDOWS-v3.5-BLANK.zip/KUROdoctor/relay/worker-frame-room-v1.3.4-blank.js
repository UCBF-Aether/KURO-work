/**
 * KUROdoctor v1.3.4 — DoctorFrameRoom Durable Object class.
 *
 * WHERE IT SLOTS IN
 * -----------------
 * This class is NOT a fetch() fragment. It is a top-level export in
 * the merged worker, inserted BEFORE the default-export line
 * (deploy-remote-endpoints-v1.4.0-v1.3.4.sh does this mechanically,
 * and the v1.3.4 test harness does the same). The worker's
 * /doctor/frame routes (in worker-remote-patch-v1.3.4.js) reach it
 * through the DOCTOR_FRAME_ROOM binding:
 *   env.DOCTOR_FRAME_ROOM.get(env.DOCTOR_FRAME_ROOM.idFromName("doctor-frame"))
 *
 * WHAT IT DOES
 * ------------
 * Holds the LATEST live-feed frame IN MEMORY ONLY. One frame, no
 * history, no KV write, no storage write of any kind per frame.
 * POST /frame replaces the stored frame; GET /frame returns it
 * (404 no_frame when nothing has been posted). A worker restart or
 * DO eviction drops the frame; the agent re-posts within 60s
 * (liveness) or on the next screen change, so the loss is transient.
 *
 * FREE TIER
 * ---------
 * This is the SQLite-backed kind of Durable Object class: it must be
 * declared via `new_sqlite_classes` (a free plan 403s code 10097 on
 * `new_classes`). The binding + the migration are declared in the
 * deploy metadata. The migration is ONE-TIME and flag-gated in the
 * deploy script (KURO_DOCTOR_FRAME_ROOM_MIGRATION=1); re-sending it
 * fails 400 code 10074, exactly like BridgeRoom's history — later
 * redeploys keep the binding and omit the migration.
 *
 * BUDGET (one active feed): at most 17,280 frame posts/day (agent,
 * hard cap 1 per 5s) + 17,280 frame reads/day (the eye, 1 per 5s)
 * + ~10,000 existing requests/day = ~45,000 requests/day, inside
 * the 100k/day Workers and 100k/day DO caps. Three simultaneous
 * feeds would exceed the free allowance — one feed at a time.
 */

export class DoctorFrameRoom {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    // Latest frame only; never persisted anywhere.
    this.frame = null;
  }

  async fetch(request) {
    const url = new URL(request.url);
    const json = (obj, status = 200) =>
      new Response(JSON.stringify(obj), {
        status,
        headers: { "Content-Type": "application/json" },
      });

    // POST /frame — replace the stored frame.
    if (url.pathname === "/frame" && request.method === "POST") {
      let body;
      try {
        body = await request.json();
      } catch (e) {
        return json({ ok: false, error: "bad_json" }, 400);
      }
      if (typeof body.image_b64 !== "string" || body.image_b64.length === 0) {
        return json({ ok: false, error: "bad_image" }, 400);
      }
      if (body.image_b64.length > 100000) {
        return json({ ok: false, error: "too_large" }, 400);
      }
      this.frame = {
        image_b64: body.image_b64,
        width: typeof body.width === "number" ? Math.floor(body.width) : null,
        height: typeof body.height === "number" ? Math.floor(body.height) : null,
        bytes: typeof body.bytes === "number" ? Math.floor(body.bytes) : null,
        received_at: new Date().toISOString(),
      };
      return json({ ok: true });
    }

    // GET /frame — return the latest stored frame.
    if (url.pathname === "/frame" && request.method === "GET") {
      if (!this.frame) {
        return json({ ok: false, error: "no_frame" }, 404);
      }
      return new Response(JSON.stringify(this.frame), {
        headers: { "Content-Type": "application/json" },
      });
    }

    return json({ ok: false, error: "not_found" }, 404);
  }
}
