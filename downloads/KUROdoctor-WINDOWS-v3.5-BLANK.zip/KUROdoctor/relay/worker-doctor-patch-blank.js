/**
 * KUROdoctor v1 — doctor-channel patch for your own Cloudflare Worker.
 *
 * WHERE IT SLOTS IN
 * -----------------
 * This code is NOT a standalone worker. It is a set of route handlers
 * that belong INSIDE the `fetch(request, env, ctx)` method of
 * your worker script (worker-base-blank.js), immediately BEFORE the final
 * fallback line:
 *
 *     return new Response("kurodoctor blank worker ok", { headers: cors });
 *
 * It reuses the enclosing scope's `url`, `request`, `env`, `cors`, and
 * `json()` helper — exactly the same names the existing /report,
 * /command, and /ack handlers use — so nothing else in worker.js
 * changes. No existing endpoint, KV key, or Durable Object binding
 * is touched. The doctor channel lives entirely under /doctor/* with
 * its own KV keys (doctor:latest, doctor:command, doctor:ack), so the
 * phone bridge and the doctor agent can never see each other's state.
 *
 * MERGE: deploy-remote-endpoints-v1.3.1-blank.sh does this mechanically
 * (copy worker-base-blank.js, insert this block before the fallback,
 * node --check the result, then deploy via deploy-worker-blank.py).
 * Do not hand-edit the merged file — edit this patch and re-run the
 * deploy script.
 *
 * DOCTOR CHANNEL OVERVIEW
 * ------------------------
 * A rescue Linux stick boots a sick PC and runs a doctor agent that
 * phones home here. Muse issues commands; the agent polls
 * GET /doctor/command, executes, and POSTs the outcome to
 * /doctor/ack. Command JSON is {cmd, id, ...args}; ack JSON is
 * {id, done, at, result}. Full spec: DOCTOR-API.md (same directory).
 */

// POST /doctor/report — store the latest doctor-agent status report.
// Body: {"hostname":"...","boot_id":"...","agent_version":"...",
//        "uptime_s":123,"ip":"...","timestamp":"<iso>"}
// Unknown/extra fields are kept as posted (bridge /report style:
// known fields are normalized, the rest passes through).
if (url.pathname === "/doctor/report" && request.method === "POST") {
  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ ok: false, error: "bad_json" }, 400);
  }
  const report = {
    ...body,
    hostname: typeof body.hostname === "string" ? body.hostname : "",
    boot_id: typeof body.boot_id === "string" ? body.boot_id : "",
    agent_version:
      typeof body.agent_version === "string" ? body.agent_version : "",
    uptime_s: typeof body.uptime_s === "number" ? body.uptime_s : null,
    ip: typeof body.ip === "string" ? body.ip : "",
    timestamp:
      typeof body.timestamp === "string"
        ? body.timestamp
        : new Date().toISOString(),
    received_at: new Date().toISOString(),
  };
  await env.BRIDGE_KV.put("doctor:latest", JSON.stringify(report));
  return json({ ok: true });
}

// GET /doctor/latest — return the latest stored doctor report.
if (url.pathname === "/doctor/latest" && request.method === "GET") {
  const v = await env.BRIDGE_KV.get("doctor:latest");
  if (!v) return json({ ok: false, error: "no_report" }, 404);
  return new Response(v, {
    headers: { ...cors, "Content-Type": "application/json" },
  });
}

// POST /doctor/command — store a command for the doctor agent.
// Body: {"cmd":"ping","id":"<uuid>"}
//       {"cmd":"sysinfo","id":"<uuid>"}
//       {"cmd":"smart","device":"/dev/sda","id":"<uuid>"} (device optional)
//       {"cmd":"df","id":"<uuid>"}
//       {"cmd":"ls","path":"/var/log","id":"<uuid>"} (path optional, default "/")
//       {"cmd":"cat","path":"/etc/hostname","id":"<uuid>"}
//       {"cmd":"dmesg","lines":100,"id":"<uuid>"} (lines optional, default 100)
// Only the listed commands are accepted (unknown cmd -> 400 unknown_cmd).
// `id` is auto-generated if omitted. Validation mirrors the bridge
// /command handler: bad args are rejected here, before anything is
// stored, so a bad command can never reach the agent.
if (url.pathname === "/doctor/command" && request.method === "POST") {
  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ ok: false, error: "bad_json" }, 400);
  }
  const cmd = body.cmd;
  const allowed = ["ping", "sysinfo", "smart", "df", "ls", "cat", "dmesg"];
  if (!allowed.includes(cmd)) {
    return json({ ok: false, error: "unknown_cmd" }, 400);
  }
  const id =
    typeof body.id === "string" && body.id.length > 0
      ? body.id
      : crypto.randomUUID();
  const command = { cmd, id, received_at: new Date().toISOString() };

  // smart: optional device path (e.g. "/dev/sda"); must be a string
  // starting with "/dev/" when given. Default: agent picks the boot disk.
  if (cmd === "smart") {
    if (body.device !== undefined) {
      if (typeof body.device !== "string" || !body.device.startsWith("/dev/")) {
        return json({ ok: false, error: "bad_device" }, 400);
      }
      command.device = body.device;
    }
  }

  // ls: optional directory path; defaults to "/" on the agent.
  if (cmd === "ls") {
    if (body.path !== undefined) {
      if (typeof body.path !== "string" || !body.path.startsWith("/")) {
        return json({ ok: false, error: "bad_path" }, 400);
      }
      command.path = body.path;
    }
  }

  // cat: path is REQUIRED and must be absolute. If Muse already knows
  // the file size (e.g. from a prior ls), it may pass `size`; a size
  // over the 100 KB cap is rejected here (400 file_too_large) so the
  // agent never has to fetch it. The agent enforces the same 100 KB
  // cap at read time and acks done:false + error file_too_large if
  // the file grew past the cap between ls and cat.
  if (cmd === "cat") {
    if (typeof body.path !== "string" || body.path.length === 0 || !body.path.startsWith("/")) {
      return json({ ok: false, error: "bad_path" }, 400);
    }
    command.path = body.path;
    if (body.size !== undefined) {
      if (typeof body.size !== "number" || body.size < 0) {
        return json({ ok: false, error: "bad_size" }, 400);
      }
      if (body.size > 102400) {
        return json({ ok: false, error: "file_too_large" }, 400);
      }
      command.size = Math.floor(body.size);
    }
  }

  // dmesg: optional line count, clamped to 1..500 (default 100).
  if (cmd === "dmesg") {
    let lines = typeof body.lines === "number" ? Math.round(body.lines) : 100;
    if (lines < 1) lines = 1;
    if (lines > 500) lines = 500;
    command.lines = lines;
  }

  // "ping", "sysinfo", and "df" take no extra fields.
  await env.BRIDGE_KV.put("doctor:command", JSON.stringify(command));
  return json({ ok: true, id });
}

// GET /doctor/command — return the latest stored doctor command,
// or {"cmd":null} when none has been posted yet.
if (url.pathname === "/doctor/command" && request.method === "GET") {
  const v = await env.BRIDGE_KV.get("doctor:command");
  if (!v) return json({ cmd: null });
  return new Response(v, {
    headers: { ...cors, "Content-Type": "application/json" },
  });
}

// POST /doctor/ack — the doctor agent confirms it executed a command.
// Body: {"id":"<uuid>","done":true,"at":"<iso>","result":{...}}
// `result` is the command's outcome (shape depends on cmd — see
// DOCTOR-API.md). On failure done:false and result carries
// {"error":"<code>","detail":"..."} (e.g. file_too_large, bad_path).
if (url.pathname === "/doctor/ack" && request.method === "POST") {
  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ ok: false, error: "bad_json" }, 400);
  }
  const ack = {
    id: typeof body.id === "string" ? body.id : "",
    done: body.done === true,
    at: typeof body.at === "string" ? body.at : new Date().toISOString(),
    result:
      body.result !== undefined && typeof body.result === "object" && body.result !== null
        ? body.result
        : {},
    received_at: new Date().toISOString(),
  };
  await env.BRIDGE_KV.put("doctor:ack", JSON.stringify(ack));
  return json({ ok: true });
}

// GET /doctor/ack — return the latest doctor ack, or {"done":false}.
if (url.pathname === "/doctor/ack" && request.method === "GET") {
  const v = await env.BRIDGE_KV.get("doctor:ack");
  if (!v) return json({ done: false });
  return new Response(v, {
    headers: { ...cors, "Content-Type": "application/json" },
  });
}
