/**
 * KUROdoctor — blank base worker for a new owner (bring-your-own-Cloudflare).
 *
 * WHAT THIS IS
 * -------------
 * The empty shell of a Cloudflare Worker. It contains NO doctor code,
 * NO bridge code, NO Durable Objects, and NO account-specific values
 * at all — no account ID, no worker name, no KV namespace ID, no
 * subdomain. Those all come from the owner's own Cloudflare account
 * at deploy time (environment variables — see
 * deploy-remote-endpoints-v1.3.1-blank.sh and deploy-worker-blank.py).
 *
 * HOW IT IS USED
 * ---------------
 * The blank deploy script copies this file, then inserts the doctor
 * patches before the fallback line at the bottom of fetch():
 *   1. worker-remote-patch-v1.3.1.js (remote control + queue + ack
 *      hardening + uninstall + owner override)
 *   2. worker-doctor-patch.js (v1 doctor channel: report/latest/
 *      command/ack)
 * ...in that order, because handlers are sequential if-statements and
 * the first match returns. The v1.3.1 patch's POST /doctor/command
 * handler SHADOWS the v1 one for that single route; the v1 handler
 * stays below as dead code for that route only.
 *
 * The patches reuse the names defined here inside fetch(): `url`,
 * `request`, `env`, `cors`, and the `json()` helper. Do not rename
 * them — the patches depend on those exact names.
 *
 * The only KV binding the doctor channel needs is BRIDGE_KV (a KV
 * namespace the owner creates in their own account; the name is
 * historical — it is just the doctor channel's storage). It is
 * declared in the deploy metadata, not here.
 */

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };
    const json = (obj, status = 200) =>
      new Response(JSON.stringify(obj), {
        status,
        headers: { ...cors, "Content-Type": "application/json" },
      });
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }
    return new Response("kurodoctor blank worker ok", { headers: cors });
  },
};
