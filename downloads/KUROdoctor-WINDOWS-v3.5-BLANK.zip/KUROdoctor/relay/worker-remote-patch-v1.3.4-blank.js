/**
 * KUROdoctor v1.3.4 — remote-control patch for your own Cloudflare Worker.
 *
 * WHERE IT SLOTS IN
 * -----------------
 * This code is NOT a standalone worker. It is a set of route handlers
 * that belong INSIDE the `fetch(request, env, ctx)` method of
 * your worker script (worker-base-blank.js), immediately BEFORE the final
 * fallback line:
 *
 *     return new Response("kurodoctor blank worker ok", { headers: cors });
 *
 * It reuses the enclosing scope's `url`, `request`, `env`, `cors`, and
 * `json()` helper — exactly the same names the existing /report,
 * /command, and /ack handlers use.
 *
 * ORDER MATTERS — READ THIS BEFORE MERGING
 * ----------------------------------------
 * The v1 doctor patch (worker-doctor-patch.js) is ALREADY deployed and
 * its POST /doctor/command handler allows only
 * ["ping","sysinfo","smart","df","ls","cat","dmesg"]. The base worker
 * (worker-base-blank.js) does NOT contain any doctor code,
 * so a deploy must merge BOTH patches. deploy-remote-endpoints-v1.3.4-blank.sh
 * inserts THIS patch BEFORE the v1 patch. Handlers are sequential
 * if-statements and the first match returns, so this file's
 * POST /doctor/command handler (full copy of the v1 logic plus the
 * extended allow-list and new-arg validation) SHADOWS the v1 one for
 * that single route. The v1 handler stays in the merged file below it
 * as dead code for POST /doctor/command only — its GET /doctor/command
 * and all other v1 handlers still run. Do not delete either patch
 * without redeploying both together.
 *
 * WHAT CHANGED IN v1.3.4 (vs v1.3.3)
 * ----------------------------------
 * TWO functional changes.
 *   1. `type` accepts an optional `process` field (e.g.
 *      "notepad++"): a string of 1-200 chars with no control
 *      characters, copied into the queued command (bad value ->
 *      400 bad_process). The agent focuses that window before
 *      typing; with no field it focuses the foreground window
 *      (or the most recently started visible window) and refuses
 *      to type when nothing can be focused. Text validation is
 *      unchanged.
 *   2. NEW ROUTES: POST /doctor/frame + GET /doctor/frame (see
 *      the bottom of this file). The agent holds no token, so
 *      POST carries none: it is gated on existing session state
 *      via doctorCheckSession from the v1.4.0 auth patch (paired
 *      + locked -> 423 locked; nothing paired -> the v1.4.0
 *      safety valve allows it). GET is open, same as GET
 *      /doctor/screenshot. Frames live ONLY in the new
 *      DoctorFrameRoom Durable Object's memory
 *      (worker-frame-room-v1.3.4.js, SQLite-backed class, one-time
 *      new_sqlite_classes migration, flag-gated in the deploy
 *      script) — no KV write per frame. Image cap 100000 base64
 *      chars (~75KB); the agent targets <=40KB JPEGs.
 * Everything else in this file is byte-identical to v1.3.3: this
 * patch carries no auth logic, and the queue, the never-400 ack,
 * the owner_override rule, the relay-side credential-tool
 * blocklist on `exec`, uninstall, and install are unchanged.
 *
 * WHAT CHANGED IN v1.3.3 (vs v1.3.2)
 * ----------------------------------
 * ONE functional change, in the POST /doctor/command "install"
 * validation ONLY: the kind allow-list gains exactly two new kinds
 * — "winget" and "exe" — and the relay now validates and passes
 * through the installer's `path`, `url`, and `args` fields,
 * mirroring the Windows agent's Invoke-CmdInstall validation
 * exactly. v1.3.2 accepted kinds steam | msi | appx | app | brew |
 * flatpak | pacman and stored ONLY kind/name/appid, so a Windows
 * install could never carry the path/url the agent requires for
 * msi/exe — every msi/exe install failed at the agent, and a
 * winget install could not even be queued. Now:
 *   - kind: steam | msi | appx | app | brew | flatpak | pacman |
 *     winget | exe (bad kind -> 400 bad_kind, as before).
 *   - name: unchanged (1-200 chars, no backslash / slash / '..').
 *   - path / url: msi/exe ONLY, never winget. When present they
 *     must be strings of 1-500 chars with no '..', and must end
 *     in the extension matching the kind (.msi / .exe,
 *     case-insensitive). Valid values are copied into the queued
 *     command so they reach the agent. A path/url on a
 *     name/appid-only kind (steam | appx | app | brew | flatpak |
 *     pacman) is ignored, exactly as in v1.3.2 — never stored.
 *   - args: exe ONLY, a string of at most 500 chars with no
 *     newlines. Any other kind carrying args is rejected.
 *   - Presence: winget requires a name; msi/exe require a path
 *     or url; steam | appx | app | brew | flatpak | pacman keep
 *     the v1.3.2 rule (name or appid required). Anything else is
 *     rejected with 400 bad_target BEFORE queueing, so a bad
 *     install can never reach the agent.
 * Everything else in this file is byte-identical to v1.3.2: this
 * patch carries no auth logic, and the queue, the never-400 ack,
 * the owner_override rule, the relay-side credential-tool
 * blocklist on `exec`, uninstall, and deep are unchanged.
 *
 * WHAT CHANGED IN v1.3.2 (vs v1.3.1)
 * ----------------------------------
 * ONE functional change: the POST /doctor/command allow-list gains
 * exactly one new command — "install" — with validation mirroring
 * "uninstall" exactly (kind steam | msi | appx | app | brew |
 * flatpak | pacman; name <=200 chars, no backslash / slash / '..';
 * appid integer, steam only; at least one of name/appid required;
 * errors bad_kind / bad_target). Everything else in this file is
 * byte-identical to v1.3.1: the queue, the never-400 ack, the
 * owner_override rule, and the relay-side credential-tool blocklist
 * on `exec` are unchanged.
 *
 * WHAT CHANGED IN v1.3.1 (vs v1.3.0)
 * ----------------------------------
 * QUEUE: the relay no longer holds ONE command in doctor:command.
 * POST /doctor/command appends to a FIFO queue in doctor:queue
 * (JSON array, max 10; 400 queue_full at 10) and returns
 * {ok:true, id, position}. GET /doctor/command returns the HEAD
 * of the queue WITHOUT popping it, or {cmd:null} when empty.
 * POST /doctor/received {id} removes that id from the queue
 * (400 bad_id when id is missing / not a string; 400 unknown_id
 * when the id is not queued). The agent posts it immediately
 * after GETting a new command, BEFORE executing it.
 * POST /doctor/ack is now handled HERE (shadowing v1, same
 * position rule as the command handler - this patch before v1)
 * with never-400-on-content behaviour: the body is read as text
 * once, then parsed as JSON. A body that is not JSON is salvaged:
 * the id is pulled out with a regex and a minimal ack is stored
 * ({id, done:false, result:{error:'ack_unparseable'}}) with a
 * 200. A result over 16KB is truncated server-side (replaced
 * with {error:'ack_too_large'}). A missing or non-object result
 * defaults to {}. 400 only when the body is completely empty or
 * unreadable.
 * NEW COMMAND: "uninstall" (kind steam | msi | appx | app | brew |
 * flatpak | pacman; name <=200 chars, no backslash / slash / '..';
 * appid integer, steam only; at least one of name/appid required;
 * errors bad_kind / bad_target). The Windows agent handles steam |
 * msi | appx; the other kinds are for the Mac/Linux agents that
 * share this relay contract.
 * exec passes owner_override through (boolean only, exec only;
 * 400 bad_override otherwise - non-boolean, or present on any
 * non-exec command).
 * BACK-COMPAT: a v1.3.0-or-older agent against the v1.3.1 relay
 * runs only the first queued command (it never sends
 * /doctor/received, so the head never pops). Agent and relay
 * must move together via the in-place pack update.
 * The old single-slot doctor:command key is RETIRED - the relay
 * no longer writes it. doctor:queue replaces it.
 *
 * WHAT CHANGED IN v1.3.0 (vs v1.2.1)
 * ----------------------------------
 * ONE functional change: the POST /doctor/command allow-list gains
 * exactly three new commands — "clean", "repair", "deep" — with
 * validation in the same style as the existing commands (bad args
 * rejected here, before anything is stored). Everything else in
 * this file is byte-identical to v1.2.1: the five-pattern
 * credential-tool blocklist on `exec` is unchanged and still
 * enforced here on the relay.
 *
 * WHY: agent v1.3 adds cleanup / repair / deep-scan flows on the PC;
 * the relay must accept and validate those commands the same way it
 * does the v5 ones. The v1.3.4 handler still SHADOWS the v1 one for
 * POST /doctor/command only — same merge order as v1.2.1 (this
 * patch BEFORE the v1 patch), because handlers are sequential
 * if-statements and the first match returns. The v1.3.4 GET
 * /doctor/command and POST /doctor/ack handlers below shadow
 * the v1 ones the same way.
 *
 * WHAT CHANGED IN v1.2.1 (ONE functional change vs v5)
 * ---------------------------------------------------
 * The POST /doctor/command handler's `exec` validation now ALSO
 * rejects command text matching credential-tool patterns with
 * 400 `blocked`, BEFORE storing, so a blocked command can never
 * reach the agent. Patterns (case-insensitive substrings):
 * mimikatz, sekurlsa, lsass, ntdsutil, ntds.dit.
 *
 * WHY: on 2026-11-19 the v1.2 Windows agent was blocked at parse
 * time on a Windows 10 PC by Windows Defender AMSI
 * (ScriptContainedMaliciousContent). The likely trigger was the
 * literal credential-tool names in the agent's own Test-ExecBlocked
 * blocklist/comments. The agent no longer carries those literals;
 * the blocklist lives here, on the relay, where Defender AMSI
 * never scans it. Everything else in this file is identical to v5.
 *
 * NEW COMMANDS (v1.3.0, agent v1.3)
 * ---------------------------------
 *   clean        {cmd:"clean"}
 *                Run the agent's cleanup flow. Takes no extra fields;
 *                any extra fields are ignored (not stored).
 *   repair       {cmd:"repair", function:"temp", names:["..."]}
 *                Run a repair flow. `function` is REQUIRED and must
 *                be one of system_files | startup | temp |
 *                defender_scan. `names` is OPTIONAL; when present it
 *                must be an array of strings, each <=50 chars, with
 *                no wildcard characters (* or ?).
 *   deep         {cmd:"deep"}
 *                Run the agent's deep-scan flow. Takes no extra
 *                fields.
 *
 * NEW COMMANDS (v5, agent v1.2 + remote-screen)
 * ---------------------------------------------
 *   exec       {cmd:"exec", command:"...", timeout_s:60}
 *              Run exactly one PowerShell command string on the PC.
 *              The agent enforces its own blocklist and timeout.
 *   screenshot {cmd:"screenshot"}
 *              Capture the whole primary screen as JPEG (agent caps
 *              it at ~200KB, base64). The image itself travels via
 *              POST /doctor/screenshot below; the command ack carries
 *              only {width, height, bytes}.
 *   mouse      {cmd:"mouse", x:100, y:200, action:"left_click"}
 *              action is one of move | left_click | right_click |
 *              double_click. The agent validates x/y against the real
 *              screen bounds; the relay only checks presence/type.
 *   type       {cmd:"type", text:"hello", process:"notepad++"}
 *              Type plain text (max 1000 chars). `process` is
 *              optional: the window to focus first. Never use on a
 *              password / login field — operator rule, see
 *              docs/remote-control.md.
 *
 * SHOW-FIRST / OK GATE (the owner's law)
 * ---------------------------------
 * The relay stores commands; it never invents them. Every remote
 * action is proposed in chat first and runs only after the owner oks that
 * exact action. The agent executes only commands that arrived via
 * the relay. No lock-screen / password bypass, no credential dumping,
 * no reboot / shutdown / wipe / format / reinstall command exists
 * anywhere in v5. Every action is audit-logged on the agent.
 *
 * MERGE: deploy-remote-endpoints-v1.4.0-blank.sh does this mechanically (copy
 * worker-base-blank.js, insert this patch THEN the v1 patch before the fallback,
 * node --check the result, then deploy via deploy-worker-blank.py).
 * Do not hand-edit the merged file.
 */

// POST /doctor/command — v1.3.4 replacement handler (SHADOWS the v1 one).
// Same shape as v1, extended allow-list + validation for the new cmds.
// Bad args are rejected here, before anything is stored, so a bad
// command can never reach the agent.
if (url.pathname === "/doctor/command" && request.method === "POST") {
  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ ok: false, error: "bad_json" }, 400);
  }
  const cmd = body.cmd;
  const allowed = [
    "ping", "sysinfo", "smart", "df", "ls", "cat", "dmesg",
    "exec", "screenshot", "mouse", "type",
    "clean", "repair", "deep",
    "uninstall",
    "install",
  ];
  if (!allowed.includes(cmd)) {
    return json({ ok: false, error: "unknown_cmd" }, 400);
  }
  const id =
    typeof body.id === "string" && body.id.length > 0
      ? body.id
      : crypto.randomUUID();
  const command = { cmd, id, received_at: new Date().toISOString() };

  // v1.3.1: owner_override passes through ONLY on exec, and only
  // as a boolean. Any other command carrying it, or a non-boolean
  // value, is rejected here (400 bad_override).
  if (body.owner_override !== undefined) {
    if (cmd !== "exec" || typeof body.owner_override !== "boolean") {
      return json({ ok: false, error: "bad_override" }, 400);
    }
    command.owner_override = body.owner_override;
  }

  // smart: optional device path (e.g. "/dev/sda"); must be a string
  // starting with "/dev/" when given. Default: agent picks the boot disk.
  if (cmd === "smart") {
    if (body.device !== undefined) {
      if (typeof body.device !== "string" || !body.device.startsWith("/dev/")) {
        return json({ ok: false, error: "bad_device" }, 400);
      }
      command.device = body.device;
    }
  }

  // ls: optional directory path; defaults to "/" on the agent.
  if (cmd === "ls") {
    if (body.path !== undefined) {
      if (typeof body.path !== "string" || !body.path.startsWith("/")) {
        return json({ ok: false, error: "bad_path" }, 400);
      }
      command.path = body.path;
    }
  }

  // cat: path is REQUIRED and must be absolute. If Muse already knows
  // the file size (e.g. from a prior ls), it may pass `size`; a size
  // over the 100 KB cap is rejected here (400 file_too_large) so the
  // agent never has to fetch it.
  if (cmd === "cat") {
    if (typeof body.path !== "string" || body.path.length === 0 || !body.path.startsWith("/")) {
      return json({ ok: false, error: "bad_path" }, 400);
    }
    command.path = body.path;
    if (body.size !== undefined) {
      if (typeof body.size !== "number" || body.size < 0) {
        return json({ ok: false, error: "bad_size" }, 400);
      }
      if (body.size > 102400) {
        return json({ ok: false, error: "file_too_large" }, 400);
      }
      command.size = Math.floor(body.size);
    }
  }

  // dmesg: optional line count, clamped to 1..500 (default 100).
  if (cmd === "dmesg") {
    let lines = typeof body.lines === "number" ? Math.round(body.lines) : 100;
    if (lines < 1) lines = 1;
    if (lines > 500) lines = 500;
    command.lines = lines;
  }

  // exec: `command` is REQUIRED, a non-empty string, max 20000 chars.
  // `timeout_s` is optional, clamped to 1..300 (agent default 60).
  // v1.2.1: the relay ALSO enforces the credential-tool blocklist on
  // the command text (case-insensitive substring match — see
  // BLOCKED_PATTERNS below). A match is rejected here with
  // 400 `blocked`, BEFORE anything is stored, so a blocked command
  // can never reach the agent. The agent keeps its own remaining
  // hard blocklist (format/wipe, lock-screen bypass, deletes
  // outside temp/cache, shutdown/reboot) and refuses those with an
  // ack done:false + error "blocked".
  // The credential-tool names live ONLY here, on the relay — never
  // in the Windows agent — because those literals in the agent
  // tripped Windows Defender AMSI at parse time on 2026-11-19.
  if (cmd === "exec") {
    if (typeof body.command !== "string" || body.command.length === 0) {
      return json({ ok: false, error: "bad_command" }, 400);
    }
    if (body.command.length > 20000) {
      return json({ ok: false, error: "command_too_large" }, 400);
    }
    // Credential-tool blocklist — TIGHT by design: only these five
    // case-insensitive substrings, matched against the lower-cased
    // command text. They name credential-dumping tooling / LSASS /
    // NTDS material; ordinary admin commands (Get-Process,
    // Get-Service, disk / SMART reads, etc.) do not contain them
    // and pass through untouched.
    const BLOCKED_PATTERNS = ["mimikatz", "sekurlsa", "lsass", "ntdsutil", "ntds.dit"];
    const lowerCmd = body.command.toLowerCase();
    if (BLOCKED_PATTERNS.some((p) => lowerCmd.includes(p))) {
      return json({ ok: false, error: "blocked" }, 400);
    }
    command.command = body.command;
    if (body.timeout_s !== undefined) {
      if (typeof body.timeout_s !== "number" || body.timeout_s < 0) {
        return json({ ok: false, error: "bad_timeout" }, 400);
      }
      let t = Math.round(body.timeout_s);
      if (t < 1) t = 1;
      if (t > 300) t = 300;
      command.timeout_s = t;
    }
  }

  // screenshot: takes no extra fields.
  // (No validation needed.)

  // mouse: x and y are REQUIRED integers; action is REQUIRED and must
  // be one of move | left_click | right_click | double_click.
  // Bounds against the real screen are the agent's job — the relay
  // does not know the screen size.
  if (cmd === "mouse") {
    if (
      typeof body.x !== "number" || !Number.isInteger(body.x) ||
      typeof body.y !== "number" || !Number.isInteger(body.y)
    ) {
      return json({ ok: false, error: "bad_coords" }, 400);
    }
    const actions = ["move", "left_click", "right_click", "double_click"];
    if (typeof body.action !== "string" || !actions.includes(body.action)) {
      return json({ ok: false, error: "bad_action" }, 400);
    }
    command.x = body.x;
    command.y = body.y;
    command.action = body.action;
  }

  // type: `text` is REQUIRED, a non-empty string, max 1000 chars.
  if (cmd === "type") {
    if (typeof body.text !== "string" || body.text.length === 0) {
      return json({ ok: false, error: "bad_text" }, 400);
    }
    if (body.text.length > 1000) {
      return json({ ok: false, error: "text_too_large" }, 400);
    }
    command.text = body.text;
    // v1.3.4: `process` is OPTIONAL, the window to focus first
    // (e.g. "notepad++"). When present it must be a string of
    // 1-200 chars with no control characters. It is copied into
    // the queued command so it reaches the agent.
    if (body.process !== undefined) {
      if (
        typeof body.process !== "string" || body.process.length === 0 ||
        body.process.length > 200 ||
        /[\u0000-\u001f]/.test(body.process)
      ) {
        return json({ ok: false, error: "bad_process" }, 400);
      }
      command.process = body.process;
    }
  }

  // clean: takes no extra fields. Any extra fields are ignored
  // (not stored). No validation needed beyond the allow-list.

  // repair: `function` is REQUIRED and must be one of
  // system_files | startup | temp | defender_scan. `names` is
  // OPTIONAL; when present it must be an array of strings, each
  // <=50 chars, containing no wildcard characters (* or ?).
  if (cmd === "repair") {
    const functions = ["system_files", "startup", "temp", "defender_scan"];
    if (typeof body.function !== "string" || !functions.includes(body.function)) {
      return json({ ok: false, error: "bad_function" }, 400);
    }
    command.function = body.function;
    if (body.names !== undefined) {
      if (
        !Array.isArray(body.names) ||
        body.names.some(
          (n) =>
            typeof n !== "string" ||
            n.length > 50 ||
            n.includes("*") ||
            n.includes("?")
        )
      ) {
        return json({ ok: false, error: "bad_names" }, 400);
      }
      command.names = body.names;
    }
  }

  // uninstall: `kind` is REQUIRED, one of steam | msi | appx |
  // app | brew | flatpak | pacman (the Windows agent handles
  // steam | msi | appx; the other kinds are for the Mac/Linux
  // agents sharing this relay). `name` is OPTIONAL but, when
  // present, must be a string <=200 chars with no backslash, no
  // slash, and no '..'. `appid` is OPTIONAL, an integer, steam
  // only. At least one of name/appid is required.
  if (cmd === "uninstall") {
    const kinds = ["steam", "msi", "appx", "app", "brew", "flatpak", "pacman"];
    if (typeof body.kind !== "string" || !kinds.includes(body.kind)) {
      return json({ ok: false, error: "bad_kind" }, 400);
    }
    command.kind = body.kind;
    if (body.name !== undefined) {
      if (
        typeof body.name !== "string" || body.name.length === 0 ||
        body.name.length > 200 || body.name.includes("\\") ||
        body.name.includes("/") || body.name.includes("..")
      ) {
        return json({ ok: false, error: "bad_target" }, 400);
      }
      command.name = body.name;
    }
    if (body.appid !== undefined) {
      if (typeof body.appid !== "number" || !Number.isInteger(body.appid)) {
        return json({ ok: false, error: "bad_target" }, 400);
      }
      if (body.kind !== "steam") {
        return json({ ok: false, error: "bad_target" }, 400);
      }
      command.appid = body.appid;
    }
    if (body.name === undefined && body.appid === undefined) {
      return json({ ok: false, error: "bad_target" }, 400);
    }
  }

  // install: `kind` is REQUIRED, one of steam | msi | appx |
  // app | brew | flatpak | pacman | winget | exe. Kinds steam |
  // appx | app | brew | flatpak | pacman behave EXACTLY as in
  // v1.3.2 (name/appid only — a path/url on one of them is
  // ignored, never stored). The Windows agent's Invoke-CmdInstall
  // accepts ONLY winget | msi | exe, and msi/exe REQUIRE a path
  // or url; the relay now mirrors that validation here so a bad
  // install is rejected BEFORE queueing and can never reach the
  // agent. `name` is unchanged (1-200 chars, no backslash, no
  // slash, no '..'). `appid` is unchanged (integer, steam only).
  // `path` / `url`: msi/exe ONLY (never winget). When present
  // they must be strings of 1-500 chars with no '..', and must
  // end in the extension matching the kind (.msi / .exe,
  // case-insensitive). Valid values are copied into the queued
  // command. `args`: exe ONLY, a string of at most 500 chars
  // with no newlines (\n or \r). Presence: winget requires a
  // name; msi/exe require a path or url; the name/appid-only
  // kinds keep the v1.3.2 rule (name or appid required).
  // Every violation below is 400 bad_target (bad kind stays
  // 400 bad_kind, as before).
  if (cmd === "install") {
    const kinds = ["steam", "msi", "appx", "app", "brew", "flatpak", "pacman", "winget", "exe"];
    if (typeof body.kind !== "string" || !kinds.includes(body.kind)) {
      return json({ ok: false, error: "bad_kind" }, 400);
    }
    command.kind = body.kind;
    if (body.name !== undefined) {
      if (
        typeof body.name !== "string" || body.name.length === 0 ||
        body.name.length > 200 || body.name.includes("\\") ||
        body.name.includes("/") || body.name.includes("..")
      ) {
        return json({ ok: false, error: "bad_target" }, 400);
      }
      command.name = body.name;
    }
    if (body.appid !== undefined) {
      if (typeof body.appid !== "number" || !Number.isInteger(body.appid)) {
        return json({ ok: false, error: "bad_target" }, 400);
      }
      if (body.kind !== "steam") {
        return json({ ok: false, error: "bad_target" }, 400);
      }
      command.appid = body.appid;
    }
    // path: msi/exe ONLY. winget carrying a path is rejected;
    // on a name/appid-only kind it is ignored (v1.3.2 behaviour).
    // On msi/exe it must be 1-500 chars, no '..', and end in the
    // extension matching the kind; a valid value is stored.
    if (body.path !== undefined) {
      if (body.kind === "winget") {
        return json({ ok: false, error: "bad_target" }, 400);
      }
      if (body.kind === "msi" || body.kind === "exe") {
        if (
          typeof body.path !== "string" || body.path.length === 0 ||
          body.path.length > 500 || body.path.includes("..")
        ) {
          return json({ ok: false, error: "bad_target" }, 400);
        }
        const ext = body.kind === "msi" ? ".msi" : ".exe";
        if (!body.path.toLowerCase().endsWith(ext)) {
          return json({ ok: false, error: "bad_target" }, 400);
        }
        command.path = body.path;
      }
    }
    // url: same rules as path, msi/exe ONLY.
    if (body.url !== undefined) {
      if (body.kind === "winget") {
        return json({ ok: false, error: "bad_target" }, 400);
      }
      if (body.kind === "msi" || body.kind === "exe") {
        if (
          typeof body.url !== "string" || body.url.length === 0 ||
          body.url.length > 500 || body.url.includes("..")
        ) {
          return json({ ok: false, error: "bad_target" }, 400);
        }
        const ext = body.kind === "msi" ? ".msi" : ".exe";
        if (!body.url.toLowerCase().endsWith(ext)) {
          return json({ ok: false, error: "bad_target" }, 400);
        }
        command.url = body.url;
      }
    }
    // args: exe ONLY, at most 500 chars, no newlines.
    if (body.args !== undefined) {
      if (body.kind !== "exe") {
        return json({ ok: false, error: "bad_target" }, 400);
      }
      if (
        typeof body.args !== "string" || body.args.length > 500 ||
        body.args.includes("\n") || body.args.includes("\r")
      ) {
        return json({ ok: false, error: "bad_target" }, 400);
      }
      command.args = body.args;
    }
    // Presence, by kind (mirrors the agent exactly):
    // winget needs a name; msi/exe need a path or url; the
    // name/appid-only kinds keep the v1.3.2 rule (name or appid).
    if (body.kind === "winget") {
      if (body.name === undefined) {
        return json({ ok: false, error: "bad_target" }, 400);
      }
    } else if (body.kind === "msi" || body.kind === "exe") {
      if (body.path === undefined && body.url === undefined) {
        return json({ ok: false, error: "bad_target" }, 400);
      }
    } else if (body.name === undefined && body.appid === undefined) {
      return json({ ok: false, error: "bad_target" }, 400);
    }
  }

  // deep: takes no extra fields. No validation needed beyond the allow-list.

  // "ping", "sysinfo", "df", "screenshot", "clean", and "deep" take
  // no extra fields.
  // v1.3.1 QUEUE: append to the FIFO queue in doctor:queue (max
  // 10). The old single-slot doctor:command key is RETIRED - the
  // relay no longer writes it.
  let queue = [];
  try {
    const rawQueue = await env.BRIDGE_KV.get("doctor:queue");
    if (rawQueue) {
      const parsed = JSON.parse(rawQueue);
      if (Array.isArray(parsed)) queue = parsed;
    }
  } catch (e) {
    queue = [];
  }
  if (queue.length >= 10) {
    return json({ ok: false, error: "queue_full" }, 400);
  }
  const position = queue.length;
  queue.push(command);
  await env.BRIDGE_KV.put("doctor:queue", JSON.stringify(queue));
  return json({ ok: true, id, position });
}

// GET /doctor/command — v1.3.1: return the HEAD of the queue
// WITHOUT popping it, or {"cmd":null} when the queue is empty.
// The agent pops the head by POSTing /doctor/received after it
// GETs a new command. This handler SHADOWS the v1 GET handler
// (this patch is merged before v1).
if (url.pathname === "/doctor/command" && request.method === "GET") {
  let queue = [];
  try {
    const rawQueue = await env.BRIDGE_KV.get("doctor:queue");
    if (rawQueue) {
      const parsed = JSON.parse(rawQueue);
      if (Array.isArray(parsed)) queue = parsed;
    }
  } catch (e) {
    queue = [];
  }
  if (queue.length === 0) return json({ cmd: null });
  return json(queue[0]);
}

// POST /doctor/received — v1.3.1: remove one command id from the
// queue. Body: {"id":"<uuid>"}. 400 bad_id when id is missing or
// not a string; 400 unknown_id when the id is not in the queue.
if (url.pathname === "/doctor/received" && request.method === "POST") {
  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ ok: false, error: "bad_json" }, 400);
  }
  if (typeof body.id !== "string" || body.id.length === 0) {
    return json({ ok: false, error: "bad_id" }, 400);
  }
  let queue = [];
  try {
    const rawQueue = await env.BRIDGE_KV.get("doctor:queue");
    if (rawQueue) {
      const parsed = JSON.parse(rawQueue);
      if (Array.isArray(parsed)) queue = parsed;
    }
  } catch (e) {
    queue = [];
  }
  const idx = queue.findIndex((c) => c && c.id === body.id);
  if (idx === -1) {
    return json({ ok: false, error: "unknown_id" }, 400);
  }
  queue.splice(idx, 1);
  await env.BRIDGE_KV.put("doctor:queue", JSON.stringify(queue));
  return json({ ok: true });
}

// POST /doctor/ack — v1.3.1 replacement handler (SHADOWS the v1
// one; this patch is merged before v1, same position rule as the
// command handler). NEVER 400 on content: the body is read as
// text once, then parsed as JSON. A body that is not JSON is
// salvaged: the id is pulled out with a regex and a minimal ack
// is stored ({id, done:false, result:{error:'ack_unparseable'}})
// with a 200. A result over 16KB is truncated server-side
// (replaced with {error:'ack_too_large'}). A missing or
// non-object result defaults to {}. 400 only when the body is
// completely empty or unreadable.
if (url.pathname === "/doctor/ack" && request.method === "POST") {
  let rawText = "";
  try {
    rawText = await request.text();
  } catch (e) {
    return json({ ok: false, error: "bad_json" }, 400);
  }
  if (!rawText || rawText.trim().length === 0) {
    return json({ ok: false, error: "bad_json" }, 400);
  }
  let body = null;
  try {
    body = JSON.parse(rawText);
  } catch (e) {
    body = null;
  }
  if (body === null || typeof body !== "object") {
    const m = rawText.match(/"id"\s*:\s*"([^"]+)"/);
    const salvagedId = m ? m[1] : null;
    const ack = {
      id: salvagedId,
      done: false,
      at: new Date().toISOString(),
      result: { error: "ack_unparseable" },
      received_at: new Date().toISOString(),
    };
    await env.BRIDGE_KV.put("doctor:ack", JSON.stringify(ack));
    return json({ ok: true });
  }
  let result = body.result;
  if (result === undefined || typeof result !== "object" || result === null) {
    result = {};
  } else if (JSON.stringify(result).length > 16384) {
    result = { error: "ack_too_large" };
  }
  const ack = {
    id: typeof body.id === "string" ? body.id : null,
    done: body.done === true,
    at: typeof body.at === "string" ? body.at : new Date().toISOString(),
    result,
    received_at: new Date().toISOString(),
  };
  await env.BRIDGE_KV.put("doctor:ack", JSON.stringify(ack));
  return json({ ok: true });
}

// POST /doctor/screenshot — store the latest screenshot from the agent.
// Body: {"image_b64":"<base64 JPEG>", "width":1920, "height":1080,
//        "bytes":123456}
// The image is capped: base64 text over 280000 chars (~210KB of JPEG)
// is rejected with 400 too_large, so one screenshot can never blow
// up the KV value. The command ack for `screenshot` carries only
// {width, height, bytes} — the pixels travel here, not in the ack.
if (url.pathname === "/doctor/screenshot" && request.method === "POST") {
  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ ok: false, error: "bad_json" }, 400);
  }
  if (typeof body.image_b64 !== "string" || body.image_b64.length === 0) {
    return json({ ok: false, error: "bad_image" }, 400);
  }
  if (body.image_b64.length > 280000) {
    return json({ ok: false, error: "too_large" }, 400);
  }
  const shot = {
    image_b64: body.image_b64,
    width: typeof body.width === "number" ? Math.floor(body.width) : null,
    height: typeof body.height === "number" ? Math.floor(body.height) : null,
    bytes: typeof body.bytes === "number" ? Math.floor(body.bytes) : null,
    received_at: new Date().toISOString(),
  };
  await env.BRIDGE_KV.put("doctor:screenshot", JSON.stringify(shot));
  return json({ ok: true });
}

// GET /doctor/screenshot — return the latest stored screenshot.
if (url.pathname === "/doctor/screenshot" && request.method === "GET") {
  const v = await env.BRIDGE_KV.get("doctor:screenshot");
  if (!v) return json({ ok: false, error: "no_screenshot" }, 404);
  return new Response(v, {
    headers: { ...cors, "Content-Type": "application/json" },
  });
}

// POST /doctor/frame — live-feed frame in, latest frame out.
// The agent holds NO token, so this route carries none. It is gated
// on existing session state (KV reads only) via doctorCheckSession
// from the v1.4.0 auth patch (same rule as POST /doctor/command
// minus the token): if a device is paired, the session must be
// unlocked (423 locked); if nothing is paired, the v1.4.0
// safety-valve rule allows it. GET /doctor/frame is open, same as
// the existing GET /doctor/screenshot — anyone with the URL can view
// the latest frame; that is the same exposure the screenshot
// endpoint already has.
// The frame lives ONLY in the DoctorFrameRoom Durable Object's
// memory (worker-frame-room-v1.3.4.js) — no KV write per frame, no
// storage write at all. A worker restart or DO eviction drops the
// frame; the agent re-posts within 60s (liveness) or on next change.
// Body: {"image_b64":"<base64 JPEG>", "width":1920, "height":1080,
//        "bytes":12345}
// The image is capped: base64 text over 100000 chars (~75KB of
// JPEG) is rejected with 400 too_large. The agent targets <=40KB
// JPEGs (quality 40, downscaled); the cap is headroom, not a goal.
if (url.pathname === "/doctor/frame" && request.method === "POST") {
  // Session gate (the auth patch is merged first; fail closed if
  // its helper is missing for any reason).
  if (typeof doctorCheckSession === "function") {
    const sessionFail = await doctorCheckSession(env, json);
    if (sessionFail) return sessionFail;
  } else {
    return json({ ok: false, error: "frame_auth_unavailable" }, 500);
  }
  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ ok: false, error: "bad_json" }, 400);
  }
  if (typeof body.image_b64 !== "string" || body.image_b64.length === 0) {
    return json({ ok: false, error: "bad_image" }, 400);
  }
  if (body.image_b64.length > 100000) {
    return json({ ok: false, error: "too_large" }, 400);
  }
  if (!env.DOCTOR_FRAME_ROOM) {
    return json({ ok: false, error: "frame_room_unbound" }, 500);
  }
  const frame = {
    image_b64: body.image_b64,
    width: typeof body.width === "number" ? Math.floor(body.width) : null,
    height: typeof body.height === "number" ? Math.floor(body.height) : null,
    bytes: typeof body.bytes === "number" ? Math.floor(body.bytes) : null,
    received_at: new Date().toISOString(),
  };
  const frameId = env.DOCTOR_FRAME_ROOM.idFromName("doctor-frame");
  const frameStub = env.DOCTOR_FRAME_ROOM.get(frameId);
  const frameRes = await frameStub.fetch(
    new Request("https://doctor-frame/frame", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(frame),
    })
  );
  const frameText = await frameRes.text();
  return new Response(frameText, {
    status: frameRes.status,
    headers: { ...cors, "Content-Type": "application/json" },
  });
}

// GET /doctor/frame — return the latest stored frame (open, same as
// GET /doctor/screenshot). 404 no_frame when nothing has been posted.
if (url.pathname === "/doctor/frame" && request.method === "GET") {
  if (!env.DOCTOR_FRAME_ROOM) {
    return json({ ok: false, error: "frame_room_unbound" }, 500);
  }
  const frameId = env.DOCTOR_FRAME_ROOM.idFromName("doctor-frame");
  const frameStub = env.DOCTOR_FRAME_ROOM.get(frameId);
  const frameRes = await frameStub.fetch(
    new Request("https://doctor-frame/frame", { method: "GET" })
  );
  const frameText = await frameRes.text();
  return new Response(frameText, {
    status: frameRes.status,
    headers: { ...cors, "Content-Type": "application/json" },
  });
}
