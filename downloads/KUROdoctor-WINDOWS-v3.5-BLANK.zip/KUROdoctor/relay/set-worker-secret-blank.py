#!/usr/bin/env python3
"""Set one Cloudflare Worker secret on YOUR OWN worker (blank variant).

Usage:
  DOCTOR_TOKEN=<value> python3 set-worker-secret-blank.py --name DOCTOR_TOKEN --from-env DOCTOR_TOKEN

The secret value is read from the named environment variable — NEVER
from the command line (it would show in `ps` output and shell history)
— and is NEVER printed back. The script needs the same four variables
as deploy-worker-blank.py:
  CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_API_TOKEN,
  KURODOCTOR_WORKER_NAME (KURODOCTOR_KV_NAMESPACE_ID is not needed
  for secrets).

The PUT upserts: setting a secret that already exists replaces it.
Exit code is non-zero when the API call fails, so a deploy script can
abort before uploading a worker that depends on the secret.
"""
import json
import os
import sys
import urllib.request
import urllib.error


def need(name):
    value = os.environ.get(name, "").strip()
    if not value:
        print("ERROR: missing required environment variable: %s" % name, file=sys.stderr)
        sys.exit(1)
    return value


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        raise RuntimeError("redirect refused")


def main():
    args = sys.argv[1:]
    name = None
    from_env = None
    i = 0
    while i < len(args):
        if args[i] == "--name" and i + 1 < len(args):
            name = args[i + 1]
            i += 2
        elif args[i] == "--from-env" and i + 1 < len(args):
            from_env = args[i + 1]
            i += 2
        else:
            print("ERROR: unknown argument: %s" % args[i], file=sys.stderr)
            return 2
    if not name or not from_env:
        print("ERROR: --name and --from-env are both required", file=sys.stderr)
        return 2
    value = os.environ.get(from_env, "").strip()
    if not value:
        print("ERROR: environment variable %s is empty" % from_env, file=sys.stderr)
        return 2

    account_id = need("CLOUDFLARE_ACCOUNT_ID")
    token = need("CLOUDFLARE_API_TOKEN")
    script_name = need("KURODOCTOR_WORKER_NAME")

    url = (
        "https://api.cloudflare.com/client/v4/accounts/"
        + account_id
        + "/workers/scripts/"
        + script_name
        + "/secrets"
    )
    body = json.dumps({"name": name, "text": value, "type": "secret_text"}).encode()
    req = urllib.request.Request(url, data=body, method="PUT")
    req.add_header("Authorization", "Bearer " + token)
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.build_opener(NoRedirect()).open(req, timeout=60) as r:
            result = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8")
        except Exception:
            detail = ""
        print("ERROR: Cloudflare API returned HTTP %s" % e.code, file=sys.stderr)
        if detail:
            print(detail, file=sys.stderr)
        return 1
    # The API response echoes the secret NAME but never its value.
    print(json.dumps(result, indent=2))
    if not result.get("success"):
        print("ERROR: setting secret %s failed (see above)." % name, file=sys.stderr)
        return 1
    print("Secret %s stored." % name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
