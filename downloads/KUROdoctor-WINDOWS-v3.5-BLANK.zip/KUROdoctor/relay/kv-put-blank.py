#!/usr/bin/env python3
"""Write one KV value on YOUR OWN KV namespace (blank variant).

Usage:
  PAIRING_CODE=<value> python3 kv-put-blank.py --key doctor:session:pairing --from-env PAIRING_CODE

The value is read from the named environment variable — NEVER from the
command line (it would show in `ps` output and shell history) — and is
NEVER printed back. Needs the same variables as deploy-worker-blank.py:
  CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_API_TOKEN,
  KURODOCTOR_KV_NAMESPACE_ID.
Exit code is non-zero when the API call fails.
"""
import json
import os
import sys
import urllib.request
import urllib.error
from urllib.parse import quote


def need(name):
    value = os.environ.get(name, "").strip()
    if not value:
        print("ERROR: missing required environment variable: %s" % name, file=sys.stderr)
        sys.exit(1)
    return value


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        raise RuntimeError("redirect refused")


def main():
    args = sys.argv[1:]
    key = None
    from_env = None
    i = 0
    while i < len(args):
        if args[i] == "--key" and i + 1 < len(args):
            key = args[i + 1]
            i += 2
        elif args[i] == "--from-env" and i + 1 < len(args):
            from_env = args[i + 1]
            i += 2
        else:
            print("ERROR: unknown argument: %s" % args[i], file=sys.stderr)
            return 2
    if not key or not from_env:
        print("ERROR: --key and --from-env are both required", file=sys.stderr)
        return 2
    value = os.environ.get(from_env, "").strip()
    if not value:
        print("ERROR: environment variable %s is empty" % from_env, file=sys.stderr)
        return 2

    account_id = need("CLOUDFLARE_ACCOUNT_ID")
    token = need("CLOUDFLARE_API_TOKEN")
    kv_namespace_id = need("KURODOCTOR_KV_NAMESPACE_ID")

    url = (
        "https://api.cloudflare.com/client/v4/accounts/"
        + account_id
        + "/storage/kv/namespaces/"
        + kv_namespace_id
        + "/values/"
        + quote(key, safe="")
    )
    req = urllib.request.Request(url, data=value.encode(), method="PUT")
    req.add_header("Authorization", "Bearer " + token)
    req.add_header("Content-Type", "text/plain")
    try:
        with urllib.request.build_opener(NoRedirect()).open(req, timeout=60) as r:
            result = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8")
        except Exception:
            detail = ""
        print("ERROR: Cloudflare API returned HTTP %s" % e.code, file=sys.stderr)
        if detail:
            print(detail, file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    if not result.get("success"):
        print("ERROR: KV write for key %s failed (see above)." % key, file=sys.stderr)
        return 1
    print("KV key %s written." % key)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
