#!/usr/bin/env python3
"""Deploy a KUROdoctor worker to YOUR OWN Cloudflare account.

This is the bring-your-own-Cloudflare uploader. It contains NO
hardcoded account ID, worker name, KV namespace ID, subdomain, or
relay URL — every one of those comes from environment variables, and
the script refuses to run with a clear error naming the missing one.

Required environment variables:
  CLOUDFLARE_ACCOUNT_ID   your Cloudflare account ID (dashboard:
                          top-right account menu, or the URL when you
                          open Workers — the 32-hex-char segment)
  CLOUDFLARE_API_TOKEN    an API token with Workers Scripts:Edit and
                          Workers KV Storage:Edit (dashboard: My
                          Profile -> API Tokens -> Create Token)
  KURODOCTOR_WORKER_NAME  the name for your worker, e.g. "kurodoctor"
                          (your worker URL becomes
                          https://<name>.<subdomain>.workers.dev)
  KURODOCTOR_KV_NAMESPACE_ID
                          the ID of a KV namespace you created for the
                          doctor channel (dashboard: Workers & Pages ->
                          KV -> Create a namespace). The script binds
                          it as BRIDGE_KV — the name is historical, it
                          is just the doctor channel's storage.

Usage:
  CLOUDFLARE_ACCOUNT_ID=... CLOUDFLARE_API_TOKEN=... \
  KURODOCTOR_WORKER_NAME=... KURODOCTOR_KV_NAMESPACE_ID=... \
  python3 deploy-worker-blank.py [--script worker.js]

What it does:
  1. Uploads the script with a multipart/form-data PUT, the same
     mechanism Cloudflare's own tooling uses. The metadata declares
     ONLY the KV binding — no Durable Objects, no migrations. (The
     doctor channel never uses Durable Objects; those belong to the
     phone bridge, which is not part of this pack.)
  2. Enables the workers.dev subdomain for the worker (POST
     .../workers/scripts/<name>/subdomain {"enabled": true}).
     API-deployed workers need this or the workers.dev route returns
     Cloudflare error 1042.
  3. Prints the API responses as JSON. A "success": true on both
     means the worker is live.

Nothing in this file belongs to any other owner, and nothing here phones home to
anyone else — it talks only to api.cloudflare.com with YOUR token.
"""
import json
import os
import sys
import urllib.request
import urllib.error


def need(name):
    value = os.environ.get(name, "").strip()
    if not value:
        print("ERROR: missing required environment variable: %s" % name, file=sys.stderr)
        print("Set it and run again. See the header of this file for where each value comes from.", file=sys.stderr)
        sys.exit(1)
    return value


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        raise RuntimeError("redirect refused")


def api_call(url, method, token, body_bytes, content_type):
    req = urllib.request.Request(url, data=body_bytes, method=method)
    req.add_header("Authorization", "Bearer " + token)
    req.add_header("Content-Type", content_type)
    try:
        with urllib.request.build_opener(NoRedirect()).open(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8")
        except Exception:
            detail = ""
        print("ERROR: Cloudflare API returned HTTP %s for %s %s" % (e.code, method, url), file=sys.stderr)
        if detail:
            print(detail, file=sys.stderr)
        sys.exit(1)


def main():
    account_id = need("CLOUDFLARE_ACCOUNT_ID")
    token = need("CLOUDFLARE_API_TOKEN")
    script_name = need("KURODOCTOR_WORKER_NAME")
    kv_namespace_id = need("KURODOCTOR_KV_NAMESPACE_ID")

    script_path = sys.argv[2] if len(sys.argv) > 2 and sys.argv[1] == "--script" else "worker.js"
    with open(script_path, "rb") as f:
        script_bytes = f.read()

    metadata = {
        "main_module": "worker.js",
        "bindings": [
            {
                "type": "kv_namespace",
                "name": "BRIDGE_KV",
                "namespace_id": kv_namespace_id,
            },
        ],
    }

    boundary = "----kurodoctor-blank-multipart-9c41e7b2"
    parts = []
    parts.append(
        ("--" + boundary + "\r\n").encode()
        + b'Content-Disposition: form-data; name="metadata"\r\n'
        + b"Content-Type: application/json\r\n\r\n"
        + json.dumps(metadata).encode()
        + b"\r\n"
    )
    parts.append(
        ("--" + boundary + "\r\n").encode()
        + b'Content-Disposition: form-data; name="worker.js"; filename="worker.js"\r\n'
        + b"Content-Type: application/javascript+module\r\n\r\n"
        + script_bytes
        + b"\r\n"
    )
    parts.append(("--" + boundary + "--\r\n").encode())
    body = b"".join(parts)

    base = "https://api.cloudflare.com/client/v4/accounts/" + account_id + "/workers/scripts/" + script_name
    print("Uploading worker '%s' ..." % script_name)
    result = api_call(base, "PUT", token, body, "multipart/form-data; boundary=" + boundary)
    print(json.dumps(result, indent=2))
    if not result.get("success"):
        print("ERROR: worker upload was not successful (see above).", file=sys.stderr)
        return 1

    print("Enabling the workers.dev subdomain ...")
    sub = api_call(base + "/subdomain", "POST", token, json.dumps({"enabled": True}).encode(), "application/json")
    print(json.dumps(sub, indent=2))
    if not sub.get("success"):
        print("ERROR: subdomain enable was not successful (see above).", file=sys.stderr)
        return 1

    print("DONE. Your worker URL is https://%s.<your-subdomain>.workers.dev" % script_name)
    print("Copy that URL into relay-config.json next to the agent, then run the launcher.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
