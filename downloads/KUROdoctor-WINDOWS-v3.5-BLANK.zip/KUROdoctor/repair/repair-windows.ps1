﻿# KUROdoctor - Windows Repair Module
# =====================================
# v1.3.1 (2026-11-19) - ASCII + restore-point frequency fix.
#   Old hash (v1.3.0): bf4ff4cf0f9a453335c73f25b548d1a772974e3662255a52ebe7f145783a604d
#   (new hash is recorded in the v1.3.1 build report, not here.)
#   - ENCODING: this file used to contain em-dash characters and was
#     never put through the ASCII/CRLF/BOM check. It is now pure
#     ASCII, CRLF line endings, UTF-8 BOM, like the agent files.
#     Every em-dash became a plain hyphen; nothing else changed.
#   - RESTORE POINT: New-KuroRestorePoint now sets
#     SystemRestorePointCreationFrequency to 0 (DWORD) before
#     Checkpoint-Computer, so Windows' 24h frequency limit does not
#     block creation. Admin-gated; failure is non-fatal and the
#     checkpoint is attempted anyway. On Checkpoint-Computer
#     failure it now checks for a restore point created within the
#     last 24h; if one exists, that point IS the snapshot (status
#     'ok', detail names it honestly) instead of failing the whole
#     repair. This is the v1.3.0 live bug: an MSI restore point made
#     ~30 min earlier blocked the checkpoint, the repair job
#     finished with no effect, and its completion ack was lost.
#   - ROOT-CAUSE NOTE (honest, NOT proven - the exact ack bytes
#     were never captured): the most likely cause of the lost
#     repair ack is non-ASCII (em-dash) text from this module
#     reaching the ack (via a job exception/detail string), which
#     PowerShell 5.1 sends in the local ANSI code page and
#     Cloudflare's UTF-8 JSON parser rejects - the pure-ASCII
#     started ack went through, the completion ack did not. The
#     module encoding fix + the agent's ack sanitization together
#     close it. Do not claim this as proven.
# Plain-English protocol (the Doctor's Protocol, docs/doctor-protocol.md):
#   1. Diagnose FIRST. Nothing in this file diagnoses - it only repairs,
#      and only after the owner has heard the plain-language report and
#      said go for that specific repair.
#   2. Report first, owner go per repair. Every function below REFUSES
#      to change anything unless the caller passes -ConfirmGo - the
#      switch the caller passes only after the owner says go for that
#      repair. The one exception is -WhatIf, which never needs -ConfirmGo
#      and never changes anything: it only prints what WOULD happen.
#   3. Files rescued first. Repairs never touch user documents or photos.
#   4. Snapshot / rollback before changes. New-KuroRestorePoint runs
#      FIRST in every repair run and creates a System Restore point. If
#      it fails, this file says so plainly and STOPS - no other repair in
#      that run is allowed to proceed.
#   5. Audit log of everything done. Every function writes one entry
#      (timestamp, repair name, target, before/after, result) to
#      repair-audit.log next to this script, and returns a small result
#      object in the sweep-JSON shape.
#   6. Never auto-run on connect. Nothing in this file runs by itself.
#      Every repair is a separate named function the caller invokes
#      one at a time, after the owner's go.
#   7. No reinstall, no wipe, no reboot without the owner's explicit go
#      for that step. There is NO reboot command in this file at all,
#      no reinstall, and no wipe - this module repairs in place only.
#
# What this module does NOT do (named next steps, not in this slice):
#   - Mac / Android deep repair. Those patients get their own repair
#     modules later; this file is Windows only.
#   - No lock-screen / password bypass, no root / jailbreak, no remote
#     screen takeover, no touching a device unless its owner installed
#     or ran the agent and said go. No iPhones, ever.
#   - No third-party scanner and no deleting files outside the temp /
#     Windows Update caches named in Clear-TempCaches. Defender only.
#
# Usage (from PowerShell, on the patient's Windows PC):
#   . .\repair-windows.ps1
#   New-KuroRestorePoint -WhatIf
#   New-KuroRestorePoint -ConfirmGo
#   Repair-SystemFiles -WhatIf
#   Repair-SystemFiles -ConfirmGo
#   Clear-StartupItems -Names @("OneDrive") -WhatIf
#   Clear-StartupItems -Names @("OneDrive") -ConfirmGo
#   Clear-TempCaches -WhatIf
#   Start-DefenderScan -WhatIf
#
# 100% our own code and text. No bundled tools, no third-party agent.

# ---------------------------------------------------------------------------
# Shared state + helpers (not repairs)
# ---------------------------------------------------------------------------

# Restore-point state for this session. Other repairs check it: if a
# restore point was attempted and FAILED, they refuse to run.
# Values: "not_attempted", "ok", "failed".
$script:KuroRestorePointState = "not_attempted"
$script:KuroRestorePointDetail = "No restore point created yet in this run. Run New-KuroRestorePoint first."

function Get-KuroAuditLogPath {
    # Audit log lives next to this script, always.
    $dir = $PSScriptRoot
    if (-not $dir) { $dir = (Get-Location).Path }
    return (Join-Path $dir "repair-audit.log")
}

function Write-KuroAuditLog {
    param(
        [Parameter(Mandatory = $true)][string]$Repair,
        [string]$Target = "",
        [string]$Before = "",
        [string]$After = "",
        [Parameter(Mandatory = $true)][string]$Result,
        [string]$Detail = ""
    )
    # One line per entry: timestamp | repair | target | before | after | result | detail
    # Newlines are flattened so the log stays one entry per line.
    $stamp = (Get-Date).ToString("o")
    $clean = {
        param($s)
        if ($null -eq $s) { return "" }
        return ([string]$s -replace "`r`n", " " -replace "`n", " " -replace "`r", " " -replace "\|", "/")
    }
    $line = "$stamp | repair=$(& $clean $Repair) | target=$(& $clean $Target) | before=$(& $clean $Before) | after=$(& $clean $After) | result=$(& $clean $Result) | detail=$(& $clean $Detail)"
    try {
        Add-Content -Path (Get-KuroAuditLogPath) -Value $line -Encoding UTF8 -ErrorAction Stop
    }
    catch {
        Write-Host "KUROdoctor: WARNING - could not write the audit log: $($_.Exception.Message)"
        Write-Host "KUROdoctor: the audit entry that could not be saved was: $line"
    }
}

function New-KuroResult {
    param(
        [Parameter(Mandatory = $true)][string]$Repair,
        [Parameter(Mandatory = $true)][ValidateSet("ok", "failed", "dry_run", "skipped")][string]$Status,
        [string]$Before = "",
        [string]$After = "",
        [string]$Detail = ""
    )
    return [PSCustomObject]@{
        repair = $Repair
        status = $Status
        before = $Before
        after  = $After
        detail = $Detail
    }
}

function Test-KuroGo {
    # Returns $true only when this run is allowed to change things.
    # -WhatIf never needs -ConfirmGo and never changes anything.
    param(
        [Parameter(Mandatory = $true)][string]$Repair,
        [switch]$WhatIf,
        [switch]$ConfirmGo
    )
    if ($WhatIf) { return $true }
    if (-not $ConfirmGo) {
        Write-Host "KUROdoctor: $Repair refused - no owner go. Pass -ConfirmGo after the owner says go for this repair, or -WhatIf to preview it without changing anything."
        return $false
    }
    return $true
}

function Test-KuroRestorePointOk {
    # After a FAILED restore point, no other repair in this run proceeds.
    param([Parameter(Mandatory = $true)][string]$Repair)
    if ($script:KuroRestorePointState -eq "failed") {
        Write-Host "KUROdoctor: $Repair refused - the System Restore point failed earlier in this run ($script:KuroRestorePointDetail). No repairs run without a restore point. Fix the restore-point problem first, then try again."
        return $false
    }
    if ($script:KuroRestorePointState -eq "not_attempted") {
        Write-Host "KUROdoctor: NOTE - no System Restore point has been created yet in this run. Run New-KuroRestorePoint first so this repair can be undone. Continuing only because the owner said go for this repair."
    }
    return $true
}

# ---------------------------------------------------------------------------
# 1. New-KuroRestorePoint - FIRST, always. If this fails, STOP.
# ---------------------------------------------------------------------------
function New-KuroRestorePoint {
    param(
        [switch]$WhatIf,
        [switch]$ConfirmGo
    )
    $repair = "restore-point"
    $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
    $description = "KUROdoctor repair $stamp"

    if ($WhatIf) {
        $detail = "Would create a System Restore point named '$description' (Checkpoint-Computer, type MODIFY_SETTINGS). Nothing changed."
        Write-Host "KUROdoctor [dry run] $repair : $detail"
        Write-KuroAuditLog -Repair $repair -Target "System Restore" -Before "restore point not yet created" -After "no change (dry run)" -Result "dry_run" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "dry_run" -Before "restore point not yet created" -After "no change (dry run)" -Detail $detail)
    }

    if (-not (Test-KuroGo -Repair $repair -ConfirmGo:$ConfirmGo)) {
        $detail = "Refused: owner go not given. Pass -ConfirmGo after the owner says go, or -WhatIf to preview."
        Write-KuroAuditLog -Repair $repair -Target "System Restore" -Before "restore point not yet created" -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before "restore point not yet created" -After "no change" -Detail $detail)
    }

    # Before: how many restore points exist, and what is the newest one?
    $beforeCount = 0
    $beforeLatest = "none found"
    try {
        $existing = @(Get-ComputerRestorePoint -ErrorAction Stop)
        $beforeCount = $existing.Count
        if ($beforeCount -gt 0) {
            $beforeLatest = ($existing | Sort-Object CreationTime -Descending | Select-Object -First 1).Description
        }
    }
    catch {
        $beforeLatest = "could not list existing restore points: $($_.Exception.Message)"
    }
    $before = "$beforeCount restore point(s) on this PC; newest: $beforeLatest"

    # v1.3.1: lift Windows' 24h restore-point frequency limit
    # (SystemRestorePointCreationFrequency = 0) so a point made
    # earlier today does not block this one. Admin-gated; a
    # failure here is non-fatal - Checkpoint-Computer still tries.
    try {
        $freqPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore"
        Set-ItemProperty -Path $freqPath -Name "SystemRestorePointCreationFrequency" -Value 0 -Type DWord -ErrorAction Stop
    }
    catch {
        Write-Host "KUROdoctor: NOTE - could not set SystemRestorePointCreationFrequency to 0 ($($_.Exception.Message)); trying the checkpoint anyway."
    }

    try {
        Checkpoint-Computer -Description $description -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
        $script:KuroRestorePointState = "ok"
        $script:KuroRestorePointDetail = "Restore point '$description' created."
        $after = "$($beforeCount + 1) restore point(s) on this PC; newest: $description"
        $detail = "System Restore point created: '$description'. If any later repair goes wrong, the PC can be rolled back to this point."
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target "System Restore" -Before $before -After $after -Result "ok" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "ok" -Before $before -After $after -Detail $detail)
    }
    catch {
        $checkpointError = $_.Exception.Message
        # v1.3.1: a fresh point was refused - but a point made
        # within the last 24h is still a valid snapshot. Use it
        # honestly (name it) instead of failing the whole repair.
        $recentPoint = $null
        try {
            $recentPoint = @(Get-ComputerRestorePoint -ErrorAction Stop) |
                Where-Object { $_.CreationTime -gt (Get-Date).AddHours(-24) } |
                Sort-Object CreationTime -Descending | Select-Object -First 1
        }
        catch { $recentPoint = $null }
        if ($null -ne $recentPoint) {
            $script:KuroRestorePointState = "ok"
            $script:KuroRestorePointDetail = "Using existing restore point '$($recentPoint.Description)' from $($recentPoint.CreationTime)."
            $after = "$beforeCount restore point(s) on this PC; newest: $($recentPoint.Description) (created $($recentPoint.CreationTime))"
            $detail = "No NEW restore point was created - Windows refused a fresh one ($checkpointError) - but a restore point from $($recentPoint.CreationTime) named '$($recentPoint.Description)' already exists within the last 24h, so THAT point is the snapshot for this repair. If any later repair goes wrong, the PC can be rolled back to it."
            Write-Host "KUROdoctor: $detail"
            Write-KuroAuditLog -Repair $repair -Target "System Restore" -Before $before -After $after -Result "ok" -Detail $detail
            return (New-KuroResult -Repair $repair -Status "ok" -Before $before -After $after -Detail $detail)
        }
        $script:KuroRestorePointState = "failed"
        $script:KuroRestorePointDetail = $checkpointError
        $detail = "FAILED to create a System Restore point: $checkpointError STOPPING - no other repair will run in this session until a restore point can be created. (Windows sometimes refuses a second restore point made soon after another one; if a point was just made, that is the likely cause - check the existing points first.)"
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target "System Restore" -Before $before -After "no change - no restore point created" -Result "failed" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "failed" -Before $before -After "no change - no restore point created" -Detail $detail)
    }
}

# ---------------------------------------------------------------------------
# 2. Repair-SystemFiles - sfc /scannow
# ---------------------------------------------------------------------------
function Repair-SystemFiles {
    param(
        [switch]$WhatIf,
        [switch]$ConfirmGo
    )
    $repair = "system-files"
    $target = "sfc /scannow"

    if ($WhatIf) {
        $detail = "Would run 'sfc /scannow' - Windows scans its protected system files and repairs any that are damaged. Nothing changed."
        Write-Host "KUROdoctor [dry run] $repair : $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before "system files not yet scanned" -After "no change (dry run)" -Result "dry_run" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "dry_run" -Before "system files not yet scanned" -After "no change (dry run)" -Detail $detail)
    }

    if (-not (Test-KuroGo -Repair $repair -ConfirmGo:$ConfirmGo)) {
        $detail = "Refused: owner go not given. Pass -ConfirmGo after the owner says go, or -WhatIf to preview."
        Write-KuroAuditLog -Repair $repair -Target $target -Before "system files not yet scanned" -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before "system files not yet scanned" -After "no change" -Detail $detail)
    }

    if (-not (Test-KuroRestorePointOk -Repair $repair)) {
        $detail = "Refused: the System Restore point failed earlier in this run. No repairs run without a restore point."
        Write-KuroAuditLog -Repair $repair -Target $target -Before "system files not yet scanned" -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before "system files not yet scanned" -After "no change" -Detail $detail)
    }

    $before = "system files not yet scanned in this run"
    Write-Host "KUROdoctor: running 'sfc /scannow' - this takes a few minutes. Please wait."
    try {
        $output = (& sfc.exe /scannow 2>&1 | Out-String)
        $code = $LASTEXITCODE
        $after = "sfc finished (exit code $code)"
        if ($code -eq 0) {
            $detail = "System file check finished clean. $output"
            Write-Host "KUROdoctor: system file check finished clean."
            Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After $after -Result "ok" -Detail $detail
            return (New-KuroResult -Repair $repair -Status "ok" -Before $before -After $after -Detail $detail)
        }
        else {
            $detail = "sfc /scannow finished with exit code $code (not clean - it may have found problems it could not fix, or it may need the Windows image repaired first with Repair-WindowsImage). Output: $output"
            Write-Host "KUROdoctor: $detail"
            Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After $after -Result "failed" -Detail $detail
            return (New-KuroResult -Repair $repair -Status "failed" -Before $before -After $after -Detail $detail)
        }
    }
    catch {
        $detail = "FAILED to run sfc /scannow: $($_.Exception.Message)"
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change - scan did not run" -Result "failed" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "failed" -Before $before -After "no change - scan did not run" -Detail $detail)
    }
}

# ---------------------------------------------------------------------------
# 3. Repair-WindowsImage - DISM /Online /Cleanup-Image /RestoreHealth
# ---------------------------------------------------------------------------
function Repair-WindowsImage {
    param(
        [switch]$WhatIf,
        [switch]$ConfirmGo
    )
    $repair = "windows-image"
    $target = "DISM /Online /Cleanup-Image /RestoreHealth"

    if ($WhatIf) {
        $detail = "Would run 'DISM /Online /Cleanup-Image /RestoreHealth' - Windows repairs its own repair store (the image sfc uses), using Windows Update as the source. Nothing changed."
        Write-Host "KUROdoctor [dry run] $repair : $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before "Windows image not yet repaired" -After "no change (dry run)" -Result "dry_run" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "dry_run" -Before "Windows image not yet repaired" -After "no change (dry run)" -Detail $detail)
    }

    if (-not (Test-KuroGo -Repair $repair -ConfirmGo:$ConfirmGo)) {
        $detail = "Refused: owner go not given. Pass -ConfirmGo after the owner says go, or -WhatIf to preview."
        Write-KuroAuditLog -Repair $repair -Target $target -Before "Windows image not yet repaired" -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before "Windows image not yet repaired" -After "no change" -Detail $detail)
    }

    if (-not (Test-KuroRestorePointOk -Repair $repair)) {
        $detail = "Refused: the System Restore point failed earlier in this run. No repairs run without a restore point."
        Write-KuroAuditLog -Repair $repair -Target $target -Before "Windows image not yet repaired" -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before "Windows image not yet repaired" -After "no change" -Detail $detail)
    }

    $before = "Windows image not yet repaired in this run"
    Write-Host "KUROdoctor: running DISM RestoreHealth - this takes several minutes and needs the internet (it fetches clean files from Windows Update). Please wait."
    try {
        $output = (& DISM.exe /Online /Cleanup-Image /RestoreHealth 2>&1 | Out-String)
        $code = $LASTEXITCODE
        $after = "DISM finished (exit code $code)"
        if ($code -eq 0) {
            $detail = "Windows image repair finished. $output"
            Write-Host "KUROdoctor: Windows image repair finished."
            Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After $after -Result "ok" -Detail $detail
            return (New-KuroResult -Repair $repair -Status "ok" -Before $before -After $after -Detail $detail)
        }
        else {
            $detail = "DISM finished with exit code $code (not clean - it may need a working internet connection to fetch clean files). Output: $output"
            Write-Host "KUROdoctor: $detail"
            Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After $after -Result "failed" -Detail $detail
            return (New-KuroResult -Repair $repair -Status "failed" -Before $before -After $after -Detail $detail)
        }
    }
    catch {
        $detail = "FAILED to run DISM: $($_.Exception.Message)"
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change - DISM did not run" -Result "failed" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "failed" -Before $before -After "no change - DISM did not run" -Detail $detail)
    }
}

# ---------------------------------------------------------------------------
# 4. Clear-StartupItems - disable ONLY startup items the owner named
# ---------------------------------------------------------------------------
function Clear-StartupItems {
    param(
        [Parameter(Mandatory = $false)][string[]]$Names = @(),
        [switch]$WhatIf,
        [switch]$ConfirmGo
    )
    $repair = "startup-items"
    $target = ($Names -join ", ")

    if ($Names.Count -eq 0) {
        $detail = "No startup items named. Nothing disabled - pass -Names @(\"Exact Name\") with the exact name(s) from the diagnosis report. Only named items are ever disabled."
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target "(none named)" -Before "startup items unchanged" -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before "startup items unchanged" -After "no change" -Detail $detail)
    }

    # Source of truth: the Run / RunOnce registry keys, plus
    # Win32_StartupCommand (which reports the same entries and a few
    # others, e.g. Startup-folder shortcuts). Match by EXACT name.
    $runKeys = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
    )
    $found = @()
    foreach ($key in $runKeys) {
        try {
            $props = Get-ItemProperty -Path $key -ErrorAction Stop
            foreach ($prop in $props.PSObject.Properties) {
                if ($prop.Name -in @("PSPath", "PSParentPath", "PSChildName", "PSDrive", "PSProvider")) { continue }
                if ($Names -contains $prop.Name) {
                    $found += [PSCustomObject]@{ Name = $prop.Name; Command = "$($prop.Value)"; Source = $key; Kind = "registry" }
                }
            }
        }
        catch {
            # Key missing or unreadable - not an error, just no entries there.
        }
    }
    try {
        $cim = Get-CimInstance -ClassName Win32_StartupCommand -ErrorAction Stop
        foreach ($entry in $cim) {
            if ($Names -contains $entry.Name) {
                $already = $found | Where-Object { $_.Name -eq $entry.Name }
                if (-not $already) {
                    $found += [PSCustomObject]@{ Name = $entry.Name; Command = "$($entry.Command)"; Source = "$($entry.Location)"; Kind = "startup-command-only" }
                }
            }
        }
    }
    catch {
        # Win32_StartupCommand unavailable - the registry keys above are the source.
    }

    $before = "named items found: $($found.Count) of $($Names.Count) named ($target)"
    if ($found.Count -eq 0) {
        $detail = "None of the named startup items ($target) were found in the Run registry keys or Win32_StartupCommand. Nothing disabled - check the exact spelling in the diagnosis report."
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before $before -After "no change" -Detail $detail)
    }

    $registryItems = @($found | Where-Object { $_.Kind -eq "registry" })
    $otherItems = @($found | Where-Object { $_.Kind -ne "registry" })
    $plan = ($found | ForEach-Object { "$($_.Name) [$($_.Source)] = $($_.Command)" }) -join "; "

    if ($WhatIf) {
        $detail = "Would disable $($registryItems.Count) startup item(s) by removing their Run registry value(s): $plan. " +
            "Items found only through Win32_StartupCommand ($($otherItems.Count)) would NOT be touched - they are not in a Run key, so removing them here is not safe; they are listed only. Nothing changed, and no item you did not name is touched."
        Write-Host "KUROdoctor [dry run] $repair : $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change (dry run)" -Result "dry_run" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "dry_run" -Before $before -After "no change (dry run)" -Detail $detail)
    }

    if (-not (Test-KuroGo -Repair $repair -ConfirmGo:$ConfirmGo)) {
        $detail = "Refused: owner go not given. Pass -ConfirmGo after the owner says go, or -WhatIf to preview."
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before $before -After "no change" -Detail $detail)
    }

    if (-not (Test-KuroRestorePointOk -Repair $repair)) {
        $detail = "Refused: the System Restore point failed earlier in this run. No repairs run without a restore point."
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before $before -After "no change" -Detail $detail)
    }

    $disabled = @()
    $failed = @()
    foreach ($item in $registryItems) {
        try {
            Remove-ItemProperty -Path $item.Source -Name $item.Name -ErrorAction Stop
            $disabled += $item.Name
            Write-Host "KUROdoctor: disabled startup item '$($item.Name)' (removed from $($item.Source)). Its old command was saved in the audit log so it can be put back: $($item.Command)"
        }
        catch {
            $failed += "$($item.Name): $($_.Exception.Message)"
        }
    }
    $after = "disabled: $($disabled.Count); not disabled (registry): $($failed.Count); listed only, not touched: $($otherItems.Count)"
    if ($failed.Count -eq 0 -and $disabled.Count -gt 0) {
        $detail = "Disabled $($disabled.Count) named startup item(s): $($disabled -join ', '). Their old commands are in the audit log for rollback. Items found only through Win32_StartupCommand ($($otherItems.Count)) were listed, not touched. No other startup item was changed."
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before "$before | commands: $plan" -After $after -Result "ok" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "ok" -Before $before -After $after -Detail $detail)
    }
    else {
        $detail = "Disabled $($disabled.Count) item(s) ($($disabled -join ', ')); failed to disable $($failed.Count): $($failed -join '; '). Items found only through Win32_StartupCommand ($($otherItems.Count)) were listed, not touched."
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before "$before | commands: $plan" -After $after -Result "failed" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "failed" -Before $before -After $after -Detail $detail)
    }
}

# ---------------------------------------------------------------------------
# 5. Clear-TempCaches - temp + Windows Update cache only. Never user files.
# ---------------------------------------------------------------------------
function Clear-TempCaches {
    param(
        [switch]$WhatIf,
        [switch]$ConfirmGo
    )
    $repair = "temp-caches"
    $target = "`$env:TEMP, C:\Windows\Temp, SoftwareDistribution\Download"
    $tempDirs = @()
    if ($env:TEMP) { $tempDirs += $env:TEMP }
    $tempDirs += "C:\Windows\Temp"
    $tempDirs += "C:\Windows\SoftwareDistribution\Download"

    # Measure one folder: file count + total bytes (errors tolerated -
    # locked files are simply skipped and counted as left behind).
    function Measure-KuroTempDir {
        param([string]$Path)
        $bytes = 0; $count = 0
        if (-not (Test-Path -LiteralPath $Path)) { return @{ Bytes = 0; Count = 0; Exists = $false } }
        try {
            $files = Get-ChildItem -LiteralPath $Path -Recurse -File -Force -ErrorAction SilentlyContinue
            foreach ($f in $files) { $bytes += $f.Length; $count += 1 }
        }
        catch { }
        return @{ Bytes = $bytes; Count = $count; Exists = $true }
    }

    $beforeParts = @()
    $beforeBytes = 0; $beforeCount = 0
    foreach ($dir in $tempDirs) {
        $m = Measure-KuroTempDir -Path $dir
        $beforeBytes += $m.Bytes; $beforeCount += $m.Count
        $beforeParts += "$dir = $($m.Count) files, $([math]::Round($m.Bytes / 1MB, 1)) MB"
    }
    $before = "$beforeCount temp/cache files, $([math]::Round($beforeBytes / 1MB, 1)) MB total | " + ($beforeParts -join "; ")

    if ($WhatIf) {
        $detail = "Would delete $beforeCount temp/cache files ($([math]::Round($beforeBytes / 1MB, 1)) MB) from ONLY these three places: $($tempDirs -join ', '). The folders themselves stay; files in use are left alone. No documents, photos, or any other user files are touched. Nothing changed."
        Write-Host "KUROdoctor [dry run] $repair : $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change (dry run)" -Result "dry_run" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "dry_run" -Before $before -After "no change (dry run)" -Detail $detail)
    }

    if (-not (Test-KuroGo -Repair $repair -ConfirmGo:$ConfirmGo)) {
        $detail = "Refused: owner go not given. Pass -ConfirmGo after the owner says go, or -WhatIf to preview."
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before $before -After "no change" -Detail $detail)
    }

    if (-not (Test-KuroRestorePointOk -Repair $repair)) {
        $detail = "Refused: the System Restore point failed earlier in this run. No repairs run without a restore point."
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before $before -After "no change" -Detail $detail)
    }

    # Delete files INSIDE the three folders only - never the folders
    # themselves, never anything outside them. Locked files are skipped.
    $removedCount = 0; $removedBytes = 0; $leftCount = 0
    foreach ($dir in $tempDirs) {
        if (-not (Test-Path -LiteralPath $dir)) { continue }
        try {
            $items = Get-ChildItem -LiteralPath $dir -Force -ErrorAction SilentlyContinue
            foreach ($item in $items) {
                try {
                    if ($item.PSIsContainer) {
                        $sub = Get-ChildItem -LiteralPath $item.FullName -Recurse -File -Force -ErrorAction SilentlyContinue
                        foreach ($f in $sub) { $removedBytes += $f.Length }
                        Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction Stop
                        $removedCount += $sub.Count
                    }
                    else {
                        $removedBytes += $item.Length
                        Remove-Item -LiteralPath $item.FullName -Force -ErrorAction Stop
                        $removedCount += 1
                    }
                }
                catch {
                    $leftCount += 1
                }
            }
        }
        catch {
            $leftCount += 1
        }
    }
    $afterParts = @()
    $afterBytes = 0; $afterCount = 0
    foreach ($dir in $tempDirs) {
        $m = Measure-KuroTempDir -Path $dir
        $afterBytes += $m.Bytes; $afterCount += $m.Count
        $afterParts += "$dir = $($m.Count) files, $([math]::Round($m.Bytes / 1MB, 1)) MB"
    }
    $after = "$afterCount temp/cache files left, $([math]::Round($afterBytes / 1MB, 1)) MB total | " + ($afterParts -join "; ")
    $detail = "Removed $removedCount temp/cache file(s), freeing $([math]::Round($removedBytes / 1MB, 1)) MB, from the three temp/update-cache folders only. $leftCount item(s) could not be removed (in use) and were left alone. No documents, photos, or other user files were touched."
    Write-Host "KUROdoctor: $detail"
    Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After $after -Result "ok" -Detail $detail
    return (New-KuroResult -Repair $repair -Status "ok" -Before $before -After $after -Detail $detail)
}

# ---------------------------------------------------------------------------
# 6. Start-DefenderScan - Windows Defender quick scan + quarantine, Defender only
# ---------------------------------------------------------------------------
function Start-DefenderScan {
    param(
        [switch]$WhatIf,
        [switch]$ConfirmGo
    )
    $repair = "defender-scan"
    $target = "Windows Defender QuickScan"

    # Defender status first - a scan means nothing if Defender is missing
    # or turned off, and we say so plainly instead of pretending.
    $defenderPresent = $false
    $defenderEnabled = $false
    $statusText = "unknown"
    try {
        $mpStatus = Get-MpComputerStatus -ErrorAction Stop
        $defenderPresent = $true
        $defenderEnabled = [bool]$mpStatus.RealTimeProtectionEnabled
        $statusText = "Defender present; real-time protection enabled: $defenderEnabled; last quick scan: $($mpStatus.QuickScanStartTime); last full scan: $($mpStatus.FullScanStartTime)"
    }
    catch {
        $statusText = "Windows Defender status could not be read: $($_.Exception.Message)"
    }
    $before = $statusText

    if ($WhatIf) {
        $detail = "Would run a Windows Defender QuickScan (Start-MpScan -ScanType QuickScan), then list what Defender found (Get-MpThreatDetection). Defender quarantines anything it finds itself - this file deletes no files. Nothing changed. Current status: $statusText"
        Write-Host "KUROdoctor [dry run] $repair : $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change (dry run)" -Result "dry_run" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "dry_run" -Before $before -After "no change (dry run)" -Detail $detail)
    }

    if (-not (Test-KuroGo -Repair $repair -ConfirmGo:$ConfirmGo)) {
        $detail = "Refused: owner go not given. Pass -ConfirmGo after the owner says go, or -WhatIf to preview."
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before $before -After "no change" -Detail $detail)
    }

    if (-not $defenderPresent) {
        $detail = "Windows Defender is not available on this PC (its status could not be read). No scan ran, no third-party scanner was used, and no files were touched."
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change - Defender unavailable" -Result "failed" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "failed" -Before $before -After "no change - Defender unavailable" -Detail $detail)
    }
    if (-not $defenderEnabled) {
        $detail = "Windows Defender is present but real-time protection is OFF. No scan ran - a scan from a disabled Defender cannot be trusted. Turn Defender back on first, then run this repair again. No files were touched."
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change - Defender disabled" -Result "failed" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "failed" -Before $before -After "no change - Defender disabled" -Detail $detail)
    }

    # A scan reads files; it does not change them, so no restore-point
    # gate is needed here - but the session flag still stops the run
    # if a restore point failed earlier, for consistency.
    if (-not (Test-KuroRestorePointOk -Repair $repair)) {
        $detail = "Refused: the System Restore point failed earlier in this run. No repairs run without a restore point."
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change" -Result "skipped" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "skipped" -Before $before -After "no change" -Detail $detail)
    }

    Write-Host "KUROdoctor: running a Windows Defender QuickScan - this takes a few minutes. Please wait."
    $scanStart = Get-Date
    try {
        Start-MpScan -ScanType QuickScan -ErrorAction Stop
    }
    catch {
        $detail = "FAILED to start the Defender QuickScan: $($_.Exception.Message) No files were touched."
        Write-Host "KUROdoctor: $detail"
        Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After "no change - scan did not start" -Result "failed" -Detail $detail
        return (New-KuroResult -Repair $repair -Status "failed" -Before $before -After "no change - scan did not start" -Detail $detail)
    }
    $duration = [math]::Round(((Get-Date) - $scanStart).TotalSeconds, 1)

    $threats = @()
    try {
        $threats = @(Get-MpThreatDetection -ErrorAction Stop)
    }
    catch {
        $threats = @()
    }
    $threatList = ($threats | ForEach-Object { "$($_.ThreatName) (severity: $($_.SeverityID), found: $($_.InitialDetectionTime), quarantined by Defender: yes)" }) -join "; "
    if ($threats.Count -eq 0) { $threatList = "no threats reported" }
    $after = "QuickScan finished in ${duration}s; threats found: $($threats.Count); $threatList"
    $detail = "Windows Defender QuickScan finished in ${duration}s. Threats found: $($threats.Count). $threatList Defender quarantines what it finds itself - this file deleted nothing. If threats were found, the owner should hear the plain-language report before anything else is done with them."
    Write-Host "KUROdoctor: $detail"
    Write-KuroAuditLog -Repair $repair -Target $target -Before $before -After $after -Result "ok" -Detail $detail
    return (New-KuroResult -Repair $repair -Status "ok" -Before $before -After $after -Detail $detail)
}
