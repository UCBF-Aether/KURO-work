#!/usr/bin/env python3
"""KUROdoctor agent v1.3.10 -- Linux / SteamOS (Steam Deck).

A doctor for devices, running from the HOME directory only.

  * v1.3.9 launch kind (live on the Deck 2026-11-22): the root
    agent could not open a GUI app as the session user -- exec
    refuses runuser / env / su / sudo, and launching flatpak as
    root breaks the sandbox (bwrap fd failure). New `launch`
    kind: {"cmd": "launch", "desktop": "/path/to/app.desktop"}
    reads the real installed app's .desktop file, parses Exec,
    strips field codes, and runs it detached via the same
    _wrap_as_user() drop the capture path uses. Narrow: the file
    must live in a real XDG application dir, and the parsed Exec
    argv must pass the exec argv blocklist -- launch can only run
    what exec could run, as the session user instead of root.
    No root fallback. The exec blocklist is unchanged.
  * v1.3.9 mouse fix: the relay (v1.3.4) sends left_click /
    right_click / double_click, but the agent accepted only
    move / click / move_click -- only "move" passed both, so no
    click ever worked end to end. cmd_mouse now accepts the
    relay names too (left_click = move + button 1, right_click
    = move + button 3, double_click = move + two button-1
    clicks) and keeps the old names for compat. xdotool on
    Wayland is still unproven live (it needs an XWayland
    DISPLAY); a xdotool that cannot open a display fails
    plainly, never a fake ok.
  * v1.3.9 install fix (live on the Deck 2026-11-22): the flatpak
    install kind ran `flatpak install -y <appid>` with NO remote
    and NO scope. On the owner's Deck flathub exists in BOTH
    installations (system + the owner's user one), so flatpak
    cannot resolve the remote, prints an interactive prompt
    ("Which do you want to use (0 to abort)? [0-2]") and aborts
    with "No remote chosen to resolve matches for
    'net.cozic.joplin_desktop'". The duplicate remote STAYS
    (the owner's choice -- their own apps live in the user installation),
    so the doctor now installs explicitly:
    `flatpak install -y --system flathub <appid>`. The
    already-installed precheck now queries BOTH scopes, so a
    user-scope install still counts as already installed instead
    of the doctor adding a system duplicate next to it.
  * v1.3.10 full access (the owner's word is the authorisation,
    2026-11-22): when the owner gives an explicit go naming the
    exact action and target, that IS the authorisation -- the
    agent must not second-guess it. Commands may carry an
    `owner_go` stamp {"action": <verb>, "target": <exact target>};
    the agent verifies the stamp's target matches the command's
    actual target exactly (same path normalisation the blocklist
    uses) and lifts ONLY the matching rule: rm of a protected
    path ("rm"), writes to trust destinations ("write"), wipe /
    format ("wipe"), crontab installs ("crontab"), mutating
    systemctl --user ("systemctl"). The stamp NEVER lifts
    credential dumping, lock-screen / password bypass, `net
    user` password changes, shutdown / reboot, bcdedit,
    flashing, or anything touching a device whose owner did not
    authorise it. Without a matching stamp those actions are
    refused exactly as before. Also new in v1.3.10: `runuser` /
    `sudo -u` via exec ONLY to drop to the detected session user
    (never elevation, never root, never another user); `flatpak
    uninstall --delete-data` allowed (the string checker no
    longer mistakes the flag for a Desktop delete); `launch`
    takes an executable path (AppImage / script / binary) and an
    optional `args` list. `python3 -c` stays refused -- write
    files with cp / tee / install to a non-trust destination
    instead (that is what blocked the .desktop write, not the
    trust rule: a .desktop under ~/.local/share/applications
    was never a trust destination).
  * v1.3.8 eyes fix (live on the Deck 2026-11-22): spectacle's raw
    JPEG (275,527 bytes -> ~367,000 base64 chars) is rejected by
    the relay frame room (400 too_large over 100,000 chars), and
    `convert` / `magick` / `gm` are all absent on the Deck -- so
    the live-feed frame path now scales with ffmpeg (present at
    /usr/bin/ffmpeg) when `convert` is absent or fails on every
    scale, same 50% / 25% / 12.5% ladder at the 40KB cap, run as
    the session owner when the agent is root. Raw-as-is is kept
    only when no converter
    exists or every conversion fails, and it logs that the frame
    will likely be rejected as too_large.
  * v1.3.8 queue un-wedge: a queue head already in seen_ids is
    re-popped (POST /doctor/received, best-effort, never executed
    again) instead of being skipped silently forever.
  * v1.3.7 eyes fix (live on the Deck 2026-11-22): the agent runs as
    root, but on Wayland only the SESSION OWNER can ask KWin / the
    portal for a screenshot -- root asking is ignored (spectacle
    exits 1: "On Wayland, Spectacle requires KDE Plasma's KWin
    compositor, which does not seem to be available"). So when the
    agent runs as root and a session owner is detectable, the
    screenshot chain runs each tool AS that user (runuser -u
    <user> -- ..., else sudo -u <user> ...), with the session env
    passed through, and the capture file goes in the session
    user's writable area -- never /root/.cache. If the drop fails,
    the same tool is retried directly as root, exactly as v1.3.6
    did; unprivileged runs capture directly, unchanged.

Steam Deck realities this agent is built for:
  * SteamOS is Arch-based. The root filesystem is READ-ONLY by default
    (steamos-readonly). This agent NEVER writes outside $HOME on its
    own initiative, and NEVER installs packages on its own initiative.
  * v1.3.6 runs as ADMIN (root) when the launcher elevates it -- the
    owner types HIS OWN password at the kdesu / sudo prompt, and the
    launcher never stores, logs, echoes, or auto-types it. As root
    the agent can SEE everything: kernel log errors (dmesg was
    blocked for the unprivileged user), SMART drive health, and
    every user's processes. When elevation is declined, the agent
    runs UNPRIVILEGED instead and the root-only sweep sections
    report "unavailable (needs admin)" -- never a crash, never
    faked data.
  * Admin access does NOT make anything silent. Show-first / ok-gate
    still rules: every fix is shown in chat first and runs only on
    the owner's go for that exact action. Root makes the exec
    blocklist MORE important, not less -- format / wipe and deleting
    user documents / photos run only with his explicit go for that
    exact target (the v1.3.10 owner_go stamp, above); credential
    digging, lock-screen bypass, password changes, and reboot /
    shutdown are refused even with it, as root, by the blocklist
    below.
  * Run it in Desktop Mode, from Konsole. pacman is the package
    manager. This agent never sets the owner's password, and it
    NEVER runs `steamos-readonly disable` -- the owner does that
    himself when he chooses to.
  * Screenshot / mouse / type depend on tools that may or may not be
    installed (grim, spectacle, scrot, import, xwd, xdotool). The agent CHECKS
    for them and returns 'unavailable' loudly when one is missing --
    it never installs anything and never fails silently.

The doctor ALWAYS goes in blind: on first connect -- before any
command is polled and before the user is asked anything -- the agent
runs a full diagnostic sweep on its own (drive health, disk space,
startup items, running processes, temperatures, pending updates,
boot time, plus a background malware scan -- and, when running as
admin, kernel log errors, SMART drive health, and the full process
list) and puts the results in the boot report. The user's guess ("it's riddled with viruses") is
optional context only, never the diagnosis.

Stdlib only -- no pip dependencies. Python 3.

Relay base URL comes from relay-config.json next to this script, or
from the KURODOCTOR_RELAY environment variable (env wins). There is
NO hardcoded relay URL anywhere in this file. If the URL is blank or
missing, the agent prints a plain-language message telling the owner
to set it and exits cleanly (exit code 2, no traceback).

Shared relay contract (same queue/ack shape as the Windows / Mac
agents; the phone commands below are new in the Linux v1.3.5 agent):
    POST /doctor/report    boot report (on demand only --
                           no periodic heartbeat)
    POST /doctor/frame     live-feed frame (change-only, JPEG q40,
                           <=40KB, max 1 post per 5s, 60s liveness;
                           no token -- the agent holds none)
    GET  /doctor/command   head of the queue, WITHOUT popping
    POST /doctor/received  {id} pops that id from the queue
    POST /doctor/ack       {id, done, at, result}
KV keys: doctor:latest (report), doctor:queue (FIFO, max 10),
doctor:ack (latest ack), doctor:screenshot. The old single-slot
doctor:command key is RETIRED.
The agent posts /doctor/received IMMEDIATELY after GETting a new
command, BEFORE executing it. A per-process seen-ids set stays as a
backstop against duplicates.

Polling: 1s while active (a command was seen recently or jobs are
pending), else 10s. No periodic heartbeat: the agent reports once
at boot (retried only until it first lands) and otherwise only
when commanded -- status comes from ping / sysinfo acks.
Idle traffic is roughly 8,640 polls/day (reads only -- zero KV
writes at idle), against ~86,000/day if it polled every second
nonstop.

Ack hygiene: every ack string field is sanitized to ASCII
(non-ASCII -> '?', control chars stripped except newline/tab/CR),
each string field is capped at 4096 chars (appended with
'... [truncated]'), and the whole ack JSON is capped at ~16KB. If a
full ack POST fails, the agent falls back to one minimal ack
{id, done, at, result:{error:'ack_content_rejected'}}.

Async commands (exec / repair / deep / uninstall / install) return a 'started'
ack immediately (done:true, started:true, status:'running') and a
completion ack when the job finishes -- including on timeout, with
any partial output. Any result carrying an 'error' key is acked
done:false. A job is never left silent.

Commands implemented:
    ping       no-op, ack done
    sysinfo    uname, CPU, RAM, disks, network interfaces
    smart      smartctl -a --json per disk; smartctl_missing if absent
    df         disk space
    ls         {"path": ...} directory listing
    cat        {"path": ...} file contents, base64; >100KB refused
    dmesg      last 100 lines of the kernel log
    exec       {"command": ..., "timeout_s": 1-300, "owner_override": bool,
                "owner_go": {"action": ..., "target": ...}}
               owner_go is the owner's explicit go for that exact
               action+target (see the v1.3.10 note above); without a
               matching stamp, protected rm / trust writes / wipes
               are refused exactly as before. A wipe authorised by
               a stamp is restated in the started ack's owner_go.
               runs in a background job; parsed to an argv list and
               argv-blocklist-checked first -- NEVER a shell (see the
               ARGV EXECUTION section below run_exec_sync). Shell
               syntax (| > < ; & $() backticks, any $VAR but $HOME)
               is refused with a pointer to exec_pipeline.
    exec_pipeline
               {"stages": [[argv...], ...], "timeout_s": 1-300} -- up
               to 4 stages, each an argv list, connected by real
               pipes in Python (no shell). Every stage is checked
               by the argv blocklist BEFORE anything runs, so a
               blocked stage refuses the whole pipeline. This is
               the shape for the diagnostic pipelines the doctor
               uses live, e.g. du -sh ... | sort -rh | head -8,
               sent as [["du","-sh",...],["sort","-rh"],["head","-8"]].
               Relay kind: needs the relay allow-list entry (the
               exec-pipeline relay patch); until the relay carries
               it, the agent accepts the kind locally but the relay
               rejects it with unknown_cmd.
    screenshot capture via grim -> spectacle -> scrot -> import ->
               xwd (first one present); JPEG <=200KB when a converter
               is available, or as-is when the capture is already JPEG
    mouse      {"action": "move"|"click"|"move_click"|"left_click"|
               "right_click"|"double_click", "x": int, "y": int,
               "button": 1|2|3} via xdotool, if present. The relay
               (v1.3.4) sends left_click/right_click/double_click;
               the agent maps them to button 1 / button 3 / a
               double button-1 click, and keeps move/click/
               move_click for compat. xdotool is X11-only: on a
               Wayland session it needs an XWayland DISPLAY, and
               when xdotool cannot open a display the command
               fails plainly (mouse_failed) -- never a fake ok.
    launch     {"desktop": "/path/to/app.desktop"} -- launch a GUI
               app AS THE SESSION USER, detached (v1.3.9). Reads
               the .desktop file, parses its Exec line, strips
               field codes (%u %U %f %F %i %c %k, flatpak @@u @@),
               and runs the resulting argv via the same
               _wrap_as_user() drop the capture path uses
               (runuser -u <user> -- ..., session env passed
               through). Narrow by design: the file must live in
               a real XDG application dir (/usr/share/applications,
               /usr/local/share/applications, /var/lib/flatpak, or
               the session user's ~/.local/share/applications /
               ~/.local/share/flatpak), and the parsed Exec argv
               must pass the same _argv_block_reason the exec kind
               applies -- so launch can only run what exec could
               run, but as the session user instead of root. No
               root fallback: root with no detectable session
               owner, or no wrapper to drop with, refuses plainly.
               Never a shell. The exec blocklist is unchanged
               except for v1.3.10's narrow exec drop (runuser /
               sudo -u ONLY to the detected session user); env /
               su stay refused via exec. v1.3.10: launch also
               takes {"executable": "/path/to/app.AppImage"} -- an
               executable file under the session user's home or
               /opt (never /tmp, never a system binary), run as
               the session user the same way -- plus an optional
               "args" list (argv only, each arg block-checked like
               an Exec token; a single string is refused).
    type       {"text": ..., "process": ...} (<=1000 chars) via
               xdotool, if present; optional "process" (a Linux app
               name) focuses that app's window first -- no window,
               nothing is typed (see _focus_window)
    clean      Trash + /tmp + ~/.cache only, before/after MB
    deep       read-only deep diagnosis (async; every section
               independent, failure tolerated with an 'unavailable' note)
    repair     {"function": system_files|startup|temp|defender_scan|
               service|pacman, "names": [...]} -- snapshot-first via
               repair-linux-1.3.6.py; refuses loudly if the snapshot
               cannot be written. service takes "action":
               start|stop|restart|enable|disable (systemctl, admin
               only); pacman installs or, with "remove": true,
               removes ONLY the named packages (admin only, never a
               blind full upgrade). Both refuse needs_admin when the
               agent is not running as root.
    uninstall  {"kind": flatpak|pacman|app, "name": ..., "appid": int}
               running-process precheck first; pacman gated on a
               writable root filesystem AND working sudo
    install    {"kind": brew|flatpak|pacman, "name": ...}
               tool-present + already-installed prechecks first;
               pacman gated on a writable root filesystem AND
               working sudo; verified installed afterwards
    phone_checkup
               read-only phone health over USB adb: model, Android
               version, SDK, storage, battery, RAM, app count.
               One compact ack. adb missing -> adb_missing;
               no phone -> no_device; not allowed yet ->
               unauthorized ("tap Allow on the phone").
    phone_repair
               {"kind": clear_cache|disable|force_stop|uninstall,
                "package": ...} -- adb shell pm/am on the USB
               phone, before/after state in the ack. Same package
               regex/limits and protected set as the relay;
               protected -> protected_package. Never touches
               documents or photos.

Usage:
    python3 kuro-doctor-agent-linux-1.3.6.py            # normal
    python3 kuro-doctor-agent-linux-1.3.6.py --once     # one poll cycle
    python3 kuro-doctor-agent-linux-1.3.6.py --report-only
    python3 kuro-doctor-agent-linux-1.3.6.py --sweep-only

Live feed (v1.3.4): once per poll iteration the agent calls
send_frame_tick(), which mirrors the Windows agent's
Send-KDDoctorFrameTick -- same capture path, JPEG q40, 40KB cap,
SHA-256 change-only compare, max 1 post per 5s, 60s liveness
re-post, POST /doctor/frame with no token. It never throws into
the agent loop. Honest Wayland limit: grim needs a wlr-screencopy
compositor and scrot/import/xwd + xdotool are X11-only, so on a
Wayland desktop (e.g. the Deck's gamescope / Plasma Wayland)
without a native capturer, screenshots report
screenshot_unavailable and mouse/type/focus report
unavailable/no_window -- never silently. Spectacle (KDE's own
tool, Wayland-native, shipped on the Deck) is second in the chain
and writes JPEG directly, so the live feed needs no ImageMagick
on the Deck. The Deck itself is the real test; nothing here
claims Wayland capture works until a frame actually lands.

Back-compat note: a v1.3.1-or-older agent against a v1.3.2 relay runs
only the first queued command (it never sends /doctor/received).
Agent and relay must move together.
"""

import argparse
import base64
import glob
import hashlib
import json
import os
import platform
import pwd
import re
import shlex
import shutil
import socket
import stat as statmod
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone

VERSION = "1.3.11"
AGENT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(AGENT_DIR, "relay-config.json")
REPAIR_MODULE = os.path.join(AGENT_DIR, "repair-linux-1.3.6.py")


def _current_uid():
    """Effective uid, or -1 where the platform has no geteuid."""
    try:
        return os.geteuid()
    except AttributeError:  # pragma: no cover - non-POSIX
        return -1


def is_admin():
    """True when this agent runs as root (effective uid 0).

    The launcher elevates with the owner's own password (kdesu /
    sudo); when it cannot, the agent runs unprivileged and root-only
    sections report 'unavailable (needs admin)' instead of faking
    data. Read dynamically (os.geteuid at call time) so tests can
    monkeypatch os.geteuid or this function to simulate either side.
    """
    return _current_uid() == 0

POLL_ACTIVE_S = 1        # seconds between polls while active
POLL_IDLE_S = 10         # seconds between polls while idle
ACTIVE_WINDOW_S = 30     # a command seen within this window keeps polling fast
CAT_MAX_BYTES = 100 * 1024  # 100 KB cap on cat
SCREENSHOT_MAX_BYTES = 200 * 1024  # 200 KB cap on screenshot JPEG
EXEC_MAX_CHARS = 20000
EXEC_TIMEOUT_MIN_S = 1
EXEC_TIMEOUT_MAX_S = 300
ACK_STRING_CAP = 4096
ACK_JSON_CAP = 16 * 1024
TYPE_MAX_CHARS = 1000
SCAN_TIMEOUT_S = 1800  # 30 minutes max for the background malware scan


# ---------------------------------------------------------------- logging

def log(msg):
    """Timestamped log line to stderr (stdout stays clean for --sweep-only JSON)."""
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(f"[{ts}] {msg}", flush=True, file=sys.stderr)


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def audit_log(msg):
    """Append one audit line under $HOME only. Every line carries
    the uid (0 = root), so a root exec is always attributable.
    Never raises, never blocks: if the audit file cannot be written,
    the line is dropped and the agent carries on (the stderr log
    still has it). Callers audit an exec BEFORE it runs -- the
    audit call sits ahead of the blocklist check and the job start
    in execute_command, never after."""
    try:
        audit_dir = os.path.join(os.path.expanduser("~"), ".cache",
                                 "kurodoctor")
        os.makedirs(audit_dir, exist_ok=True)
        with open(os.path.join(audit_dir, "audit.log"), "a",
                  encoding="utf-8") as fh:
            fh.write(f"{now_iso()} uid={_current_uid()} {msg}\n")
    except OSError:
        pass


# ---------------------------------------------------------------- relay config

def load_relay_url():
    """Relay base URL: KURODOCTOR_RELAY env var wins, else
    relay-config.json next to this script. Returns '' when blank or
    missing -- the caller turns that into the plain-language exit."""
    env_url = os.environ.get("KURODOCTOR_RELAY", "").strip()
    if env_url:
        return env_url
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as fh:
            cfg = json.load(fh)
        if isinstance(cfg, dict):
            url = cfg.get("relay_url", "")
            if isinstance(url, str):
                return url.strip()
    except (OSError, ValueError):
        pass
    return ""


RELAY = load_relay_url().rstrip("/")
BOOT_ID = str(uuid.uuid4())


def relay_missing_message():
    return (
        "KUROdoctor: no relay URL is set.\n"
        "Open relay-config.json next to the agent and put your Cloudflare\n"
        "worker URL in \"relay_url\" (the full https:// address of your\n"
        "doctor relay worker), then run the launcher again.\n"
        "Or set the KURODOCTOR_RELAY environment variable to the same URL.\n"
        "Nothing was sent anywhere, and no report was saved -- the agent\n"
        "cannot reach its relay without that address. Exiting."
    )


# ---------------------------------------------------------------- relay I/O

def relay_post(path, payload):
    """POST JSON to the relay. Returns parsed JSON (or {}), or None on error."""
    url = RELAY + path
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json",
                 "User-Agent": f"KUROdoctor/{VERSION}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", "replace")
            if not body.strip():
                return {}
            try:
                return json.loads(body)
            except json.JSONDecodeError:
                return {"_raw": body}
    except urllib.error.HTTPError as e:
        log(f"relay POST {path} -> HTTP {e.code}")
        return None
    except Exception as e:  # network down, DNS failure, relay unreachable...
        log(f"relay POST {path} failed: {e}")
        return None


def relay_get(path):
    """GET from the relay. Returns parsed JSON (or {}), or None on error."""
    url = RELAY + path
    req = urllib.request.Request(
        url, headers={"User-Agent": f"KUROdoctor/{VERSION}"}, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", "replace")
            if not body.strip():
                return {}
            try:
                return json.loads(body)
            except json.JSONDecodeError:
                return {"_raw": body}
    except urllib.error.HTTPError as e:
        # 204 / 404 with "no command waiting" is normal, not an error.
        if e.code in (204, 404):
            return {}
        log(f"relay GET {path} -> HTTP {e.code}")
        return None
    except Exception as e:
        log(f"relay GET {path} failed: {e}")
        return None


# ---------------------------------------------------------------- ack hygiene

def _sanitize_string(value):
    """ASCII-only, control chars stripped except newline/tab/CR,
    capped at ACK_STRING_CAP chars."""
    out = []
    for ch in value:
        o = ord(ch)
        if o > 127:
            out.append("?")
        elif o < 32 and ch not in ("\n", "\t", "\r"):
            continue
        else:
            out.append(ch)
    text = "".join(out)
    if len(text) > ACK_STRING_CAP:
        text = text[:ACK_STRING_CAP] + "... [truncated]"
    return text


def sanitize_result(value):
    """Recursively sanitize an ack result dict: every string field
    ASCII-only and capped. Lists/dicts/numbers pass through."""
    if isinstance(value, str):
        return _sanitize_string(value)
    if isinstance(value, dict):
        return {str(k): sanitize_result(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [sanitize_result(v) for v in value]
    return value


def build_ack(cmd_id, done, result):
    """Build a sanitized ack, capped at ~16KB of JSON. If the sanitized
    ack is still over the cap, progressively truncate the largest
    string fields until it fits (never silently drop the error key)."""
    result = sanitize_result(result if isinstance(result, dict)
                             else {"value": result})
    ack = {"id": cmd_id, "done": bool(done), "at": now_iso(),
           "result": result}
    encoded = json.dumps(ack).encode("utf-8")
    if len(encoded) <= ACK_JSON_CAP:
        return ack
    # Over cap: shrink string fields, largest first, keeping 'error'.
    flat = []

    def collect(obj, path):
        if isinstance(obj, str):
            flat.append((len(obj), path))
        elif isinstance(obj, dict):
            for k, v in obj.items():
                collect(v, path + [k])
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                collect(v, path + [i])

    collect(result, [])
    flat.sort(key=lambda item: item[0], reverse=True)
    for _length, path in flat:
        target = result
        for key in path[:-1]:
            target = target[key]
        leaf = path[-1]
        current = target[leaf]
        if isinstance(current, str) and len(current) > 200:
            target[leaf] = current[:200] + "... [truncated]"
        encoded = json.dumps(ack).encode("utf-8")
        if len(encoded) <= ACK_JSON_CAP:
            break
    if len(json.dumps(ack).encode("utf-8")) > ACK_JSON_CAP:
        # Last resort: keep only the error, if any, plus a note.
        slim = {}
        if isinstance(result, dict) and "error" in result:
            slim["error"] = result["error"]
        slim["note"] = "ack result was too large and was trimmed"
        ack["result"] = slim
    return ack


def post_ack(ack):
    """Post an ack, up to 3 attempts 2s apart. On total failure, try
    one minimal ack. Returns True if anything was delivered."""
    for attempt in range(1, 4):
        if relay_post("/doctor/ack", ack) is not None:
            log(f"acked id={ack.get('id')} done={ack.get('done')} "
                f"(attempt {attempt})")
            return True
        log(f"ack for id={ack.get('id')} NOT delivered "
            f"(attempt {attempt} of 3)")
        if attempt < 3:
            time.sleep(2)
    minimal = {"id": ack.get("id"), "done": False, "at": now_iso(),
               "result": {"error": "ack_content_rejected"}}
    if relay_post("/doctor/ack", minimal) is not None:
        log(f"minimal fallback ack delivered for id={ack.get('id')}")
        return True
    log(f"ack for id={ack.get('id')} FAILED after 3 attempts - "
        "the result may be lost at the relay")
    return False


# ---------------------------------------------------------------- SteamOS facts

def os_release():
    """Parsed /etc/os-release ({} when unreadable)."""
    info = {}
    try:
        with open("/etc/os-release", encoding="utf-8",
                  errors="replace") as fh:
            for line in fh:
                if "=" in line:
                    key, val = line.split("=", 1)
                    info[key.strip()] = val.strip().strip('"')
    except OSError:
        pass
    return info


def is_steamos():
    info = os_release()
    return (info.get("ID", "").lower() == "steamos"
            or "steamos" in info.get("NAME", "").lower()
            or "steam" in info.get("NAME", "").lower())


def root_readonly():
    """True when / is mounted read-only (the SteamOS default). Read
    from /proc/mounts -- no writes, no test file, no sudo."""
    try:
        with open("/proc/mounts", encoding="utf-8",
                  errors="replace") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) >= 4 and parts[1] == "/":
                    opts = parts[3].split(",")
                    return "ro" in opts
    except OSError:
        pass
    return None  # unknown -- callers treat unknown as "assume read-only"


def sudo_works():
    """True only when sudo runs non-interactively (no password prompt).
    `sudo -n true` never prompts; a failure means sudo is unavailable
    or needs a password the owner has not set yet."""
    if shutil.which("sudo") is None:
        return False
    try:
        proc = subprocess.run(["sudo", "-n", "true"],
                              capture_output=True, text=True, timeout=10)
        return proc.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


# ---------------------------------------------------------------- device info

def _read_file(path):
    try:
        with open(path, "r", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return ""


def device_model():
    """Best-effort device model string from DMI, else the machine arch."""
    for path in ("/sys/devices/virtual/dmi/id/product_name",
                 "/sys/devices/virtual/dmi/id/board_name"):
        val = _read_file(path)
        if val:
            vendor = _read_file("/sys/devices/virtual/dmi/id/sys_vendor")
            return f"{vendor} {val}".strip() if vendor else val
    return platform.machine()


def list_disks():
    """Whole-disk device paths, e.g. ['/dev/sda', '/dev/nvme0n1']."""
    disks = []
    try:
        out = subprocess.run(
            ["lsblk", "-J", "-d", "-o", "NAME,TYPE"],
            capture_output=True, text=True, timeout=10)
        if out.returncode == 0:
            data = json.loads(out.stdout)
            for dev in data.get("blockdevices", []):
                if dev.get("type") == "disk":
                    disks.append("/dev/" + dev["name"])
            if disks:
                return disks
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    try:
        with open("/proc/partitions") as f:
            for line in f:
                parts = line.split()
                if len(parts) == 4:
                    name = parts[3]
                    if name.startswith(("sd", "vd", "hd")) and name[-1].isalpha():
                        disks.append("/dev/" + name)
                    elif name.startswith("nvme") and name.endswith(
                            tuple(f"n{i}" for i in range(10))):
                        disks.append("/dev/" + name)
    except OSError:
        pass
    return sorted(set(disks))


def network_state():
    """Interfaces and addresses, best effort, no external tools required."""
    interfaces = {}
    try:
        for _idx, name in socket.if_nameindex():
            mac = _read_file(f"/sys/class/net/{name}/address")
            operstate = _read_file(f"/sys/class/net/{name}/operstate")
            interfaces[name] = {"mac": mac or None, "state": operstate or None,
                                "addresses": []}
    except OSError:
        pass
    try:
        out = subprocess.run(["ip", "-j", "addr"], capture_output=True,
                             text=True, timeout=10)
        if out.returncode == 0:
            for iface in json.loads(out.stdout):
                name = iface.get("ifname")
                if name not in interfaces:
                    interfaces[name] = {}
                interfaces[name]["addresses"] = [
                    a.get("local") for a in iface.get("addr_info", [])
                    if a.get("local")]
                interfaces[name]["state"] = iface.get("operstate")
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    hostname = socket.gethostname()
    return {"hostname": hostname, "interfaces": interfaces}


def smart_summary():
    """Short SMART summary per disk, or smartctl_missing."""
    if shutil.which("smartctl") is None:
        return {"status": "smartctl_missing",
                "summary": "smartctl is not installed on this machine, "
                           "so drive health could not be read."}
    results = []
    for disk in list_disks():
        try:
            out = subprocess.run(
                ["smartctl", "-a", "--json", disk],
                capture_output=True, text=True, timeout=30)
            try:
                data = json.loads(out.stdout)
            except json.JSONDecodeError:
                results.append({"disk": disk, "error": "unparsable_output"})
                continue
            status = "unknown"
            passed = None
            if isinstance(data.get("smart_status"), dict):
                passed = data["smart_status"].get("passed")
                status = "passed" if passed else "FAILED"
            temp = None
            if isinstance(data.get("temperature"), dict):
                temp = data["temperature"].get("current")
            results.append({
                "disk": disk,
                "model": data.get("model_name"),
                "serial": data.get("serial_number"),
                "status": status,
                "smart_passed": passed,
                "temperature_c": temp,
                "power_on_hours": (
                    data.get("power_on_time") or {}).get("hours"),
            })
        except (OSError, subprocess.SubprocessError) as e:
            results.append({"disk": disk, "error": str(e)})
    if not results:
        return {"status": "no_disks",
                "summary": "No disks found to check."}
    bad = [r["disk"] for r in results if r.get("status") == "FAILED"]
    if bad:
        summary = "WARNING: SMART reports a failing drive: " + ", ".join(bad)
    else:
        summary = "SMART: " + ", ".join(
            f"{r['disk']} {r.get('status', 'unknown')}" for r in results)
    return {"status": "ok", "summary": summary, "disks": results}


def build_report():
    """The boot report payload. The blind sweep runs here,
    on first connect, before any command is polled -- its results ride
    in the boot report. The one-shot sweep-scan follow-up reuses the
    cached sweep."""
    disks = list_disks()
    df = disk_space()
    ro = root_readonly()
    return {
        "agent": "kuro-doctor",
        "version": VERSION,
        "platform": "linux-steamos" if is_steamos() else "linux",
        "boot_id": BOOT_ID,
        "admin": is_admin(),
        "uid": _current_uid(),
        "at": now_iso(),
        "device": {
            "model": device_model(),
            "hostname": socket.gethostname(),
            "os": f"{platform.system()} {platform.release()}",
            "kernel": platform.version(),
            "arch": platform.machine(),
            "os_release": os_release().get("PRETTY_NAME", ""),
            "steamos": is_steamos(),
            "root_readonly": ro,
        },
        "disks": disks,
        "disk_space": df,
        "smart": smart_summary(),
        "network": network_state(),
        "sweep": get_sweep(),
    }


def send_report():
    report = build_report()
    log(f"sending report: model={report['device']['model']} "
        f"steamos={report['device']['steamos']} "
        f"root_readonly={report['device']['root_readonly']} "
        f"disks={report['disks']} smart={report['smart'].get('status')}")
    result = relay_post("/doctor/report", report)
    if result is None:
        log("report NOT delivered (relay unreachable)")
        return False
    log("report delivered")
    return True

# ---------------------------------------------------------------- blind sweep
# The doctor ALWAYS goes in blind. On first connect -- before any command
# is polled and before the user is asked anything -- the agent runs a full
# diagnostic sweep on its own and reports what IT finds. The user's guess
# ("it's riddled with viruses") is optional context only, never the
# diagnosis. Fast sections run synchronously and go in the boot report;
# the malware scan is slow, so it runs in a background thread and its
# result arrives later as a follow-up POST /doctor/report with
# kind "sweep-scan-result". Every section is independent: one that cannot
# run reports {"status": "unavailable", "reason": ...} and never blocks
# the others or the boot report.
# The 8 original sweep sections: smart, disk_space, startup_items,
# processes, temps, pending_updates, boot_time, malware_scan.
# v1.3.6 adds 3 root-only sections: kernel_log, smart_root,
# processes_all. Each reports {"status": "unavailable", "reason":
# "needs admin"} when the agent is not running as root.

SWEEP_VERSION = 2
_SCAN = {"thread": None, "result": None, "started": False}
_SWEEP_CACHE = None


def _unavailable(reason):
    return {"status": "unavailable", "reason": reason}


def _run(cmd, timeout=15):
    """Run a command, return stdout on success, '' on any failure.

    Never raises. A nonzero exit counts as failure (no usable output).
    """
    try:
        out = subprocess.run(cmd, capture_output=True, text=True,
                             timeout=timeout)
        return out.stdout if out.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def sweep_smart():
    """Drive health (SMART) -- reuses smart_summary(), normalised."""
    s = smart_summary()
    if s.get("status") != "ok":
        return _unavailable(s.get("summary") or s.get("status")
                            or "unknown")
    return {"status": "ok", "summary": s.get("summary"),
            "disks": s.get("disks", [])}


def sweep_disk_space():
    """Disk space per mount, with use_pct added."""
    df = disk_space()
    if "error" in df:
        return _unavailable(df["error"])
    mounts = []
    for m in df.get("mounts", []):
        total = m.get("total_gb") or 0
        used = m.get("used_gb") or 0
        mounts.append({
            "mount": m["mount"],
            "total_gb": total,
            "used_gb": used,
            "free_gb": m.get("free_gb"),
            "use_pct": round(used / total * 100, 1) if total else 0,
        })
    return {"status": "ok", "mounts": mounts}


def sweep_startup():
    """Startup items: systemd user units + xdg autostart + user crontab."""
    items = []
    saw_source = False
    out = _run(["systemctl", "--user", "list-unit-files", "--type=service",
                "--state=enabled", "--no-legend", "--no-pager"], timeout=15)
    if out:
        saw_source = True
        for line in out.splitlines():
            parts = line.split()
            if parts and parts[0].endswith(".service"):
                items.append({"name": parts[0], "command": "",
                              "source": "systemd-user"})
    home = os.path.expanduser("~")
    for autostart_dir in (os.path.join(home, ".config", "autostart"),
                          "/etc/xdg/autostart"):
        if os.path.isdir(autostart_dir):
            saw_source = True
            try:
                for fname in sorted(os.listdir(autostart_dir)):
                    if not fname.endswith(".desktop"):
                        continue
                    cmd = ""
                    try:
                        with open(os.path.join(autostart_dir, fname),
                                  errors="replace") as f:
                            for line in f:
                                if line.startswith("Exec="):
                                    cmd = line[5:].strip()
                                    break
                    except OSError:
                        pass
                    items.append({"name": fname[:-len(".desktop")],
                                  "command": cmd, "source": "xdg-autostart"})
            except OSError:
                pass
    if shutil.which("crontab") is not None:
        saw_source = True
        out = _run(["crontab", "-l"], timeout=10)
        for line in out.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                items.append({"name": line[:80], "command": line,
                              "source": "crontab"})
    if not saw_source:
        return _unavailable("no startup sources readable "
                            "(no systemctl, no /etc/xdg/autostart, "
                            "no crontab)")
    return {"status": "ok", "count": len(items), "items": items[:50]}


def sweep_processes():
    """Process count + top 10 by CPU and by memory (via ps, else /proc).

    The /proc fallback has no CPU % -- top_cpu is [] there and top_memory
    is sorted by RSS.
    """
    procs = []
    out = _run(["ps", "-eo", "pid,comm,%cpu,rss", "--sort=-%cpu"],
               timeout=15)
    for line in out.splitlines()[1:]:  # skip the header
        parts = line.split()
        if len(parts) < 4:
            continue
        try:
            procs.append({
                "pid": int(parts[0]),
                "name": parts[1],
                "cpu_pct": float(parts[2]),
                "mem_mb": round(int(parts[3]) / 1024.0, 1),
            })
        except ValueError:
            continue
    if procs:
        top_cpu = procs[:10]
        top_mem = sorted(procs, key=lambda p: p["mem_mb"],
                         reverse=True)[:10]
        return {"status": "ok", "count": len(procs),
                "top_cpu": top_cpu, "top_memory": top_mem}
    try:
        pids = [d for d in os.listdir("/proc") if d.isdigit()]
    except OSError as e:
        return _unavailable(f"cannot list processes: {e}")
    for pid in pids:
        try:
            name = ""
            rss_kb = 0
            with open(f"/proc/{pid}/status") as f:
                for line in f:
                    if line.startswith("Name:"):
                        name = line.split(":", 1)[1].strip()
                    elif line.startswith("VmRSS:"):
                        rss_kb = int(line.split()[1])
            procs.append({"pid": int(pid), "name": name, "cpu_pct": None,
                          "mem_mb": round(rss_kb / 1024.0, 1)})
        except (OSError, ValueError):
            continue
    if not procs:
        return _unavailable("no processes visible in /proc")
    top_mem = sorted(procs, key=lambda p: p["mem_mb"], reverse=True)[:10]
    return {"status": "ok", "count": len(pids),
            "top_cpu": [], "top_memory": top_mem}


def sweep_temps():
    """Temperatures: /sys/class/thermal, else `sensors` if present."""
    sensors = []
    base = "/sys/class/thermal"
    try:
        for zone in sorted(os.listdir(base)):
            if not zone.startswith("thermal_zone"):
                continue
            temp = _read_file(os.path.join(base, zone, "temp"))
            typ = _read_file(os.path.join(base, zone, "type"))
            if temp:
                try:
                    sensors.append({
                        "name": typ or zone,
                        "temp_c": round(int(temp) / 1000.0, 1),
                    })
                except ValueError:
                    pass
    except OSError:
        pass
    if not sensors:
        out = _run(["sensors"], timeout=10)
        for line in out.splitlines():
            m = re.search(r"^([^:]+):\s+\+?([0-9.]+)°C", line)
            if m:
                sensors.append({"name": m.group(1).strip(),
                                "temp_c": float(m.group(2))})
    if not sensors:
        return _unavailable("no thermal zones in /sys/class/thermal "
                            "and no `sensors` output")
    return {"status": "ok", "sensors": sensors}


def sweep_pending_updates():
    """Pending updates. pacman first (Arch / SteamOS), apt as fallback.
    Read-only: nothing is ever installed or downloaded."""
    if shutil.which("pacman") is not None:
        out = _run(["pacman", "-Qu"], timeout=60)
        updates = []
        for line in out.splitlines():
            line = line.strip()
            if line:
                updates.append(line.split()[0])
        return {"status": "ok", "manager": "pacman",
                "count": len(updates), "updates": updates[:20],
                "reboot_required": False,
                "note": "SteamOS updates itself as a whole image; "
                        "pacman -Qu lists package updates only and this "
                        "agent never installs any of them."}
    if shutil.which("apt") is None and shutil.which("apt-get") is None:
        return _unavailable("no package manager found "
                            "(neither pacman nor apt/apt-get present)")
    out = _run(["apt", "list", "--upgradable"], timeout=30)
    updates = []
    for line in out.splitlines():
        if "/" in line and "upgradable" in line:
            updates.append(line.split("/")[0].strip())
    return {"status": "ok", "manager": "apt", "count": len(updates),
            "updates": updates[:20],
            "reboot_required": os.path.exists("/var/run/reboot-required")}


def sweep_boot_time():
    """Uptime always; last boot duration from systemd-analyze if present."""
    uptime_s = None
    try:
        with open("/proc/uptime") as f:
            uptime_s = round(float(f.read().split()[0]))
    except (OSError, ValueError):
        pass
    section = {"status": "ok", "uptime_s": uptime_s}
    out = _run(["systemd-analyze"], timeout=15)
    m = re.search(r"=\s*([0-9.]+)s", out)
    if m:
        section["last_boot_s"] = float(m.group(1))
        section["last_boot_source"] = "systemd-analyze"
    return section


def _scan_worker():
    """Background thread: run clamscan over the HOME directory only
    (the whole-filesystem scan of the rescue stick makes no sense on a
    Deck -- the system partition is read-only and owned by Valve).
    The result lands in _SCAN["result"]; the main loop picks it up and
    posts the follow-up report. Never raises."""
    started = time.monotonic()
    home = os.path.expanduser("~")
    try:
        out = subprocess.run(
            ["clamscan", "-r", "--infected", "--no-summary",
             "--exclude-dir=^/proc", "--exclude-dir=^/sys",
             "--exclude-dir=^/dev", home],
            capture_output=True, text=True, timeout=SCAN_TIMEOUT_S)
        infected = [line.strip() for line in out.stdout.splitlines()
                    if line.strip()]
        _SCAN["result"] = {
            "status": "ok",
            "scanner": "clamscan",
            "scope": home,
            "threats_found": len(infected),
            "infected_files": infected[:20],
            "duration_s": round(time.monotonic() - started, 1),
        }
    except subprocess.TimeoutExpired:
        _SCAN["result"] = {
            "status": "unavailable", "scanner": "clamscan",
            "reason": f"scan timed out after {SCAN_TIMEOUT_S}s"}
    except OSError as e:
        _SCAN["result"] = {
            "status": "unavailable", "scanner": "clamscan",
            "reason": str(e)}


def sweep_malware_scan(processes_section):
    """Malware scan section of the boot report. Slow, so it is kicked
    off in a background thread and the boot report carries status
    "pending". The result arrives later as a follow-up report. If no
    scanner is installed, the section is unavailable and carries a
    process-anomaly note instead."""
    if shutil.which("clamscan") is None:
        note = "no scanner installed; rely on the processes section"
        if isinstance(processes_section, dict) \
                and processes_section.get("status") == "ok":
            note += (f" -- {processes_section.get('count')} processes "
                     f"running")
            top = processes_section.get("top_cpu") or []
            if top:
                note += f", top CPU: {top[0].get('name')}"
        return {"status": "unavailable", "scanner": "clamscan",
                "reason": "scanner_missing: clamscan is not installed",
                "process_anomaly_note": note}
    if not _SCAN["started"]:
        _SCAN["started"] = True
        thread = threading.Thread(target=_scan_worker, daemon=True)
        thread.start()
        _SCAN["thread"] = thread
    return {"status": "pending", "scanner": "clamscan",
            "scope": os.path.expanduser("~"),
            "note": "scan started in the background; result arrives as a "
                    "follow-up report (kind sweep-scan-result)"}


def sweep_kernel_log():
    """Kernel log errors (dmesg) -- ROOT ONLY. On the Deck this was
    blocked for the unprivileged user, which is the whole point of
    running as admin: without root, dmesg hides the kernel buffer.
    Unprivileged -> unavailable 'needs admin'. Admin but dmesg fails
    (e.g. a containerised VM) -> unavailable with the real failure,
    never faked data."""
    if not is_admin():
        return {"status": "unavailable", "reason": "needs admin",
                "needs_admin": True,
                "detail": "kernel log errors need admin (root): dmesg "
                          "is restricted for unprivileged users."}
    try:
        out = subprocess.run(["dmesg"], capture_output=True, text=True,
                             timeout=15)
    except (OSError, subprocess.SubprocessError) as e:
        return _unavailable(f"dmesg failed: {e}")
    lines = [ln for ln in (out.stdout or "").splitlines() if ln.strip()]
    if out.returncode != 0 and not lines:
        detail = (out.stderr or "").strip()[:200] or "dmesg returned no output"
        return _unavailable(f"dmesg failed: {detail}")
    errors = [ln for ln in lines
              if re.search(r"\b(error|fail(ed|ure)?|panic|oops|BUG)\b", ln,
                           re.IGNORECASE)]
    return {"status": "ok", "needs_admin": True, "source": "dmesg",
            "error_lines": len(errors), "total_lines": len(lines),
            "sample": errors[-10:]}


def sweep_smart_root():
    """SMART drive health as a root section -- needs admin because
    smartctl reads raw device data. Missing smartctl -> unavailable
    with the install hint; the agent NEVER installs it itself."""
    if not is_admin():
        return {"status": "unavailable", "reason": "needs admin",
                "needs_admin": True,
                "detail": "SMART drive health needs admin (root)."}
    if shutil.which("smartctl") is None:
        return {"status": "unavailable", "reason": "smartctl_missing",
                "needs_admin": True,
                "detail": "smartctl is not installed on this machine, so "
                          "drive health could not be read. Install with: "
                          "sudo pacman -S smartmontools -- this agent "
                          "never installs it itself."}
    s = smart_summary()
    if s.get("status") != "ok":
        return _unavailable(s.get("summary") or s.get("status") or "unknown")
    return {"status": "ok", "needs_admin": True,
            "summary": s.get("summary"), "disks": s.get("disks", [])}


def sweep_processes_all():
    """Full process list including other users' processes (ps aux)
    -- ROOT ONLY. The plain `processes` section stays as the
    owner-view list; this one adds the user column, so a runaway
    process owned by another user is visible too."""
    if not is_admin():
        return {"status": "unavailable", "reason": "needs admin",
                "needs_admin": True,
                "detail": "the full process list (other users' "
                          "processes) needs admin (root)."}
    procs = []
    out = _run(["ps", "aux"], timeout=15)
    for line in out.splitlines()[1:]:  # skip the header
        parts = line.split(None, 10)
        if len(parts) < 11:
            continue
        try:
            procs.append({"user": parts[0], "pid": int(parts[1]),
                          "cpu_pct": float(parts[2]),
                          "mem_pct": float(parts[3]),
                          "command": parts[10][:120]})
        except ValueError:
            continue
    if not procs:
        return _unavailable("ps aux returned no processes")
    top_cpu = sorted(procs, key=lambda p: p["cpu_pct"],
                     reverse=True)[:10]
    top_mem = sorted(procs, key=lambda p: p["mem_pct"],
                     reverse=True)[:10]
    users = sorted({p["user"] for p in procs})
    return {"status": "ok", "needs_admin": True, "count": len(procs),
            "users": users, "top_cpu": top_cpu, "top_memory": top_mem}


def run_blind_sweep():
    """Run the blind sweep: the doctor diagnoses on its own, first thing
    on connect, before any command is polled and before the user is
    asked anything. Every section is independent."""
    processes = sweep_processes()
    return {
        "sweep_version": SWEEP_VERSION,
        "smart": sweep_smart(),
        "disk_space": sweep_disk_space(),
        "startup_items": sweep_startup(),
        "processes": processes,
        "temps": sweep_temps(),
        "pending_updates": sweep_pending_updates(),
        "boot_time": sweep_boot_time(),
        "malware_scan": sweep_malware_scan(processes),
        "kernel_log": sweep_kernel_log(),
        "smart_root": sweep_smart_root(),
        "processes_all": sweep_processes_all(),
    }


def get_sweep():
    """The cached blind sweep -- run once on first connect, reused by
    every later report so the sweep never re-runs."""
    global _SWEEP_CACHE
    if _SWEEP_CACHE is None:
        _SWEEP_CACHE = run_blind_sweep()
    return _SWEEP_CACHE


def check_scan_followup():
    """If the background malware scan finished, post its follow-up
    report (kind "sweep-scan-result") and update the cached sweep so
    the one-shot follow-up shows the outcome. Delivers exactly once."""
    if not _SCAN["started"] or _SCAN["result"] is None:
        return
    result = _SCAN["result"]
    _SCAN["result"] = None  # deliver once
    if _SWEEP_CACHE is not None:
        _SWEEP_CACHE["malware_scan"] = result
    payload = {
        "agent": "kuro-doctor",
        "version": VERSION,
        "kind": "sweep-scan-result",
        "boot_id": BOOT_ID,
        "hostname": socket.gethostname(),
        "at": now_iso(),
        "sweep": {"malware_scan": result},
    }
    log(f"malware scan finished: status={result.get('status')} "
        f"threats={result.get('threats_found')}")
    delivered = relay_post("/doctor/report", payload)
    if delivered is None:
        log("scan follow-up report NOT delivered (relay unreachable)")
    else:
        log("scan follow-up report delivered")


# ---------------------------------------------------------------- basic commands

def disk_space():
    """Disk space for each mounted filesystem (df-style)."""
    mounts = []
    try:
        with open("/proc/mounts") as f:
            seen = set()
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    mount = parts[1]
                    if mount in seen or mount.startswith(("/proc", "/sys",
                                                          "/dev", "/run")):
                        continue
                    seen.add(mount)
                    try:
                        usage = shutil.disk_usage(mount)
                        mounts.append({
                            "mount": mount,
                            "total_gb": round(usage.total / 1e9, 2),
                            "used_gb": round(usage.used / 1e9, 2),
                            "free_gb": round(usage.free / 1e9, 2),
                        })
                    except OSError:
                        continue
    except OSError:
        pass
    if not mounts:  # fallback: just the root filesystem
        try:
            usage = shutil.disk_usage("/")
            mounts.append({"mount": "/", "total_gb": round(usage.total / 1e9, 2),
                           "used_gb": round(usage.used / 1e9, 2),
                           "free_gb": round(usage.free / 1e9, 2)})
        except OSError as e:
            return {"error": str(e)}
    return {"mounts": mounts}


def cmd_sysinfo(_args):
    uname = platform.uname()
    cpu_model = ""
    cpu_count = os.cpu_count() or 0
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    cpu_model = line.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    mem_total_mb = mem_free_mb = None
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    mem_total_mb = int(line.split()[1]) // 1024
                elif line.startswith("MemAvailable:"):
                    mem_free_mb = int(line.split()[1]) // 1024
    except (OSError, ValueError):
        pass
    return {
        "uname": {"system": uname.system, "node": uname.node,
                  "release": uname.release, "version": uname.version,
                  "machine": uname.machine},
        "cpu": {"model": cpu_model or "unknown", "count": cpu_count},
        "ram_mb": {"total": mem_total_mb, "available": mem_free_mb},
        "disks": list_disks(),
        "network": network_state(),
    }


def cmd_smart(_args):
    return smart_summary()


def cmd_df(_args):
    return disk_space()


def cmd_ls(args):
    path = args.get("path")
    if not path or not isinstance(path, str):
        return {"error": "bad_path", "detail": "ls needs a string 'path'"}
    if not os.path.isdir(path):
        return {"error": "bad_path", "detail": f"not a directory: {path}"}
    try:
        entries = []
        for name in sorted(os.listdir(path)):
            full = os.path.join(path, name)
            try:
                st = os.lstat(full)
                kind = ("dir" if statmod.S_ISDIR(st.st_mode)
                        else "link" if statmod.S_ISLNK(st.st_mode) else "file")
                entries.append({"name": name, "type": kind, "size": st.st_size})
            except OSError:
                entries.append({"name": name, "type": "unknown", "size": None})
        return {"path": path, "entries": entries}
    except OSError as e:
        return {"error": "bad_path", "detail": str(e)}


def cmd_cat(args):
    path = args.get("path")
    if not path or not isinstance(path, str):
        return {"error": "bad_path", "detail": "cat needs a string 'path'"}
    if not os.path.isfile(path):
        return {"error": "bad_path", "detail": f"no such file: {path}"}
    try:
        size = os.path.getsize(path)
    except OSError as e:
        return {"error": "bad_path", "detail": str(e)}
    if size > CAT_MAX_BYTES:
        return {"error": "file_too_large",
                "detail": f"{path} is {size} bytes, over the "
                          f"{CAT_MAX_BYTES}-byte limit"}
    try:
        with open(path, "rb") as f:
            data = f.read()
        return {"path": path, "size": size,
                "encoding": "base64",
                "content": base64.b64encode(data).decode("ascii")}
    except OSError as e:
        return {"error": "bad_path", "detail": str(e)}


def cmd_dmesg(args):
    lines = 100
    if isinstance(args.get("lines"), int):
        lines = max(1, min(args["lines"], 500))
    try:
        out = subprocess.run(["dmesg"], capture_output=True, text=True,
                             timeout=15)
        all_lines = out.stdout.splitlines()
        return {"lines": all_lines[-lines:], "total_lines": len(all_lines)}
    except OSError as e:
        return {"error": "dmesg_unavailable", "detail": str(e)}

# ---------------------------------------------------------------- exec blocklist
# Word-boundary matching for phrases and whole-token matching for
# bare command names -- never substring matching, so innocent words
# never false-positive (e.g. "shutdown" inside the hyphenated word
# "shutdown-the-server-notes" is not a shutdown command, and "format"
# inside "reformat-my-notes" is not a format command). Credential-
# dumping tool names are NOT listed here: that check lives in the
# relay only, by design -- this agent must never carry those names.
# Every rule below names a destructive action, not a tool for reading
# secrets. v1.3.6 (root) additions follow the same rule: they block
# by TARGET or ACTION -- shadow / sudoers paths, hash-dump phrasing,
# device writes, SSH private-key filenames, browser credential
# stores, chmod/chown on system paths -- so the blocklist holds AS
# ROOT, where a bypass would hurt most. Legitimate repair stays
# open: systemctl restarts, pacman installs, reading system logs
# (dmesg, journalctl), and smartctl reads are all allowed.

def _wb(pattern):
    """Wrap a pattern in word boundaries (case-insensitive at use)."""
    return re.compile(r"\b" + pattern + r"\b", re.IGNORECASE)


# --- v1.3.6 fix: NORMALISE-THEN-CHECK -------------------------------
# The old code pattern-matched the RAW command string, but
# run_exec_sync used to execute it with shell=True /bin/bash, and bash
# normalises quotes, $VAR, ${IFS}, ~user, //, /./, prefixes and
# wrappers BEFORE the command runs -- so the string the blocklist
# saw was not the command that ran. test_exec_blocked now
# normalises first (strip quotes/escapes, expand ~ and $VAR,
# collapse // and /./, strip sudo/pkexec/env prefixes and sh -c /
# bash -c wrappers recursively) and applies every rule to the
# normalised form AND to every unwrapped inner command. Since the
# durable argv-execution fix below, this checker is the SECOND
# layer: relay exec strings are parsed to argv and checked by the
# argv blocklist FIRST (no shell is ever involved), and this
# checker still runs on the raw command as defence in depth.
# Commands containing $(, backticks, ${IFS}/$IFS, $'...' or process
# substitution are refused outright: those are obfuscation
# primitives, not legitimate admin work. Two normalised tracks are
# checked: the splice track (an unknown $VAR expands to "" so
# splices such as /etc/sha${X}dow collapse back to /etc/shadow)
# and the var track (an unknown $VAR becomes the __VAR__ sentinel,
# and any destructive command whose target still holds __VAR__ is
# refused, because its real target cannot be proven safe). Known
# values resolve in both tracks: $HOME is the real home, and
# VAR=value assignments earlier in the same command (D=/dev/sda;
# dd ... of=$D) are substituted before checking.
#
# Scope change vs the old _rm_root_target (which protected exactly
# a root path, never anything underneath it): rm now protects any
# path under a system root (/etc /usr /var /bin /sbin /lib /lib64
# /boot /root /opt /srv) and any path under a user home -- except
# the .cache subtree and /tmp, which repair cache cleanup needs.
# chmod/chown are checked by _chmod_reason on the normalised form,
# so quoted targets (chmod 777 '/etc/hostname') are caught on
# their own, not by accident of a "passwd" token in the path.

_VAR_SENTINEL = "__VAR__"
_SYSTEM_ROOTS = ("/etc", "/usr", "/var", "/bin", "/sbin", "/lib",
                 "/lib64", "/boot", "/opt", "/srv")
_TEMP_DIRS = ("/tmp/", "/dev/shm/", "/var/tmp/")
_INTERPRETERS = {"sh", "bash", "dash", "zsh", "ksh", "python",
                 "python3", "perl", "ruby", "node"}
_SHELL_WORDS = {"sh", "bash", "dash", "zsh", "ksh"}
_PREFIX_WORDS = {"sudo", "pkexec", "doas", "env", "nice", "ionice",
                 "su", "runuser", "timeout", "setsid", "nohup",
                 "stdbuf", "command", "builtin"}
# Prefix flags that take a following value (sudo -u <user>, ...).
_VALUE_FLAGS = {"-u", "-g", "-U", "-C", "-D", "-R", "-T", "-t", "-p",
                "--user", "--group"}
_DESTRUCTIVE_WORDS = {"rm", "shred", "dd", "mkfs", "chmod", "chown",
                      "wipefs", "blkdiscard", "ddrescue", "sgdisk",
                      "parted", "shutdown", "reboot", "halt",
                      "poweroff"}


def _reject_obfuscation(command):
    """Reason when the raw command uses a shell obfuscation primitive
    that normalisation cannot make safe, else None."""
    if "$(" in command:
        return "blocked: command substitution $(...) is not allowed"
    if "`" in command:
        return "blocked: backtick command substitution is not allowed"
    if re.search(r"\$\{?IFS\}?", command):
        return "blocked: ${IFS}/$IFS word-splitting glue is not allowed"
    if "$'" in command:
        return "blocked: $'...' ANSI-C quoting is not allowed"
    if "<(" in command or ">(" in command:
        return "blocked: process substitution <(...) / >(...) is not allowed"
    return None


def _strip_quotes_escapes(text):
    """Drop single/double quotes and backslash escapes: d''d -> dd,
    /etc/sha'dow' -> /etc/shadow, of='/dev/sda' -> of=/dev/sda."""
    out = []
    i = 0
    while i < len(text):
        c = text[i]
        if c == "\\" and i + 1 < len(text):
            out.append(text[i + 1])
            i += 2
        elif c in ("'", '"'):
            i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


def _parse_assignments(text):
    """VAR=value pairs at a segment start (D=/dev/sda; dd ... of=$D),
    for substitution before checking."""
    assignments = {}
    for m in re.finditer(
            r"(?:^|[;|&]\s*)([A-Za-z_][A-Za-z0-9_]*)=([^\s;|&]+)", text):
        assignments[m.group(1)] = m.group(2)
    return assignments


def _expand_vars(text, assignments, splice):
    """Expand $HOME, ${VAR:-default} and $VAR/${VAR}. Known names
    come from `assignments` plus HOME. Unknown names become "" on
    the splice track and the __VAR__ sentinel on the var track."""
    home = os.path.expanduser("~")

    def _value(name, default):
        if name == "HOME":
            return home
        if name in assignments:
            return assignments[name]
        if default is not None:
            return default
        return "" if splice else _VAR_SENTINEL

    def _sub_braced(m):
        mm = re.match(r"([A-Za-z_][A-Za-z0-9_]*)(?::-?([^}]*))?$",
                      m.group(1))
        if not mm:
            return "" if splice else _VAR_SENTINEL
        return _value(mm.group(1), mm.group(2))

    text = re.sub(r"\$\{([^}]*)\}", _sub_braced, text)
    text = re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*)",
                  lambda m: _value(m.group(1), None), text)
    return text


def _expand_tilde(text):
    """~ -> the real home, ~user -> /home/user (~root -> /root)."""
    home = os.path.expanduser("~")

    def _sub(m):
        name = m.group(1) or ""
        if not name:
            return home
        if name == "root":
            return "/root"
        return "/home/" + name

    return re.sub(r"(?<![A-Za-z0-9_./~:-])~([A-Za-z_][A-Za-z0-9_.-]*)?",
                  _sub, text)


def _collapse_paths(text):
    """Collapse //, drop /./ and trailing /., resolve /seg/../
    inside absolute paths."""
    text = re.sub(r"/{2,}", "/", text)
    text = re.sub(r"/\./", "/", text)
    text = re.sub(r"/\.(?=[\s;|&]|$)", "", text)
    while True:
        new = re.sub(r"/[^/\s;|&]+/\.\.(?=/|$)", "", text)
        if new == text:
            return text
        text = new


def _normalise_command(command):
    """Return (splice_track, var_track): both quote-stripped, tilde-
    and variable-expanded, slash-collapsed forms of the command."""
    stripped = _strip_quotes_escapes(command)
    assignments = _parse_assignments(stripped)
    tracks = []
    for splice in (True, False):
        text = _expand_vars(stripped, assignments, splice)
        text = _expand_tilde(text)
        text = _collapse_paths(text)
        tracks.append(text)
    return tracks[0], tracks[1]


def _segments(text):
    """Split a normalised command on shell separators."""
    return [s for s in re.split(r"\s*(?:&&|\|\||[;|&\n])\s*", text)
            if s.strip()]


def _strip_prefix_tokens(tokens):
    """Drop leading elevation prefixes (sudo [-n/-u user], pkexec,
    env [VAR=...], nice, timeout <secs>, ...) from one segment's
    token list. Returns the remaining tokens."""
    i = 0
    while i < len(tokens):
        base = os.path.basename(tokens[i])
        if base not in _PREFIX_WORDS:
            break
        i += 1
        while i < len(tokens):
            tok = tokens[i]
            if re.match(r"[A-Za-z_][A-Za-z0-9_]*=", tok) \
                    and not tok.startswith("-"):
                i += 1
                continue
            if tok == "--":
                i += 1
                break
            if tok.startswith("-") and len(tok) > 1:
                i += 2 if tok in _VALUE_FLAGS else 1
                continue
            break
        if base == "timeout" and i < len(tokens) \
                and not tokens[i].startswith("-"):
            i += 1
    return tokens[i:]


def _unwrap_segment(segment):
    """Strip one wrapper layer from a single ;-segment. Returns the
    inner command, or None when there is no wrapper layer."""
    tokens = segment.split()
    if not tokens:
        return None
    # sh -c / bash -c / su [user] -c: the rest after -c is the payload.
    for j, tok in enumerate(tokens):
        if tok == "-c" and j >= 1 and os.path.basename(tokens[j - 1]) \
                in _SHELL_WORDS | {"su", "runuser"}:
            return " ".join(tokens[j + 1:]) or None
    for j, tok in enumerate(tokens):
        if tok == "-c" and j >= 2 \
                and os.path.basename(tokens[0]) in ("su", "runuser"):
            return " ".join(tokens[j + 1:]) or None
    # Elevation prefixes: sudo rm ... / env VAR=x rm ... / pkexec ...
    rest = _strip_prefix_tokens(tokens)
    if len(rest) < len(tokens) and rest:
        return " ".join(rest)
    # eval <inner>
    if os.path.basename(tokens[0]) == "eval":
        return " ".join(tokens[1:]) or None
    # xargs <cmd> [args...]: the subcommand runs with stdin data.
    if os.path.basename(tokens[0]) == "xargs":
        args = tokens[1:]
        k = 0
        while k < len(args):
            tok = args[k]
            if tok in ("-I", "-d", "-n", "-P", "--max-args",
                       "--max-procs"):
                k += 2
            elif tok.startswith("-") and len(tok) > 1:
                k += 1
            else:
                break
        return " ".join(args[k:]) or None
    return None


def _unwrap_commands(text):
    """Return [text] plus every inner command reached by stripping
    elevation prefixes and sh -c / bash -c / eval / xargs wrappers,
    recursively. Each returned command is checked with the full
    rule set."""
    found = [text]
    seen = {text}
    queue = [text]
    while queue:
        current = queue.pop(0)
        for segment in _segments(current):
            inner = _unwrap_segment(segment)
            if inner is not None and inner not in seen:
                seen.add(inner)
                found.append(inner)
                queue.append(inner)
    return found


def _is_system_path(path):
    return any(path == root or path.startswith(root + "/")
               for root in _SYSTEM_ROOTS)


def _is_cache_path(path):
    home = os.path.expanduser("~")
    if path == home + "/.cache" or path.startswith(home + "/.cache/"):
        return True
    if path == "/root/.cache" or path.startswith("/root/.cache/"):
        return True
    return re.match(r"^/home/[^/]+/\.cache(/|$)", path) is not None


def _is_temp_path(tok):
    return tok.startswith(_TEMP_DIRS) or tok in ("/tmp", "/dev/shm",
                                                 "/var/tmp")


def _is_protected_rm_target(tok):
    """True when `tok` is a path rm must not touch: /, a system root
    or anything under one, /root or anything under it, /home, a
    whole user home or anything under one -- except the .cache
    subtree (repair cache cleanup) and /tmp (scratch)."""
    if tok in ("/", "~"):
        return True
    if _VAR_SENTINEL in tok:
        return True
    home = os.path.expanduser("~")
    if tok == home or tok.startswith(home + "/"):
        return not _is_cache_path(tok)
    if tok == "/home" or tok.startswith("/home/"):
        return not _is_cache_path(tok)
    if tok == "/root" or tok.startswith("/root/"):
        return not _is_cache_path(tok)
    if _is_system_path(tok):
        return True
    return False


def _rm_reason(tokens, owner_go=None):
    """tokens[0] is rm (basename). Blocks recursive removal of a
    protected target, removal of a protected path even without -r,
    wildcards outside the safe areas (.cache, /tmp), and targets
    that still hold an unresolved variable. A v1.3.10 owner_go
    stamp (action "rm") naming a protected target exactly lifts
    the refusal for that target only."""
    recursive = False
    targets = []
    for tok in tokens[1:]:
        if tok == "--":
            continue
        if tok.startswith("-") and len(tok) > 1 and tok != "-":
            if "r" in tok[1:] or "R" in tok[1:] \
                    or tok == "--recursive":
                recursive = True
            continue
        targets.append(tok)
    if not targets:
        return ("refused: rm names no target -- say exactly which "
                "file or folder to remove (the owner's go must name "
                "that exact target)")
    if "--no-preserve-root" in tokens:
        return "blocked: rm --no-preserve-root"
    for tok in targets:
        if _VAR_SENTINEL in tok:
            return ("blocked: rm with an unresolved variable target")
        if "*" in tok or "?" in tok:
            prefix = re.split(r"[*?]", tok, 1)[0]
            if not prefix or _is_protected_rm_target(prefix.rstrip("/")):
                return "blocked: rm with a wildcard over a protected path"
            if recursive and not (_is_cache_path(prefix)
                                  or prefix.startswith("/tmp/")
                                  or prefix == "/tmp"):
                return "blocked: rm with a wildcard"
            continue
        if _is_protected_rm_target(tok):
            if _owner_go_covers(owner_go, "rm", tok):
                continue
            if recursive:
                return ("blocked: recursive removal aimed at a system "
                        "or home path")
            return "blocked: removal of a system or home path"
    return None


def _chmod_reason(tokens):
    """tokens[0] is chmod or chown (basename). Runs on the
    normalised form, so quoted targets are caught on their own.
    Blocks any target under a system root, or a whole home dir.
    A plain file inside a home (chmod 755 ~/script.sh) stays
    allowed, by design."""
    args = []
    mode_consumed = False
    for t in tokens[1:]:
        if t.startswith("-") and len(t) > 1 and t != "-":
            if t.startswith("--reference="):
                val = t.split("=", 1)[1]
                if _is_system_path(val) or _VAR_SENTINEL in val:
                    return "blocked: chmod/chown on a system path"
                mode_consumed = True
            elif t.startswith(("--mode=", "--owner=", "--group=")):
                mode_consumed = True
            continue
        args.append(t)
    home = os.path.expanduser("~")
    for tok in args:
        if _VAR_SENTINEL in tok:
            return "blocked: chmod/chown with an unresolved variable target"
    targets = args if mode_consumed else args[1:]
    for tok in targets:
        if _VAR_SENTINEL in tok:
            return "blocked: chmod/chown with an unresolved variable target"
        if _is_system_path(tok):
            return "blocked: chmod/chown on a system path"
        if tok in ("/", "/home", "/root", home):
            return "blocked: chmod/chown on a system or home path"
        if re.fullmatch(r"/home/[^/]+", tok):
            return "blocked: chmod/chown on a user home"
    return None


def _find_reason(tokens):
    """tokens[0] is find (basename). Blocks -delete and -exec( dir)
    rm (or another destructive word) rooted at a protected path, at
    '.' / with no path / with an unresolved variable path. The
    .cache subtree and /tmp stay open for cleanup."""
    args = tokens[1:]
    path = None
    for tok in args:
        if tok.startswith("-"):
            break
        path = tok
        break
    destructive = "-delete" in args
    for j, tok in enumerate(args):
        if tok in ("-exec", "-execdir", "-ok", "-okdir"):
            nxt = args[j + 1] if j + 1 < len(args) else ""
            if os.path.basename(nxt) in _DESTRUCTIVE_WORDS \
                    or os.path.basename(nxt) in _INTERPRETERS:
                destructive = True
    if not destructive:
        return None
    if path is None or path in (".", "..") \
            or _VAR_SENTINEL in (path or ""):
        return ("blocked: find -delete / -exec rm with no safe "
                "target path")
    if _is_cache_path(path) or path.startswith("/tmp/") or path == "/tmp":
        return None
    if _is_protected_rm_target(path):
        return ("blocked: find -delete / -exec rm under a system "
                "or home path")
    return None


def _xargs_reason(tokens):
    """tokens[0] is xargs. The subcommand runs with stdin data as
    its arguments, so a destructive subcommand is refused whatever
    the piped-in path is."""
    args = tokens[1:]
    k = 0
    while k < len(args):
        tok = args[k]
        if tok in ("-I", "-d", "-n", "-P", "--max-args", "--max-procs"):
            k += 2
        elif tok.startswith("-") and len(tok) > 1:
            k += 1
        else:
            break
    if k >= len(args):
        return None
    head = os.path.basename(args[k])
    if head in _DESTRUCTIVE_WORDS or head in _INTERPRETERS \
            or head == "tee":
        return "blocked: xargs running a destructive command"
    return None


def _dd_reason(tokens, owner_go=None):
    """tokens[0] is dd (basename). Blocks of= to a device, to an
    unresolved variable, or to a system / home path. A v1.3.10
    owner_go stamp lifts of= to a device / protected path when it
    names that exact target (action "wipe"), and of= to a trust
    file when it names that exact file (action "write")."""
    for j, tok in enumerate(tokens):
        val = None
        if tok.startswith("of="):
            val = tok[3:]
        elif tok == "of" and j + 2 < len(tokens) \
                and tokens[j + 1] == "=":
            val = tokens[j + 2]
        if val is None:
            continue
        if val.startswith("/dev/") or _VAR_SENTINEL in val:
            if val.startswith("/dev/") \
                    and _owner_go_covers(owner_go, "wipe", val):
                continue
            return "blocked: writing raw data to a device"
        if _is_trust_write_dest(val):
            if _owner_go_covers(owner_go, "write", val):
                continue
            return _trust_dest_reason(val)
        if _is_system_path(val) or _is_protected_rm_target(val):
            if _owner_go_covers(owner_go, "wipe", val):
                continue
            return "blocked: dd writing to a system or home path"
    return None


def _copy_dest_reason(tokens, owner_go=None):
    """tokens[0] is cp / mv / ln / install / tee (basename).
    Destination is the last non-flag token. Blocks writing over a
    system path, writing a script file into a temp dir, and a
    destination that still holds an unresolved variable. A v1.3.10
    owner_go stamp (action "write") naming the destination exactly
    lifts the trust-file refusal for that destination only."""
    dest = None
    for tok in tokens[1:]:
        if tok.startswith("-") and len(tok) > 1:
            continue
        dest = tok
    if dest is None:
        return None
    if _VAR_SENTINEL in dest:
        return "blocked: copy/move to an unresolved variable target"
    if dest.endswith(".sh") and _is_temp_path(dest):
        return "blocked: writing a script file into a temp dir"
    if _is_trust_write_dest(dest):
        if _owner_go_covers(owner_go, "write", dest):
            return None
        return _trust_dest_reason(dest)
    if _is_system_path(dest):
        return "blocked: writing over a system path"
    return None


def _segment_reason(tokens, owner_go=None):
    """Apply the per-segment rules to one ;-segment's tokens
    (elevation prefixes already stripped)."""
    tokens = _strip_prefix_tokens(tokens)
    if not tokens:
        return None
    head = os.path.basename(tokens[0])
    # v1.3.10: categorical refusals -- no stamp ever lifts these.
    reason = _categorical_reason_tokens(tokens)
    if reason is not None:
        return reason
    # v1.3.10: a bare wipe verb with no exact target is refused
    # asking for it (never guessed, never run blind).
    if head in ("wipe", "format", "erase", "clean") \
            and not any(tok.startswith("/") for tok in tokens):
        return ("refused: %s names no exact target -- say exactly "
                "which drive, partition or folder to %s (the "
                "owner's go must name that exact target)" % (head, head))
    if head in ("format", "diskpart"):
        targets = [tok for tok in tokens[1:] if tok.startswith("/")]
        if not targets:
            return ("refused: %s names no exact target -- say "
                    "exactly which drive, partition or folder to "
                    "%s (the owner's go must name that exact "
                    "target)" % (head, head))
        for target in targets:
            if _owner_go_covers(owner_go, "wipe", target):
                return None
        return ("blocked: %s is a wipe -- refused without the "
                "owner's go naming the exact drive, partition or "
                "folder" % head)
    if head == "cipher":
        wvals = []
        bare_w = False
        for tok in tokens[1:]:
            low = tok.lower()
            if low == "/w":
                bare_w = True
            elif low.startswith("/w:") or low.startswith("/w="):
                wvals.append(tok[3:])
        if bare_w and not wvals:
            return ("refused: cipher /w names no exact target -- "
                    "say exactly which drive, partition or folder "
                    "to wipe (the owner's go must name that exact "
                    "target)")
        if wvals:
            for target in wvals:
                if _owner_go_covers(owner_go, "wipe", target):
                    return None
            return ("blocked: cipher /w is a wipe -- refused "
                    "without the owner's go naming the exact "
                    "drive, partition or folder")
        return None
    if head == "rm":
        return _rm_reason(tokens, owner_go)
    if head in ("chmod", "chown"):
        return _chmod_reason(tokens)
    if head == "find":
        return _find_reason(tokens)
    if head == "xargs":
        return _xargs_reason(tokens)
    if head == "dd":
        return _dd_reason(tokens, owner_go)
    if head in ("cp", "mv", "ln", "install", "tee", "rsync"):
        return _copy_dest_reason(tokens, owner_go)
    if head == "crontab":
        return _crontab_reason(tokens, owner_go)
    if head == "systemctl":
        return _argv_systemctl_reason(tokens, owner_go)
    if head in _INTERPRETERS or head in ("source", "."):
        for tok in tokens[1:]:
            if _is_temp_path(tok):
                return ("blocked: running a script from a "
                        "world-writable temp dir")
        return None
    if _is_temp_path(tokens[0]):
        return ("blocked: executing a file from a world-writable "
                "temp dir")
    return None


def _check_normalised(text, owner_go=None):
    """Apply every rule to one normalised command string. Returns a
    reason or None. owner_go is the v1.3.10 stamp (None = no stamp):
    it lifts only its own action+target in the rm / trust-write /
    wipe branches below, never the categorical rules."""
    for segment in _segments(text):
        tokens = segment.split()
        if not tokens:
            continue
        reason = _segment_reason(tokens, owner_go)
        if reason is not None:
            return reason
    # v1.3.10: whether the stamp's target is actually in this text.
    wipe_covered = ((owner_go or {}).get("action") == "wipe"
                    and _stamp_target_in_text(owner_go, text))
    # Staged-payload writes / pipes, on the whole command.
    if re.search(r">>?\s*(?:/tmp/|/dev/shm/|/var/tmp/)[^\s;|&]*\.sh\b",
                 text):
        return ("blocked: writing a script file into a world-writable "
                "temp dir")
    if re.search(r"\b(curl|wget)\b[^|;&\n]*\|\s*(sudo\s+|pkexec\s+|"
                 r"env\s+)?(sh|bash|dash|zsh)\b", text):
        return "blocked: piping a download into a shell"
    if re.search(r"\|\s*(sudo\s+|pkexec\s+|env\s+)?(sh|bash|dash|zsh)\b",
                 text):
        return "blocked: piping into a shell"
    if re.search(r"\b(curl|wget)\b[^|;&\n]*(-o|--output)[\s=]+"
                 r"(?:/tmp/|/dev/shm/|/var/tmp/)[^\s;|&]*\.sh\b", text):
        return "blocked: downloading a script into a temp dir"
    token_reason = _token_block_reason(
        text, skip=("mkfs", "blkdiscard") if wipe_covered else ())
    if token_reason is not None:
        return token_reason
    # v1.3.10: the profile-folder deletion rule fires only when a
    # segment's head IS a delete verb (rm / del / delete / erase).
    # A --delete-data FLAG (flatpak uninstall) is not a delete verb,
    # and the app id's "_desktop" suffix is not a folder -- the old
    # form refused `flatpak uninstall --delete-data` outright.
    # An rm stamp naming an exact target in this text lifts it.
    rm_covered = ((owner_go or {}).get("action") == "rm"
                  and _stamp_target_in_text(owner_go, text))
    if not rm_covered:
        lowered = text.lower()
        home = os.path.expanduser("~").lower()
        for segment in _segments(text):
            seg_tokens = _strip_prefix_tokens(segment.split())
            if not seg_tokens:
                continue
            if os.path.basename(seg_tokens[0]) not in (
                    "rm", "del", "delete", "erase"):
                continue
            for folder in ("documents", "pictures", "desktop"):
                if folder in lowered \
                        or os.path.join(home, folder) in lowered:
                    return ("blocked: deletion under user-profile "
                            f"{folder.capitalize()} -- owner_override "
                            "only allows .desktop shortcut deletes "
                            "under ~/Desktop")
    for idx, (pattern, reason) in enumerate(EXEC_BLOCK_RULES):
        if wipe_covered and idx in _WIPE_EXEC_RULE_INDEXES:
            continue
        if pattern.search(text):
            return reason
    return None



EXEC_BLOCK_RULES = [
    (re.compile(r"--no-preserve-root", re.IGNORECASE),
     "blocked: rm --no-preserve-root"),
    (re.compile(r"\bdd\s+[^|;&\n]*of\s*=\s*/dev/", re.IGNORECASE),
     "blocked: writing raw data to a device"),
    (re.compile(r"\bdd\s+[^|;&\n]*if\s*=\s*/dev/(zero|random|urandom)\s+[^|;&\n]*of\s*=\s*/dev/",
                re.IGNORECASE),
     "blocked: writing raw data to a device"),
    (_wb(r"ddrescue|shred\s+[^|;&\n]*/dev/"), "blocked: destructive disk write"),
    (_wb(r"wipefs|sgdisk\s+[^|;&\n]*--zap-all|parted\s+[^|;&\n]*mklabel"),
     "blocked: partition-table destruction"),
    (re.compile(r"lock[\s\-]?screen[^|;&\n]*bypass|bypass[^|;&\n]*lock[\s\-]?screen",
                re.IGNORECASE),
     "blocked: lock-screen bypass"),
    (re.compile(r"flash[^|;&\n]*firmware|firmware[^|;&\n]*flash|bios[^|;&\n]*flash|uefi[^|;&\n]*flash",
                re.IGNORECASE),
     "blocked: flashing / firmware tool"),
    (_wb(r"steamos-readonly\s+disable"), "blocked: disabling the read-only root filesystem"),
    # --- v1.3.6 root additions: block by target / action ---
    (re.compile(r"/etc/(g?shadow)\b", re.IGNORECASE),
     "blocked: reading a credential file (/etc/shadow, /etc/gshadow)"),
    (re.compile(r"/etc/sudoers(\.d)?\b", re.IGNORECASE),
     "blocked: editing the sudoers file"),
    (re.compile(r"\bgetent\s+shadow\b", re.IGNORECASE),
     "blocked: dumping password hashes (getent shadow)"),
    (re.compile(r"\b(dump|extract|steal|leak)[^|;&\n]*\b(hash|password)s?\b"
                r"|\b(hash|password)s?\b[^|;&\n]*\b(dump|extract)\b",
                re.IGNORECASE),
     "blocked: dumping password hashes"),
    # chmod/chown are NOT in this table: the old regex required an
    # unquoted \s/ and missed quoted targets, so they are checked
    # by _chmod_reason on the normalised form instead (see above).
    (re.compile(r"\b(shred|blkdiscard|wipefs)\b[^|;&\n]*/dev/",
                re.IGNORECASE),
     "blocked: destructive disk write to a device"),
    (re.compile(r"\bid_(rsa|dsa|ecdsa|ed25519)(?!\.pub)\b"),
     "blocked: reading an SSH private key"),
    (re.compile(r"(Login Data|key4\.db|logins\.json|cookies\.sqlite|cert9\.db)",
                re.IGNORECASE),
     "blocked: reading a browser credential store"),
]


# v1.3.10: indexes into EXEC_BLOCK_RULES whose rules are WIPE-class
# (a wipe authorised by a matching owner_go stamp lifts exactly
# these, and nothing else): 1-2 dd to a device, 3 ddrescue / shred
# to a device, 4 wipefs / sgdisk --zap-all / parted mklabel, 12
# shred / blkdiscard / wipefs to a device. The test asserts the
# list length and these reasons, so a reorder breaks loudly.
_WIPE_EXEC_RULE_INDEXES = frozenset({1, 2, 3, 4, 12})


# Whole-token command words: matched against shell tokens (letters,
# digits, _ . - + kept together), so a hyphenated innocent word such
# as "shutdown-the-server-notes" never false-positives -- the token
# is one word, not the bare command name. "mkfs.ext4" still matches
# via the part before the first dot.
_TOKEN_BLOCK_WORDS = {
    "shutdown": "blocked: shutdown / reboot / poweroff",
    "reboot": "blocked: shutdown / reboot / poweroff",
    "halt": "blocked: shutdown / reboot / poweroff",
    "poweroff": "blocked: shutdown / reboot / poweroff",
    "passwd": "blocked: password change (passwd)",
    "useradd": "blocked: account change (useradd / userdel / usermod)",
    "userdel": "blocked: account change (useradd / userdel / usermod)",
    "usermod": "blocked: account change (useradd / userdel / usermod)",
    "chpasswd": "blocked: password change (chpasswd)",
    "mkfs": "blocked: filesystem creation (mkfs)",
    "flashrom": "blocked: flashing / firmware tool",
    "blkdiscard": "blocked: destructive disk write",
    "visudo": "blocked: editing the sudoers file",
}


def _token_block_reason(command, skip=()):
    """Return the reason when a whole shell token is a blocked command
    word, else None. `skip` names words a matching owner_go wipe
    stamp has already authorised (mkfs / blkdiscard only -- the
    power / account words are never skipped)."""
    for token in re.findall(r"[A-Za-z0-9_.\-+]+", command.lower()):
        base = token.split(".")[0]
        if base in _TOKEN_BLOCK_WORDS and base not in skip:
            return _TOKEN_BLOCK_WORDS[base]
        if token in _TOKEN_BLOCK_WORDS and token not in skip:
            return _TOKEN_BLOCK_WORDS[token]
    return None


# --- v1.3.10: CATEGORICAL REFUSALS (never lifted by owner_go) ----
# Tools and actions no stamp ever authorises, in either layer:
# credential dumping, lock-screen / password bypass, `net user`
# password changes, bcdedit. (Shutdown / reboot, flashing tools,
# elevation, shells / interpreters and env / su are refused by the
# never-command / token rules, which likewise never consult a
# stamp. format / diskpart / cipher /w are NOT here -- they are
# wipe-class and a matching wipe stamp authorises them.)
_CATEGORICAL_TOOL_SUBSTRINGS = (
    "mimikatz", "sekurlsa", "lsass", "ntdsutil", "ntds.dit",
    "bcdedit",
)


def _categorical_reason_tokens(tokens):
    """Reason when argv / segment tokens name a categorically
    refused tool or action, else None. Checked on tokens (not
    substrings of a sentence), so a hyphenated innocent word
    never false-positives -- but a token that IS one of these
    tools, or CONTAINS one (invoke-mimikatz, lsass.exe), always
    does. An owner_go stamp NEVER lifts this."""
    lowered = [t.lower() for t in tokens]
    for tok in lowered:
        for bad in _CATEGORICAL_TOOL_SUBSTRINGS:
            if bad in tok:
                return ("blocked: %s is never run -- credential "
                        "dumping / system tools are refused even "
                        "with the owner's go" % bad)
    for j, tok in enumerate(lowered):
        if tok == "net" and j + 1 < len(lowered) \
                and lowered[j + 1] == "user":
            if len(lowered[j + 2:]) >= 2:
                return ("blocked: net user password change is never "
                        "run via exec")
    joined = " ".join(lowered)
    if "bypass" in joined and ("lock" in joined
                               or "password" in joined
                               or "passwd" in joined):
        return "blocked: lock-screen / password bypass"
    return None


def _is_desktop_shortcut_delete(command, owner_override):
    """Owner-override path (same narrow rule as the Windows agent):
    ONLY shortcut-file deletes under ~/Desktop -- on Linux that means
    .desktop shortcut files. The override lifts the Desktop refusal
    ONLY for .desktop files under ~/Desktop: no -Recurse, no wildcards,
    no Documents / Pictures / Downloads. Returns the matched .desktop
    path, or None when this is not a qualifying delete."""
    if not owner_override:
        return None
    home = os.path.expanduser("~")
    desktop = os.path.join(home, "Desktop")
    # rm [flags] <path> -- flags must be plain, no -r/-R, no * or ?.
    m = re.match(r"^\s*rm\s+(-[a-zA-Z]*\s+)?(\S+)\s*$", command)
    if not m:
        return None
    flags = (m.group(1) or "").strip()
    if "r" in flags or "R" in flags:
        return None
    target = m.group(2)
    if "*" in target or "?" in target:
        return None
    if not target.endswith(".desktop"):
        return None
    abs_target = os.path.abspath(os.path.expanduser(target))
    if os.path.dirname(abs_target) != desktop:
        return None
    return abs_target


def test_exec_blocked(command, owner_override=False, owner_go=None):
    """Return None when the command may run, else a short reason string.

    Checks, in order: (1) the owner-override shortcut-delete path --
    a qualifying .desktop delete under ~/Desktop is allowed even
    though it names the Desktop; (2) outright refusal of shell
    obfuscation primitives ($(...), backticks, ${IFS}/$IFS, $'...',
    process substitution); (3) the full rule set applied to BOTH
    normalised tracks (splice track and var track) and to every
    unwrapped inner command (sudo/pkexec/env prefixes, sh -c /
    bash -c wrappers, eval, xargs subcommands); (4) the user-profile
    Documents / Pictures / Desktop deletion rule. The .cache subtree
    and /tmp stay open for repair cleanup; everything under a system
    root or a user home (other than .cache) is a protected rm target.
    owner_go (v1.3.10) lifts only its own action+target when the
    stamp's target matches the command's actual target exactly;
    the categorical refusals ignore it.
    """
    if not isinstance(command, str) or not command.strip():
        return "blocked: empty command"
    if _is_desktop_shortcut_delete(command, owner_override) is not None:
        return None
    reason = _reject_obfuscation(command)
    if reason is not None:
        return reason
    splice, var_track = _normalise_command(command)
    for text in (splice, var_track):
        for candidate in _unwrap_commands(text):
            reason = _check_normalised(candidate, owner_go)
            if reason is not None:
                return reason
    return None


# --- DURABLE FIX: ARGV EXECUTION (no shell) ------------------------
# Two independent verifications proved string blocklists over
# shell=True cannot be made sound (round 1: 53 destructive
# bypasses; round 2: 27 new holes in 9 fresh classes -- tar
# --checkpoint-action, wrapper binaries, `exec` prefix,
# flags-before--c, spaced flag values, unruled shell redirection,
# cp/tee/install to /dev/*, unchecked mv/rsync sources, find
# -exec exfiltration). There is no third round of string rules.
# Relay exec strings are now parsed to an argv list and executed
# with subprocess shell=False. No shell ever interprets a relay
# command, so shell syntax cannot smuggle a second command in:
#   * shlex.split turns the string into tokens (quotes are real
#     quoting, not string surgery -- d''d is dd, /etc/sha'dow'
#     is /etc/shadow, and both are seen as such);
#   * ~ / ~user expands via os.path.expanduser; $HOME (and only
#     $HOME) expands -- any other $VAR is refused, not expanded;
#   * globs (* / ?) expand via the glob module BEFORE checking,
#     and a glob with no match is refused (an unexpanded * is
#     never passed through);
#   * any token still carrying a shell metacharacter (| > < ; &
#     backtick, $( ) is REFUSED with a pointer to exec_pipeline
#     for pipes -- never silently mangled;
#   * the argv blocklist below checks argv[0] by basename plus
#     every argument, with paths resolved (normpath + realpath
#     through the nearest existing ancestor, so /tmp/../etc and
#     /tmp/link -> /etc are seen as /etc);
#   * the old normalise-then-check string checker
#     (test_exec_blocked) still runs on the raw command as a
#     SECOND layer, defence in depth.
# Refusal wording: "refused: ..." means the command used shell
# syntax the argv path does not execute (pipes, redirection,
# substitution, other variables, unexpanded globs); "blocked: ..."
# means an argv-blocklist rule (or the string checker) fired.
# Both mean the command did NOT run.
# What this deliberately closes that the string checker could
# not: staged payloads (echo ... > file; sh file -- no shell, no
# ;, no >), in-language payloads (python3 -c / perl -e / ruby -e
# are refused outright as argv[0]), wrappers of every spelling
# (no prefix parsing to defeat -- argv[0] IS the command), and
# redirection / device writes (there is no redirection at all).
# What stays open by design: rm -rf under ~/.cache and /tmp,
# find for listing, systemctl/pacman/dmesg/journalctl/smartctl
# reads, chmod of a plain file inside a home, the owner-override
# .desktop delete under ~/Desktop only.
# TRUST-FILE FIX (round 3, 2026-11-22): writes to trust files
# inside a home are now refused as destinations -- anything under
# ~/.ssh except id_*.pub, shell startup files, autostart .desktop
# files, user systemd units (see _is_trust_write_dest); `crontab`
# runs only as bare `-l`; `systemctl --user` runs only read-only
# queries. Reads of .pub keys / known_hosts stay allowed.
# Residuals NOT closed by this fix (stated plainly): a symlink
# planted in advance inside an allowed area could redirect a
# write that lexically targets /tmp (only the nearest existing
# ancestor is realpath-resolved, and a race between check and
# run remains -- as root, a pre-planted symlink is a local
# compromise already, not a relay-command bypass); cp -r / tar
# of a whole directory can copy files the argv list does not
# name one by one (named credential files are refused; the
# /etc/ssh and ~/.ssh directories are refused as copy sources,
# but a directory copy of any other tree is a read, not a
# write, and is allowed).

_SHELL_WORDS_ARGV = _SHELL_WORDS | {"fish"}
_ARGV_NEVER_COMMANDS = {
    # Shells and inline-code interpreters: a relay exec never runs
    # a shell or an interpreter. A benign inner command goes as a
    # plain exec (or an exec_pipeline stage) instead.
    "sh", "bash", "dash", "zsh", "ksh", "fish",
    "python", "python3", "perl", "ruby", "node", "php", "lua",
    "tclsh",
    # Elevation: the launcher handles it; exec never needs it, and
    # it must never hang the agent on a password prompt.
    "sudo", "pkexec", "su", "runuser", "doas",
    # Wrappers that hide the real command behind a prefix.
    "systemd-run", "chroot", "nsenter", "unshare", "busybox",
    "timeout", "nice", "ionice", "stdbuf", "setsid", "env", "exec",
    "command", "builtin", "eval", "nohup", "xargs", "at", "batch",
    # Power / accounts / firmware / partition / network control.
    "shutdown", "reboot", "halt", "poweroff", "passwd", "chpasswd",
    "useradd", "userdel", "usermod", "visudo", "steamos-readonly",
    "sgdisk", "parted", "fdisk", "sfdisk", "cfdisk", "cryptsetup",
    "losetup", "mkswap", "swapon", "swapoff", "flashrom",
    "modprobe", "insmod", "rmmod", "mount", "umount",
    "iptables", "nft", "nmcli", "ifconfig", "iw", "ethtool",
    # Remote execution / exfiltration channels.
    "ssh", "scp", "sftp", "nc", "ncat", "socat",
}
# Tools that write files: a device path in any of their arguments
# is refused (a read tool such as smartctl may still name a device).
_ARGV_WRITE_TOOLS = {"dd", "cp", "mv", "ln", "install", "tee",
                     "shred", "wipefs", "blkdiscard", "rsync", "tar"}
# Basenames that name a credential wherever they appear as a path.
_CREDENTIAL_BASENAMES = {
    "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519",
    "Login Data", "key4.db", "logins.json", "cookies.sqlite",
    "cert9.db", "shadow", "gshadow", "passwd", "sudoers",
}
_DEVICE_PREFIXES = ("sd", "nvme", "mmcblk", "vd", "hd", "xvd")
MAX_PIPELINE_STAGES = 4


def _is_device_path(path):
    """True for a raw disk device (/dev/sd*, /dev/nvme*, /dev/mmcblk*,
    /dev/vd*, /dev/hd*, /dev/xvd*) -- whole disks and partitions."""
    if not path.startswith("/dev/"):
        return False
    return path[5:].startswith(_DEVICE_PREFIXES)


def _resolve_path(path):
    """Resolve a path for checking: absolute, dot-collapsed, and
    symlinks resolved through the nearest existing ancestor (so
    /tmp/../etc is /etc and /tmp/link -> /etc is /etc)."""
    p = os.path.normpath(os.path.abspath(os.path.expanduser(path)))
    if os.path.lexists(p):
        return os.path.realpath(p)
    parts = []
    cur = p
    while cur and not os.path.lexists(cur):
        parts.append(os.path.basename(cur))
        cur = os.path.dirname(cur)
    base = os.path.realpath(cur) if cur else "/"
    for part in reversed(parts):
        base = os.path.join(base, part)
    return os.path.normpath(base)


def _is_home_path(path):
    """True for any path under a user home or /root (resolved)."""
    p = _resolve_path(path)
    home = os.path.expanduser("~")
    return (p == home or p.startswith(home + "/")
            or p == "/home" or p.startswith("/home/")
            or p == "/root" or p.startswith("/root/"))


def _is_ssh_dir(path):
    """True for /etc/ssh or any ~/.ssh directory (resolved) -- a
    credential store, never a copy source."""
    p = _resolve_path(path)
    if p == "/etc/ssh" or p.startswith("/etc/ssh/"):
        return True
    home = os.path.expanduser("~")
    if p == home + "/.ssh" or p.startswith(home + "/.ssh/"):
        return True
    return re.match(r"^/home/[^/]+/\.ssh(/|$)", p) is not None


# --- TRUST-FILE FIX (round-3 FAIL, 2026-11-22) --------------------
# Round 3 proved the argv blocklist protected the private key
# itself (id_ed25519 as a destination is BLOCKED) but not the
# trust files sitting next to it in the same directory: cp / tee /
# install / mv / rsync could overwrite ~/.ssh/authorized_keys,
# ~/.ssh/config, ~/.bashrc, ~/.config/autostart/*.desktop,
# ~/.config/systemd/user/*.service, and `crontab <file>` installed
# a user crontab -- persistent SSH access / code execution at next
# login as the agent's user. The predicate below is the fix: it is
# consulted ONLY for write destinations (never for reads -- cat of
# a .pub key or known_hosts stays allowed), in _argv_block_reason
# (so plain exec AND exec_pipeline stages are covered -- the
# pipeline validator calls the same function) and, as a second
# layer, in the string checker.
_TRUST_STARTUP_BASENAMES = {
    ".bashrc", ".bash_profile", ".bash_login", ".profile",
    ".zshrc", ".zprofile", ".zlogin", ".zshenv",
}


def _is_trust_write_dest(path):
    """True when `path` (resolved through _resolve_path, so a
    symlink to a trust file is caught) is a trust file a relay
    exec must never OVERWRITE: anything at/under any ~/.ssh
    EXCEPT an id_*.pub public key (known_hosts is NOT benign --
    it is a trust file); a shell startup file in any home
    (/home/*, /root, ~); anything at/under
    ~/.config/autostart or ~/.config/systemd/user. The .ssh
    directory itself counts (cp file ~/.ssh/ writes INTO it)."""
    p = _resolve_path(path)
    base = os.path.basename(p)
    home = os.path.expanduser("~")

    def _under(sub):
        if re.match(r"^(?:/root|/home/[^/]+)/" + re.escape(sub)
                    + r"(/|$)", p):
            return True
        return p == home + "/" + sub \
            or p.startswith(home + "/" + sub + "/")

    if _under(".ssh"):
        return not (base.startswith("id_") and base.endswith(".pub"))
    if base in _TRUST_STARTUP_BASENAMES and _is_home_path(p):
        return True
    if _under(".config/autostart") or _under(".config/systemd/user"):
        return True
    return False


def _trust_dest_reason(dest):
    """Reason for refusing a write whose destination is a trust file."""
    return ("blocked: writing over a trust file (%s) -- SSH trust "
            "files, shell startup files, autostart entries and user "
            "systemd units are never written via exec" % dest)


def _crontab_reason(argv, owner_go=None):
    """argv[0] is crontab. Only the read-only list form runs via
    exec (`crontab -l`, already used by the startup-items sweep);
    a file argument, `-` (stdin), `-r` and `-e` all install,
    replace or delete the user's crontab and are refused -- unless
    v1.3.10's owner_go stamp names that exact crontab file
    (action "crontab"), which authorises installing it."""
    if list(argv[1:]) == ["-l"]:
        return None
    positionals = [a for a in argv[1:] if not a.startswith("-")]
    if len(positionals) == 1 \
            and _owner_go_covers(owner_go, "crontab", positionals[0]):
        return None
    return ("blocked: crontab installs, replaces or deletes a user "
            "crontab; only 'crontab -l' (list) is allowed via exec "
            "-- or the owner's go naming that exact crontab file")


def _names_credential(element):
    """True when a path-like argv element names a credential file:
    /etc/shadow or /etc/gshadow, an SSH private key (never its .pub),
    or a browser credential store. Bare words (package names such as
    `passwd` for pacman) are not paths and are not checked."""
    if "/" not in element and not element.startswith(("~", ".")):
        return False
    base = os.path.basename(element.rstrip("/"))
    if base in _CREDENTIAL_BASENAMES:
        return True
    if _resolve_path(element) in ("/etc/shadow", "/etc/gshadow"):
        return True
    return False


def _split_flags(args, value_flags):
    """Split argv[1:] into (positionals, [(flag, value), ...]).
    Flags in value_flags consume the next token (or an attached
    value: -tDIR / --flag=value). Every other -flag is skipped.
    '--' ends flag parsing; everything after it is positional."""
    positionals = []
    values = []
    i = 0
    while i < len(args):
        tok = args[i]
        if tok == "--":
            positionals.extend(args[i + 1:])
            break
        if tok.startswith("--"):
            if "=" in tok:
                name, val = tok.split("=", 1)
                if name in value_flags:
                    values.append((name, val))
                i += 1
                continue
            if tok in value_flags and i + 1 < len(args):
                values.append((tok, args[i + 1]))
                i += 2
                continue
            i += 1
            continue
        if tok.startswith("-") and len(tok) > 1 and tok != "-":
            attached = None
            for flag in value_flags:
                if len(flag) == 2 and tok.startswith(flag) \
                        and len(tok) > 2:
                    attached = flag
                    break
            if attached is not None:
                values.append((attached, tok[2:]))
                i += 1
                continue
            if tok in value_flags and i + 1 < len(args):
                values.append((tok, args[i + 1]))
                i += 2
                continue
            i += 1
            continue
        positionals.append(tok)
        i += 1
    return positionals, values


def _expand_exec_tokens(tokens, refuse_meta=True):
    """Expand one shlex-split token list into a final argv list:
    ~ / ~user, $HOME only, globs. Returns (argv, reason); reason is
    not None when the tokens cannot be expanded safely. With
    refuse_meta (the exec-string path), a token still carrying a
    shell metacharacter after expansion is refused; pipeline
    stages pass refuse_meta=False, because their elements are
    already argv -- a '|' inside a grep pattern there is data,
    not syntax, and no shell exists to interpret it."""
    home = os.path.expanduser("~")
    out = []
    for tok in tokens:
        expanded = os.path.expanduser(tok)
        if expanded.startswith("~"):
            return None, ("refused: unresolvable '~' in %r (no such "
                          "user); use the full /home/<user> path" % tok)
        rebuilt = []
        i = 0
        while i < len(expanded):
            ch = expanded[i]
            if ch == "$":
                m = re.match(r"\$(?:HOME|\{HOME\})", expanded[i:])
                if m:
                    rebuilt.append(home)
                    i += len(m.group(0))
                    continue
                if i + 1 < len(expanded) and (
                        expanded[i + 1].isalpha()
                        or expanded[i + 1] in "{_"):
                    return None, ("refused: only $HOME is expanded; "
                                  "%r names another variable -- send "
                                  "the literal value instead" % expanded)
                rebuilt.append(ch)
                i += 1
                continue
            rebuilt.append(ch)
            i += 1
        expanded = "".join(rebuilt)
        if "*" in expanded or "?" in expanded:
            matches = sorted(glob.glob(expanded))
            if not matches:
                return None, ("refused: %r is a glob with no match "
                              "(an unexpanded * / ? is never passed "
                              "through); list the directory first"
                              % expanded)
            out.extend(matches)
            continue
        out.append(expanded)
    if not refuse_meta:
        return out, None
    for tok in out:
        if any(c in tok for c in "|><;&`") or "$(" in tok:
            return None, ("refused: shell syntax in %r after expansion; "
                          "use exec_pipeline for pipes, or send each "
                          "command separately as exec" % tok)
    return out, None


# --- v1.3.10: OWNER_GO STAMP --------------------------------------
# The owner's word is the authorisation (2026-11-22): when the owner
# gives an explicit go naming the exact action and target, that IS
# the authorisation -- the agent must not second-guess it. Commands
# arriving from the relay may carry an optional `owner_go` object:
#   {"action": "<verb>", "target": "<exact target string>"}
# Muse stamps it only when the owner gave that explicit go in chat.
# The stamp is consulted ONLY in the branches below, and ONLY when
# its target matches the command's actual target EXACTLY (string
# equality after _resolve_path, the same normalisation the
# blocklist uses) -- never inferred, never a different target.
#   "rm"        -- rm of a protected path (the exact path removed)
#   "write"     -- a write whose destination is a trust file
#   "wipe"      -- wipe / format / diskpart / cipher /w, mkfs,
#                  shred, wipefs, blkdiscard, dd to a device
#   "crontab"   -- installing a crontab file (the exact file)
#   "systemctl" -- a mutating systemctl --user subcommand (the
#                  exact unit name, e.g. "foo.service")
# The stamp NEVER lifts the categorical refusals (checked in
# _categorical_reason_tokens and by the never-command / token
# rules, none of which consult a stamp): credential dumping,
# lock-screen / password bypass, `net user` password changes,
# shutdown / reboot, bcdedit, flashing tools, elevation, shell /
# interpreter execution, env / su. A malformed stamp (not a dict,
# missing or non-string action / target, unknown action) is
# ignored -- the command then faces the normal rules. A vague
# command with no exact target is refused asking for it; no stamp
# can name what was never named.
_OWNER_GO_ACTIONS = {"rm", "write", "wipe", "crontab", "systemctl"}


def _owner_go_stamp(cmd_obj):
    """Validated owner_go stamp from a command object, or None.
    A stamp outside the known action vocabulary, or with a missing
    / non-string action or target, is not a stamp at all."""
    stamp = cmd_obj.get("owner_go") if isinstance(cmd_obj, dict) else None
    if not isinstance(stamp, dict):
        return None
    action = stamp.get("action")
    target = stamp.get("target")
    if action not in _OWNER_GO_ACTIONS:
        return None
    if not isinstance(target, str) or not target:
        return None
    return {"action": action, "target": target}


def _owner_go_covers(owner_go, action, target):
    """True when the stamp names this exact action+target. Path
    targets compare after _resolve_path (so ~/x, /home/<user>/x
    and a trailing slash all spell the same target); targets
    without a slash (systemd unit names) compare as exact
    strings."""
    if not owner_go or owner_go.get("action") != action:
        return False
    stamp_target = owner_go.get("target") or ""
    if not isinstance(target, str) or not target:
        return False
    if "/" in stamp_target or "/" in target:
        try:
            return _resolve_path(stamp_target) == _resolve_path(target)
        except Exception:
            return False
    return stamp_target == target


def _stamp_target_in_text(owner_go, text):
    """True when the stamp's target appears among the path-like
    tokens of a normalised command string (resolved the same way
    the blocklist resolves paths). Used by the string checker to
    lift whole-text rules (profile-folder deletes, wipe patterns)
    only when the stamped target is actually in the command."""
    if not owner_go:
        return False
    try:
        wanted = _resolve_path(owner_go.get("target") or "")
    except Exception:
        return False
    for tok in re.split(r"[\s;|&]+", text or ""):
        tok = tok.strip("\"'").rstrip(",")
        if not tok:
            continue
        for cand in (tok, tok.split("=", 1)[-1] if "=" in tok else tok):
            try:
                if _resolve_path(cand) == wanted:
                    return True
            except Exception:
                continue
    return False


def _argv_rm_reason(argv, owner_override=False, owner_go=None):
    """argv[0] is rm. Refuses any target under a system root or a
    user home, except the .cache subtree and /tmp (repair cleanup).
    The owner override allows exactly one .desktop delete under
    ~/Desktop, with no -r/-R and no wildcard (same narrow rule as
    the string checker). A v1.3.10 owner_go stamp (action "rm")
    naming a protected target exactly lifts the refusal for that
    target only; --no-preserve-root stays refused even with it."""
    args = argv[1:]
    flags = []
    targets = []
    i = 0
    while i < len(args):
        tok = args[i]
        if tok == "--":
            targets.extend(args[i + 1:])
            break
        if tok.startswith("-") and len(tok) > 1 and tok != "-":
            flags.append(tok)
            i += 1
            continue
        targets.append(tok)
        i += 1
    if not targets:
        return ("refused: rm names no target -- say exactly which "
                "file or folder to remove (the owner's go must name "
                "that exact target)")
    if "--no-preserve-root" in flags:
        return "blocked: rm --no-preserve-root"
    if owner_override and len(targets) == 1:
        flag_letters = "".join(f.lstrip("-") for f in flags)
        if "r" not in flag_letters and "R" not in flag_letters \
                and targets[0].endswith(".desktop"):
            target = _resolve_path(targets[0])
            home = os.path.expanduser("~")
            if os.path.dirname(target) == os.path.join(home, "Desktop"):
                return None
    for tok in targets:
        if _is_protected_rm_target(_resolve_path(tok)):
            if _owner_go_covers(owner_go, "rm", tok):
                continue
            return ("blocked: rm aimed at a system path or a user "
                    "home (only the .cache subtree and /tmp are "
                    "open for cleanup)")
    return None


def _argv_chmod_reason(argv):
    """argv[0] is chmod, chown or chgrp. Refuses targets under a
    system root, or a whole home directory. A plain file inside a
    home (chmod 755 ~/script.sh) and anything under .cache / /tmp
    stays allowed, by design."""
    head = os.path.basename(argv[0])
    positionals, values = _split_flags(
        argv[1:], {"-m", "-o", "-g", "-t", "--mode", "--owner",
                   "--group", "--target-directory", "--reference",
                   "--from"})
    for flag, val in values:
        if flag == "--reference" and (
                _is_system_path(_resolve_path(val))
                or _VAR_SENTINEL in val):
            return "blocked: chmod/chown --reference on a system path"
    if head == "chown":
        targets = positionals[1:]  # first positional is owner spec
    elif head == "chgrp":
        targets = positionals
    else:  # chmod: first positional is the mode
        targets = positionals[1:] if positionals else []
    home = os.path.expanduser("~")
    for tok in targets:
        p = _resolve_path(tok)
        if _is_system_path(p):
            return "blocked: chmod/chown on a system path"
        if p in ("/", "/home", "/root", home) \
                or re.fullmatch(r"/home/[^/]+", p):
            return ("blocked: chmod/chown on a system path or a "
                    "whole user home")
    return None


def _argv_copy_reason(argv, owner_go=None):
    """argv[0] is cp / mv / ln / install / tee / rsync. Destination
    under a system root or /dev is refused for all of them; mv and
    rsync sources under a system root are refused too (moving a
    system file away breaks the system just as surely as rm);
    rsync --remove-source-files is mv by another name, so its
    sources under a user home are refused as well (except .cache
    and /tmp). Copying a whole credential directory (/etc/ssh,
    ~/.ssh) is refused for cp / rsync / tar sources."""
    head = os.path.basename(argv[0])
    args = argv[1:]
    if head == "tee":
        positionals, _values = _split_flags(args, set())
        for tok in positionals:
            p = _resolve_path(tok)
            if _is_system_path(p) or _is_device_path(p):
                return ("blocked: tee writing over a system path or "
                        "a device")
            if _is_trust_write_dest(tok):
                if _owner_go_covers(owner_go, "write", tok):
                    continue
                return _trust_dest_reason(tok)
        return None
    if head == "rsync":
        positionals, _values = _split_flags(args, {
            "-e", "--rsh", "--exclude", "--include", "--filter",
            "--exclude-from", "--include-from", "--files-from",
            "--log-file", "--password-file", "--address", "--port",
            "--suffix", "--temp-dir", "--partial-dir", "--backup-dir",
            "--chmod", "--usermap", "--groupmap", "--chown",
            "--out-format", "--max-size", "--min-size", "--timeout",
            "--contimeout", "--bwlimit"})
        if not positionals:
            return None
        dest = _resolve_path(positionals[-1])
        if _is_system_path(dest) or _is_device_path(dest):
            return ("blocked: rsync writing over a system path or "
                    "a device")
        if _is_trust_write_dest(positionals[-1]) and not \
                _owner_go_covers(owner_go, "write", positionals[-1]):
            return _trust_dest_reason(positionals[-1])
        for src in positionals[:-1]:
            if _is_system_path(_resolve_path(src)) \
                    or _is_ssh_dir(src):
                return ("blocked: rsync source under a system root "
                        "or a credential directory")
        if "--remove-source-files" in args:
            for src in positionals[:-1]:
                if _is_protected_rm_target(_resolve_path(src)):
                    return ("blocked: rsync --remove-source-files "
                            "moving a system path or a user home "
                            "(only .cache and /tmp are open)")
        return None
    positionals, values = _split_flags(args, {
        "-t", "--target-directory", "-m", "-o", "-g",
        "--mode", "--owner", "--group"})
    dest = None
    for flag, val in values:
        if flag in ("-t", "--target-directory"):
            dest = val
    if dest is None and positionals:
        dest = positionals[-1]
    if dest is not None:
        p = _resolve_path(dest)
        if _is_system_path(p) or _is_device_path(p):
            return ("blocked: writing over a system path or a "
                    "device")
        if _is_trust_write_dest(dest) and not \
                _owner_go_covers(owner_go, "write", dest):
            return _trust_dest_reason(dest)
    if head == "mv":
        for src in positionals[:-1]:
            if _is_system_path(_resolve_path(src)):
                return ("blocked: mv moving a system file away "
                        "(the source is never left behind)")
    if head == "cp":
        for src in positionals[:-1]:
            if _is_ssh_dir(src):
                return ("blocked: cp source is a credential "
                        "directory (/etc/ssh or ~/.ssh)")
    return None


def _argv_systemctl_reason(argv, owner_go=None):
    """argv[0] is systemctl. Only the read / service-control
    subcommands run via exec; power and session subcommands never
    do (poweroff, reboot, suspend, mask, ...). For --user, the
    bar is higher: the user systemd session is the persistence
    plane (a planted user unit + enable/start is code execution
    at login), so only read-only queries run (status, is-active,
    is-enabled, show, list-units); every mutating subcommand --
    enable/disable/start/stop/restart/reload/mask/unmask/
    set-property and friends -- is refused, unless v1.3.10's
    owner_go stamp names that exact unit (action "systemctl")."""
    ok = {"start", "stop", "restart", "reload", "enable", "disable",
          "status", "is-active", "is-enabled"}
    positionals, _values = _split_flags(argv[1:], set())
    if "--user" in argv[1:]:
        user_ok = {"status", "is-active", "is-enabled", "show",
                   "list-units"}
        if not positionals:
            return ("blocked: systemctl --user needs a read-only "
                    "subcommand (status, is-active, is-enabled, "
                    "show, list-units)")
        sub = positionals[0]
        if sub not in user_ok:
            unit = positionals[1] if len(positionals) > 1 else None
            if unit is not None and _owner_go_covers(
                    owner_go, "systemctl", unit):
                return None
            return ("blocked: systemctl --user %s mutates the user "
                    "systemd session (read-only via exec: status, "
                    "is-active, is-enabled, show, list-units) -- or "
                    "the owner's go naming that exact unit" % sub)
        return None
    if not positionals:
        return ("blocked: systemctl needs a subcommand (start, stop, "
                "restart, reload, enable, disable, status, is-active, "
                "is-enabled)")
    sub = positionals[0]
    if sub not in ok:
        return ("blocked: systemctl %s is not run via exec "
                "(allowed: start, stop, restart, reload, enable, "
                "disable, status, is-active, is-enabled)" % sub)
    return None


_PKG_RE = re.compile(r"^[a-z0-9][a-z0-9+._-]*$")


def _argv_pacman_reason(argv):
    """argv[0] is pacman. -S / -R take named packages only, never
    -Syu (no -Sy / -Su / --refresh / --sysupgrade, no -U local
    file). -Q queries are reads and stay open."""
    args = argv[1:]
    if "--refresh" in args or "--sysupgrade" in args:
        return ("blocked: pacman full upgrades (-Syu / --refresh / "
                "--sysupgrade) are never run via exec")
    letters_ops = [tok[1:] for tok in args
                   if tok.startswith("-") and not tok.startswith("--")
                   and len(tok) > 1]
    for letters in letters_ops:
        if "S" in letters and ("y" in letters or "u" in letters):
            return ("blocked: pacman -Sy / -Su / -Syu is a refresh "
                    "or upgrade, never run via exec")
        if "U" in letters:
            return ("blocked: pacman -U installs a local file; "
                    "named packages only via -S")
    has_S = any("S" in l for l in letters_ops)
    has_R = any("R" in l for l in letters_ops)
    has_Q = any("Q" in l for l in letters_ops)
    if has_Q and not (has_S or has_R):
        return None
    if has_S and not has_R:
        for letters in letters_ops:
            if letters.startswith("S") and len(letters) > 1 \
                    and set(letters[1:]) <= set("sil"):
                return None  # -Ss / -Si / -Sl: read-only search
        pkgs = [a for a in args if not a.startswith("-")]
        if not pkgs:
            return "blocked: pacman -S needs named packages"
        for p in pkgs:
            if not _PKG_RE.match(p):
                return ("blocked: pacman -S takes plain package "
                        "names only (%r is not one)" % p)
        return None
    if has_R and not has_S:
        pkgs = [a for a in args if not a.startswith("-")]
        if not pkgs:
            return "blocked: pacman -R needs named packages"
        for p in pkgs:
            if not _PKG_RE.match(p):
                return ("blocked: pacman -R takes plain package "
                        "names only (%r is not one)" % p)
        return None
    return ("blocked: pacman via exec is only -S / -R with named "
            "packages, or -Q queries")


def _argv_drop_reason(argv, owner_override=False, owner_go=None):
    """argv[0] is runuser or sudo (v1.3.10). Allowed ONLY as a drop
    to the detected session user: `runuser -u <user> [--] <cmd...>`
    or `sudo -u <user> <cmd...>`. Any other shape -- no -u, a
    target other than the session user, root, another user, an
    `env` prefix, a -c payload, a nested user-switch -- is
    refused. The inner command must itself pass the full argv
    blocklist (recursively) and the string checker, so the drop
    can only run what exec could run as the session user instead
    of root. `su` is not handled here and stays refused outright.
    No owner_go stamp is needed for the drop itself (dropping to
    the session user is not a protected action); the inner
    command's own rules still apply, stamp included."""
    head = os.path.basename(argv[0])
    args = argv[1:]
    target = None
    i = 0
    if i < len(args) and args[i] in ("-u", "--user"):
        if i + 1 >= len(args):
            return "blocked: %s -u needs a user name" % head
        target = args[i + 1]
        i += 2
    elif i < len(args) and args[i].startswith("--user="):
        target = args[i].split("=", 1)[1]
        i += 1
    else:
        return ("blocked: %s is never run via exec except to drop "
                "to the detected session user (%s -u <session user> "
                "<command>)" % (head, head))
    if not target:
        return "blocked: %s -u needs a user name" % head
    if i < len(args) and args[i] == "--":
        i += 1
    inner = args[i:]
    if not inner:
        return "blocked: %s -u <user> needs a command to run" % head
    if inner[0].startswith("-"):
        return ("blocked: %s -u <user> needs a command, not flags "
                "(%s -- a -c payload runs through a shell and is "
                "never run via exec)" % (head, inner[0]))
    if os.path.basename(inner[0]) == "env":
        return "blocked: env is never run via exec"
    if os.path.basename(inner[0]) in ("runuser", "sudo", "su"):
        return "blocked: nested user-switching is never run via exec"
    owner = _session_owner()
    if owner is None:
        return ("blocked: no graphical session user is detectable, "
                "so there is no session user to drop to")
    # Name only: this runuser build rejects a numeric uid outright
    # (proven on this VM: `runuser -u 0` fails with "user 0 does
    # not exist"), so accepting one here would approve a command
    # the real wrapper then refuses.
    ok = target == owner["name"]
    if not ok:
        return ("blocked: %s -u only drops to the detected session "
                "user (%s); target %r is refused -- elevation to "
                "root or another user is never run via exec"
                % (head, owner["name"], target))
    inner_expanded, reason = _expand_exec_tokens(inner)
    if reason is not None:
        return reason
    if not inner_expanded:
        return "blocked: %s -u <user> needs a command to run" % head
    reason = _argv_block_reason(inner_expanded, owner_override,
                                owner_go)
    if reason is not None:
        return reason
    reason = test_exec_blocked(
        " ".join(shlex.quote(a) for a in inner_expanded),
        owner_override, owner_go)
    if reason is not None:
        return reason
    return None


def _argv_block_reason(argv, owner_override=False, owner_go=None,
                       allow_home_binary=False, allow_drop=True):
    """The argv blocklist: argv[0] by basename, every argument by
    resolved path. Returns a reason, or None when the argv may run.
    Refuses by default when in doubt about a dangerous tool.
    owner_go is the v1.3.10 stamp (None = no stamp): it lifts ONLY
    its own action+target in the rm / trust-write / wipe /
    crontab / systemctl branches, never the categorical rules.
    allow_home_binary is launch-only: the launch kind has its own
    location allow-list for the executable itself, so rule 4 (no
    program-by-path from a home or temp dir) does not apply to the
    launched binary -- every other rule still does. allow_drop is
    launch-only too (False): a .desktop Exec line may not itself
    be a user-switch wrapper, because launch already drops."""
    if not argv:
        return "blocked: empty command"
    head = os.path.basename(argv[0])
    args = argv[1:]
    # 0. Categorical refusals -- an owner_go stamp never lifts these.
    reason = _categorical_reason_tokens(argv)
    if reason is not None:
        return reason
    # 0b. A bare wipe verb with no exact target is refused asking
    # for it (never guessed, never run blind).
    if head in ("wipe", "format", "erase", "clean") \
            and not any(a.startswith("/") for a in args):
        return ("refused: %s names no exact target -- say exactly "
                "which drive, partition or folder to %s (the "
                "owner's go must name that exact target)" % (head, head))
    # 1. Credential files, wherever they appear as a path argument.
    for element in args:
        if _names_credential(element):
            return ("blocked: naming a credential file (/etc/shadow, "
                    "/etc/gshadow, an SSH private key, a browser "
                    "credential store)")
    # 2. A device path in a file-writing tool's arguments.
    if head in _ARGV_WRITE_TOOLS or head.startswith("mkfs"):
        for element in args:
            if element.startswith("-"):
                continue
            if _is_device_path(_resolve_path(element)):
                if _owner_go_covers(owner_go, "wipe", element):
                    continue
                return ("blocked: writing to a raw disk device "
                        "(%s)" % element)
    # 3. Commands that are never run via exec at all.
    if head in _ARGV_NEVER_COMMANDS:
        if head in ("runuser", "sudo"):
            if not allow_drop:
                return ("blocked: %s is never run via exec" % head)
            return _argv_drop_reason(argv, owner_override, owner_go)
        if head in _SHELL_WORDS_ARGV and "-c" in args:
            inner = args[args.index("-c") + 1] \
                if args.index("-c") + 1 < len(args) else ""
            inner_reason = test_exec_blocked(
                inner, owner_override, owner_go) if inner else None
            if inner_reason is not None:
                return inner_reason
            return ("blocked: shell interpreters are never run via "
                    "exec; send the inner command as a plain exec "
                    "(or exec_pipeline for pipes)")
        return ("blocked: %s is never run via exec" % head)
    # 4. Running a program by path out of a staging area.
    # (Skipped for the launched binary itself: launch enforces
    # its own location allow-list instead.)
    if "/" in argv[0] and not allow_home_binary:
        p = _resolve_path(argv[0])
        if _is_temp_path(p) or _is_home_path(p):
            return ("blocked: executing a program by path from a "
                    "home or temp directory")
    if head == "rm":
        return _argv_rm_reason(argv, owner_override, owner_go)
    if head in ("format", "diskpart"):
        targets = [a for a in args if a.startswith("/")]
        if not targets:
            return ("refused: %s names no exact target -- say "
                    "exactly which drive, partition or folder to "
                    "%s (the owner's go must name that exact "
                    "target)" % (head, head))
        for target in targets:
            if _owner_go_covers(owner_go, "wipe", target):
                return None
        return ("blocked: %s is a wipe -- refused without the "
                "owner's go naming the exact drive, partition or "
                "folder" % head)
    if head == "cipher":
        wvals = []
        bare_w = False
        for tok in args:
            low = tok.lower()
            if low == "/w":
                bare_w = True
            elif low.startswith("/w:") or low.startswith("/w="):
                wvals.append(tok[3:])
        if bare_w and not wvals:
            return ("refused: cipher /w names no exact target -- "
                    "say exactly which drive, partition or folder "
                    "to wipe (the owner's go must name that exact "
                    "target)")
        if wvals:
            for target in wvals:
                if _owner_go_covers(owner_go, "wipe", target):
                    return None
            return ("blocked: cipher /w is a wipe -- refused "
                    "without the owner's go naming the exact "
                    "drive, partition or folder")
        return None
    if head in ("chmod", "chown", "chgrp"):
        return _argv_chmod_reason(argv)
    if head == "find":
        for tok in args:
            if tok in ("-delete", "-exec", "-execdir", "-ok", "-okdir"):
                return ("blocked: find -delete / -exec / -execdir / "
                        "-ok is never run via exec; list with find, "
                        "then act on named paths")
        for j, tok in enumerate(args):
            if tok in ("-fprint", "-fprint0", "-fls") \
                    and j + 1 < len(args):
                p = _resolve_path(args[j + 1])
                if _is_system_path(p) or _is_device_path(p):
                    return ("blocked: find writing its listing over "
                            "a system path or a device")
                if _is_trust_write_dest(args[j + 1]) and not \
                        _owner_go_covers(owner_go, "write",
                                         args[j + 1]):
                    return _trust_dest_reason(args[j + 1])
        return None
    if head == "tar":
        # Mode letters across the flag tokens: create/append/update
        # write an archive file (-f is a WRITE destination then);
        # extract/list only read it (-f is a source then, and -C
        # is the WRITE destination instead).
        _mode = ""
        for _k, tok in enumerate(args):
            if tok in ("--create", "--append", "--update"):
                _mode += "cru"[("--create", "--append", "--update")
                               .index(tok)]
            elif tok == "--extract":
                _mode += "x"
            elif tok.startswith("-") and not tok.startswith("--"):
                _mode += tok.lstrip("-")
            elif _k == 0 and re.fullmatch(r"[a-zA-Z]+", tok):
                _mode += tok  # old bare form: `tar cf ...`
        for j, tok in enumerate(args):
            if tok == "--checkpoint-action" \
                    or tok.startswith("--checkpoint-action="):
                return ("blocked: tar --checkpoint-action runs "
                        "commands; refused outright")
            if tok == "--to-command" \
                    or tok.startswith("--to-command="):
                return ("blocked: tar --to-command runs commands; "
                        "refused outright")
            if tok in ("-C", "--directory") and j + 1 < len(args):
                if _is_system_path(_resolve_path(args[j + 1])):
                    return ("blocked: tar extracting over a system "
                            "path")
                if "x" in _mode \
                        and _is_trust_write_dest(args[j + 1]) \
                        and not _owner_go_covers(
                            owner_go, "write", args[j + 1]):
                    return _trust_dest_reason(args[j + 1])
        if any(c in _mode for c in "cru"):
            # Archive file: -f VALUE / --file VALUE / --file=VALUE /
            # a combined -cf VALUE / -czf VALUE, or the old bare
            # form `tar cf VALUE ...` (mode word with no dash).
            _fvals = []
            if args and re.fullmatch(r"[a-zA-Z]+", args[0]) \
                    and "f" in args[0] and len(args) > 1:
                _fvals.append(args[1])
            for j, tok in enumerate(args):
                val = None
                if tok in ("-f", "--file") and j + 1 < len(args):
                    val = args[j + 1]
                elif tok.startswith("--file="):
                    val = tok.split("=", 1)[1]
                elif re.fullmatch(r"-[a-zA-Z]*f[a-zA-Z]*", tok) \
                        and j + 1 < len(args):
                    val = args[j + 1]
                if val is not None:
                    _fvals.append(val)
            for val in _fvals:
                if _is_trust_write_dest(val) and not \
                        _owner_go_covers(owner_go, "write", val):
                    return _trust_dest_reason(val)
        for src in _split_flags(args, {"-C", "--directory",
                                       "--checkpoint", "-f",
                                       "--file"})[0]:
            if _is_ssh_dir(src):
                return ("blocked: tar source is a credential "
                        "directory (/etc/ssh or ~/.ssh)")
        return None
    if head == "dd":
        for j, tok in enumerate(args):
            val = None
            if tok.startswith("of="):
                val = tok[3:]
            elif tok == "of" and j + 2 < len(args) \
                    and args[j + 1] == "=":
                val = args[j + 2]
            elif tok == "of" and j + 1 < len(args):
                val = args[j + 1]
            if val is None:
                continue
            if _is_trust_write_dest(val):
                if _owner_go_covers(owner_go, "write", val):
                    continue
                return _trust_dest_reason(val)
            if _is_device_path(_resolve_path(val)) \
                    or _is_protected_rm_target(_resolve_path(val)):
                if _owner_go_covers(owner_go, "wipe", val):
                    continue
                return ("blocked: dd writing to a device or a "
                        "system / home path")
        return None
    if head.startswith("mkfs"):
        positionals = _split_flags(args, set())[0]
        if not positionals:
            return ("refused: mkfs names no exact target -- say "
                    "exactly which drive or partition to format "
                    "(the owner's go must name that exact target)")
        for tok in positionals:
            if _is_device_path(_resolve_path(tok)) \
                    or _is_protected_rm_target(_resolve_path(tok)):
                if _owner_go_covers(owner_go, "wipe", tok):
                    continue
                return ("blocked: mkfs on a device or a system / "
                        "home path")
        return None
    if head in ("shred", "wipefs", "blkdiscard"):
        positionals = _split_flags(args, set())[0]
        if not positionals:
            return ("refused: %s names no exact target -- say "
                    "exactly which drive, partition or folder to "
                    "wipe (the owner's go must name that exact "
                    "target)" % head)
        for tok in positionals:
            if _is_device_path(_resolve_path(tok)) \
                    or _is_protected_rm_target(_resolve_path(tok)):
                if _owner_go_covers(owner_go, "wipe", tok):
                    continue
                return ("blocked: destructive disk write to a "
                        "device or a system / home path")
        return None
    if head in ("cp", "mv", "ln", "install", "tee", "rsync"):
        return _argv_copy_reason(argv, owner_go)
    if head == "crontab":
        return _crontab_reason(argv, owner_go)
    if head == "systemctl":
        return _argv_systemctl_reason(argv, owner_go)
    if head == "pacman":
        return _argv_pacman_reason(argv)
    if head == "getent":
        if any(a in ("shadow", "gshadow", "passwd") for a in args):
            return "blocked: dumping password hashes (getent shadow)"
        return None
    if head == "sysctl":
        if "-w" in args or "--write" in args \
                or any("=" in a and not a.startswith("-") for a in args):
            return ("blocked: sysctl writes a kernel setting; reads "
                    "only via exec")
        return None
    if head in ("curl", "wget"):
        for j, tok in enumerate(args):
            dest = None
            if tok in ("-o", "--output") and j + 1 < len(args):
                dest = args[j + 1]
            elif tok.startswith("--output="):
                dest = tok.split("=", 1)[1]
            if dest is not None:
                p = _resolve_path(dest)
                if _is_system_path(p) or _is_device_path(p):
                    return ("blocked: download writing over a "
                            "system path or a device")
                if _is_trust_write_dest(dest) and not \
                        _owner_go_covers(owner_go, "write", dest):
                    return _trust_dest_reason(dest)
        return None
    if head == "ip":
        if any(a in ("add", "del", "delete", "set", "flush")
               for a in args):
            return ("blocked: ip changes network state; reads only "
                    "via exec")
        return None
    if head in ("kill", "killall", "pkill"):
        if "1" in args or "-1" in args:
            return "blocked: killing PID 1 / all processes"
        if head in ("killall", "pkill") \
                and any(a in ("init", "systemd") for a in args):
            return "blocked: killing init / systemd"
        return None
    return None


def _parse_exec_command(command, owner_override=False, owner_go=None):
    """Parse + check one relay exec string. Returns (argv, reason):
    argv is the final argv list when the command may run, else None
    with reason a short refusal string. Layers, in order: (1)
    shlex split + shell-metacharacter refusal (pipes and friends
    go to exec_pipeline); (2) ~/ $HOME / glob expansion; (3) the
    argv blocklist; (4) the normalise-then-check string checker on
    the raw command (second layer, defence in depth). owner_go
    (v1.3.10) is threaded through layers (3) and (4) and lifts
    only its own action+target."""
    if not isinstance(command, str) or not command.strip():
        return None, "blocked: empty command"
    try:
        tokens = shlex.split(command)
    except ValueError as e:
        return None, ("refused: could not parse command (%s); send "
                      "it as exec_pipeline stages or retype it" % e)
    if not tokens:
        return None, "blocked: empty command"
    # A never-command (shell, interpreter, sudo, wrapper, ...) is
    # refused on argv[0] alone, before the metachar scan -- so
    # `python3 -c "...;..."` reports the interpreter refusal, not
    # the ';' inside its -c argument, and `sh -c '...'` reports
    # what the inner command's own check says.
    if os.path.basename(tokens[0]) in _ARGV_NEVER_COMMANDS:
        reason = _argv_block_reason(tokens, owner_override, owner_go)
        if reason is not None:
            return None, reason
        # The ONLY never-command that can pass is the v1.3.10
        # runuser / sudo drop to the detected session user: the
        # whole argv (wrapper + inner command) is what runs.
        if os.path.basename(tokens[0]) in ("runuser", "sudo"):
            argv, reason = _expand_exec_tokens(tokens)
            if reason is not None:
                return None, reason
            return argv, None
        return None, ("blocked: %s is never run via exec"
                      % os.path.basename(tokens[0]))
    for tok in tokens:
        if any(c in tok for c in "|><;&`") or "$(" in tok:
            return None, ("refused: shell syntax (%r) is not "
                          "executed; use exec_pipeline for pipes, "
                          "or send each command separately as exec"
                          % tok)
    argv, reason = _expand_exec_tokens(tokens)
    if reason is not None:
        return None, reason
    if not argv:
        return None, "blocked: empty command"
    if "=" in argv[0]:
        return None, ("refused: VAR=value assignments are not "
                      "executed; send the command without the "
                      "assignment")
    reason = _argv_block_reason(argv, owner_override, owner_go)
    if reason is not None:
        return None, reason
    reason = test_exec_blocked(command, owner_override, owner_go)
    if reason is not None:
        return None, reason
    return argv, None


def check_exec_command(command, owner_override=False, owner_go=None):
    """Return None when a relay exec string may run, else the short
    refusal reason. The single entry point the tests probe.
    owner_go is the v1.3.10 stamp (None = no stamp)."""
    _argv, reason = _parse_exec_command(command, owner_override,
                                        owner_go)
    return reason


def run_exec_argv_sync(argv, timeout_s, started=None):
    """Run one argv list with shell=False, capture stdout+stderr
    merged, enforce the timeout. Returns {output, exit_code,
    timed_out}. Never raises."""
    if started is None:
        started = time.monotonic()
    try:
        proc = subprocess.run(argv, shell=False, capture_output=True,
                              text=True, timeout=timeout_s)
        return {"output": (proc.stdout or "") + (proc.stderr or ""),
                "exit_code": proc.returncode, "timed_out": False,
                "duration_s": round(time.monotonic() - started, 1)}
    except subprocess.TimeoutExpired as e:
        partial = ""
        if e.stdout:
            partial += e.stdout if isinstance(e.stdout, str) else e.stdout.decode("utf-8", "replace")
        if e.stderr:
            partial += e.stderr if isinstance(e.stderr, str) else e.stderr.decode("utf-8", "replace")
        return {"output": partial, "exit_code": None, "timed_out": True,
                "duration_s": round(time.monotonic() - started, 1),
                "detail": f"command timed out after {timeout_s}s; "
                          "partial output above, process stopped"}
    except (OSError, ValueError) as e:
        return {"output": "", "exit_code": None, "timed_out": False,
                "duration_s": round(time.monotonic() - started, 1),
                "error": "exec_failed", "detail": str(e)}


def run_exec_sync(command, timeout_s, owner_override=False,
                  owner_go=None):
    """Run one relay exec command WITHOUT a shell: parse to argv,
    blocklist-check, run with shell=False. Returns {output,
    exit_code, timed_out}. A refused command returns
    error='blocked' with the reason in 'detail' and runs nothing.
    Never raises. (The only shell=True call site in this agent was
    here; it is gone -- grep shell=True to confirm.) v1.3.10:
    owner_override and owner_go are threaded here -- v1.3.9
    re-parsed without them, so a stamp- or override-authorised
    command passed the dispatch check and then refused itself
    inside the job."""
    started = time.monotonic()
    argv, reason = _parse_exec_command(command, owner_override,
                                       owner_go)
    if reason is not None:
        return {"output": "", "exit_code": None, "timed_out": False,
                "duration_s": round(time.monotonic() - started, 1),
                "error": "blocked", "detail": reason}
    return run_exec_argv_sync(argv, timeout_s, started)


def validate_pipeline_stages(stages, owner_go=None):
    """Validate an exec_pipeline 'stages' value. Returns
    (parsed_stages, reason): parsed_stages is the list of final
    argv lists when every stage passes, else None with reason.
    Shape first (list of 1..4 stages, each a non-empty list of
    non-empty strings, total <= EXEC_MAX_CHARS), then EVERY stage
    is expanded (~/ $HOME / globs) and argv-blocklist-checked --
    plus the string checker on the joined stage -- BEFORE anything
    runs, so one blocked stage refuses the whole pipeline.
    owner_go (v1.3.10) is threaded through both checks."""
    if not isinstance(stages, list) or not stages:
        return None, ("refused: exec_pipeline needs a non-empty "
                      "'stages' list of argv lists")
    if len(stages) > MAX_PIPELINE_STAGES:
        return None, ("refused: exec_pipeline allows at most %d "
                      "stages (%d sent); split it into two "
                      "pipelines" % (MAX_PIPELINE_STAGES, len(stages)))
    total = 0
    parsed = []
    for stage in stages:
        if not isinstance(stage, list) or not stage:
            return None, ("refused: each exec_pipeline stage must "
                          "be a non-empty argv list")
        if any(not isinstance(a, str) or not a for a in stage):
            return None, ("refused: each exec_pipeline stage "
                          "argument must be a non-empty string")
        total += sum(len(a) for a in stage)
        if total > EXEC_MAX_CHARS:
            return None, ("refused: exec_pipeline stages total "
                          "%d chars, over the %d-char limit"
                          % (total, EXEC_MAX_CHARS))
        argv, reason = _expand_exec_tokens(stage, refuse_meta=False)
        if reason is not None:
            return None, reason
        reason = _argv_block_reason(argv, owner_go=owner_go)
        if reason is not None:
            return None, reason
        joined = " ".join(shlex.quote(a) for a in argv)
        reason = test_exec_blocked(joined, owner_go=owner_go)
        if reason is not None:
            return None, reason
        parsed.append(argv)
    return parsed, None


def run_pipeline_sync(stages, timeout_s, owner_go=None):
    """Run an exec_pipeline: validate EVERY stage first (a blocked
    stage refuses the whole pipeline before anything runs), then
    connect the stages with real pipes in Python (no shell) and
    capture the last stage's stdout plus every stage's stderr,
    merged. One timeout_s budget bounds the whole pipeline (no
    stage can run longer than timeout_s). Returns {output,
    exit_code (last stage), timed_out, stages: [exit codes]}.
    Never raises."""
    started = time.monotonic()
    parsed, reason = validate_pipeline_stages(stages, owner_go)
    if reason is not None:
        return {"output": "", "exit_code": None, "timed_out": False,
                "duration_s": round(time.monotonic() - started, 1),
                "error": "blocked", "detail": reason}
    procs = []
    stdin = None
    try:
        for argv in parsed[:-1]:
            proc = subprocess.Popen(argv, stdin=stdin,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, text=True)
            procs.append(proc)
            if stdin is not None:
                stdin.close()
            stdin = proc.stdout
        last = subprocess.Popen(parsed[-1], stdin=stdin,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True)
        procs.append(last)
        if stdin is not None:
            stdin.close()
    except (OSError, ValueError) as e:
        for proc in procs:
            try:
                proc.kill()
            except OSError:
                pass
        return {"output": "", "exit_code": None, "timed_out": False,
                "duration_s": round(time.monotonic() - started, 1),
                "error": "exec_failed", "detail": str(e)}
    try:
        out, err = last.communicate(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        for proc in procs:
            try:
                proc.kill()
            except OSError:
                pass
        try:
            out, err = last.communicate(timeout=5)
        except (OSError, subprocess.SubprocessError):
            out, err = "", ""
        return {"output": (out or "") + (err or ""),
                "exit_code": None, "timed_out": True,
                "duration_s": round(time.monotonic() - started, 1),
                "detail": f"pipeline timed out after {timeout_s}s; "
                          "partial output above, processes stopped"}
    output = ""
    for proc in procs[:-1]:
        try:
            _o, e = proc.communicate(timeout=5)
        except (OSError, subprocess.SubprocessError):
            e = ""
        if e:
            output += e
    output += (out or "") + (err or "")
    return {"output": output, "exit_code": last.returncode,
            "timed_out": False,
            "duration_s": round(time.monotonic() - started, 1),
            "stages": [p.returncode for p in procs]}


# ---------------------------------------------------------------- screenshot / mouse / type
# Screenshot chain (first tool present wins): grim (Wayland) ->
# spectacle (KDE, Wayland-native -- shipped on the Deck, confirmed
# present at /usr/bin/spectacle on the live Deck 2026-11-22, where
# grim / scrot / import / xwd were all absent) -> scrot (X11) ->
# import (ImageMagick) -> xwd (X11). Wayland-native tools come
# first, X11-only after; the existing relative order is otherwise
# preserved. A present-but-failing tool is skipped (the loop falls
# through on nonzero exit / missing / empty file). Spectacle gets
# a .jpg output path so it writes JPEG directly; the other tools
# get .png (xwd gets .xwd). v1.3.7: when the agent runs as root, each
# tool is first run AS the graphical session owner (runuser -u
# <user> -- ..., else sudo -u <user> ...) with the session env
# passed through -- root asking KWin / the portal for a screenshot
# is ignored on Wayland (proven live: spectacle exits 1 as root
# even with WAYLAND_DISPLAY / XDG_RUNTIME_DIR / DBUS_SESSION_BUS_
# ADDRESS all set). If the drop fails, the same tool is retried
# directly as root; unprivileged runs capture directly, unchanged.
# The capture file goes in the session user's writable area when
# dropping (never /root/.cache, which the dropped user cannot
# write). The agent CHECKS for each tool and
# returns 'screenshot_unavailable' loudly when none is present --
# it never installs anything. The capture is scaled / compressed
# to JPEG <=200KB when ImageMagick `convert` is available;
# otherwise the raw capture is returned with a note saying so
# (an already-JPEG capture is returned as JPEG). Pixels go in the
# ack result as image_b64, the same interface as the Windows
# agent. Mouse / type go through xdotool when present, else
# 'unavailable' loudly -- never installed, never silent.

SCREENSHOT_TOOLS = [
    ("grim", ["grim", "{path}"]),
    ("spectacle", ["spectacle", "-b", "-n", "-o", "{path}"]),
    ("scrot", ["scrot", "{path}"]),
    ("import", ["import", "-window", "root", "{path}"]),
    ("xwd", ["xwd", "-root", "-out", "{path}"]),
]


def _session_owner():
    """Owner of the graphical session, or None when none is
    detectable. v1.3.7: the root agent cannot ask KWin / the portal
    for a screenshot -- only the session owner can -- so the
    capture runs as this user. Detection, in order:
      1. XDG_RUNTIME_DIR=/run/user/<uid> -> pwd.getpwuid(uid).
      2. The owner (st_uid) of $XDG_RUNTIME_DIR via os.stat.
      3. Last resort, only when a session dir IS set: the name
         "deck" (the Deck's session user) via pwd.getpwnam.
    Returns {"name", "uid", "gid", "home", "runtime_dir"} or None.
    No session dir at all -> None (the caller captures directly).
    A uid with no passwd entry comes back with its numeric id as
    the name (runuser / sudo both accept one) and no home, so the
    runtime dir is the writable area instead."""
    runtime_dir = os.environ.get("XDG_RUNTIME_DIR") or ""
    uid = None
    if runtime_dir:
        base = os.path.basename(runtime_dir.rstrip("/"))
        if base.isdigit():
            uid = int(base)
        else:
            try:
                uid = os.stat(runtime_dir).st_uid
            except OSError:
                uid = None
    if uid is not None:
        try:
            pw = pwd.getpwuid(uid)
            return {"name": pw.pw_name, "uid": pw.pw_uid,
                    "gid": pw.pw_gid, "home": pw.pw_dir,
                    "runtime_dir": runtime_dir}
        except KeyError:
            pass
        return {"name": str(uid), "uid": uid, "gid": uid,
                "home": "", "runtime_dir": runtime_dir}
    if runtime_dir:
        try:
            pw = pwd.getpwnam("deck")
            return {"name": pw.pw_name, "uid": pw.pw_uid,
                    "gid": pw.pw_gid, "home": pw.pw_dir,
                    "runtime_dir": runtime_dir}
        except KeyError:
            return None
    return None


def _session_capture_env(owner):
    """Env for a capture run as the session owner: the caller's env
    with the three session vars passed through explicitly (plus
    the session user's HOME, so tools don't write into /root)."""
    env = dict(os.environ)
    for key in ("WAYLAND_DISPLAY", "XDG_RUNTIME_DIR",
                "DBUS_SESSION_BUS_ADDRESS"):
        value = os.environ.get(key)
        if value:
            env[key] = value
    if owner.get("home"):
        env["HOME"] = owner["home"]
    return env


def _capture_tmpdir(owner):
    """Writable capture dir for _capture_screenshot_file(). With no
    owner (direct capture, v1.3.6 path) this is ~/.cache/kurodoctor
    -- /root/.cache/kurodoctor when root. When dropping to the
    session user that dir is UNWRITABLE for the dropped user, so
    use the session user's home /.cache/kurodoctor instead, or
    /run/user/<uid>/kurodoctor when the home is unknown. A dir
    created here by root is chowned to the session user so the
    dropped tool can write into it (best-effort; a dir already
    owned by that user is unchanged). Raises OSError when the dir
    cannot be created, as the old inline makedirs did."""
    if owner is not None:
        if owner.get("home"):
            tmpdir = os.path.join(owner["home"], ".cache", "kurodoctor")
        elif owner.get("runtime_dir"):
            tmpdir = os.path.join(owner["runtime_dir"], "kurodoctor")
        else:
            tmpdir = os.path.join("/run/user", str(owner["uid"]),
                                  "kurodoctor")
    else:
        tmpdir = os.path.join(os.path.expanduser("~"), ".cache",
                              "kurodoctor")
    os.makedirs(tmpdir, exist_ok=True)
    if owner is not None:
        # Root-owned parent dirs would block the dropped user.
        for d in (tmpdir, os.path.dirname(tmpdir)):
            try:
                os.chown(d, owner["uid"], owner["gid"])
            except OSError:
                pass
    return tmpdir


def _wrap_as_user(cmd, owner, env):
    """Wrap cmd to run as the session owner, or None when no wrapper
    is available. runuser first (it keeps the caller's env, so the
    session vars passed via env= reach the tool); else sudo, with
    the session vars set via `env` on the command line (sudo's env
    scrubbing cannot strip assignments the env command itself
    makes). No shell is involved either way -- plain argv lists."""
    name = owner["name"]
    if shutil.which("runuser") is not None:
        return ["runuser", "-u", name, "--"] + list(cmd), env
    if shutil.which("sudo") is not None:
        session_vars = ["%s=%s" % (key, env[key]) for key in
                        ("WAYLAND_DISPLAY", "XDG_RUNTIME_DIR",
                         "DBUS_SESSION_BUS_ADDRESS", "HOME")
                        if env.get(key)]
        return (["sudo", "-u", name, "env"] + session_vars
                + list(cmd), env)
    return None


def _capture_screenshot_file():
    """Try the screenshot chain. Returns (tool, path) or (None, reason).

    v1.3.7: when this agent runs as root AND a session owner is
    detectable (and is not root itself), each tool is first run AS
    that user with the session env passed through -- root asking
    KWin for a screenshot is ignored on Wayland. If the user-drop
    fails (no wrapper, wrapper error, or no usable file), the same
    tool is retried directly as root, exactly as v1.3.6 did -- the
    drop can never make a capture worse than v1.3.6. Unprivileged
    runs, and runs with no detectable session user, capture
    directly, exactly as v1.3.6 did."""
    drop = False
    owner = None
    if _current_uid() == 0:
        owner = _session_owner()
        if owner is not None and owner["uid"] != 0:
            drop = True
    try:
        tmpdir = _capture_tmpdir(owner if drop else None)
    except OSError as e:
        return None, f"cannot create screenshot work dir: {e}"
    for tool, template in SCREENSHOT_TOOLS:
        if shutil.which(tool) is None:
            continue
        # Spectacle writes JPEG when the output path ends .jpg; the
        # other tools write PNG (xwd writes its own .xwd format).
        ext = ".jpg" if tool == "spectacle" else (
            ".xwd" if tool == "xwd" else ".png")
        path = os.path.join(tmpdir, f"screenshot-{int(time.time())}{ext}")
        cmd = [arg.format(path=path) for arg in template]
        attempts = []
        if drop:
            wrapped = _wrap_as_user(
                cmd, owner, _session_capture_env(owner))
            if wrapped is not None:
                attempts.append(wrapped)
        attempts.append((cmd, None))
        for attempt_cmd, attempt_env in attempts:
            try:
                proc = subprocess.run(attempt_cmd, capture_output=True,
                                      text=True, timeout=30,
                                      env=attempt_env)
            except (OSError, subprocess.SubprocessError):
                proc = None
            if proc is not None and proc.returncode == 0 \
                    and os.path.isfile(path) \
                    and os.path.getsize(path) > 0:
                return tool, path
            try:
                os.remove(path)
            except OSError:
                pass
    present = [t for t, _ in SCREENSHOT_TOOLS if shutil.which(t)]
    if not present:
        return None, ("screenshot_unavailable: none of grim, spectacle, "
                      "scrot, import, or xwd is installed on this machine. "
                      "Install one (for example spectacle on a KDE/Wayland "
                      "desktop, scrot on X11) and try again -- "
                      "this agent never installs anything itself.")
    return None, ("screenshot_unavailable: a screenshot tool is present "
                  f"({', '.join(present)}) but every capture attempt failed.")


def _jpeg_bytes(path):
    """Convert a capture to JPEG <=200KB when ImageMagick is available.
    Returns (bytes, format, note). Without a converter, returns the raw
    capture bytes with a note saying so."""
    try:
        with open(path, "rb") as fh:
            raw = fh.read()
    except OSError as e:
        return None, None, f"cannot read capture file: {e}"
    if shutil.which("convert") is not None:
        for quality in (70, 50, 30):
            out_path = path + ".jpg"
            try:
                proc = subprocess.run(
                    ["convert", path, "-resize", "1280x>",
                     "-quality", str(quality), out_path],
                    capture_output=True, text=True, timeout=30)
                if proc.returncode == 0 and os.path.isfile(out_path):
                    with open(out_path, "rb") as fh:
                        data = fh.read()
                    try:
                        os.remove(out_path)
                    except OSError:
                        pass
                    if len(data) <= SCREENSHOT_MAX_BYTES:
                        return data, "jpeg", (
                            f"converted with ImageMagick (quality {quality})")
                    # Too big even at this quality: try lower, else keep
                    # the smallest we produced.
                    if quality == 30:
                        return data, "jpeg", (
                            "converted with ImageMagick (quality 30) but "
                            f"still {len(data)} bytes, over the 200KB cap; "
                            "returned anyway so the screen is visible")
            except (OSError, subprocess.SubprocessError):
                pass
        if raw[:2] == b"\xff\xd8":
            return raw, "jpeg", ("ImageMagick convert failed; the capture "
                                 "is already JPEG, returned as-is")
        return raw, "raw", ("ImageMagick convert failed; returning the raw "
                            "capture unconverted")
    if raw[:2] == b"\xff\xd8":
        return raw, "jpeg", ("capture is already JPEG (spectacle wrote "
                             "a .jpg); no converter needed")
    return raw, "raw", ("no JPEG converter available (ImageMagick not "
                        "installed); returning the raw capture")


def cmd_screenshot(_args):
    tool, path_or_reason = _capture_screenshot_file()
    if tool is None:
        return {"error": "screenshot_unavailable",
                "detail": path_or_reason}
    try:
        data, fmt, note = _jpeg_bytes(path_or_reason)
    finally:
        try:
            os.remove(path_or_reason)
        except OSError:
            pass
    if data is None:
        return {"error": "screenshot_unavailable", "detail": note}
    relay_post("/doctor/report", {
        "agent": "kuro-doctor", "version": VERSION, "kind": "screenshot",
        "boot_id": BOOT_ID, "hostname": socket.gethostname(),
        "at": now_iso(), "tool": tool, "format": fmt})
    return {"tool": tool, "format": fmt, "size_bytes": len(data),
            "note": note,
            "image_b64": base64.b64encode(data).decode("ascii")}

# ---------------------------------------------------------------- live feed
# v1.3.4 - live-feed eyes. Mirrors the Windows agent's
# Send-KDDoctorFrameTick: change-only frames to POST /doctor/frame,
# JPEG quality 40, 40KB cap with scale-down (50% / 25% / 12.5%),
# hard cap 1 post per 5 seconds even when the screen keeps changing,
# liveness re-post every 60 seconds when nothing changed. The agent
# holds NO token; the POST carries {image_b64, width, height, bytes}
# and no token, exactly like Windows. The tick never throws into the
# agent loop: every failure is swallowed after one throttled log /
# audit line (first successful post + failures only, never one line
# per frame). If no relay URL is configured the tick does nothing.
# Capture reuses _capture_screenshot_file() and the ImageMagick
# convert path (v1.3.7: the capture runs as the session owner when
# the agent is root, so frames come from the real session too).
# v1.3.8: `convert` / `magick` / `gm` are all ABSENT on the Deck
# (proven live 2026-11-22), and spectacle's raw JPEG (275,527
# bytes -> ~367,000 base64 chars) is rejected by the frame room
# (400 too_large over 100,000 chars) -- so when `convert` is
# absent (or present but failing on every scale) the frame path
# scales with ffmpeg (/usr/bin/ffmpeg, proven present on the
# Deck), same 50% / 25% / 12.5% ladder at the 40KB cap, run as
# the session owner when the agent is root. A capture that is
# already JPEG is returned raw ONLY when no converter exists or
# every conversion fails, and that fallback logs (throttled) that
# the frame will likely be rejected as too_large; a non-JPEG
# capture with no working converter still fails the tick (the tick
# logs, throttled, and returns).

FRAME_MAX_BYTES = 40 * 1024  # 40 KB cap on live-feed JPEG
FRAME_JPEG_QUALITY = 40
FRAME_SCALES = (0.5, 0.25, 0.125)
# v1.3.8: ffmpeg MJPEG quality (-q:v; valid range 2 best .. 31
# worst). 8 approximates ImageMagick quality ~40-50 -- legible at
# small frame sizes while the scale ladder does the heavy size
# reduction. -q:v 40 would be out of range for the MJPEG encoder
# (it is NOT the same scale as ImageMagick's 0-100 quality).
FRAME_FFMPEG_QUALITY = 8
# v1.3.8: fallback frame widths (px) when the capture is not a
# JPEG and its size is therefore unknown (e.g. a PNG from grim /
# scrot) -- one per FRAME_SCALES step, same 50% / 25% / 12.5%
# shape as the ladder. A JPEG capture uses its real dimensions
# via _jpeg_dimensions() instead.
FRAME_FALLBACK_WIDTHS = (640, 320, 160)
FRAME_MIN_INTERVAL_S = 5    # hard cap: at most 1 post per 5 seconds
FRAME_LIVENESS_S = 60       # re-post when unchanged for this long
_FRAME_STATE = {"last_hash": None, "last_post_at": None,
                "post_count": 0, "last_error_at": 0.0,
                "last_raw_fallback_at": 0.0}
# v1.3.8: monotonic time of the last re-pop log line per already-
# seen command id (poll_once un-wedge). Bounded the same way
# seen_ids is: one entry per id the agent has ever seen.
_REPOP_LOG_AT = {}


def _jpeg_dimensions(data):
    """Width/height of a JPEG byte string, parsed from its SOF marker
    (stdlib only -- no Pillow, no `identify` needed). (0, 0) when the
    header cannot be parsed."""
    try:
        if len(data) < 4 or data[0:2] != b"\xff\xd8":
            return 0, 0
        pos = 2
        while pos + 4 <= len(data):
            if data[pos] != 0xFF:
                return 0, 0
            marker = data[pos + 1]
            if marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
                pos += 2
                continue
            length = (data[pos + 2] << 8) | data[pos + 3]
            if marker in (0xC0, 0xC1, 0xC2):
                if pos + 9 <= len(data):
                    height = (data[pos + 5] << 8) | data[pos + 6]
                    width = (data[pos + 7] << 8) | data[pos + 8]
                    return width, height
                return 0, 0
            pos += 2 + length
    except (IndexError, TypeError):
        pass
    return 0, 0


def _frame_log_raw_fallback(detail):
    """One throttled log line per 60s window for the raw-as-is
    fallback: a tick runs every few seconds, so an unthrottled
    line here would spam the log while the feed stays oversize."""
    now = time.monotonic()
    if now - _FRAME_STATE["last_raw_fallback_at"] < 60:
        return
    _FRAME_STATE["last_raw_fallback_at"] = now
    log(f"live feed: {detail}")


def _frame_jpeg_bytes(path):
    """Convert a capture to a live-feed JPEG: quality 40, scaled down
    (50% / 25% / 12.5%) until it fits the 40KB cap. Returns
    (bytes, width, height), or (None, 0, 0) when no converter is
    available AND the capture is not already JPEG, or when every
    conversion fails and the capture is not JPEG either. Converter
    preference, v1.3.8: `convert` first (unchanged path); if it
    yields nothing, ffmpeg; then raw-as-is ONLY when neither
    converter exists or every conversion fails -- and in that
    fallback case a (throttled) log line notes the frame will
    likely be rejected as too_large by the relay. When even the
    smallest scale is still over the cap, the smallest is returned
    anyway (same Windows parity -- the relay's own ~100k
    base64-char cap is the backstop).

    ffmpeg ladder (v1.3.8): per scale step,
      ffmpeg -y -i <in> -vf scale=<w>:-2 -q:v 8 <out>
    where <w> is the capture width at that scale (from
    _jpeg_dimensions() on the capture; FRAME_FALLBACK_WIDTHS when
    the capture is not a JPEG and its size is unknown), <out> is
    path + ".frame.jpg" in the same dir as the capture (the
    session user's tmpdir -- see _capture_tmpdir), timeout 30s
    per attempt, argv-only, no shell. When the agent runs as root
    AND a session owner is detectable, the ffmpeg call runs
    through _wrap_as_user() (runuser -u <name> -- ... else
    sudo -u <name> env ...), the same mechanism as the v1.3.7
    capture; the owner is re-resolved here via _session_owner()
    rather than threaded through the capture chain, because it is
    deterministic from the process env (the same env the capture
    in this same tick used) -- no new module state, no capture
    change. When unprivileged, or with no detectable session
    owner, or when no wrapper is available, ffmpeg runs directly.
    """
    try:
        with open(path, "rb") as fh:
            raw = fh.read()
    except OSError:
        return None, 0, 0
    is_jpeg = raw[:2] == b"\xff\xd8"
    if shutil.which("convert") is not None:
        # Unchanged v1.3.4-v1.3.7 path: ImageMagick scale ladder.
        best = None
        for scale in FRAME_SCALES:
            out_path = path + ".frame.jpg"
            try:
                proc = subprocess.run(
                    ["convert", path, "-resize", f"{int(scale * 100)}%",
                     "-quality", str(FRAME_JPEG_QUALITY), out_path],
                    capture_output=True, text=True, timeout=30)
                if proc.returncode == 0 and os.path.isfile(out_path):
                    with open(out_path, "rb") as fh:
                        data = fh.read()
                    try:
                        os.remove(out_path)
                    except OSError:
                        pass
                    best = data
                    if len(data) <= FRAME_MAX_BYTES:
                        break
            except (OSError, subprocess.SubprocessError):
                continue
        if best is not None:
            width, height = _jpeg_dimensions(best)
            return best, width, height
        # Every convert step failed: fall through to the ffmpeg
        # ladder below. Both converters get attempted before the
        # raw-as-is fallback -- convert present-but-broken must not
        # give up while ffmpeg could still shrink the frame.
    if shutil.which("ffmpeg") is not None:
        # v1.3.8: ffmpeg scale ladder, mirroring the convert path.
        width, _height = _jpeg_dimensions(raw)
        owner = None
        if is_admin():
            owner = _session_owner()
            if owner is not None and owner["uid"] == 0:
                owner = None
        best = None
        for step, scale in enumerate(FRAME_SCALES):
            if width > 0:
                target_w = max(2, int(width * scale) // 2 * 2)
            else:
                target_w = FRAME_FALLBACK_WIDTHS[step]
            out_path = path + ".frame.jpg"
            cmd = ["ffmpeg", "-y", "-i", path, "-vf",
                   f"scale={target_w}:-2", "-q:v",
                   str(FRAME_FFMPEG_QUALITY), out_path]
            run_cmd, run_env = cmd, None
            if owner is not None:
                wrapped = _wrap_as_user(
                    cmd, owner, _session_capture_env(owner))
                if wrapped is not None:
                    run_cmd, run_env = wrapped
            try:
                proc = subprocess.run(
                    run_cmd, capture_output=True, text=True,
                    timeout=30, env=run_env)
                if proc.returncode == 0 and os.path.isfile(out_path):
                    with open(out_path, "rb") as fh:
                        data = fh.read()
                    try:
                        os.remove(out_path)
                    except OSError:
                        pass
                    best = data
                    if len(data) <= FRAME_MAX_BYTES:
                        break
            except (OSError, subprocess.SubprocessError):
                continue
        if best is not None:
            width, height = _jpeg_dimensions(best)
            return best, width, height
        # Every ffmpeg step failed: fall through to the raw-as-is
        # fallback below (JPEG only), exactly as when no converter
        # exists at all.
    if is_jpeg:
        width, height = _jpeg_dimensions(raw)
        _frame_log_raw_fallback(
            "no working converter (convert absent; ffmpeg absent or "
            "every scale failed) -- returning the raw JPEG as-is "
            f"({len(raw)} bytes); it will likely be rejected by the "
            "relay as too_large (frame room cap: 100,000 base64 "
            "chars, 400 too_large)")
        return raw, width, height
    return None, 0, 0


def _frame_log_failure(detail):
    """One throttled log + audit line per 60s window: the feed must
    never spam the log while a capture or the relay stays down."""
    now = time.monotonic()
    if now - _FRAME_STATE["last_error_at"] < 60:
        return
    _FRAME_STATE["last_error_at"] = now
    log(f"live feed: frame failed: {detail}")
    audit_log(f"cmd=frame done=false result=frame_failed detail={detail}")


def send_frame_tick():
    """One live-feed tick: capture, change-only compare, maybe POST.
    Called once per poll iteration from main(). Never raises."""
    if not RELAY:
        return
    try:
        now = time.monotonic()
        last_post = _FRAME_STATE["last_post_at"]
        if last_post is not None:
            since_post = now - last_post
            if since_post < FRAME_MIN_INTERVAL_S:
                return
            due_liveness = since_post >= FRAME_LIVENESS_S
        else:
            due_liveness = True
        tool, path_or_reason = _capture_screenshot_file()
        if tool is None:
            _frame_log_failure(f"capture failed: {path_or_reason}")
            return
        try:
            data, width, height = _frame_jpeg_bytes(path_or_reason)
        finally:
            try:
                os.remove(path_or_reason)
            except OSError:
                pass
        if data is None:
            _frame_log_failure("JPEG conversion failed (no `convert` / "
                               "ffmpeg and capture was not already JPEG, "
                               "or every conversion failed)")
            return
        digest = hashlib.sha256(data).hexdigest()
        if digest == _FRAME_STATE["last_hash"] and not due_liveness:
            return
        payload = {"image_b64": base64.b64encode(data).decode("ascii"),
                   "width": width, "height": height, "bytes": len(data)}
        if relay_post("/doctor/frame", payload) is None:
            _frame_log_failure("POST /doctor/frame failed (relay "
                               "unreachable or HTTP error)")
            return
        _FRAME_STATE["last_hash"] = digest
        _FRAME_STATE["last_post_at"] = now
        _FRAME_STATE["post_count"] += 1
        if _FRAME_STATE["post_count"] == 1:
            log(f"live feed: first frame posted "
                f"({len(data)} bytes, {width}x{height})")
            audit_log(f"cmd=frame done=true result=first frame "
                      f"bytes={len(data)}")
    except Exception as e:
        _frame_log_failure(f"tick failed: {e}")


def _xdotool_or_unavailable(what):
    if shutil.which("xdotool") is None:
        return {"error": "unavailable",
                "detail": f"{what} needs xdotool, which is not installed "
                          "on this machine. Install xdotool and try again "
                          "-- this agent never installs anything itself."}
    return None


def cmd_mouse(args):
    missing = _xdotool_or_unavailable("mouse control")
    if missing is not None:
        return missing
    action = args.get("action")
    if action not in ("move", "click", "move_click", "left_click",
                      "right_click", "double_click"):
        return {"error": "bad_action",
                "detail": "mouse needs action move|click|move_click|"
                          "left_click|right_click|double_click"}
    try:
        x = int(args.get("x"))
        y = int(args.get("y"))
    except (TypeError, ValueError):
        return {"error": "bad_coords",
                "detail": "mouse needs integer x and y"}
    button = args.get("button", 1)
    if button not in (1, 2, 3):
        return {"error": "bad_button",
                "detail": "mouse button must be 1, 2, or 3"}
    # v1.3.9: the relay (v1.3.4) sends left_click / right_click /
    # double_click, but the agent used to accept only move / click /
    # move_click -- so a relay-valid click was refused here, and a
    # relay-invalid move_click never got past the relay. Only "move"
    # passed both, so no click ever worked end to end. Map the
    # relay names onto xdotool: left_click = move + click button 1,
    # right_click = move + click button 3, double_click = move +
    # two rapid button-1 clicks. A caller-supplied "button" is
    # honored only for the plain click / move_click forms; the
    # relay names fix the button. xdotool is X11-only: on a
    # Wayland session it needs an XWayland DISPLAY, and a
    # xdotool that cannot open a display exits nonzero, so the
    # command fails plainly (mouse_failed) -- never a fake ok.
    if action == "left_click":
        button = 1
    elif action == "right_click":
        button = 3
    elif action == "double_click":
        button = 1
    try:
        if action in ("move", "move_click", "left_click",
                      "right_click", "double_click"):
            proc = subprocess.run(["xdotool", "mousemove", str(x), str(y)],
                                  capture_output=True, text=True, timeout=10)
            if proc.returncode != 0:
                return {"error": "mouse_failed",
                        "detail": (proc.stderr or proc.stdout).strip()}
        if action in ("click", "move_click", "left_click",
                      "right_click"):
            proc = subprocess.run(["xdotool", "click", str(button)],
                                  capture_output=True, text=True, timeout=10)
            if proc.returncode != 0:
                return {"error": "mouse_failed",
                        "detail": (proc.stderr or proc.stdout).strip()}
        elif action == "double_click":
            proc = subprocess.run(
                ["xdotool", "click", "--repeat", "2", "--delay", "100",
                 "1"],
                capture_output=True, text=True, timeout=10)
            if proc.returncode != 0:
                return {"error": "mouse_failed",
                        "detail": (proc.stderr or proc.stdout).strip()}
    except (OSError, subprocess.SubprocessError) as e:
        return {"error": "mouse_failed", "detail": str(e)}
    return {"ok": True, "action": action, "x": x, "y": y, "button": button}


def _xdotool_run(args, timeout=10):
    """Run xdotool, return stripped stdout, or None on any failure
    (missing binary, timeout, nonzero exit)."""
    try:
        proc = subprocess.run(["xdotool"] + args, capture_output=True,
                              text=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError):
        return None
    if proc.returncode != 0:
        return None
    return proc.stdout.strip()


def _ci_regex(text):
    """Case-insensitive regex for xdotool search (it has no
    ignore-case flag): each ASCII letter becomes [aA], regex
    metacharacters are escaped. Mirrors the Windows focus match,
    which is case-insensitive."""
    out = []
    for ch in text:
        if ch.isalpha() and ch.isascii():
            out.append(f"[{ch.lower()}{ch.upper()}]")
        elif ch in "\\.^$*+?()[]{}|":
            out.append("\\" + ch)
        else:
            out.append(ch)
    return "".join(out)


def _xdotool_search(pattern):
    """Visible window ids matching a pattern, via WM_CLASS, instance
    name, then window title (in that order), deduplicated. xdotool
    search returns ids in stacking order, so the LAST id is the
    topmost -- the closest xdotool gets to "most recently used".
    xdotool reports no window creation time, so "most recently
    opened" cannot be proven from here; topmost is the honest proxy."""
    seen = []
    for mode in ("--class", "--classname", "--name"):
        try:
            proc = subprocess.run(
                ["xdotool", "search", "--onlyvisible", mode, pattern],
                capture_output=True, text=True, timeout=10)
        except (OSError, subprocess.SubprocessError):
            continue
        for line in proc.stdout.splitlines():
            line = line.strip()
            if line.isdigit():
                wid = int(line)
                if wid not in seen:
                    seen.append(wid)
    return seen


def _window_pid(wid):
    out = _xdotool_run(["getwindowpid", str(wid)])
    if out and out.isdigit():
        return int(out)
    return None


def _proc_name(pid):
    try:
        with open(f"/proc/{pid}/comm") as fh:
            return fh.read().strip()
    except OSError:
        return ""


def _ancestor_pids():
    """This process's pid plus every ancestor pid, via /proc. The
    agent's own terminal is one of these (the shell / terminal that
    launched it)."""
    pids = set()
    pid = os.getpid()
    while pid and pid not in pids:
        pids.add(pid)
        try:
            with open(f"/proc/{pid}/stat") as fh:
                content = fh.read()
            m = re.match(r"\d+ \(.*\) \S+ (\d+)", content)
            if not m:
                break
            pid = int(m.group(1))
        except (OSError, ValueError):
            break
    return pids


def _describe_window(wid):
    """{"pid": int, "name": str} for a window id: the owning process
    name from /proc, falling back to the window title."""
    pid = _window_pid(wid)
    name = _proc_name(pid) if pid else ""
    if not name:
        name = _xdotool_run(["getwindowname", str(wid)]) or ""
    return {"pid": pid or 0, "name": name}


def _activate_and_verify(wid):
    """Bring a window to the front and verify it is the active window
    afterwards. False when activation fails or another window is
    active instead -- the caller then types NOTHING."""
    try:
        proc = subprocess.run(["xdotool", "windowactivate", str(wid)],
                              capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return False
    if proc.returncode != 0:
        return False
    time.sleep(0.25)
    active = _xdotool_run(["getactivewindow"])
    return active is not None and active.isdigit() and int(active) == wid


def _focus_window(process=None):
    """Focus the window keys will land in, BEFORE any typing.
    Returns {"pid": int, "name": str} or
    {"error": "no_window" | "focus_failed", "detail": str}.
    Mirrors the Windows agent's Set-KDRemoteScreenFocus:
      - process given: the topmost visible window whose WM_CLASS /
        instance / title matches that app name (a ".exe" suffix is
        stripped for parity). No match -> no_window.
      - process absent: the current foreground window, unless it is
        the agent's own terminal (its owning pid is an ancestor of
        this process); then the topmost visible window that is NOT
        the agent's own terminal. Nothing suitable -> no_window.
    Honest limits (xdotool can report none of these): window
    creation time is unknown, so "most recently opened" is proxied
    by topmost in stacking order; whether the focused window holds
    a password / login field is unknowable -- the operator rule
    (never type into a password field) still applies."""
    if process:
        want = process.strip()
        if want.lower().endswith(".exe"):
            want = want[:-4]
        candidates = _xdotool_search(_ci_regex(want))
        if not candidates:
            return {"error": "no_window",
                    "detail": f"no visible window for process: {process}"}
        target = candidates[-1]
        if not _activate_and_verify(target):
            return {"error": "focus_failed",
                    "detail": f"could not bring to front: {process}"}
        return _describe_window(target)
    active = _xdotool_run(["getactivewindow"])
    if active and active.isdigit():
        wid = int(active)
        wpid = _window_pid(wid)
        if wpid is None or wpid not in _ancestor_pids():
            return _describe_window(wid)
    ancestors = _ancestor_pids()
    candidates = []
    for wid in _xdotool_search(".*"):
        wpid = _window_pid(wid)
        if wpid is not None and wpid in ancestors:
            continue
        candidates.append(wid)
    if not candidates:
        return {"error": "no_window",
                "detail": "no suitable window to focus"}
    target = candidates[-1]
    if not _activate_and_verify(target):
        return {"error": "focus_failed",
                "detail": "could not bring a window to front"}
    return _describe_window(target)


def cmd_type(args):
    missing = _xdotool_or_unavailable("typing")
    if missing is not None:
        return missing
    text = args.get("text")
    if not isinstance(text, str) or not text:
        return {"error": "bad_text",
                "detail": "type needs a non-empty string 'text'"}
    if len(text) > TYPE_MAX_CHARS:
        return {"error": "bad_text",
                "detail": f"text is {len(text)} chars, over the "
                          f"{TYPE_MAX_CHARS}-char limit"}
    # v1.3.4: optional `process` field (e.g. "notepad++" on Windows,
    # a Linux app name here). Validated like the relay does: string,
    # 1-200 chars, no control chars -> bad_process.
    process = args.get("process")
    process_label = "(auto)"
    if process is not None:
        if not isinstance(process, str):
            return {"error": "bad_process",
                    "detail": "process is not a string"}
        if len(process) == 0 or len(process) > 200:
            return {"error": "bad_process",
                    "detail": "process must be 1-200 chars"}
        if any(ord(ch) < 32 for ch in process):
            return {"error": "bad_process",
                    "detail": "process contains a control character"}
        process_label = process
    # Focus FIRST. If no window can be focused, type NOTHING.
    focus = _focus_window(process)
    if "error" in focus:
        return focus
    try:
        proc = subprocess.run(["xdotool", "type", "--", text],
                              capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError) as e:
        return {"error": "type_failed", "detail": str(e)}
    if proc.returncode != 0:
        return {"error": "type_failed",
                "detail": (proc.stderr or proc.stdout).strip()}
    return {"ok": True, "typed_chars": len(text), "process": process_label,
            "focused_process": focus["name"], "focused_pid": focus["pid"]}


# ---------------------------------------------------------------- launch
# v1.3.9: launch a GUI app AS THE SESSION USER, detached. The root
# agent cannot launch a GUI app as the session user through exec --
# runuser / env / su / sudo are all refused there, and launching
# flatpak as root breaks the sandbox (bwrap fd failure, proven live
# on the Deck 2026-11-22) -- so launch is its own narrow kind:
# it reads a real installed app's .desktop file, parses its Exec
# line, strips field codes, and runs the resulting argv detached
# via the same _wrap_as_user() drop the capture path uses. It is
# NOT an exec bypass: the file must live in a real XDG application
# dir, and the parsed Exec argv must pass the same
# _argv_block_reason the exec kind applies. No root fallback -- a
# root launch would write root-owned files into the user's app
# data, which is how the Joplin data dir would have broken.

_LAUNCH_FIELD_CODES = {
    "%u", "%U", "%f", "%F", "%i", "%c", "%k", "%d", "%D", "%n", "%N",
    "%v", "%m", "@@u", "@@f", "@@F", "@@",
}


def _desktop_entry_values(path):
    """(name, exec_str, error) from a .desktop file's [Desktop
    Entry] section. Manual line scan: .desktop files are simple
    INI-ish text, and configparser would choke on the % field
    codes in Exec values unless interpolation is off -- a line
    scan is the smaller, honest tool. Only the exact keys Name /
    Exec count (locale-suffixed Name[en] / Exec[en] do not)."""
    name = None
    exec_str = None
    in_entry = False
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError as e:
        return None, None, f"cannot read {path}: {e}"
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            in_entry = line[1:-1].strip() == "Desktop Entry"
            continue
        if not in_entry or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key == "Name" and name is None:
            name = value.strip()
        elif key == "Exec" and exec_str is None:
            exec_str = value.strip()
    if exec_str is None:
        return name, None, "no Exec= line in [Desktop Entry]"
    return name, exec_str, None


def _strip_exec_field_codes(argv):
    """Drop Desktop Entry field-code tokens from a parsed Exec argv
    (%u %U %f %F %i %c %k ..., plus flatpak's @@u / @@ markers).
    A `--icon` flag whose value was a stripped %i is dropped with
    it, so the app never sees a dangling --icon with no value."""
    out = []
    for i, tok in enumerate(argv):
        if tok in _LAUNCH_FIELD_CODES:
            continue
        if tok == "--icon" and i + 1 < len(argv) \
                and argv[i + 1] in _LAUNCH_FIELD_CODES:
            continue
        out.append(tok)
    return out


def _launch_app_dirs(owner):
    """Absolute dir prefixes a launchable .desktop file may live
    under (real XDG application dirs). Flatpak exports are symlinks
    into /var/lib/flatpak/app/.../export/share/applications (or the
    session user's ~/.local/share/flatpak/app/...), so the flatpak
    store itself is a prefix; the session user's own application
    dirs are added from the owner's home."""
    dirs = ["/usr/share/applications",
            "/usr/local/share/applications",
            "/var/lib/flatpak"]
    home = None
    if owner is not None and owner.get("home"):
        home = owner["home"]
    else:
        try:
            home = pwd.getpwuid(_current_uid()).pw_dir
        except (KeyError, OverflowError):
            home = os.path.expanduser("~")
    if home:
        dirs.append(os.path.join(home, ".local", "share",
                                 "applications"))
        dirs.append(os.path.join(home, ".local", "share", "flatpak"))
    return dirs


def _launch_desktop_allowed(path, owner):
    """True when the .desktop file's REAL path is inside a real XDG
    application dir. Symlinks are resolved first, so a /tmp file
    linked into an app dir, or an app-dir symlink pointing out,
    cannot smuggle an arbitrary launcher in."""
    real = os.path.realpath(path)
    for prefix in _launch_app_dirs(owner):
        if real.startswith(prefix.rstrip("/") + "/"):
            return True
    return False


def _launch_extra_args(args):
    """(extra_argv, error) for launch's optional `args` list: argv
    only, each element a non-empty string (1-500 chars), at most 32
    of them. A single STRING is refused -- no shell, no string
    splitting -- and so is any other non-list shape."""
    raw = args.get("args", None)
    if raw is None:
        return [], None
    if isinstance(raw, str):
        return None, {"error": "bad_args",
                      "detail": "launch 'args' must be a list of "
                                "strings (argv), not a single string "
                                "-- no shell, no string splitting"}
    if not isinstance(raw, list):
        return None, {"error": "bad_args",
                      "detail": "launch 'args' must be a list of "
                                "strings (argv)"}
    if len(raw) > 32:
        return None, {"error": "bad_args",
                      "detail": "launch 'args' allows at most 32 "
                                "arguments"}
    for item in raw:
        if not isinstance(item, str) or not item or len(item) > 500:
            return None, {"error": "bad_args",
                          "detail": "each launch arg must be a "
                                    "non-empty string (1-500 chars)"}
    return list(raw), None


# Basenames a launchable executable is never allowed to be, on top
# of _ARGV_NEVER_COMMANDS (which already covers shells,
# interpreters, sudo / runuser / su, shutdown, passwd and friends):
# destructive / wiping tools, by name.
_LAUNCH_EXECUTABLE_NEVER = {
    "format", "diskpart", "cipher", "shred", "wipefs", "blkdiscard",
    "dd", "ddrescue", "flashrom",
}


def _launch_executable_allowed(path, owner):
    """(ok, reason) for a launchable executable file: it must live
    under the session user's home or /opt -- a sane location for a
    user-installed app -- never in a world-writable temp dir and
    never among the system binaries (the argv block check is the
    gate for what the binary may be, and a system binary is not
    launchable this way). Symlinks are resolved first, so a link
    under the home pointing at a system binary cannot smuggle
    one in."""
    real = os.path.realpath(path)
    if _is_temp_path(real) or real in ("/tmp", "/dev/shm", "/var/tmp"):
        return False, ("launch only runs executables under the "
                       "session user's home or /opt, never from a "
                       "world-writable temp dir")
    home = None
    if owner is not None and owner.get("home"):
        home = owner["home"]
    else:
        try:
            home = pwd.getpwuid(_current_uid()).pw_dir
        except (KeyError, OverflowError):
            home = os.path.expanduser("~")
    if home and (real == home or real.startswith(home + "/")):
        return True, None
    if real == "/opt" or real.startswith("/opt/"):
        return True, None
    return False, ("launch only runs executables under the session "
                   "user's home or /opt -- system binaries are not "
                   "launchable this way")


def _launch_start(argv, extra_args, owner, app_label, result_extra,
                  log_detail):
    """Shared launch tail: wrap as the session user (or run
    directly), Popen detached, 0.5s fast-fail check, started:true
    result. An app whose launcher exits 0 at once (it daemonised)
    counts as started -- only a nonzero fast exit is a failure."""
    env = None
    as_user = None
    if owner is not None:
        wrapped = _wrap_as_user(argv, owner,
                                _session_capture_env(owner))
        if wrapped is None:
            return {"error": "no_wrapper",
                    "detail": "cannot drop to the session user: "
                              "neither runuser nor sudo is installed "
                              "on this machine"}
        argv, env = wrapped
        as_user = owner["name"]
    else:
        try:
            as_user = pwd.getpwuid(_current_uid()).pw_name
        except (KeyError, OverflowError):
            as_user = str(_current_uid())
    try:
        proc = subprocess.Popen(
            argv, stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True, env=env)
    except OSError as e:
        return {"error": "launch_failed",
                "detail": f"could not start {app_label}: {e}"}
    # The app is detached; give it half a second to fail fast
    # (missing binary, bad Exec) and report that instead of
    # claiming success for a process that already died.
    time.sleep(0.5)
    rc = proc.poll()
    if rc is not None and rc != 0:
        return {"error": "launch_failed",
                "detail": f"{app_label} exited at once "
                          f"(returncode {rc}) -- check the Exec line"}
    log(f"launch: {app_label} started as {as_user} ({log_detail})")
    result = {"ok": True, "started": True, "app": app_label,
              "as_user": as_user}
    result.update(result_extra)
    if extra_args:
        result["args"] = list(extra_args)
    return result


def _launch_desktop(desktop, extra_args, owner):
    """The v1.3.9 .desktop path, unchanged except for the optional
    extra args (appended after the stripped Exec argv) and the
    launch-only rule that an Exec line may not itself be a
    user-switch wrapper: launch already drops to the session user,
    so an Exec starting with runuser / sudo is refused here even
    though v1.3.10's exec allows the drop."""
    if not _launch_desktop_allowed(desktop, owner):
        return {"error": "not_an_app",
                "detail": "launch only runs real installed apps: the "
                          ".desktop file must live in an application "
                          "directory (/usr/share/applications, "
                          "/usr/local/share/applications, "
                          "/var/lib/flatpak, or the session user's "
                          "~/.local/share/applications / "
                          "~/.local/share/flatpak)"}
    name, exec_str, err = _desktop_entry_values(desktop)
    if err is not None:
        return {"error": "bad_desktop", "detail": err}
    try:
        argv = shlex.split(exec_str)
    except ValueError as e:
        return {"error": "bad_exec",
                "detail": f"cannot parse Exec line ({e})"}
    argv = _strip_exec_field_codes(argv)
    if not argv:
        return {"error": "bad_exec",
                "detail": "Exec line is empty after field codes "
                          "were stripped"}
    argv = argv + list(extra_args)
    # Same argv blocklist as exec: launch may only run what exec
    # could run -- as the session user instead of root. This is
    # what keeps launch a launcher, not an exec bypass.
    # allow_drop=False: an Exec wrapper is refused here.
    # allow_home_binary=True (v1.3.10.1): the launched binary uses
    # launch's own location allow-list (home / opt), like the
    # executable path -- without it Rule 4 refuses any .desktop
    # Exec pointing at a home-installed app (e.g. an AppImage).
    reason = _argv_block_reason(argv, owner_override=False,
                                allow_home_binary=True, allow_drop=False)
    if reason is not None:
        return {"error": "blocked", "detail": reason}
    app_label = name or os.path.basename(desktop)[:-len(".desktop")]
    return _launch_start(argv, extra_args, owner, app_label,
                         {"desktop": desktop},
                         f"desktop={desktop}")


def _launch_executable(executable, extra_args, owner):
    """The v1.3.10 executable path: an AppImage, script or binary
    under the session user's home or /opt, run as the session user.
    The file must exist (checked by the caller), be a regular file
    and be executable; the location allow-list refuses /tmp and
    system binaries. The argv is [executable] + args, checked by
    the same argv blocklist as Exec -- with allow_home_binary, so
    the launch location rule (not exec's rule 4) governs the
    binary's own path -- and a binary named for a destructive or
    never-run tool is refused outright."""
    if not os.path.isfile(executable):
        return {"error": "bad_executable",
                "detail": f"not a regular file: {executable}"}
    if not os.access(executable, os.X_OK):
        return {"error": "bad_executable",
                "detail": f"not executable (chmod +x first): "
                          f"{executable}"}
    head = os.path.basename(os.path.realpath(executable))
    if head in _ARGV_NEVER_COMMANDS or head.startswith("mkfs") \
            or head in _LAUNCH_EXECUTABLE_NEVER:
        return {"error": "blocked",
                "detail": f"launch refuses an executable named "
                          f"{head!r}"}
    ok, reason = _launch_executable_allowed(executable, owner)
    if not ok:
        return {"error": "not_an_app", "detail": reason}
    argv = [os.path.realpath(executable)] + list(extra_args)
    reason = _argv_block_reason(argv, owner_override=False,
                                allow_home_binary=True)
    if reason is not None:
        return {"error": "blocked", "detail": reason}
    return _launch_start(argv, extra_args, owner,
                         os.path.basename(executable),
                         {"executable": executable},
                         f"executable={executable}")


def cmd_launch(args):
    """Launch a GUI app as the session user, detached. Synchronous:
    validates, parses, and starts the app (Popen, detached), then
    reports started:true -- the app outlives the call. Two shapes:
    {"desktop": "/path/to/app.desktop"} (v1.3.9, unchanged) and
    {"executable": "/path/to/app.AppImage"} (v1.3.10: an executable
    file under the session user's home or /opt, never /tmp, never
    a system binary). Both take an optional "args" list (argv only,
    each arg block-checked like an Exec token). Refuses plainly
    when there is no session to launch into, no way to drop to the
    session user, or the launcher fails the checks."""
    desktop = args.get("desktop")
    executable = args.get("executable")
    if desktop is not None and executable is not None:
        return {"error": "bad_launch",
                "detail": "launch takes exactly one of 'desktop' (a "
                          ".desktop file) or 'executable' (an "
                          "executable file), not both"}
    extra_args, err = _launch_extra_args(args)
    if err is not None:
        return err
    if desktop is not None:
        if not isinstance(desktop, str) or not desktop \
                or len(desktop) > 500:
            return {"error": "bad_desktop",
                    "detail": "launch needs a string 'desktop' path "
                              "(1-500 chars) to a .desktop file"}
        if not desktop.endswith(".desktop"):
            return {"error": "bad_desktop",
                    "detail": "launch needs a .desktop file path "
                              f"(got {desktop!r})"}
        if not os.path.isfile(desktop):
            return {"error": "not_found",
                    "detail": f"no such .desktop file: {desktop}"}
    if executable is not None:
        if not isinstance(executable, str) or not executable \
                or len(executable) > 500:
            return {"error": "bad_executable",
                    "detail": "launch needs a string 'executable' "
                              "path (1-500 chars) to an executable "
                              "file"}
        if not os.path.exists(executable):
            return {"error": "not_found",
                    "detail": f"no such executable file: {executable}"}
    # Who is the session user? Root drops to them; an unprivileged
    # agent IS the session user already and launches directly.
    owner = None
    if _current_uid() == 0:
        owner = _session_owner()
        if owner is None or owner["uid"] == 0:
            return {"error": "no_session",
                    "detail": "no graphical session user is "
                              "detectable, so there is no session to "
                              "launch the app into"}
    if desktop is not None:
        return _launch_desktop(desktop, extra_args, owner)
    if executable is not None:
        return _launch_executable(executable, extra_args, owner)
    return {"error": "bad_launch",
            "detail": "launch needs either a 'desktop' path to a "
                      ".desktop file or an 'executable' path to an "
                      "executable file"}

# ---------------------------------------------------------------- clean

def _dir_size_bytes(root):
    total = 0
    count = 0
    for dirpath, _dirnames, filenames in os.walk(root, followlinks=False):
        for name in filenames:
            try:
                st = os.lstat(os.path.join(dirpath, name))
                total += st.st_size
                count += 1
            except OSError:
                continue
    return total, count


def _clean_one_dir(root, older_than_s):
    """Delete regular files older than older_than_s under root.
    Returns (removed_count, freed_bytes). Never raises."""
    now = time.time()
    removed = 0
    freed = 0
    for dirpath, dirnames, filenames in os.walk(root, topdown=True,
                                                followlinks=False):
        dirnames[:] = [d for d in dirnames
                       if not d.startswith("kurodoctor-repair-backup-")
                       and not d.startswith("kurodoctor-quarantine-")]
        for name in filenames:
            path = os.path.join(dirpath, name)
            try:
                st = os.lstat(path)
                if not statmod.S_ISREG(st.st_mode):
                    continue
                if now - st.st_mtime < older_than_s:
                    continue
                os.remove(path)
                removed += 1
                freed += st.st_size
            except OSError:
                continue
    return removed, freed


def cmd_clean(_args):
    """Trash + /tmp + ~/.cache only, before/after MB. Files changed in
    the last hour are left alone (treated as in use). Nothing else is
    ever touched -- never ~/Documents, ~/Pictures, ~/Downloads."""
    home = os.path.expanduser("~")
    roots = [
        ("trash", os.path.join(home, ".local", "share", "Trash")),
        ("tmp", "/tmp"),
        ("cache", os.path.join(home, ".cache")),
    ]
    before = {}
    for label, root in roots:
        if os.path.isdir(root):
            size, count = _dir_size_bytes(root)
            before[label] = {"bytes": size, "files": count,
                             "mb": round(size / 1e6, 1)}
        else:
            before[label] = {"bytes": 0, "files": 0, "mb": 0.0,
                             "note": "not present"}
    removed_total = 0
    freed_total = 0
    per_root = {}
    for label, root in roots:
        if not os.path.isdir(root):
            per_root[label] = {"removed": 0, "freed_mb": 0.0,
                               "note": "not present"}
            continue
        removed, freed = _clean_one_dir(root, older_than_s=3600)
        removed_total += removed
        freed_total += freed
        per_root[label] = {"removed": removed,
                           "freed_mb": round(freed / 1e6, 1)}
    after = {}
    for label, root in roots:
        if os.path.isdir(root):
            size, count = _dir_size_bytes(root)
            after[label] = {"bytes": size, "files": count,
                            "mb": round(size / 1e6, 1)}
        else:
            after[label] = {"bytes": 0, "files": 0, "mb": 0.0}
    return {"before": before, "after": after, "per_root": per_root,
            "removed_files": removed_total,
            "freed_mb": round(freed_total / 1e6, 1),
            "scope": "Trash + /tmp + ~/.cache only; files changed in "
                     "the last hour left alone"}


# ---------------------------------------------------------------- USB phone
# USB phone doctor (v1.3.6): the phone plugs into this machine over
# USB and the Deck drives it with adb. Plug in, tap Allow once on the
# phone ("Always allow from this computer"), then plug-and-go forever.
# No pairing sheet, no 6-digit code, no wireless debugging anywhere
# in this flow. One driver, one command set, identical on all hosts.
#
#   phone_checkup  read-only phone health: model, Android version,
#                  SDK, storage, battery, RAM, app count
#   phone_repair   {"kind": clear_cache|disable|force_stop|uninstall,
#                  "package": ...} -- before/after state in the ack
#
# adb comes from the system package manager (SteamOS/Arch:
# `sudo pacman -S android-tools`). This agent NEVER installs adb
# itself and never uses sudo for its own operation: if adb is
# missing it acks `adb_missing` with the install hint and stops.
# Every adb invocation has a timeout and runs via a list argv
# (never shell=True). The package comes from the relay-validated
# command and is re-validated here with the same regex and limits
# as the relay; the protected set is refused here too (defense in
# depth). These four pm/am commands cannot delete documents or
# photos -- nothing here touches user files on the phone.

ADB_TIMEOUT_S = 15        # `adb devices` and short shell calls
ADB_SHELL_TIMEOUT_S = 10  # per-call timeout inside phone_checkup
ADB_REPAIR_TIMEOUT_S = 60  # one repair command on the phone
PHONE_PACKAGE_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)+$")
PHONE_REPAIR_KINDS = {
    "clear_cache": ["pm", "clear"],
    "disable": ["pm", "disable-user", "--user", "0"],
    "force_stop": ["am", "force-stop"],
    "uninstall": ["pm", "uninstall", "--user", "0"],
}
PHONE_PROTECTED = frozenset({
    "com.kuro.kurodoctor", "android", "com.android.systemui",
    "com.android.phone", "com.android.settings",
    "com.android.packageinstaller", "com.google.android.gms",
    "com.google.android.gsf",
})
ADB_INSTALL_HINT = ("adb is not installed on this machine. Install it "
                    "with: sudo pacman -S android-tools "
                    "(Arch / SteamOS), then plug the phone in again.")


def _run_adb(argv, timeout_s):
    """Run adb with a list argv. Returns (returncode, stdout, stderr).
    returncode is None when adb could not run at all (missing binary,
    timeout, or spawn failure); stderr then carries a short reason.
    Never raises."""
    if shutil.which("adb") is None:
        return None, "", "adb_missing"
    try:
        proc = subprocess.run(["adb"] + argv, capture_output=True,
                              text=True, timeout=timeout_s)
        return proc.returncode, proc.stdout or "", proc.stderr or ""
    except subprocess.TimeoutExpired:
        return None, "", f"adb timed out after {timeout_s}s"
    except OSError as e:
        return None, "", f"adb failed to start: {e}"


def detect_phone():
    """Find the USB phone. Returns (serial, info, error). serial is
    the first `device`-state serial, or None. info is a small dict
    (serial + the raw device list) on success. error is None on
    success, else an ack-style error dict."""
    code, out, err = _run_adb(["devices"], ADB_TIMEOUT_S)
    if err == "adb_missing":
        return None, None, {
            "error": "adb_missing",
            "detail": ADB_INSTALL_HINT,
            "install": "sudo pacman -S android-tools"}
    if code is None:
        return None, None, {"error": "adb_error", "detail": err}
    devices = []
    for line in out.splitlines()[1:]:  # skip "List of devices attached"
        parts = line.split()
        if len(parts) >= 2:
            devices.append({"serial": parts[0], "state": parts[1]})
    ready = [d for d in devices if d["state"] == "device"]
    if ready:
        serial = ready[0]["serial"]
        note = f"using {serial}"
        if len(ready) > 1:
            note += f" ({len(ready)} ready devices; first one used)"
        return serial, {"serial": serial, "devices": devices,
                        "note": note}, None
    if any(d["state"] == "unauthorized" for d in devices):
        return None, None, {
            "error": "unauthorized",
            "detail": "The phone is plugged in but has not allowed this "
                      "computer yet. Tap Allow on the phone (tick "
                      "\"Always allow from this computer\" so it only "
                      "asks once), then send the command again. "
                      "Nothing ran on the phone.",
            "devices": devices}
    if not devices:
        return None, None, {
            "error": "no_device",
            "detail": "No Android device is plugged in. Plug the phone "
                      "into this machine over USB and make sure USB "
                      "debugging is on, then send the command again."}
    return None, None, {
        "error": "no_device",
        "detail": "No phone is ready: adb sees "
                  + ", ".join(f"{d['serial']} ({d['state']})"
                              for d in devices)
                  + ". Unplug it and plug it back in, then tap Allow "
                    "on the phone if it asks.",
        "devices": devices}


def _adb_shell(serial, args, timeout_s=ADB_SHELL_TIMEOUT_S):
    """`adb -s <serial> shell <args>`. Returns (rc, stdout, stderr)."""
    return _run_adb(["-s", serial, "shell"] + args, timeout_s)


def _parse_phone_battery(text):
    """dumpsys battery -> {status, level_pct, ...}; same field names
    as the standalone phone app's report."""
    vals = {}
    for key in ("level", "scale", "status", "health", "temperature",
                "voltage"):
        m = re.search(r"(?m)^\s*%s:\s*(\S+)\s*$" % key, text)
        if m:
            vals[key] = m.group(1)
    if "level" not in vals:
        return {"status": "unavailable",
                "reason": "dumpsys battery output did not contain a level"}
    try:
        level = int(vals["level"])
        scale = int(vals.get("scale", "100")) or 100
        pct = round(level * 100.0 / scale, 1)
    except ValueError:
        return {"status": "unavailable",
                "reason": "dumpsys battery level was not a number"}
    out = {"status": "ok", "level_pct": pct}
    # Same code maps as the standalone phone app (kurodoctor-adb.py):
    # dumpsys reports numbers; the ack carries the plain words.
    if "status" in vals:
        out["charging_state"] = {
            "1": "unknown", "2": "charging", "3": "discharging",
            "4": "not charging", "5": "full"}.get(vals["status"],
                                                 vals["status"])
    if "health" in vals:
        out["health"] = {
            "1": "unknown", "2": "good", "3": "overheat", "4": "dead",
            "5": "over voltage", "6": "unspecified failure",
            "7": "cold"}.get(vals["health"], vals["health"])
    if "temperature" in vals:
        try:
            out["temperature_c"] = int(vals["temperature"]) / 10.0
        except ValueError:
            pass
    if "voltage" in vals:
        try:
            out["voltage_mv"] = int(vals["voltage"])
        except ValueError:
            pass
    return out


def _parse_phone_df(text):
    """`df` on the phone -> {status, mounts:[...]}; same shape as the
    standalone phone app's disk_space section."""
    mounts = []
    for line in text.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 6:
            continue
        try:
            total_kb = int(parts[1])
            used_kb = int(parts[2])
            free_kb = int(parts[3])
        except ValueError:
            continue
        if total_kb <= 0:
            continue
        mounts.append({
            "mount": parts[5],
            "total_gb": round(total_kb * 1024 / 1e9, 2),
            "used_gb": round(used_kb * 1024 / 1e9, 2),
            "free_gb": round(free_kb * 1024 / 1e9, 2),
            "use_pct": round(used_kb * 100.0 / total_kb, 1),
        })
    if not mounts:
        return {"status": "unavailable",
                "reason": "df output had no usable mounts"}
    return {"status": "ok", "mounts": mounts}


def _parse_phone_meminfo(text):
    """`cat /proc/meminfo` on the phone -> {status, total_mb,
    available_mb}."""
    vals = {}
    for line in text.splitlines():
        if line.startswith(("MemTotal:", "MemAvailable:")):
            key, val = line.split(":", 1)
            try:
                vals[key.strip()] = int(val.split()[0]) // 1024
            except (ValueError, IndexError):
                pass
    if "MemTotal" not in vals:
        return {"status": "unavailable",
                "reason": "no MemTotal in /proc/meminfo"}
    return {"status": "ok", "source": "/proc/meminfo",
            "total_mb": vals.get("MemTotal"),
            "available_mb": vals.get("MemAvailable")}


def _parse_phone_free(text):
    """`free -m` fallback when /proc/meminfo cannot be read."""
    for line in text.splitlines():
        parts = line.split()
        if parts and parts[0] == "Mem:" and len(parts) >= 7:
            try:
                return {"status": "ok", "source": "free",
                        "total_mb": int(parts[1]),
                        "available_mb": int(parts[6])}
            except ValueError:
                pass
    return {"status": "unavailable",
            "reason": "free output had no Mem: line"}


def cmd_phone_checkup(_args):
    """Read-only phone health over USB adb. Every section is
    independent: one that cannot run reports unavailable and never
    blocks the others. Returns one compact result dict (the ack cap
    trims it if a phone ever reports something huge)."""
    serial, _info, error = detect_phone()
    if error is not None:
        return error
    result = {"serial": serial, "notes": []}
    code, out, err = _adb_shell(serial, ["getprop"])
    if code == 0:
        props = {}
        for m in re.finditer(r"\[(.+?)\]: \[(.*?)\]", out):
            props[m.group(1)] = m.group(2)
        result["device"] = {
            "model": props.get("ro.product.model", "unknown"),
            "manufacturer": props.get("ro.product.manufacturer", "unknown"),
            "android_version": props.get("ro.build.version.release",
                                         "unknown"),
            "sdk": props.get("ro.build.version.sdk", "unknown"),
        }
    else:
        result["device"] = {
            "status": "unavailable",
            "reason": "getprop failed: " + (err or out).strip()[:200]}
    code, out, err = _adb_shell(serial, ["dumpsys", "battery"])
    result["battery"] = (
        _parse_phone_battery(out) if code == 0 else {
            "status": "unavailable",
            "reason": "dumpsys battery failed: "
                      + (err or out).strip()[:200]})
    code, out, err = _adb_shell(serial, ["df"])
    result["storage"] = (
        _parse_phone_df(out) if code == 0 else {
            "status": "unavailable",
            "reason": "df failed: " + (err or out).strip()[:200]})
    code, out, err = _adb_shell(serial, ["cat", "/proc/meminfo"])
    if code == 0:
        result["memory"] = _parse_phone_meminfo(out)
    else:
        code2, out2, err2 = _adb_shell(serial, ["free", "-m"])
        result["memory"] = (
            _parse_phone_free(out2) if code2 == 0 else {
                "status": "unavailable",
                "reason": "memory unreadable: "
                          + (err2 or out2).strip()[:200]})
    code, out, err = _adb_shell(serial, ["pm", "list", "packages"])
    if code == 0:
        result["app_count"] = sum(
            1 for ln in out.splitlines()
            if ln.strip().startswith("package:"))
    else:
        result["app_count"] = None
        result["notes"].append("pm list packages failed: "
                               + (err or out).strip()[:200])
    return result


def validate_phone_repair(cmd_obj):
    """Validate kind + package with the same rules as the relay.
    Returns (kind, package, error_dict)."""
    kind = cmd_obj.get("kind")
    if kind not in PHONE_REPAIR_KINDS:
        return None, None, {
            "error": "bad_kind",
            "detail": "phone_repair kind must be one of "
                      + ", ".join(sorted(PHONE_REPAIR_KINDS))
                      + f"; got {kind!r}"}
    package = cmd_obj.get("package")
    if (not isinstance(package, str) or not package
            or len(package) > 200
            or not PHONE_PACKAGE_RE.match(package)):
        return None, None, {
            "error": "bad_package",
            "detail": "phone_repair needs a real package name "
                      "(e.g. com.example.app), 1-200 chars"}
    if package in PHONE_PROTECTED:
        return None, None, {
            "error": "protected_package",
            "detail": f"{package} is protected: the doctor never "
                      "repairs the system UI, the phone, settings, "
                      "the installer, Play services, or itself. "
                      "Nothing ran."}
    return kind, package, None


def _phone_package_state(serial, package):
    """Before/after snapshot for one package: installed? disabled?
    running? Each probe is best-effort; a failed probe reports None
    for that field instead of failing the repair."""
    state = {"installed": None, "disabled": None, "running": None}
    code, out, _err = _adb_shell(serial,
                                 ["pm", "list", "packages", package])
    if code == 0:
        state["installed"] = any(
            ln.strip() == "package:" + package
            for ln in out.splitlines())
    code, out, _err = _adb_shell(
        serial, ["pm", "list", "packages", "-d", package])
    if code == 0:
        state["disabled"] = any(
            ln.strip() == "package:" + package
            for ln in out.splitlines())
    code, out, _err = _adb_shell(serial, ["pidof", package])
    if code == 0:
        state["running"] = bool(out.strip())
    elif code == 1:
        state["running"] = False  # pidof exits 1 when nothing matches
    return state


def run_phone_repair_sync(cmd_obj):
    """Synchronous phone-repair worker (runs inside an async job
    thread, like the host repair). Returns a result dict; an 'error'
    key means done:false."""
    kind, package, error = validate_phone_repair(cmd_obj)
    if error is not None:
        return error
    serial, _info, error = detect_phone()
    if error is not None:
        return error
    before = _phone_package_state(serial, package)
    if before.get("installed") is False:
        return {"error": "not_installed", "kind": kind,
                "package": package, "serial": serial,
                "detail": f"{package} is not installed on the phone, "
                          "so there is nothing to repair. Nothing ran.",
                "before": before}
    argv = PHONE_REPAIR_KINDS[kind] + [package]
    code, out, err = _adb_shell(serial, argv,
                                timeout_s=ADB_REPAIR_TIMEOUT_S)
    after = _phone_package_state(serial, package)
    output = (out + err).strip()
    result = {"kind": kind, "package": package, "serial": serial,
              "before": before, "after": after,
              "exit_code": code, "output": output[:500]}
    if code != 0:
        result["error"] = "repair_failed"
        result["detail"] = (f"adb {kind} on {package} failed "
                            f"(exit {code}). The before/after state "
                            "above shows what actually changed -- check "
                            "it before retrying.")
        return result
    result["status"] = "ok"
    return result


# ---------------------------------------------------------------- deep
# Read-only deep diagnosis. Every section is independent: a section
# that cannot run reports {"status": "unavailable", "reason": ...} and
# never blocks the others. Nothing here changes anything.

def deep_smart():
    s = smart_summary()
    if s.get("status") != "ok":
        return {"status": "unavailable",
                "reason": s.get("summary") or s.get("status") or "unknown"}
    return {"status": "ok", "summary": s.get("summary"),
            "disks": s.get("disks", [])}


def deep_disks():
    if shutil.which("lsblk") is not None:
        try:
            out = subprocess.run(["lsblk", "-J", "-o",
                                  "NAME,SIZE,TYPE,MOUNTPOINT,FSTYPE"],
                                 capture_output=True, text=True, timeout=15)
            if out.returncode == 0:
                return {"status": "ok", "source": "lsblk",
                        "devices": json.loads(out.stdout).get("blockdevices", [])}
        except (OSError, ValueError, subprocess.SubprocessError):
            pass
    return {"status": "unavailable",
            "reason": "lsblk not present or failed; disk list in the "
                      "boot report is the fallback"}


def deep_df():
    df = disk_space()
    if "error" in df:
        return {"status": "unavailable", "reason": df["error"]}
    return {"status": "ok", "mounts": df.get("mounts", [])}


def deep_uptime():
    section = {"status": "ok"}
    try:
        with open("/proc/uptime") as f:
            section["uptime_s"] = round(float(f.read().split()[0]))
    except (OSError, ValueError):
        section["uptime_s"] = None
    try:
        with open("/proc/loadavg") as f:
            section["loadavg"] = f.read().split()[:3]
    except OSError:
        pass
    return section


def deep_journal_errors():
    """Kernel + system error counts from journalctl, last 24h."""
    if shutil.which("journalctl") is None:
        return {"status": "unavailable",
                "reason": "journalctl not present on this machine"}
    try:
        out = subprocess.run(
            ["journalctl", "--since", "24 hours ago", "-p", "err",
             "--no-pager", "-o", "short"],
            capture_output=True, text=True, timeout=30)
        if out.returncode != 0:
            return {"status": "unavailable",
                    "reason": "journalctl failed: "
                              + (out.stderr or "").strip()[:200]}
        lines = [ln for ln in out.stdout.splitlines() if ln.strip()]
        return {"status": "ok", "window": "last 24h",
                "error_lines": len(lines),
                "sample": lines[-10:]}
    except (OSError, subprocess.SubprocessError) as e:
        return {"status": "unavailable", "reason": str(e)}


def deep_memory():
    section = {"status": "ok"}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith(("MemTotal:", "MemAvailable:",
                                    "SwapTotal:", "SwapFree:")):
                    key, val = line.split(":", 1)
                    section[key.strip()] = int(val.split()[0])
    except (OSError, ValueError):
        pass
    out = _run(["ps", "-eo", "pid,comm,%mem,rss", "--sort=-%mem"],
               timeout=15)
    top = []
    for line in out.splitlines()[1:11]:
        parts = line.split()
        if len(parts) >= 4:
            try:
                top.append({"pid": int(parts[0]), "name": parts[1],
                            "mem_pct": float(parts[2]),
                            "mem_mb": round(int(parts[3]) / 1024.0, 1)})
            except ValueError:
                continue
    section["top_memory"] = top
    if not top and "MemTotal" not in section:
        return {"status": "unavailable",
                "reason": "no memory info readable"}
    return section


def run_deep():
    """Run every deep section, independently. Returns the result dict."""
    return {
        "smart": deep_smart(),
        "disks": deep_disks(),
        "disk_space": deep_df(),
        "uptime": deep_uptime(),
        "journal_errors_24h": deep_journal_errors(),
        "memory": deep_memory(),
        "note": "read-only diagnosis; nothing was changed",
    }

# ---------------------------------------------------------------- repair
# Repair mapping (relay `repair` function -> Linux repair module):
#   system_files  -> repair-linux-1.3.6.py apt-repair (named packages only)
#   startup       -> repair-linux-1.3.6.py startup-cleanup (named items only)
#   temp          -> repair-linux-1.3.6.py temp-cleanup
#   defender_scan -> repair-linux-1.3.6.py malware-quarantine (clamscan; MOVE
#                    infected files to quarantine, never delete)
#   service       -> repair-linux-1.3.6.py service-control (systemctl
#                    start|stop|restart|enable|disable, named units only,
#                    ADMIN ONLY -- refuses needs_admin when unprivileged)
#   pacman        -> repair-linux-1.3.6.py pacman-repair (install, or
#                    remove with "remove": true, named packages only,
#                    ADMIN ONLY, never a blind full upgrade)
# Honest Arch / SteamOS note: repair-linux-1.3.6.py is apt-based. On Arch /
# SteamOS there is no apt, so system_files CANNOT install packages
# here -- the agent reports that plainly (pacman installs would need
# a writable root filesystem and sudo, which the Deck does not have
# by default) and runs only the read-only part: a list of upgradable
# packages via `pacman -Qu`. startup / temp / defender_scan work the
# same on Arch as anywhere else -- they touch only user-level files
# and the home directory. Snapshot-first always: the repair module
# takes its own snapshot (manifest + backup under /tmp) before any
# change, and if the snapshot cannot be written the repair refuses
# loudly -- the agent never silently proceeds and never finishes a
# repair with no effect and no error.

REPAIR_FUNCTIONS = ("system_files", "startup", "temp", "defender_scan",
                      "service", "pacman")


def _run_repair_module(repair_name, extra_args, timeout_s):
    """Run repair-linux-1.3.6.py --go --repair <name> [extra args].
    Returns (exit_code, stdout_text, stderr_text). Never raises.
    The module lives next to this agent in the pack."""
    if not os.path.isfile(REPAIR_MODULE):
        return None, "", (f"repair module not found next to the agent: "
                          f"{REPAIR_MODULE}. The pack is incomplete -- "
                          "repair-linux-1.3.6.py must sit beside the agent.")
    cmd = [sys.executable, REPAIR_MODULE, "--go", "--repair", repair_name]
    cmd.extend(extra_args)
    audit_log(f"repair-module repair={repair_name} args={extra_args}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout_s)
        return proc.returncode, proc.stdout or "", proc.stderr or ""
    except subprocess.TimeoutExpired:
        return None, "", f"repair module timed out after {timeout_s}s"
    except OSError as e:
        return None, "", f"repair module failed to start: {e}"


def run_repair_sync(cmd_obj, timeout_s):
    """Synchronous repair worker (runs inside an async job thread).
    Returns a result dict; an 'error' key means done:false."""
    function = cmd_obj.get("function")
    if function not in REPAIR_FUNCTIONS:
        return {"error": "bad_function",
                "detail": f"repair function must be one of "
                          f"{', '.join(REPAIR_FUNCTIONS)}"}
    names = cmd_obj.get("names") or []
    if not isinstance(names, list) or any(
            not isinstance(n, str) or len(n) > 50 or "*" in n or "?" in n
            for n in names):
        return {"error": "bad_names",
                "detail": "repair names must be an array of strings, "
                          "<=50 chars each, no * or ? wildcards"}
    # Root repairs (service / pacman) are gated BEFORE the snapshot:
    # validation first, then privilege -- an unprivileged call must
    # not run anything at all, not even the snapshot. bad_action is
    # reported even when unprivileged (it is a validation error).
    if function == "service":
        action = cmd_obj.get("action")
        if action not in ("start", "stop", "restart", "enable", "disable"):
            return {"error": "bad_action", "function": function,
                    "detail": "service repair needs action "
                              "start|stop|restart|enable|disable"}
        if not is_admin():
            return {"error": "needs_admin", "function": function,
                    "detail": "service control needs admin (root): run "
                              "the agent as root via the launcher "
                              "elevation, then retry. Nothing was changed."}
    if function == "pacman" and not is_admin():
        return {"error": "needs_admin", "function": function,
                "detail": "package install/remove needs admin (root): "
                          "run the agent as root via the launcher "
                          "elevation, then retry. Nothing was changed."}
    # Snapshot FIRST, always, via the module itself. If the snapshot
    # cannot be written, refuse loudly -- never silently proceed.
    code, out, err = _run_repair_module("snapshot", [], timeout_s=120)
    if code != 0:
        return {"error": "snapshot_failed",
                "function": function,
                "detail": "The snapshot (manifest + backup) could not be "
                          "written, so NO repair ran. Nothing was changed. "
                          f"Module output: {(out + err).strip()[-500:]}",
                "module_exit": code}
    snapshot_note = "snapshot taken (manifest + backup under /tmp)"
    if function == "system_files":
        if shutil.which("apt-get") is None:
            # Arch / SteamOS: no apt. Read-only package listing only.
            upgradable = []
            if shutil.which("pacman") is not None:
                listing = _run(["pacman", "-Qu"], timeout=60)
                upgradable = [ln.split()[0] for ln in
                              listing.splitlines() if ln.strip()]
            return {"function": function, "status": "unavailable",
                    "snapshot": snapshot_note,
                    "detail": "system_files on Arch / SteamOS cannot "
                              "install packages: repair-linux-1.3.6.py is "
                              "apt-based and this machine has no apt. "
                              "Package installs would need a writable root "
                              "filesystem and sudo, which the Deck does "
                              "not have by default. Nothing was installed. "
                              "Upgradable packages (read-only listing): "
                              f"{len(upgradable)}",
                    "upgradable": upgradable[:20]}
        extra = []
        for pkg in names:
            extra.extend(["--package", pkg])
        code, out, err = _run_repair_module("apt-repair", extra,
                                            timeout_s=timeout_s)
        return {"function": function, "status": "ok" if code == 0 else "failed",
                "snapshot": snapshot_note, "module_exit": code,
                "module_output": (out + err).strip()[-2000:],
                "packages": names}
    if function == "startup":
        extra = []
        for name in names:
            extra.extend(["--target", name])
        code, out, err = _run_repair_module("startup-cleanup", extra,
                                            timeout_s=timeout_s)
        return {"function": function, "status": "ok" if code == 0 else "failed",
                "snapshot": snapshot_note, "module_exit": code,
                "module_output": (out + err).strip()[-2000:],
                "targets": names}
    if function == "temp":
        code, out, err = _run_repair_module("temp-cleanup", [],
                                            timeout_s=timeout_s)
        return {"function": function, "status": "ok" if code == 0 else "failed",
                "snapshot": snapshot_note, "module_exit": code,
                "module_output": (out + err).strip()[-2000:]}
    if function == "service":
        # Action + privilege were validated above, before the snapshot.
        action = cmd_obj.get("action")
        extra = ["--action", action]
        for name in names:
            extra.extend(["--target", name])
        code, out, err = _run_repair_module("service-control", extra,
                                            timeout_s=timeout_s)
        return {"function": function, "action": action,
                "status": "ok" if code == 0 else "failed",
                "snapshot": snapshot_note, "module_exit": code,
                "module_output": (out + err).strip()[-2000:],
                "targets": names}
    if function == "pacman":
        # Privilege was validated above, before the snapshot.
        extra = []
        for pkg in names:
            extra.extend(["--package", pkg])
        if cmd_obj.get("remove"):
            extra.append("--remove")
        code, out, err = _run_repair_module("pacman-repair", extra,
                                            timeout_s=timeout_s)
        return {"function": function, "remove": bool(cmd_obj.get("remove")),
                "status": "ok" if code == 0 else "failed",
                "snapshot": snapshot_note, "module_exit": code,
                "module_output": (out + err).strip()[-2000:],
                "packages": names}
    # defender_scan -> malware-quarantine (clamscan; MOVE, never delete).
    code, out, err = _run_repair_module("malware-quarantine", [],
                                        timeout_s=timeout_s)
    return {"function": function, "status": "ok" if code == 0 else "failed",
            "snapshot": snapshot_note, "module_exit": code,
            "module_output": (out + err).strip()[-2000:]}


# ---------------------------------------------------------------- uninstall
# Kinds accepted: flatpak | pacman | app. Any other kind -> ack error
# 'bad_kind', nothing executed. RUNNING-PROCESS PRECHECK FIRST: if a
# process is running whose path is under the target or whose name
# matches, refuse 'target_running', list the process names, delete
# nothing. flatpak = scope-aware since v1.3.9: the scopes the app
# is in are found first (`flatpak list --app --system` /
# `--user`), then each scope is removed with
# `flatpak uninstall -y --<scope> <id>` and the result says which
# scopes were removed. A bare `flatpak uninstall -y <id>` fails
# when the app is in BOTH scopes (same multiple-installations
# ambiguity as the bare install), and --system alone would leave
# the owner's user copy behind while reporting "removed".
# pacman = refuse loudly on the Deck unless the root filesystem is
# writable AND sudo works -- both gates are checked and the refusal
# names the gate that failed. app = remove the user-level install
# (desktop file + home-dir folder) and verify it is gone.

UNINSTALL_KINDS = ("flatpak", "pacman", "app")
_NAME_RE = re.compile(r"^[A-Za-z0-9._\-+]+$")


def _validate_uninstall_target(cmd_obj):
    """Validate name/appid. Returns (kind, name, appid, error_dict)."""
    kind = cmd_obj.get("kind")
    if kind not in UNINSTALL_KINDS:
        return None, None, None, {
            "error": "bad_kind",
            "detail": f"uninstall kind must be one of "
                      f"{', '.join(UNINSTALL_KINDS)}; got {kind!r}"}
    name = cmd_obj.get("name")
    appid = cmd_obj.get("appid")
    if kind == "flatpak":
        if not isinstance(name, str) or not name:
            return None, None, None, {
                "error": "bad_name",
                "detail": "flatpak uninstall needs a string 'name' "
                          "(the flatpak application ID, e.g. "
                          "org.mozilla.firefox)"}
    elif kind == "pacman":
        if not isinstance(name, str) or not _NAME_RE.match(name):
            return None, None, None, {
                "error": "bad_name",
                "detail": "pacman uninstall needs a plain package name "
                          "(letters, digits, . _ - + only)"}
    else:  # app
        if not isinstance(name, str) or not name or len(name) > 200 \
                or "\\" in name or "/" in name or ".." in name:
            return None, None, None, {
                "error": "bad_name",
                "detail": "app uninstall needs a plain program name "
                          "(<=200 chars, no backslash, no slash, no '..')"}
    if appid is not None and not isinstance(appid, int):
        return None, None, None, {
            "error": "bad_appid",
            "detail": "appid must be an integer (steam only, not used "
                      "by this Linux agent)"}
    return kind, name, appid, None


def _running_processes():
    """List running processes: [{pid, name, exe}]. Never raises."""
    procs = []
    out = _run(["ps", "-eo", "pid,comm"], timeout=15)
    pid_to_name = {}
    for line in out.splitlines()[1:]:
        parts = line.split(None, 1)
        if len(parts) == 2:
            try:
                pid_to_name[int(parts[0])] = parts[1].strip()
            except ValueError:
                continue
    try:
        pids = [d for d in os.listdir("/proc") if d.isdigit()]
    except OSError:
        pids = []
    for pid in pids:
        try:
            name = pid_to_name.get(int(pid), "")
            exe = ""
            try:
                exe = os.readlink(f"/proc/{pid}/exe")
            except OSError:
                pass
            if not name:
                try:
                    with open(f"/proc/{pid}/comm") as fh:
                        name = fh.read().strip()
                except OSError:
                    pass
            procs.append({"pid": int(pid), "name": name, "exe": exe})
        except (OSError, ValueError):
            continue
    return procs


def _target_running_check(kind, name, app_paths):
    """Running-process precheck. Returns a list of matching process
    names (empty when nothing is running). A process matches when its
    name matches the target name (case-insensitive) or its executable
    path sits under one of the target paths."""
    matches = []
    needle = (name or "").lower()
    for proc in _running_processes():
        pname = (proc.get("name") or "").lower()
        exe = proc.get("exe") or ""
        hit = False
        if needle and (pname == needle or needle in pname
                       or pname in needle):
            hit = True
        for base in app_paths:
            if exe and base and exe.startswith(base):
                hit = True
        if hit:
            matches.append(proc.get("name") or f"pid {proc.get('pid')}")
    return sorted(set(matches))


def _app_locations(name):
    """User-level install locations for an app: desktop files and
    home-dir folders that look like this program."""
    home = os.path.expanduser("~")
    locations = []
    for base in (os.path.join(home, ".local", "share", "applications"),
                 os.path.join(home, ".local", "share", "flatpak"),
                 "/usr/share/applications"):
        try:
            for fname in sorted(os.listdir(base)):
                if fname.lower().startswith(name.lower()) \
                        and fname.endswith(".desktop"):
                    locations.append(os.path.join(base, fname))
        except OSError:
            pass
    for base in (os.path.join(home, ".local", "share"),
                 os.path.join(home, ".local", "opt"),
                 os.path.join(home, "Applications"),
                 os.path.join(home, ".var", "app")):
        candidate = os.path.join(base, name)
        if os.path.exists(candidate):
            locations.append(candidate)
    return locations


def run_uninstall_sync(cmd_obj, timeout_s):
    """Synchronous uninstall worker (runs inside an async job thread).
    Returns a result dict; an 'error' key means done:false."""
    kind, name, _appid, err = _validate_uninstall_target(cmd_obj)
    if err is not None:
        return err
    if kind == "flatpak":
        app_paths = [os.path.join(os.path.expanduser("~"), ".var", "app", name),
                     os.path.join("/var", "lib", "flatpak", "app", name)]
        running = _target_running_check(kind, name, app_paths)
        if running:
            return {"error": "target_running", "kind": kind, "name": name,
                    "detail": "The program is still running, so nothing "
                              "was deleted. Close it first and try again.",
                    "running_processes": running}
        if shutil.which("flatpak") is None:
            return {"error": "unavailable", "kind": kind, "name": name,
                    "detail": "flatpak is not installed on this machine, "
                              "so nothing was uninstalled."}
        # v1.3.9: scope-aware uninstall. A bare `flatpak uninstall
        # -y <id>` fails when the app is installed in BOTH scopes
        # (same multiple-installations ambiguity that broke the
        # bare install: flathub in system + user). --system alone
        # would also be wrong here: it would leave the owner's
        # user copy behind and still report "removed" while the
        # app is installed. So the doctor finds every scope the
        # app is in and removes each one, saying which.
        scopes = _flatpak_scopes(name)
        if scopes is None:
            # List query could not run at all; fall back to the
            # doctor's install target only (system scope).
            scopes = ["system"]
        if not scopes:
            return {"error": "not_found", "kind": kind, "name": name,
                    "detail": f"flatpak {name} is not installed in "
                              "either scope (system or user). Nothing "
                              "was removed."}
        removed = []
        failed = []
        outputs = []
        for scope in scopes:
            try:
                proc = subprocess.run(
                    ["flatpak", "uninstall", "-y", f"--{scope}", name],
                    capture_output=True, text=True, timeout=timeout_s)
            except subprocess.TimeoutExpired:
                failed.append(
                    f"{scope}: timed out after {timeout_s}s")
                continue
            except OSError as e:
                failed.append(f"{scope}: {e}")
                continue
            outputs.append((proc.stdout or "").strip())
            if proc.returncode != 0:
                failed.append(
                    f"{scope}: "
                    f"{(proc.stderr or proc.stdout).strip()[-500:]}")
                continue
            removed.append(scope)
        if failed:
            return {"error": "uninstall_failed", "kind": kind, "name": name,
                    "removed": removed, "failed": failed,
                    "detail": f"flatpak {name} was removed from "
                              f"{removed or 'no scope'} but could not be "
                              f"removed from {failed}; check before "
                              f"retrying"}
        scope_words = " and ".join(removed)
        return {"kind": kind, "name": name, "status": "removed",
                "scopes": removed,
                "detail": f"flatpak {name} uninstalled from the "
                          f"{scope_words} scope(s)",
                "output": "\n".join(o for o in outputs if o)[-1000:]}
    if kind == "pacman":
        ro = root_readonly()
        if ro is not False:
            return {"error": "readonly_root", "kind": kind, "name": name,
                    "detail": "Refusing: the root filesystem is "
                              "read-only (SteamOS default"
                              + (" -- could not confirm it is writable"
                                 if ro is None else "")
                              + "). Pacman cannot remove a package while "
                              "the system partition is read-only. To allow "
                              "this, the owner must first run "
                              "`sudo steamos-readonly disable` in Konsole "
                              "-- and understand that disables SteamOS "
                              "system updates until it is re-enabled. "
                              "Nothing was removed."}
        if not sudo_works():
            return {"error": "sudo_unavailable", "kind": kind, "name": name,
                    "detail": "Refusing: sudo does not work without a "
                              "password prompt on this machine. Set a sudo "
                              "password first with `passwd` in Konsole, "
                              "then try again. Nothing was removed."}
        running = _target_running_check(kind, name, [])
        if running:
            return {"error": "target_running", "kind": kind, "name": name,
                    "detail": "The program is still running, so nothing "
                              "was removed. Close it first and try again.",
                    "running_processes": running}
        try:
            proc = subprocess.run(
                ["sudo", "-n", "pacman", "-Rns", "--noconfirm", name],
                capture_output=True, text=True, timeout=timeout_s)
        except subprocess.TimeoutExpired:
            return {"error": "timeout", "kind": kind, "name": name,
                    "detail": f"pacman removal timed out after "
                              f"{timeout_s}s; the package may be partly "
                              "removed -- check before retrying"}
        except OSError as e:
            return {"error": "uninstall_failed", "kind": kind, "name": name,
                    "detail": str(e)}
        if proc.returncode != 0:
            return {"error": "uninstall_failed", "kind": kind, "name": name,
                    "detail": (proc.stderr or proc.stdout).strip()[-1000:]}
        return {"kind": kind, "name": name, "status": "removed",
                "detail": f"pacman package {name} removed",
                "output": (proc.stdout or "").strip()[-1000:]}
    # app: user-level install only -- desktop file + home-dir folder.
    locations = _app_locations(name)
    if not locations:
        return {"error": "not_found", "kind": kind, "name": name,
                "detail": f"No user-level install of {name!r} was found "
                          "(no matching desktop file or home-dir folder). "
                          "Nothing was removed."}
    running = _target_running_check(kind, name, locations)
    if running:
        return {"error": "target_running", "kind": kind, "name": name,
                "detail": "The program is still running, so nothing was "
                          "deleted. Close it first and try again.",
                "running_processes": running}
    removed = []
    failed = []
    for path in locations:
        try:
            if os.path.isdir(path) and not os.path.islink(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
            removed.append(path)
        except OSError as e:
            failed.append(f"{path}: {e}")
    still_there = [p for p in locations if os.path.exists(p)]
    if still_there:
        return {"error": "uninstall_failed", "kind": kind, "name": name,
                "removed": removed, "failed": failed,
                "still_present": still_there,
                "detail": "Some parts could not be removed; the rest "
                          "were. See still_present."}
    return {"kind": kind, "name": name, "status": "removed",
            "removed": removed,
            "detail": f"User-level install of {name} removed "
                      f"({len(removed)} location(s)); verified gone."}


# ---------------------------------------------------------------- install
# Kinds accepted: brew | flatpak | pacman. Any other kind -> ack error
# 'bad_kind', nothing executed. PRECHECKS FIRST: the package manager
# must exist on PATH, and the package must not already be installed
# (brew: `brew list <name>`; flatpak: `flatpak list --app --system`
# AND `flatpak list --app --user`, matching the id in either scope;
# pacman: `pacman -Q <name>`). Already installed -> ack done
# with status 'already_installed' and nothing is run. pacman = refuse
# loudly on the Deck unless the root filesystem is writable AND sudo
# works -- both gates are checked and the refusal names the gate that
# failed (same gates as the pacman uninstall). flatpak installs are
# v1.3.9: `flatpak install -y --system flathub <appid>` -- remote
# AND scope explicit, because a bare `flatpak install -y <appid>`
# fails on a machine where flathub exists in both installations
# (the Deck: system + the owner's user one): flatpak cannot resolve
# the remote and aborts with "No remote chosen to resolve matches".
# The install is verified afterwards with the same list/query
# command: an exit code of 0 is never trusted on its own, and the
# completion ack carries 'verified': true/false. Steps are recorded
# as items in the same shape as the uninstall results (kind / name /
# status / detail, plus a 'steps' list).

INSTALL_KINDS = ("brew", "flatpak", "pacman")


def _validate_install_target(cmd_obj):
    """Validate kind/name. Returns (kind, name, error_dict)."""
    kind = cmd_obj.get("kind")
    if kind not in INSTALL_KINDS:
        return None, None, {
            "error": "bad_kind",
            "detail": f"install kind must be one of "
                      f"{', '.join(INSTALL_KINDS)}; got {kind!r}"}
    name = cmd_obj.get("name")
    if not isinstance(name, str) or not name or len(name) > 200 \
            or ".." in name or not _NAME_RE.match(name):
        return None, None, {
            "error": "bad_name",
            "detail": "install needs a plain package name (<=200 chars, "
                      "letters, digits, . _ - + only, no '..')"}
    return kind, name, None


def _query_installed(cmd, timeout=30):
    """Run a list/query command. Returns (returncode, stdout), or
    (None, '') when the tool cannot be run at all. Never raises."""
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout)
        return proc.returncode, (proc.stdout or "")
    except (OSError, subprocess.SubprocessError):
        return None, ""


def _flatpak_scopes(name):
    """Scopes (subset of ["system", "user"]) where a flatpak id is
    installed, or None when a list query itself could not run.
    v1.3.9: explicit per-scope queries -- a bare `flatpak list
    --app` is not a promise about which scopes it covers on every
    flatpak version, and the doctor must know the scope before it
    uninstalls (a bare uninstall fails when the app is in both)."""
    scopes = []
    for scope in ("system", "user"):
        rc, out = _query_installed(
            ["flatpak", "list", "--app", f"--{scope}"])
        if rc is None:
            return None
        if rc != 0:
            continue
        for line in out.splitlines():
            if name in line.split():
                scopes.append(scope)
                break
    return scopes


def _is_installed(kind, name):
    """Already-installed precheck. Returns True/False, or None when
    the check itself could not run (caller treats None as 'unknown',
    never as installed)."""
    if kind == "brew":
        rc, _out = _query_installed(["brew", "list", name])
        return None if rc is None else rc == 0
    if kind == "flatpak":
        # v1.3.9: query BOTH scopes explicitly. The doctor installs
        # to the system scope, but a user-scope install must still
        # count as already installed -- otherwise the doctor would
        # install a system duplicate next to the owner's own copy.
        scopes = _flatpak_scopes(name)
        if scopes is None:
            return None
        return bool(scopes)
    # pacman
    rc, _out = _query_installed(["pacman", "-Q", name])
    return None if rc is None else rc == 0


def run_install_sync(cmd_obj, timeout_s):
    """Synchronous install worker (runs inside an async job thread).
    Returns a result dict; an 'error' key means done:false."""
    kind, name, err = _validate_install_target(cmd_obj)
    if err is not None:
        return err
    steps = []
    tool = {"brew": "brew", "flatpak": "flatpak",
            "pacman": "pacman"}[kind]
    if shutil.which(tool) is None:
        steps.append({"step": "tool_present", "ok": False,
                      "detail": f"{tool} is not installed on this machine"})
        return {"error": "unavailable", "kind": kind, "name": name,
                "steps": steps,
                "detail": f"{tool} is not installed on this machine, "
                          "so nothing was installed."}
    steps.append({"step": "tool_present", "ok": True,
                  "detail": f"{tool} is installed"})
    already = _is_installed(kind, name)
    if already:
        steps.append({"step": "already_installed", "ok": True,
                      "detail": f"{name} is already installed"})
        return {"kind": kind, "name": name, "status": "already_installed",
                "verified": True, "steps": steps,
                "detail": f"{name} is already installed; nothing was run."}
    steps.append({"step": "already_installed", "ok": False,
                  "detail": f"{name} is not installed yet"})
    if kind == "pacman":
        ro = root_readonly()
        if ro is not False:
            steps.append({"step": "deck_gates", "ok": False,
                          "detail": "root filesystem is read-only"})
            return {"error": "readonly_root", "kind": kind, "name": name,
                    "steps": steps,
                    "detail": "Refusing: the root filesystem is "
                              "read-only (SteamOS default"
                              + (" -- could not confirm it is writable"
                                 if ro is None else "")
                              + "). Pacman cannot install a package while "
                              "the system partition is read-only. To allow "
                              "this, the owner must first run "
                              "`sudo steamos-readonly disable` in Konsole "
                              "-- and understand that disables SteamOS "
                              "system updates until it is re-enabled. "
                              "Nothing was installed."}
        if not sudo_works():
            steps.append({"step": "deck_gates", "ok": False,
                          "detail": "passwordless sudo does not work"})
            return {"error": "sudo_unavailable", "kind": kind, "name": name,
                    "steps": steps,
                    "detail": "Refusing: sudo does not work without a "
                              "password prompt on this machine. Set a sudo "
                              "password first with `passwd` in Konsole, "
                              "then try again. Nothing was installed."}
        steps.append({"step": "deck_gates", "ok": True,
                      "detail": "root writable and passwordless sudo works"})
    if kind == "brew":
        argv = ["brew", "install", name]
    elif kind == "flatpak":
        # v1.3.9: remote AND scope explicit. A bare `flatpak
        # install -y <appid>` fails on a machine where flathub
        # exists in both installations (system + user): flatpak
        # cannot resolve the remote, prompts interactively, and
        # aborts with "No remote chosen to resolve matches".
        # The duplicate remote stays (owner's choice); the doctor
        # always installs to the system scope from flathub.
        argv = ["flatpak", "install", "-y", "--system", "flathub", name]
    else:  # pacman
        argv = ["sudo", "-n", "pacman", "-S", "--noconfirm", name]
    try:
        proc = subprocess.run(argv, capture_output=True, text=True,
                              timeout=timeout_s)
    except subprocess.TimeoutExpired:
        steps.append({"step": "install", "ok": False,
                      "detail": f"install timed out after {timeout_s}s"})
        return {"error": "timeout", "kind": kind, "name": name,
                "steps": steps,
                "detail": f"{kind} install timed out after {timeout_s}s; "
                          "the package may be partly installed -- check "
                          "before retrying"}
    except OSError as e:
        steps.append({"step": "install", "ok": False, "detail": str(e)})
        return {"error": "install_failed", "kind": kind, "name": name,
                "steps": steps, "detail": str(e)}
    output = (proc.stdout or "").strip()[-1000:]
    if proc.returncode != 0:
        steps.append({"step": "install", "ok": False,
                      "detail": (proc.stderr or proc.stdout).strip()[-1000:]})
        return {"error": "install_failed", "kind": kind, "name": name,
                "steps": steps,
                "detail": (proc.stderr or proc.stdout).strip()[-1000:]}
    steps.append({"step": "install", "ok": True,
                  "detail": f"{kind} install exited 0"})
    # Never trust the exit code alone: verify with the same query.
    verified = _is_installed(kind, name)
    steps.append({"step": "verify", "ok": bool(verified),
                  "detail": f"verified installed: {bool(verified)}"})
    if not verified:
        return {"error": "install_failed", "kind": kind, "name": name,
                "verified": False, "steps": steps,
                "detail": f"{kind} install reported success but {name} "
                          "is still not listed as installed; check "
                          "before retrying",
                "output": output}
    return {"kind": kind, "name": name, "status": "installed",
            "verified": True, "steps": steps,
            "detail": f"{kind} package {name} installed (verified)",
            "output": output}


# ---------------------------------------------------------------- async jobs
# exec / repair / deep / uninstall / install run in daemon threads so the poll
# loop stays responsive. A handler returns a 'started' ack immediately
# and the main loop posts the completion ack when the job finishes --
# including on timeout, with any partial output. A job is never left
# silent. Implementation: threading.Thread per job (the sanest stdlib
# route -- no extra processes, shared state is a plain dict guarded by
# the GIL, and the thread's result is read by the main loop).

_PENDING_JOBS = []  # list of dicts: {id, kind, thread, result, started_at, timeout_s}
_JOBS_LOCK = threading.Lock()


def _job_runner(job):
    """Thread body: run the worker, store its result. Never raises --
    a worker crash becomes an error result, never silence."""
    try:
        job["result"] = job["worker"]()
    except Exception as e:  # noqa: BLE001 - a job must always ack
        log(f"job {job['id']} ({job['kind']}) raised: {e}")
        job["result"] = {"error": "job_failed", "detail": str(e)}


def start_async_job(cmd_id, kind, worker, timeout_s):
    """Start a job thread and return its 'started' ack result."""
    job = {"id": cmd_id, "kind": kind, "worker": worker,
           "result": None, "started_at": time.monotonic(),
           "timeout_s": timeout_s}
    thread = threading.Thread(target=_job_runner, args=(job,),
                              daemon=True)
    job["thread"] = thread
    with _JOBS_LOCK:
        _PENDING_JOBS.append(job)
    thread.start()
    log(f"job started: id={cmd_id} kind={kind} timeout_s={timeout_s}")
    return {"started": True, "status": "running", "kind": kind,
            "timeout_s": timeout_s}


def check_pending_jobs():
    """Poll finished jobs; post each completion ack exactly once.
    A job past its timeout is acked done:false with timed_out=true
    and whatever partial result exists (the thread is daemonised and
    abandoned -- it cannot be killed, so the ack says so plainly).
    Returns the number of jobs still pending."""
    finished = []
    with _JOBS_LOCK:
        snapshot = list(_PENDING_JOBS)
    for job in snapshot:
        timed_out = (time.monotonic() - job["started_at"]
                     > job["timeout_s"])
        if job["result"] is not None:
            result = job["result"]
            done = "error" not in result
            ack = build_ack(job["id"], done, result)
            post_ack(ack)
            finished.append(job)
        elif timed_out:
            result = {"error": "timeout", "kind": job["kind"],
                      "timed_out": True,
                      "detail": f"job timed out after {job['timeout_s']}s "
                                "and was abandoned (a running thread "
                                "cannot be stopped cleanly); the work may "
                                "still finish in the background -- check "
                                "before retrying"}
            ack = build_ack(job["id"], False, result)
            post_ack(ack)
            finished.append(job)
    if finished:
        with _JOBS_LOCK:
            for job in finished:
                if job in _PENDING_JOBS:
                    _PENDING_JOBS.remove(job)
    with _JOBS_LOCK:
        return len(_PENDING_JOBS)


# ---------------------------------------------------------------- dispatch

def _exec_timeout(cmd_obj):
    timeout_s = 60
    raw = cmd_obj.get("timeout_s")
    if isinstance(raw, (int, float)):
        timeout_s = int(raw)
    timeout_s = max(EXEC_TIMEOUT_MIN_S, min(EXEC_TIMEOUT_MAX_S, timeout_s))
    return timeout_s


def execute_command(cmd_obj):
    """Run one command object. Returns (cmd_id, ack_payload) for
    synchronous commands, or (cmd_id, 'started' ack) for async ones
    (the completion ack follows from check_pending_jobs)."""
    cmd_id = cmd_obj.get("id")
    name = cmd_obj.get("cmd")
    if not isinstance(name, str) or not name:
        return cmd_id, build_ack(cmd_id, False, {
            "error": "unknown_cmd",
            "detail": "command has no 'cmd' string"})
    if name == "ping":
        return cmd_id, build_ack(cmd_id, True, {"pong": True})
    if name == "sysinfo":
        return cmd_id, build_ack(cmd_id, True, cmd_sysinfo(cmd_obj))
    if name == "smart":
        return cmd_id, build_ack(cmd_id, True, cmd_smart(cmd_obj))
    if name == "df":
        return cmd_id, build_ack(cmd_id, True, cmd_df(cmd_obj))
    if name == "ls":
        result = cmd_ls(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "cat":
        result = cmd_cat(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "dmesg":
        result = cmd_dmesg(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "screenshot":
        result = cmd_screenshot(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "mouse":
        result = cmd_mouse(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "type":
        result = cmd_type(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "launch":
        audit_log(f"launch id={cmd_id} desktop={cmd_obj.get('desktop')} "
                  f"executable={cmd_obj.get('executable')} "
                  f"args={cmd_obj.get('args')}")
        result = cmd_launch(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "clean":
        return cmd_id, build_ack(cmd_id, True, cmd_clean(cmd_obj))
    if name == "exec":
        command = cmd_obj.get("command")
        if not isinstance(command, str) or not command.strip():
            return cmd_id, build_ack(cmd_id, False, {
                "error": "bad_command",
                "detail": "exec needs a non-empty string 'command'"})
        if len(command) > EXEC_MAX_CHARS:
            return cmd_id, build_ack(cmd_id, False, {
                "error": "bad_command",
                "detail": f"command is {len(command)} chars, over the "
                          f"{EXEC_MAX_CHARS}-char limit"})
        owner_override = bool(cmd_obj.get("owner_override", False))
        owner_go = _owner_go_stamp(cmd_obj)
        audit_log(f"exec id={cmd_id} owner_override={owner_override} "
                  f"owner_go={owner_go} command={command}")
        # Durable fix: argv execution -- check_exec_command parses
        # to argv and applies the argv blocklist first, with the
        # string checker as a second layer. No shell is involved.
        blocked = check_exec_command(command, owner_override, owner_go)
        if blocked is not None:
            log(f"exec refused (id={cmd_id}): {blocked}")
            audit_log(f"exec id={cmd_id} refused: {blocked}")
            return cmd_id, build_ack(cmd_id, False, {
                "error": "blocked", "detail": blocked})
        timeout_s = _exec_timeout(cmd_obj)
        started = start_async_job(
            cmd_id, "exec",
            lambda: run_exec_sync(command, timeout_s, owner_override,
                                  owner_go), timeout_s)
        # v1.3.10: when the command runs ONLY because the stamp
        # authorised it, the started ack restates the exact target
        # the owner said go for -- so the ack itself shows what was
        # authorised, and a mismatched stamp never reaches here.
        if owner_go is not None and check_exec_command(
                command, owner_override) is not None:
            started = dict(started)
            started["owner_go"] = {"action": owner_go["action"],
                                   "target": owner_go["target"]}
            audit_log(f"exec id={cmd_id} owner_go authorised: "
                      f"{owner_go['action']} {owner_go['target']}")
        return cmd_id, build_ack(cmd_id, True, started)
    if name == "exec_pipeline":
        stages = cmd_obj.get("stages")
        timeout_s = _exec_timeout(cmd_obj)
        owner_go = _owner_go_stamp(cmd_obj)
        n_stages = len(stages) if isinstance(stages, list) else "bad"
        audit_log(f"exec_pipeline id={cmd_id} stages={n_stages} "
                  f"owner_go={owner_go}")
        parsed, reason = validate_pipeline_stages(stages, owner_go)
        if reason is not None:
            log(f"exec_pipeline refused (id={cmd_id}): {reason}")
            audit_log(f"exec_pipeline id={cmd_id} refused: {reason}")
            return cmd_id, build_ack(cmd_id, False, {
                "error": "blocked", "detail": reason})
        started = start_async_job(
            cmd_id, "exec_pipeline",
            lambda: run_pipeline_sync(parsed, timeout_s, owner_go),
            timeout_s)
        if owner_go is not None and validate_pipeline_stages(
                stages)[1] is not None:
            started = dict(started)
            started["owner_go"] = {"action": owner_go["action"],
                                   "target": owner_go["target"]}
            audit_log(f"exec_pipeline id={cmd_id} owner_go "
                      f"authorised: {owner_go['action']} "
                      f"{owner_go['target']}")
        return cmd_id, build_ack(cmd_id, True, started)
    if name == "repair":
        audit_log(f"repair id={cmd_id} function={cmd_obj.get('function')} "
                  f"names={cmd_obj.get('names')}")
        timeout_s = _exec_timeout(cmd_obj)
        started = start_async_job(
            cmd_id, "repair",
            lambda: run_repair_sync(cmd_obj, timeout_s), timeout_s)
        return cmd_id, build_ack(cmd_id, True, started)
    if name == "deep":
        timeout_s = _exec_timeout(cmd_obj)
        started = start_async_job(
            cmd_id, "deep", run_deep, timeout_s)
        return cmd_id, build_ack(cmd_id, True, started)
    if name == "uninstall":
        timeout_s = _exec_timeout(cmd_obj)
        started = start_async_job(
            cmd_id, "uninstall",
            lambda: run_uninstall_sync(cmd_obj, timeout_s), timeout_s)
        return cmd_id, build_ack(cmd_id, True, started)
    if name == "install":
        timeout_s = _exec_timeout(cmd_obj)
        audit_log(f"install id={cmd_id} kind={cmd_obj.get('kind')} "
                  f"name={cmd_obj.get('name')}")
        started = start_async_job(
            cmd_id, "install",
            lambda: run_install_sync(cmd_obj, timeout_s), timeout_s)
        return cmd_id, build_ack(cmd_id, True, started)
    if name == "phone_checkup":
        result = cmd_phone_checkup(cmd_obj)
        return cmd_id, build_ack(cmd_id, "error" not in result, result)
    if name == "phone_repair":
        audit_log(f"phone_repair id={cmd_id} kind={cmd_obj.get('kind')} "
                  f"package={cmd_obj.get('package')}")
        # Floor of 180s: the driver itself can take up to ~2 min
        # worst case (60s repair + state probes), so a shorter
        # caller timeout must not ack-timeout a repair that is
        # still running its adb calls.
        timeout_s = max(_exec_timeout(cmd_obj), 180)
        started = start_async_job(
            cmd_id, "phone_repair",
            lambda: run_phone_repair_sync(cmd_obj), timeout_s)
        return cmd_id, build_ack(cmd_id, True, started)
    log(f"unknown command: {name!r} (id={cmd_id})")
    return cmd_id, build_ack(cmd_id, False, {
        "error": "unknown_cmd", "detail": f"no such command: {name}"})


def extract_commands(payload):
    """Normalise a GET /doctor/command response into a list of command dicts.

    Accepts a bare command {"cmd": ..., "id": ...}, {"command": {...}},
    {"commands": [...]}, or an empty / no-command body ({} / {"cmd": null}).
    """
    if not isinstance(payload, dict):
        return []
    if payload.get("commands") and isinstance(payload["commands"], list):
        return [c for c in payload["commands"] if isinstance(c, dict)]
    inner = payload.get("command")
    if isinstance(inner, dict):
        return [inner]
    if payload.get("cmd"):
        return [payload]
    return []


def poll_once(seen_ids):
    """One poll cycle: GET the head of the queue WITHOUT popping, then
    POST /doctor/received IMMEDIATELY for a new command id, BEFORE
    executing it. Returns the number of commands executed.

    v1.3.8 un-wedge: when the head id is already in seen_ids, the
    skip path RE-POSTs /doctor/received for it (best-effort, one
    attempt) before skipping -- never executing on the skip path,
    so there is no re-execution risk. Live 2026-11-22 the pop of
    an executed id did not take effect (KV eventual-consistency
    race / one transient POST failure) and every later poll
    returned the same head, which the old skip path ignored
    forever -- the queue wedged until a human posted /doctor/
    received by hand. The re-pop attempt is logged at most once
    per id per minute so a wedged head does not spam the log."""
    payload = relay_get("/doctor/command")
    if payload is None:
        return 0  # relay unreachable; logged inside relay_get
    commands = extract_commands(payload)
    executed = 0
    for cmd_obj in commands:
        cmd_id = cmd_obj.get("id")
        if cmd_id is not None and cmd_id in seen_ids:
            now = time.monotonic()
            if now - _REPOP_LOG_AT.get(cmd_id, 0.0) >= 60:
                _REPOP_LOG_AT[cmd_id] = now
                log(f"re-popping already-seen command id={cmd_id} "
                    "(queue-head un-wedge; not executing it again)")
            relay_post("/doctor/received", {"id": cmd_id})
            continue
        if cmd_id is not None:
            seen_ids.add(cmd_id)
            received = relay_post("/doctor/received", {"id": cmd_id})
            if received is None:
                log(f"/doctor/received for id={cmd_id} NOT delivered "
                    "(relay unreachable) -- executing anyway; the queue "
                    "may re-deliver this command later and the seen-ids "
                    "backstop will dedup it")
            else:
                log(f"received id={cmd_id} (popped from the queue)")
        name = cmd_obj.get("cmd")
        log(f"executing command {name!r} (id={cmd_id})")
        _cid, ack = execute_command(cmd_obj)
        executed += 1
        post_ack(ack)
    return executed


# ---------------------------------------------------------------- main

def main(argv=None):
    parser = argparse.ArgumentParser(
        description="KUROdoctor agent v1.3.10 (Linux / SteamOS)")
    parser.add_argument("--once", action="store_true",
                        help="run one poll cycle and exit")
    parser.add_argument("--report-only", action="store_true",
                        help="send the boot report and exit")
    parser.add_argument("--sweep-only", action="store_true",
                        help="run the blind sweep, print the JSON, exit")
    args = parser.parse_args(argv)

    if args.sweep_only:
        # Test mode: the sweep, and nothing else -- no relay traffic
        # and no relay URL needed. (The background scan, if one
        # starts, is abandoned on exit; the printed malware_scan
        # section shows "pending".)
        print(json.dumps(run_blind_sweep(), indent=2))
        log("sweep-only mode: exiting")
        return 0

    if not RELAY:
        # Plain-language exit, no traceback, exit code 2. Nothing was
        # sent anywhere and no report was saved.
        print(relay_missing_message(), file=sys.stderr)
        return 2

    log(f"KUROdoctor agent v{VERSION} starting, relay={RELAY}")
    log(f"steamos={is_steamos()} root_readonly={root_readonly()} "
        f"admin={is_admin()} uid={_current_uid()} "
        f"home={os.path.expanduser('~')}")

    # Boot report first, always -- even if the relay is down we keep going
    # and retry it on poll iterations below, ONLY until it first lands.
    # v1.3.11: there is NO periodic heartbeat -- the 60s heartbeat was
    # removed because its 1,440 KV writes/day alone exceed Cloudflare
    # KV's 1,000 writes/day free-tier cap and killed the relay. The
    # blind sweep runs inside build_report, before any command is polled.
    boot_report_delivered = send_report()

    if args.report_only:
        log("report-only mode: exiting")
        return 0

    log("live feed: change-only frames to /doctor/frame "
        "(max 1 per 5s, 60s liveness)")

    seen_ids = set()
    last_command_at = 0.0  # monotonic time of the last command seen

    if args.once:
        executed = poll_once(seen_ids)
        if executed:
            last_command_at = time.monotonic()
        # v1.3.4 live feed: one tick per poll iteration, like the
        # main loop below. The tick rate-limits itself (max 1 post
        # per 5s) and never throws into this path.
        send_frame_tick()
        # --once must not exit while an async job is still running:
        # a started ack with no completion ack is silence. Wait for
        # every pending job to finish (or time out and ack) before
        # exiting. Bounded so --once always terminates.
        wait_deadline = time.monotonic() + EXEC_TIMEOUT_MAX_S + 30
        while check_pending_jobs() > 0 \
                and time.monotonic() < wait_deadline:
            time.sleep(0.5)
        check_scan_followup()
        log("once mode: exiting")
        return 0

    log(f"polling {RELAY}/doctor/command -- 1s while active, 10s idle; "
        f"on-demand reporting only (boot report once, no heartbeat)")
    while True:
        try:
            executed = poll_once(seen_ids)
            if executed:
                last_command_at = time.monotonic()
        except Exception as e:  # the loop itself must never die
            log(f"poll cycle raised (continuing): {e}")
        pending = check_pending_jobs()
        check_scan_followup()
        # v1.3.4 live feed: one tick per poll iteration. The tick
        # itself rate-limits (max 1 post per 5s) and never throws
        # into this loop.
        send_frame_tick()
        if not boot_report_delivered:
            # v1.3.11: no periodic heartbeat -- retry the boot report
            # ONLY until it first lands, then never again. This adds
            # zero steady-state KV writes.
            boot_report_delivered = send_report()
        active = (pending > 0
                  or time.monotonic() - last_command_at < ACTIVE_WINDOW_S)
        time.sleep(POLL_ACTIVE_S if active else POLL_IDLE_S)


if __name__ == "__main__":
    sys.exit(main())
