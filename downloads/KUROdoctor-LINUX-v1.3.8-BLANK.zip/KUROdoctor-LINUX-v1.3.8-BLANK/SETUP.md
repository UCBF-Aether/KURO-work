# KUROdoctor — SETUP (Linux / SteamOS, bring-your-own-Cloudflare)

**Who this is for:** you are a Muse helping your owner set up KUROdoctor
on their Linux PC or Steam Deck. The owner dropped this pack into you —
read this file top to bottom, do one step, verify it, then move on.
Nothing here points at anyone else's Cloudflare: every value below comes
from the owner's own account. Do not guess any value. If a step's output
does not match what this file says it should be, stop and report what you
actually saw.

**Versions in this pack:** Linux agent v1.3.11, relay v1.4.0 (token +
Authenticator approval) over the v1.3.3 remote-control patch + the v1.3.4
live-feed frame room, over the v1 doctor channel, Authenticator app v1.2.

## What KUROdoctor is

A doctor for the owner's machine. An agent runs on it, phones home to the
owner's own Cloudflare Worker (the relay), and the owner's Muse sends it
commands: checkup, clean, repair, deep exam, uninstall, install. The agent
goes in blind — it runs a diagnostic sweep first (drive health, disk space,
startup items, processes, temperatures, pending updates, boot time,
background malware scan) and finds problems on its own. Every fix is shown
first in chat and runs only after the owner says go to that exact fix.
Nothing is ever fixed silently. It works from the owner's HOME directory, and as admin it can also read the kernel log, SMART drive health, and every user's processes — but it still never writes system files or installs packages on its own: every root repair runs only after the owner says go to that exact repair (see "Admin mode" below). iPhones are excluded — this agent never touches one, ever.

## What this pack contains

| File | What it is |
|---|---|
| `SETUP.md` | This file. Start here. |
| `KUROdoctor-Authenticator-1.2.apk` | The Authenticator app, ready to install on the owner's Android phone. Install it first, then pair it (Step 2). No building needed. |
| `kuro-doctor-agent-linux-1.3.11.py` | The agent (stdlib-only Python 3, version "1.3.11"). |
| `repair-linux-1.3.6.py` | The Linux repair module (snapshot-first; the agent calls into it). |
| `kurodoctor-start-1.3.11.sh` | The launcher. Run it in Desktop Mode from Konsole on a Deck. |
| `relay-config.json` | The relay URL goes here. Ships blank (`{"relay_url": ""}`). |
| `TEST-PLAN.md` | The one-page test plan for the first run on the Deck. |

**This pack has no `relay/` folder.** The relay deploy files live in the
Windows pack's `relay/` folder (or the FULL pack's `windows/relay/`).
Deploy once from there (Step 1), then paste the same worker URL into this
pack's `relay-config.json`.

## What to ask the owner for (ask before you start)

You need four values from the owner's Cloudflare account. Ask for them
one at a time, in this order, and tell the owner where each one lives:

1. **Cloudflare account ID** — dashboard: open dash.cloudflare.com, the
   account ID is the 32-hex-character segment in the URL, or under the
   account menu top-right.
2. **API token** — dashboard: My Profile → API Tokens → Create Token.
   It needs **Workers Scripts:Edit** and **Workers KV Storage:Edit**.
   The owner pastes the token value to you once; never ask them to post
   it anywhere public, and never write it into any file in this pack.
3. **Worker name** — the owner picks one, e.g. `kurodoctor`. Their
   worker URL becomes `https://<name>.<subdomain>.workers.dev`.
4. **KV namespace ID** — dashboard: Workers & Pages → KV → Create a
   namespace (name it anything, e.g. `kurodoctor`). Copy the namespace
   ID it shows after creation.

Do not proceed until you have all four. Do not guess any of them.

## Step 1 — Deploy the relay

**Get the owner's explicit go first.** This replaces the named worker's
script and stores a secret + a KV value on their account. The deploy
script refuses to run without the approval gate (see below).

Deploy from the Windows pack's `relay/` folder (or the FULL pack's
`windows/relay/`) — the files are
`deploy-remote-endpoints-v1.4.0-blank.sh`, `deploy-worker-blank.py`,
`worker-base-blank.js`, `worker-auth-patch-v1.4.0-blank.js`,
`worker-remote-patch-v1.3.3-blank.js`, `worker-doctor-patch-blank.js`,
`set-worker-secret-blank.py`, `kv-put-blank.py`.

**What the script does, in order:**

- **Step 0 — secrets first.** It stores the DOCTOR_TOKEN as a worker
  secret and the pairing code in KV key `doctor:session:pairing`. If
  either PUT fails, the script aborts BEFORE uploading the worker
  (fail closed — never ship a worker whose token is not stored).
- **Steps 1–2 — merge.** It copies `worker-base-blank.js`, then inserts
  the three patches before the base worker's fallback line, in this
  order: **auth (v1.4.0) first, then remote control (v1.3.3), then the
  v1 doctor channel**. Order matters: the auth guard's
  `POST /doctor/command` handler runs first and returns `401`/`423`
  on failure, or falls through to the v1.3.3 handler on success.
- **Step 3 — verify.** It runs `node --check` on the merged file and
  greps that every doctor endpoint, KV key, command, repair function,
  uninstall/install kind, and auth error is present, and that the auth
  patch sits before the v1.3.3 patch. Any missing piece aborts the deploy.
- **Step 4 — deploy.** It uploads the merged worker with
  `deploy-worker-blank.py`, which also enables the workers.dev subdomain
  for the worker. The merged file is written to `relay/build/` (staging
  only).

**Run it** from the `relay/` folder, with the four values as environment
variables and the approval gate as a fifth:

```sh
cd relay
CLOUDFLARE_ACCOUNT_ID=<owner's account id> \
CLOUDFLARE_API_TOKEN=<owner's token> \
KURODOCTOR_WORKER_NAME=<owner's worker name> \
KURODOCTOR_KV_NAMESPACE_ID=<owner's KV namespace id> \
KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1 \
./deploy-remote-endpoints-v1.4.0-blank.sh
```

**Two things the script prints once — handle them exactly as follows:**

- **DOCTOR_TOKEN** — a random 32-byte hex token (64 hex characters).
  Generated by the script unless `DOCTOR_TOKEN` is passed in as an
  environment variable. Stored as a worker secret. **Save it where you
  keep secrets. Never write it into any file in this pack, any doc, or
  any chat the owner might share. The owner never sees or types it.**
  The script also saves it to `relay/.doctor-token` (chmod 600) in your
  copy — never share that file. It is the Muse-held write token: every
  `POST /doctor/command` must carry it as header `X-Doctor-Token`, or
  the relay answers `401 bad_token`. If the token is ever lost, re-run
  the deploy: unless `DOCTOR_TOKEN` is passed in, a fresh token is
  generated and stored, and the old one stops working.
- **Pairing code** — 12 random hex characters, stored in KV key
  `doctor:session:pairing`. **Give it to the owner once** so they can
  pair the Authenticator app (Step 2). It is used once, then thrown
  away. Never write it into any file in this pack.

**Safety facts the deploying Muse must know:**

- Treat the worker URL as sensitive until this deploy finishes. The
  URL alone cannot post a command once v1.4.0 is live (a command post
  needs the token AND an unlocked session — see Step 2), but the agent
  poll (`GET /doctor/command`) and the report read
  (`GET /doctor/latest`) are unauthenticated by design. Never post the
  URL anywhere public.
- The token + the Authenticator tap are what make the relay safe. The
  token proves a command came from the owner's Muse; the tap proves the
  owner approved the session. Neither alone is enough once a device is
  paired.
- **Migration rule:** this blank worker has no Durable Objects, so the
  deploy sends no migrations. If you ever deploy onto an existing
  worker that already has Durable Object classes registered, never
  re-send a migration for an already-registered class — the API answers
  HTTP 400 code 10074. Omit migrations on redeploys; a genuinely new
  Durable Object class needs its own one-time migration.
- **Subdomain:** `deploy-worker-blank.py` enables the workers.dev
  subdomain as part of the deploy. If the worker URL answers 404 after
  a deploy, check the subdomain is enabled for the worker before
  assuming anything else is wrong.

**Verify it worked:** the script prints each step, then `DONE.` and
`Your worker URL is https://<name>.<subdomain>.workers.dev`. Then
smoke-test the relay from any terminal (curl is enough — no agent
needed yet). Replace `<url>` with the worker URL, and use the token
from above as `$DOCTOR_TOKEN` on command posts. Command posts need the
token header; `GET /doctor/command` (the agent poll) does not.

```sh
curl <url>/doctor/latest
curl <url>/doctor/screenshot
curl -X POST <url>/doctor/command -H "X-Doctor-Token: $DOCTOR_TOKEN" -d '{"cmd":"ping"}'
curl -X POST <url>/doctor/command -d '{"cmd":"ping"}'
curl -X POST <url>/doctor/command -H "X-Doctor-Token: $DOCTOR_TOKEN" -d '{"cmd":"bogus"}'
curl -X POST <url>/doctor/command -H "X-Doctor-Token: $DOCTOR_TOKEN" -d '{"cmd":"exec","command":"mimikatz"}'
```

**Success looks like this:**

- `/doctor/latest` → `404` with `no_report` (nothing has reported yet).
- `/doctor/screenshot` → `404` with `no_screenshot`.
- `{"cmd":"ping"}` WITH the token → `200` with `ok:true` and a `position`.
- `{"cmd":"ping"}` WITHOUT the token → `401` with `bad_token`.
- `{"cmd":"bogus"}` with the token → `400` with `unknown_cmd`.
- `{"cmd":"exec","command":"mimikatz"}` with the token → `400` with `blocked`.

If the token-carrying ping returns `ok:true`, the relay is live and the
queue works. A device is not paired yet, so this is the token-only
safety valve (Step 2) — expected at this point. Then clean the test
command out of the queue before the agent starts: `GET <url>/doctor/command`
shows the queued ping; `POST <url>/doctor/received` with its `id` removes it.

If the script stops with `ERROR:` naming a missing variable, set that
variable and run it again. If it stops with
`STOP: ... PENDING THE OWNER'S APPROVAL`, the approval gate is not set —
get the owner's go, then re-run with `KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1`.
Nothing is uploaded until all checks pass.

## Step 2 — The token + pairing the Authenticator app

**The token (recap, so nothing is missed):** created in Step 1, stored
as the worker secret `DOCTOR_TOKEN`, saved by you where you keep secrets
(and in `relay/.doctor-token`, chmod 600, in your copy only). It lives
only with the owner's Muse — never in this pack, never shown to the
owner, never typed by the owner. Every `POST /doctor/command` carries
it as header `X-Doctor-Token`. No agent ever needs the token (agents
only poll and report).

**The Authenticator app v1.2** (`KUROdoctor-Authenticator-1.2.apk`, at
the root of this pack) is the approval half of v1.4.0. One job: receive
a session-approval request and let the owner tap **Approve** or
**Deny**. No location, no SOS, no family features, no Firebase, no
push server — it polls the relay every 5 seconds (outbound only, same
pattern as the doctor agent). The relay URL is entered at RUNTIME in
the app, never baked in — that is what makes the APK safe to ship in
this pack. The app stores only the relay URL the owner typed and the
device key the relay issued at pairing, in its private preferences. It
never holds the DOCTOR_TOKEN, any password, location, or contact. The
pairing code is used once and never stored.

**Pair it:**

1. The owner installs the APK on their Android phone (allow "install
   unknown apps" for the file manager once). On Android 13 and newer
   it asks once to allow notifications — tap **Allow**, or the phone
   cannot buzz when a session is requested with the app closed (the
   app still works while open, it just cannot alert). The only other
   permission it declares is INTERNET, granted at install.
2. You give the owner the **relay URL** (Step 1) and the **pairing
   code** (printed once by the deploy script).
3. The owner opens the app, pastes the relay URL into **Relay URL**
   (the full address, including its scheme) and the pairing code into
   **Pairing code**, and taps **Pair**. The relay returns a device key
   the app stores locally (endpoint `POST /doctor/session/pair`).

**Verify it worked:** the app shows "Paired with your relay" and
`Session: LOCKED`. A small persistent notification ("Watching for
session requests") appears and stays while the app is paired. The
background watch (v1.1) starts right away: a foreground service keeps
polling `GET /doctor/session/pending` every 5 seconds with the app
closed and raises a LOCAL notification (sound + vibration, Approve/Deny
buttons on it) the moment a pending session appears. It restarts after
a phone reboot (only if paired) and stops on unpair or relay change.

**If pairing fails**, the screen says why: "Relay answered 401" means
the pairing code is wrong (ask your Muse for the code again — it was
printed once at deploy; if it was already used, or the deploy was
re-run since, ask for a fresh deploy printout); "Could not reach the
relay" means the URL is wrong or the phone has no connection.

**Changing relay / unpairing:** changing the relay URL clears the
device key and goes back to the pairing screen with the old URL
prefilled — pair again with the new relay's pairing code. Unpairing
removes the relay URL and device key from the phone; the relay keeps
the device key on its side until cleared there, and an unpaired phone
simply stops polling, so it can never approve anything.

**Building from source (only if the owner wants to, not needed for
setup):** the app's source + build script live in the separate
Authenticator blank pack (`build_authenticator.sh`; needs the Android
SDK build-tools 34.0.0 + platform android-34 and JDK 17; output
`delivery/KUROdoctor-Authenticator-1.2.apk`; signing uses a
`debug.keystore` next to the script, generated on first build if
absent, or the path in `$KURODOCTOR_KEYSTORE`).

**Safety valve (so setup can never brick itself):** until the first
device is paired, the relay runs in token-only mode — commands need
only the token. Once a device is paired, commands need BOTH the token
AND an unlocked session. If the owner ever loses the phone, work in
token-only mode is possible only after the pairing is cleared on the
relay side — ask the owner's Muse; do not try to edit the relay by hand.

## Step 3 — Run the agent on the device

**First, point the agent at the relay.** File: `relay-config.json`.
It ships blank:

```json
{"relay_url": ""}
```

Open it and put the worker URL from Step 1 in `relay_url`. Keep the
`_comment` key — JSON has no comments, that key is the explanation.
Verify: `cat relay-config.json` shows the full `https://...` URL and
valid JSON (`python3 -m json.tool relay-config.json` prints it back).
If the agent is ever run with a blank `relay_url`, it prints a plain
message saying to set it and exits with code 2. That message means the
URL is not in the file yet — not that anything is broken.

**Copy the pack to the machine.** On a Steam Deck: switch to **Desktop
Mode**, open **Konsole**, and copy the whole pack folder into the home
directory, e.g. `~/kurodoctor/`. All files must sit together in the same
folder — the agent looks for `relay-config.json` and `repair-linux-1.3.6.py`
next to itself.

**Admin password — set it before the first run.** v1.3.11 runs as admin
(see "Admin mode" below): the launcher asks for elevation with a
graphical prompt and the owner types their own password into it. That
only works if a sudo password exists — set one in Konsole first
(`passwd`). Do not set it for them and do not assume it exists. With
no password set, elevation fails and the launcher falls back to
unprivileged mode (still a working doctor, just without dmesg, SMART,
and the full process list). Pacman uninstalls still refuse loudly
with `sudo_unavailable` when the gates do not pass — that is the agent
working as designed, not a bug.

**Run the launcher.** In Konsole, from the pack folder:

```sh
cd ~/kurodoctor
chmod +x kurodoctor-start-1.3.11.sh
./kurodoctor-start-1.3.11.sh
```

**What a healthy boot looks like** (stderr log lines):

```text
KUROdoctor agent v1.3.11 starting, relay=https://...
steamos=true root_readonly=true admin=true uid=0 home=/home/deck
sending report: model=... steamos=true root_readonly=true disks=[...] smart=...
report delivered
polling https://.../doctor/command -- 1s while active, 10s idle; on-demand reporting only (boot report once, no heartbeat)
```

`report delivered` is the success line. If the relay URL is blank, the
agent instead prints a plain message saying to set it and exits with
code 2 — that is also correct behaviour, just unfinished setup.

**One honest limit:** the Linux agent does NOT queue a report locally
if the relay is unreachable — the report lives only in the agent window,
and closing the window loses it. (The Android doctor app does queue
locally; the Windows/Linux agents do not.)

**Steam Deck notes (design truths, not workarounds):**

- **Read-only root:** SteamOS mounts `/` read-only. The agent checks
  `/proc/mounts` and refuses anything needing a system write. It never
  runs `steamos-readonly disable` itself.
- **pacman, not apt:** the repair module (`repair-linux-1.3.6.py`) is
  apt-based. On Arch/SteamOS, `system_files` repair reports honestly
  that it cannot install packages and returns a read-only `pacman -Qu`
  listing instead. `startup`, `temp`, and `defender_scan` (clamscan
  quarantine — MOVE, never delete) work the same on Arch.
- **Screenshot chain:** grim → spectacle → scrot → import → xwd,
  first one present wins. Spectacle is KDE's own screenshot tool,
  Wayland-native, and it ships on the Deck — on the live Deck
  (2026-11-22) grim, scrot, import, and xwd were all absent and
  spectacle was present, so spectacle is the expected one. It
  writes JPEG directly. v1.3.8: the live feed still needs a
  converter to shrink that JPEG -- spectacle's raw frame is
  275,527 bytes (~367,000 base64 chars) and the relay frame room
  rejects image_b64 over 100,000 chars (400 too_large), proven
  live 2026-11-22 -- and the converter is ffmpeg
  (/usr/bin/ffmpeg, present on the Deck): when `convert` is
  absent the agent scales frames with ffmpeg (50% / 25% / 12.5%
  at the 40KB cap, `-q:v 8`), run as the session owner when the
  agent is root. The agent runs as root, but on Wayland only the SESSION
  OWNER can ask KWin / the portal for a screenshot — root asking is
  ignored (proven live 2026-11-22: spectacle exits 1 as root with
  "On Wayland, Spectacle requires KDE Plasma's KWin compositor,
  which does not seem to be available", even with WAYLAND_DISPLAY,
  XDG_RUNTIME_DIR and DBUS_SESSION_BUS_ADDRESS all set). So when
  the agent is root and a session owner is detectable, each tool in
  the chain runs AS that user (`runuser -u <user> -- ...`, else
  `sudo -u <user> ...`) with the session env passed through, and
  the capture file goes in the session user's writable area, never
  `/root/.cache`. If the drop fails, the same tool is retried
  directly as root — never worse than v1.3.6. Unprivileged runs
  capture directly, unchanged. If none is installed the agent returns
  `screenshot_unavailable` loudly — it never installs anything.
- **Deck prerequisites for eyes (owner's step, agent never
  installs):** nothing to install for screenshots or the live feed
  — spectacle and ffmpeg already ship on the Deck. ImageMagick
  (`sudo pacman -S imagemagick`) is optional: with it the agent
  uses `convert` first for frames; without it (the Deck's actual
  state, proven live 2026-11-22: `convert`, `magick`, and `gm`
  all absent), or when `convert` fails on every scale, it scales
  frames with ffmpeg instead. If a Deck ever
  lacks spectacle or ffmpeg, that is a "tell Muse what is missing"
  answer, not a silent workaround.
- **Mouse/type:** need `xdotool`. If it is missing the agent returns
  `unavailable` loudly — never installed, never silent.

## Admin mode — what v1.3.6 adds (read before the first run)

v1.3.11 runs the agent as ADMIN (root) when it can, like the Windows
doctor — so it can see everything and do the root repairs the owner
approves. Nothing else about the doctor laws changes: admin does not
mean silent, and it does not mean automatic.

### HOW ADMIN WORKS — the elevation flow

The launcher (`kurodoctor-start-1.3.11.sh`) asks for elevation in
order, and stops at the first one that works:

1. **Already root** (`id -u` is 0): the agent runs directly, no prompt.
2. **kdesu present** (KDE / Deck Desktop Mode): a graphical prompt
   appears. The owner types THEIR OWN password into the KDE prompt —
   `kdesu -c "python3 <agent> <args>"`.
3. **kdesu absent but sudo present:** a terminal sudo prompt —
   `sudo -E python3 <agent> <args>`. Again, the owner types their own
   password at the prompt.
4. **Elevation declined or failed** (prompt cancelled, wrong password,
   or no elevation tool at all): the launcher runs the agent
   UNPRIVILEGED and prints a banner the owner must see:

   `KUROdoctor: Running WITHOUT admin -- dmesg, SMART and full process list unavailable.`

   The doctor still works — it just cannot see the three root-only
   sweep sections. Never a crash, never a silent fallback.

The launcher NEVER stores, logs, echoes, or auto-types the owner's
password: no password piped to sudo, no password on any command line,
no password in any file. If no sudo password is set at all (`passwd`
in Konsole sets one), elevation cannot succeed — the launcher falls
back to unprivileged mode, which is still a working doctor.

### STEAMOS HONESTY — what root can and cannot do

SteamOS mounts the root filesystem read-only by default. Admin does
NOT change that. What works with root alone:

- **Reads:** kernel log errors (`dmesg`), SMART drive health
  (`smartctl`), the full process list (`ps aux`, every user).
- **Service control:** `systemctl` start / stop / restart / enable /
  disable on ONLY the service units the owner names — and only after
  the owner says go to that exact repair.

What still needs read-only OFF (and is therefore still gated):

- **System file writes and package installs** (`pacman` install /
  remove). While `/` is read-only, a package install refuses — that
  refusal is the SteamOS gate working, not a failure. Do not treat it
  as one.
- Turning read-only off is the owner's step, done by hand in Konsole:
  `sudo steamos-readonly disable` (and `sudo steamos-readonly enable`
  to turn it back on afterwards). **The agent NEVER runs
  `steamos-readonly disable` itself** — not as admin, not ever.

### SMARTCTL — drive health needs the tool installed

The root SMART section reads drive health with `smartctl`. If
`smartctl` is not on the machine, the section reports
`smartctl_missing` and tells the owner how to fix it:

`sudo pacman -S smartmontools`

That is the owner's step, in Konsole, after the read-only gate above.
The agent never installs it itself — it reports the miss loudly and
moves on.

### Doctor laws, restated for root

- **Show-first / ok-gate still applies to every root action.** The
  app approval unlocks the SESSION; it does not approve any single
  fix. Every root repair (service control, pacman install/remove) is
  proposed in chat first and runs only after the owner says go to
  that exact repair. Admin changes what the agent CAN see and do, not
  what it MAY do without asking.
- **The blocklist holds as root.** Blocked commands (credential
  tools, `format` / `wipe`, disabling the read-only filesystem, and
  the rest) are still refused when the agent runs as root. Root does
  not bypass the blocklist.
- **Root repairs run through the existing repair flow only**
  (`repair-linux-1.3.6.py`, snapshot-first): service control and
  pacman install/remove of ONLY the packages the owner names — never
  a blind full upgrade. Both refuse `needs_admin` when the agent is
  not running as root.
- **Every action is audited, with the user id on the line.** The
  audit log on the machine records what ran, when, and what came
  back — each line carries `uid=`, so an as-root action is visible as
  one.


## Step 4 — First live test

Do this only after the owner has said in chat that you are in a session
(see "Chat go is the root of trust" in the rules below). Never request a
session the owner did not ask for in chat first.

1. **Request a session.** With the token header:
   `POST <url>/doctor/session/request` with body `{}`. Success:
   `{pending:true, session_id:"..."}`. The pending request lives 1 hour.
   Rate limit: 3 session requests per hour — a 4th returns `429`
   (see the failure table).
2. **The phone buzzes.** The Authenticator app raises a notification
   (sound + vibration), even with the app closed, with Approve/Deny
   buttons on it. Tapping the notification opens the app, which shows
   the same request. The owner taps **Approve** or **Deny**.
   Approve unlocks the session for 8 hours. Deny clears the request
   and the session stays locked. The app's status line always shows the
   truth: `Session: LOCKED` or `Session: UNLOCKED`.
3. **Send a ping.** With the token header:
   `POST <url>/doctor/command -d '{"cmd":"ping"}'`. Success:
   `{"ok":true,"id":"...","position":1}`. (Before pairing this worked
   token-only; now that a device is paired, it returns `423 locked`
   until the session is approved.)
4. **Read the ack.** `GET <url>/doctor/ack`. Success:
   `{"id":"...","done":true,"result":{"pong":true}}` — the agent saw
   the ping and answered it. Post one command at a time and wait for
   its ack before posting the next.
5. **Ask for the machine.** With the token header:
   `POST <url>/doctor/command -d '{"cmd":"sysinfo"}'`, then read the
   ack. Success: a report with real values (OS, CPU, RAM, disks), not
   an error. Then the doctor is live. A session unlock lasts 8 hours;
   the next session needs a fresh tap in the app.

**Smoke-test the queue/receipt flow once** (from any machine, token
header on command posts):

```sh
curl -s -X POST "$RELAY/doctor/command" \
  -H 'Content-Type: application/json' \
  -H "X-Doctor-Token: $DOCTOR_TOKEN" \
  -d '{"cmd":"exec","command":"uname -a","timeout_s":30}'
```

Expected: a `started` ack first (`done:true, started:true,
status:"running"`), then a completion ack carrying the `uname -a`
output. If only the `started` ack ever appears, the job path is
broken — report it, don't re-queue blindly. `GET $RELAY/doctor/report`
returns the agent's boot report JSON (`agent: kuro-doctor`,
`version: 1.3.11`, `sweep` with 11 sections: smart, disk_space,
startup_items, processes, temps, pending_updates, boot_time,
malware_scan, kernel_log, smart_root, processes_all).

**If a step fails:**

| Symptom | Cause | Fix |
|---|---|---|
| Command post `401 bad_token` | Token missing, wrong, or never stored | Use the token from Step 1; if the secret was never stored, re-run the deploy |
| Command post `423 locked` | No session approved yet (device paired) | Request a session (step 1 above), approve it in the app |
| Session request `429` | Rate limit: 3 session requests/hour used | Wait; a pending request lives 1 hour, an unlock 8 hours — do not hammer requests |
| Command post `400 queue_full` | The relay queue already holds 10 commands | Wait for the agent to drain it; do not force more in |
| Command post `400 unknown_cmd` | Command not in the allow-list | Check the name against the command list in the Windows pack's `docs/remote-control.md` |
| Command post `400 blocked` | Relay blocklist hit a credential-tool word | Reword the command; the blocklist lives on the relay only |
| Command post `400 bad_kind` / `bad_target` | Bad uninstall/install kind or target | See the install section below; kinds and name rules are enforced at the relay |
| `no relay URL is set` (exit 2) | `relay-config.json` still blank | Step 3 — paste the worker URL in |
| No boot report on the relay (`404 no_report`) | Agent not running, wrong URL, or no internet | Agent window still open? URL in `relay-config.json` correct? Connection up? Run the launcher again |
| Agent acks `target_running` on uninstall | The game/app is still running | Close it first, then send the uninstall again |
| Pairing: "Relay answered 401" | Wrong pairing code | Ask your Muse for the code printed once at deploy; a used code needs a fresh deploy printout (note: a fresh deploy also rotates the token unless `DOCTOR_TOKEN` is passed in) |
| Pairing: "Could not reach the relay" | Wrong URL or no connection | Check the URL, check the connection |
| Approve tapped, session still LOCKED | The request expired (1 hour) or was denied | Request a fresh session |
| No buzz on a session request | Notification permission off, or battery optimization killed the watch service | Settings → Apps → KUROdoctor Authenticator → Notifications ON; Battery → Unrestricted; the persistent "Watching" notification disappearing is the tell the service stopped — open the app once while paired to restart it |
| Deploy script `STOP: ... APPROVAL` | Approval gate unset | Owner's go, then `KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1` |
| Deploy script `ERROR: ... is not set` | A Cloudflare value missing | Ask the owner for that value (top of this file) |

## USB phone doctor

The phone plugs into the Deck (or Linux PC) over USB and the Deck
drives it with `adb`. Plug in, tap Allow once on the phone ("Always
allow from this computer"), then plug-and-go forever. No pairing
sheet, no 6-digit code, no wireless debugging anywhere in this flow.
One driver, one command set, identical on all three hosts.

### Install adb first (once)

On the Deck (SteamOS is Arch-based):

```
sudo pacman -S android-tools
adb version
```

Two honest gates, both the owner's choice, both outside this agent
(the agent never installs anything and never uses sudo itself):

- **Sudo password:** `sudo` needs the owner to have set a password
  first (`passwd` in Konsole). Without it, pacman refuses.
- **Read-only root:** SteamOS mounts `/` read-only by default. If
  pacman complains the filesystem is read-only, the owner runs
  `sudo steamos-readonly disable` first, installs, and can re-enable
  afterwards with `sudo steamos-readonly enable`. The agent never
  touches this setting itself.

Verify it worked: `adb version` prints a version, and with the phone
plugged in, `adb devices` lists it.

### On the phone (once)

1. Turn on **USB debugging** (Settings → Developer options → USB
   debugging). Developer options is off by default — tap the build
   number 7 times in Settings → About phone to turn it on.
2. Plug the phone into the Deck over USB.
3. The phone asks "Allow USB debugging?" — tap **Allow**, and tick
   **"Always allow from this computer"** so it only asks once.

### What Muse can ask the agent to do

- **`phone_checkup`** (no arguments): read-only phone health — model,
  Android version, SDK, storage, battery, RAM, app count. One compact
  ack. This is the same set of fields the standalone phone app
  reports.
- **`phone_repair`** (`kind` + `package`): one of `clear_cache`
  (`pm clear`), `disable` (`pm disable-user --user 0`), `force_stop`
  (`am force-stop`), `uninstall` (`pm uninstall --user 0`). The ack
  carries before/after state (installed? disabled? running?) so Muse
  can see what actually changed. None of these four commands can
  delete documents or photos — nothing here touches user files on
  the phone.

### What the errors mean

- **`adb_missing`** — adb is not installed on this machine. Install
  it with `sudo pacman -S android-tools` (above) and try again.
- **`no_device`** — no phone is plugged in (or USB debugging is off).
  Plug it in, check USB debugging, try again.
- **`unauthorized`** — the phone is plugged in but has not allowed
  this computer yet. Tap **Allow** on the phone (tick "Always allow
  from this computer" so it only asks once), then send the command
  again. Nothing ran on the phone.
- **`protected_package`** — the package is in the protected set and
  is refused in the agent as well as on the relay: the doctor app
  itself, `android`, the system UI, the phone, settings, the package
  installer, Play services. Nothing ran.
- **`bad_kind` / `bad_package`** — the kind is not one of the four,
  or the package name is not a real dotted package name (1–200
  chars). The relay validates these too before queueing.

### Relay note

`phone_repair` is already on the relay (v1.4 phone patch).
`phone_checkup` needs the relay's v1.4.1-usb patch — if Muse sends
`phone_checkup` and the relay answers `unknown_cmd`, that patch is
not deployed yet. Agent and relay must move together.

## Standing rules — these never change

- **Two factors, both required:** the token proves a command came from
  Muse; the app tap proves the owner approved the session. A post with
  no token gets `401`; a post with a token but a locked session gets
  `423`. Neither factor alone is enough once a device is paired.
- **Show-first / ok-gate:** every fix is proposed in chat first and
  runs only after the owner says go to that exact fix. Never run a
  fix the owner has not ok'd by name. The app approval unlocks the
  SESSION — it does not approve any single fix.
- **Chat go is the root of trust for sessions:** a session is only
  legitimate if the owner told their Muse in chat first. A surprise
  session — a pending or approved session the owner's Muse did not
  request after the owner's chat go — means it wasn't us. Stop and
  verify with the owner in chat before acting on any approval.
- **Never delete user documents or photos.** Desktop shortcut deletes
  (`.lnk` files only, Windows) need the `owner_override` flag on the
  exec command — see the Windows pack's `docs/remote-control.md`.
- **No reboot, shutdown, wipe, format, or reinstall** without the
  owner's explicit ok for that named step.
- **No lock-screen or password bypass, no saved-credential digging,
  no other people's machines, no iPhones, ever.**
- **No remote action without an audit entry.** Every action is written
  to an audit log on the machine — what was run, when, and what came
  back. Never type into a password or login field.
- **Polling (v1.3.11):** 1s while a command is active, 10s when idle,
  no periodic heartbeat -- the 60s heartbeat was removed because its
  1,440 KV writes/day alone exceed Cloudflare KV's 1,000 writes/day
  free-tier cap. Idle costs about 8,640 Cloudflare requests/day
  (reads only -- zero KV writes at idle), well under the 100,000
  free cap.
- **Agent and relay move together:** a v1.3.0-or-older agent against a
  v1.3.3 relay runs only the first queued command and then stalls (it
  never sends the receipt that pops the queue).

## The install command (v1.3.2)

`install` mirrors `uninstall` exactly: same relay validation, same
prechecks (tool present, already-installed short-circuit), audit-log
entry before running, async started + completion acks, verify-after-
install, never trusts exit codes alone. A failed verification reports
`status: failed` even when the installer exited 0. An EXE install with
no name is honestly unverifiable and reports failed even on installer
exit 0.

**Relay validation:** `kind` is required, one of
`steam | msi | appx | app | brew | flatpak | pacman | winget | exe`.
`name` is optional but, when present, must be a string ≤200 chars with no
backslash, no slash, and no `..`. `appid` is optional, an integer,
steam only. `path` / `url` are msi/exe only, never winget; `args` is
exe only. Winget requires a `name`; msi/exe require a `path` or `url`.
Anything else gets `400 bad_kind` / `400 bad_target`. The relay stores
and passes through `path`, `url`, and `args` for msi/exe installs.

**Per platform (agent side):**

- **Linux (this pack):** kinds `brew | flatpak | pacman`, by name. No
  apt. On a Steam Deck the pacman path runs `sudo -n pacman` only when
  BOTH gates pass (root filesystem writable AND working passwordless
  sudo) — both refuse by default on a stock Deck, where root is
  read-only.
- **Windows:** agent kinds are `winget | msi | exe`. Winget installs by
  name (`winget list` precheck + verify); MSI installs an `.msi` file
  (path or URL); EXE runs an `.exe` installer (path or URL, optional
  `args` string, e.g. `/S` — without args the installer runs as-is and
  may show its wizard). EXE has no reliable precheck and skips it.
- **Mac:** kind `brew` only, by name.

**Windows install — fixed in v1.3.3:** Windows install now works end
to end for `winget | msi | exe`. The relay accepts all three kinds
and passes `path`, `url`, and `args` through to the agent (msi/exe
take a `path` or `url`; exe takes optional `args`; winget installs by
name only). `steam` / `appx` install is NOT supported by the Windows
agent — its install kinds are `winget | msi | exe` only, so a
`steam`/`appx` install request passes the relay but is refused by
the agent. Install works end to end today for Windows
(`winget`/`msi`/`exe`), Linux (`brew`/`flatpak`/`pacman` by name), and
Mac (`brew` by name).

**Linux kind asymmetry (kept as designed):** install is
`brew`/`flatpak`/`pacman` while uninstall is `flatpak`/`pacman`/`app`
(brew is install-only, app is uninstall-only).

**The Windows steam registry fix (v1.3.2):** a steam uninstall now
removes the Programs-and-Features registry key from both roots
(including Wow6432Node), reads both back (`verify_registry_gone`), and
the final ok requires folder + appmanifest + registry ALL gone. MSI
and AppX removals are unchanged (they do proper removals). Note: a
steam uninstall now FAILS when the registry entry cannot be removed
(e.g. a non-admin run) even though folder + manifest are gone — steam
uninstalls effectively need admin when a registry entry exists.


## What changed in v1.3.11

- **On-demand reporting only -- the periodic heartbeat is gone.** The
  60s heartbeat (1,440 KV writes/day) alone exceeded Cloudflare KV's
  1,000 writes/day free-tier cap and killed the relay (POST
  /doctor/command -> 1101). The agent now posts one boot report at
  startup (retried on poll iterations ONLY until it first lands, then
  never again) and otherwise reports only when commanded -- status
  comes from ping / sysinfo acks. Idle traffic is ~8,640 polls/day
  (reads only -- zero KV writes at idle). Nothing else changed:
  full-access rules, phone driver, launch, live-feed frames, poll
  intervals, --once mode, and the repair module are all untouched.

## What changed in v1.3.10

- **Full access with the owner's go:** when the owner gives an explicit,
  specific go naming the action and the exact target, that IS the
  authorization — the agent must not refuse it on its own blocklists.
  Muse stamps the relay command with an `owner_go` object,
  `{"action": "<verb>", "target": "<exact target string>"}`, and the
  agent verifies the stamp's target matches the command's actual
  target exactly (same path normalisation the blocklist uses).
  Verbs: `rm` (protected path), `write` (trust destination),
  `wipe` (wipe / format / diskpart / cipher /w, mkfs, shred, wipefs,
  blkdiscard, dd to a device), `crontab` (installing a crontab
  file), `systemctl` (mutating `systemctl --user`, exact unit name).
  Without a stamp, or with a stamp naming a different target, those
  stay refused — and a vague command with no exact target ("clean it
  up") is refused asking for the exact target. The stamp NEVER
  authorises credential dumping, lock-screen / password bypass,
  `net user` password changes, shutdown / reboot, bcdedit, or
  flashing tools — those stay refused regardless. The started ack
  restates the stamp's exact target when the stamp is what
  authorised the run. Show-first is unchanged: the doctor still
  shows him what is about to happen so he can ok that exact action.
- **runuser / sudo -u via exec, drop only:** allowed ONLY to drop
  to the detected session user (name only — never root, never
  another user, never `-c`, which runs through a shell). The inner
  command must itself pass the full blocklist. `env` and `su`
  stay refused.
- **flatpak uninstall --delete-data:** allowed — v1.3.9 falsely
  refused it (the word "delete" in the flag plus "desktop" in the
  app id tripped the profile-folder rule; the rule now fires only
  when a segment's head IS a delete verb).
- **Launch an executable, plus launch args:** `launch` accepts an
  executable file path too (AppImage / script / binary under the
  session user's home or /opt — system binaries and temp dirs
  refused, wiping-tool basenames refused), run as the session user
  with the same blocklist checks. It also accepts an optional
  `args` list (argv only, each arg block-checked — the flag path
  for `--ozone-platform=x11`). `python3 -c` stays refused: the
  sanctioned write path is `cp` / `tee` / `install` to a
  non-trust destination. The relay must forward the optional
  `owner_go` object with the command — that part is not verified
  live yet, same as the launch patch.

## What changed in v1.3.9

- **Launch a GUI app as the session user:** new `launch` kind —
  `{"cmd": "launch", "desktop": "/path/to/app.desktop"}`. The root
  agent could not open a GUI app as the session user: exec refuses
  runuser / env / su / sudo, and launching flatpak as root breaks
  the sandbox (proven live 2026-11-22: bwrap "Can't find source
  path /proc/self/fd/21: Permission denied"). Launch reads a real
  installed app's .desktop file, parses its Exec line, strips
  field codes (%u %U %f %F %i %c %k, flatpak @@u @@), and runs it
  detached via the same session-user drop the screenshot chain
  uses (`runuser -u <user> -- ...`, session env passed through).
  Narrow by design: the file must live in a real XDG application
  dir, and the parsed Exec argv must pass the same blocklist exec
  applies — launch can only run what exec could run, as the
  session user instead of root. No root fallback. The exec
  blocklist is unchanged. The relay patch for `launch`
  (`relay/worker-launch-patch-v1.3.9.js`) is built but NOT
  deployed — until it is, the live relay answers launch with
  `unknown_cmd`.
- **Mouse clicks work end to end:** the relay (v1.3.4) sends
  left_click / right_click / double_click, but the agent accepted
  only move / click / move_click — only "move" passed both, so no
  click ever worked. cmd_mouse now accepts the relay names too
  (left_click = move + button 1, right_click = move + button 3,
  double_click = move + two button-1 clicks) and keeps the old
  names for compat. xdotool is X11-only: on a Wayland session it
  needs an XWayland DISPLAY, and a xdotool that cannot open a
  display fails plainly (`mouse_failed`) — never a fake ok. That
  Wayland half is still unproven live.
- **Flatpak install is explicit:** the install kind ran
  `flatpak install -y <appid>` with no remote and no scope, and
  on the Deck flathub exists in BOTH installations (system +
  the owner's user one), so flatpak could not resolve the remote
  and aborted with "No remote chosen to resolve matches". The
  doctor now installs `flatpak install -y --system flathub
  <appid>`, and the already-installed precheck queries BOTH
  scopes, so a user-scope install counts as already installed
  instead of the doctor adding a system duplicate next to it.
  Uninstall is scope-aware too: it finds every scope the app is
  in and removes each with `flatpak uninstall -y --<scope>
  <id>`, saying which. The duplicate remote stays (the owner's
  choice — their own apps live in the user installation).

## What changed in v1.3.8

- **Live-feed frames via ffmpeg:** v1.3.7's screenshot works on the
  Deck (spectacle as the session owner, real 275,527-byte JPEG,
  proven live 2026-11-22) but the live feed failed: every POST
  /doctor/frame got HTTP 400, because the relay frame room rejects
  image_b64 over 100,000 chars (400 too_large) and the raw JPEG is
  ~367,000 chars. `convert` / `magick` / `gm` are all absent on the
  Deck, so v1.3.7 had nothing to shrink it with and returned the raw
  JPEG as-is. v1.3.8 scales with ffmpeg (/usr/bin/ffmpeg, proven
  present on the Deck) when `convert` is absent: same 50% / 25% /
  12.5% ladder at the 40KB cap (`ffmpeg -y -i <in> -vf scale=<w>:-2
  -q:v 8 <out>`), run as the session owner when the agent is root,
  output in the session user's tmpdir. Raw-as-is survives only when
  no converter exists or every conversion fails, and then the agent
  logs (once per minute) that the frame will likely be rejected as
  too_large. `convert` first, ffmpeg next if convert yields nothing;
  nothing else changed.
- **Queue-head un-wedge:** live 2026-11-22, exec 485e1d91 was
  executed and acked but its received-pop did not take effect, and
  every later poll returned the same head id, which the agent
  skipped forever via seen_ids -- the queue wedged until a human
  posted /doctor/received by hand. v1.3.8 re-posts /doctor/received
  for an already-seen head id (best-effort, once per poll, logged
  at most once per id per minute) before skipping it, and never
  executes on the skip path.

## What changed in v1.3.7

- **Eyes capture as the session user:** on Wayland only the session
  owner can ask KWin / the portal for a screenshot — the root agent
  asking is ignored (v1.3.6 failed live on 2026-11-22: spectacle
  exits 1 as root, "On Wayland, Spectacle requires KDE Plasma's
  KWin compositor, which does not seem to be available", even with
  WAYLAND_DISPLAY, XDG_RUNTIME_DIR and DBUS_SESSION_BUS_ADDRESS all
  set). When the agent is root and a session owner is detectable,
  each tool in the screenshot chain now runs AS that user
  (`runuser -u <user> -- ...`, else `sudo -u <user> ...`) with the
  session env passed through, and the capture file goes in the
  session user's writable area, never `/root/.cache`. If the drop
  fails, the same tool is retried directly as root — never worse
  than v1.3.6. Unprivileged runs capture directly, unchanged.
  The repair module is reused unchanged (`repair-linux-1.3.6.py`).
- **Honest limit:** the as-user capture was proven against fake
  screenshot shims only (38 checks passing on the build machine,
  including a real `runuser` drop to another user). It has never run
  against a real Deck — that is the owner's test (TEST-PLAN.md
  steps 5–6).

## What changed in v1.3.6

- **Admin mode:** the agent now runs as root when it can, like the
  Windows doctor. The launcher asks for elevation (kdesu graphical
  prompt on the Deck, sudo terminal fallback); the owner types their
  own password, and the launcher never stores, logs, echoes, or
  auto-types it. Declined or failed elevation falls back to
  unprivileged mode with a printed banner — the doctor still works,
  just without the root-only sections. See "Admin mode" above.
- **Three new root-only sweep sections** (the sweep is now 11
  sections, sweep_version 2): `kernel_log` (dmesg error lines),
  `smart_root` (SMART drive health via smartctl), and `processes_all`
  (`ps aux`, every user, top 10 by CPU and memory). Unprivileged,
  each one reports `unavailable` with reason `needs admin` — never
  faked data.
- **Root repairs, same rules:** `repair` now does `service`
  (systemctl start / stop / restart / enable / disable on named units
  only) and `pacman` (install / remove of ONLY the named packages,
  never a blind full upgrade), both through the existing
  snapshot-first repair flow (`repair-linux-1.3.6.py`). Both refuse
  `needs_admin` when the agent is not running as root. The blocklist
  holds as root, and the audit log carries `uid=` on every line.
- **SMARTCTL:** if `smartctl` is missing, the root SMART section says
  so and gives the install command (`sudo pacman -S smartmontools`) —
  the owner's step, never the agent's. A package install still
  refuses while the SteamOS root filesystem is read-only; that
  refusal is the gate working, not a failure.
- **Honest limit:** the admin flow was proven by the builder's test
  run only (179 checks passing on the build machine, including the
  elevation fallback, the needs_admin gates, and the repair
  dry-runs). It has never run against a real Deck with a real kdesu
  prompt — that is the owner's test (TEST-PLAN.md steps 1–3 and 8).

## What changed in v1.3.5

- **USB phone doctor:** the agent now drives an Android phone over
  USB with `adb` — two new commands, `phone_checkup` (read-only
  health: model, Android version, SDK, storage, battery, RAM, app
  count) and `phone_repair` (`clear_cache` / `disable` / `force_stop`
  / `uninstall` for one package, with before/after state in the
  ack). Plug in, tap Allow once on the phone ("Always allow from
  this computer"), then plug-and-go forever — no pairing sheet, no
  6-digit code, no wireless debugging. `adb` comes from
  `sudo pacman -S android-tools` on the Deck (see "USB phone doctor"
  above for the sudo / read-only-root gates); the agent never
  installs it itself. Missing adb acks `adb_missing`, no phone acks
  `no_device`, not-allowed-yet acks `unauthorized` ("tap Allow on
  the phone"). The protected set (doctor app, system UI, phone,
  settings, installer, Play services) is refused in the agent as
  well as on the relay, and the four repair commands cannot delete
  documents or photos.
- **Honest limit:** the USB phone driver was proven against a fake
  `adb` shim only (device / unauthorized / no-device / adb-missing,
  all four repair kinds, protected-set refusal). It has never run
  against a real phone on a real Deck — that is the owner's test
  (TEST-PLAN.md step 6).

## What changed in v1.3.4

- **Type focuses its window first:** the `type` command now accepts an
  optional `process` field (for example `"notepad++"` on Windows, or a
  process name on this machine). When it is given, the agent focuses
  that program's window (via `xdotool`) before typing, so typed text
  lands in the right window instead of wherever focus happened to be.
- **Live-feed frame sender:** the agent now sends change-only screen
  frames to the relay — at most 1 frame per 5 seconds, and only when
  the screen actually changed. Frames go to a new relay room
  (`DoctorFrameRoom`, a SQLite-backed Durable Object: free-tier,
  in-memory only, zero KV writes), readable at `GET /doctor/frame`.
- **The live feed ships in the pack's single deploy.** The deploy
  script in the Windows pack's `relay/` folder already merges the
  v1.3.4 patch + frame room — deploy once (Step 1) and the feed works;
  there is no second v1.3.4 deploy to wait for. The relay is v1.4.0
  auth + v1.3.3 patch + v1.3.4 frame room once that deploy has run,
  and the feed was already proven live end to end on Windows (frames
  flowing from the HP).
- **One live feed at a time:** run only one agent's feed at a time.
  Three agents feeding at once would exceed the Cloudflare free tier.
- **Honest limits:** the Deck screenshot chain is proven now --
  spectacle as the session owner produced a real 275,527-byte JPEG
  live 2026-11-22 -- but the live feed has still never posted a
  frame from a real Deck: v1.3.7's raw JPEG was rejected by the
  frame room (400 too_large, 100,000-char cap), and v1.3.8's ffmpeg
  scaling is the fix for exactly that. Live Deck proof still
  pending: a real frame at `/doctor/frame`. If no frames post,
  report that, don't work around it silently. `xdotool` (mouse/type
  + window focus) is X11-only.

## Honest verification status

- The relay (v1.4.0 auth + v1.3.3 patch + v1.3.4 frame room) and the
  Authenticator loop (request → phone buzz with the app closed →
  approve → command accepted → agent exec) were proven live end to
  end against the Linux agent, and the live feed was proven end to
  end on Windows (frames flowing from the HP). The v1.3.7 Linux agent
  HAS now run on a real Steam Deck (screenshot proven live
  2026-11-22; live feed failed with 400 too_large, which v1.3.8
  fixes with ffmpeg). The v1.3.8 agent itself has never run on a
  real Deck yet — report what you actually see at each step, not
  what should happen.
- The repair module never silently no-ops: the Linux repair is
  snapshot-first (manifest + backup, stops if it cannot be written);
  every repair writes an audit entry + before/after JSON.
- `exec` output is capped at 20 KB, timeout default 60s (clamp 1–300).
  `format` / `wipe` match as whole words in the blocklist, so
  "Information" no longer false-blocks.
- Nothing in this pack is priced, published, or sent anywhere.
