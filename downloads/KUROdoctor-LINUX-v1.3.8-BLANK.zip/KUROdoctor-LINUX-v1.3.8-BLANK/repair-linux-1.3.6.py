#!/usr/bin/env python3
"""KUROdoctor -- Linux repair module v1.3.6 (stdlib only, Python 3).

v1.3.6 adds two ADMIN-ONLY repairs, run only after the owner has
heard the plain-language report and said go for that specific
repair, and only when the agent itself runs as root:
  service-control -- systemctl start|stop|restart|enable|disable
    on ONLY the service units the owner names with --target.
  pacman-repair -- install ONLY the packages the owner names with
    --package (or remove them with --remove); never a blind full
    upgrade, never -Syu. Refuses loudly when not root, when
    pacman is missing, or when the root filesystem is read-only.
The agent NEVER runs `steamos-readonly disable` -- the owner does
that himself when he chooses to.

Plain-English protocol (the Doctor's Protocol, docs/doctor-protocol.md):
  1. Diagnose FIRST. Nothing in this file diagnoses -- it only repairs,
     and only after the owner has heard the plain-language report and
     said go for that specific repair.
  2. Report first, owner go per repair. No repair changes anything
     unless the caller passes --go -- the flag the caller passes only
     after the owner says go for that repair. --dry-run never needs
     --go and never changes anything: it only prints what WOULD happen.
  3. Files rescued first. Repairs never touch user documents or photos
     (never ~/Documents, ~/Pictures, or any user documents/photos).
  4. Snapshot / rollback before changes. The `snapshot` repair runs
     FIRST, always: it writes a manifest and backs up every file the
     other repairs may change into /tmp/kurodoctor-repair-backup-<ts>/.
     If the backup cannot be written, this module says so plainly and
     STOPS -- no other repair in that run proceeds. A non-snapshot
     repair run with --go takes a snapshot first itself when none
     exists yet in /tmp.
  5. Audit log of everything done. Every real repair writes one entry
     (timestamp, repair name, target, before/after, result) to
     repair-audit.log next to this script, and prints a small JSON
     result object ({repair, status, before, after, detail}) to stdout.
     A dry run writes NOTHING to disk -- not even the audit log; it
     prints the audit entry it WOULD have written instead.
  6. Never auto-run on connect. Nothing here runs by itself. One
     repair at a time, chosen with --repair <name>, after the owner's go.
  7. No reinstall, no wipe, no reboot without the owner's explicit go
     for that step. There is NO reboot or shutdown call in this file
     at all, no reinstall, and no wipe -- this module repairs in place
     only, and it never does a blind full upgrade.

What this module does NOT do (named next steps, not in this slice):
  - Mac / Android deep repair. Those patients get their own repair
    modules later; this file is Linux only.
  - No lock-screen / password bypass, no root / jailbreak, no remote
    screen takeover, no touching a device unless its owner installed
    or ran the agent and said go. No iPhones, ever.

Usage:
  python3 repair-linux-1.3.6.py --help
  python3 repair-linux-1.3.6.py --list
  python3 repair-linux-1.3.6.py --dry-run --repair snapshot
  python3 repair-linux-1.3.6.py --dry-run --repair apt-repair
  python3 repair-linux-1.3.6.py --go --repair temp-cleanup
  python3 repair-linux-1.3.6.py --go --repair apt-repair --package curl --package git
  python3 repair-linux-1.3.6.py --go --repair startup-cleanup --target dropbox.desktop
  python3 repair-linux-1.3.6.py --go --repair startup-cleanup --target myservice.service
  python3 repair-linux-1.3.6.py --go --repair malware-quarantine

100% our own code and text. No bundled tools, no third-party agent.
Only the tools already on the machine are used (apt-get, systemctl,
clamscan); nothing is installed by this module except packages the
owner names with --package.
"""

import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

# Files larger than this are recorded in the snapshot manifest by
# path + size + hash only, never copied (a repair backup must stay small).
SMALL_FILE_LIMIT = 1024 * 1024  # 1 MB

# Temp/cache files changed in the last hour are treated as in use and
# left alone by temp-cleanup.
RECENT_FILE_SECONDS = 3600

# Malware scan timeout, matching the doctor protocol's scan budget.
SCAN_TIMEOUT_SECONDS = 1800

REPAIRS = {
    "snapshot": (
        "Back up the files other repairs may change, and write a manifest, "
        "before anything is touched."
    ),
    "apt-repair": (
        "List upgradable packages; install ONLY packages the owner names "
        "with --package, never a blind full upgrade."
    ),
    "temp-cleanup": (
        "Clean temp and cache files in /tmp and ~/.cache only, with "
        "before/after byte counts."
    ),
    "startup-cleanup": (
        "Disable ONLY the startup items the owner names with --target, "
        "by exact name."
    ),
    "malware-quarantine": (
        "Scan with clamscan if it is installed, and MOVE infected files "
        "to quarantine -- never delete them."
    ),
    "service-control": (
        "ADMIN ONLY: systemctl start|stop|restart|enable|disable ONLY "
        "the service units the owner names with --target, after --action."
    ),
    "pacman-repair": (
        "ADMIN ONLY: install ONLY the packages the owner names with "
        "--package (or remove them with --remove); never a blind full "
        "upgrade, never -Syu."
    ),
}


def now_iso():
    return datetime.datetime.now().astimezone().isoformat()


def stamp():
    return datetime.datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")


def audit_log_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "repair-audit.log")


def write_audit(repair, target, before, after, status, detail, dry_run):
    """Write one audit-log entry. In a dry run, print it instead and
    write nothing to disk -- a dry run changes nothing at all."""
    entry = {
        "timestamp": now_iso(),
        "repair": repair,
        "target": target,
        "before": before,
        "after": after,
        "result": status,
        "detail": detail,
    }
    if dry_run:
        print("[dry run] audit entry that WOULD be written to "
              "repair-audit.log:")
        print(json.dumps(entry, indent=2))
        return entry
    line = json.dumps(entry)
    try:
        with open(audit_log_path(), "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError as exc:
        print("KUROdoctor: WARNING -- could not write the audit log "
              "({}). The entry was: {}".format(exc, line),
              file=sys.stderr)
    return entry


def result(repair, status, before, after, detail):
    """One JSON result object, printed to stdout by the caller."""
    return {
        "repair": repair,
        "status": status,
        "before": before,
        "after": after,
        "detail": detail,
    }


def emit(res, dry_run):
    """Print the result object as JSON. Exit code: 0 on ok/dry_run,
    1 on failed, 2 on skipped/refused (nothing was done)."""
    print(json.dumps(res, indent=2))
    if res["status"] == "ok" or res["status"] == "dry_run":
        return 0
    if res["status"] == "failed":
        return 1
    return 2


def sha256_of(path):
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def files_maybe_changed():
    """Files the other repairs may change. The snapshot backs these up.
    Temp/cache files are disposable by definition and are NOT backed up;
    installed packages are recorded by name + version, not by copying
    system files."""
    home = os.path.expanduser("~")
    candidates = []
    # Autostart entries (user + system) -- startup-cleanup may rewrite them.
    for base in (os.path.join(home, ".config", "autostart"),
                 "/etc/xdg/autostart"):
        try:
            for name in sorted(os.listdir(base)):
                if name.endswith(".desktop"):
                    candidates.append(os.path.join(base, name))
        except OSError:
            pass
    # systemd user units -- startup-cleanup may disable them.
    for base in (os.path.join(home, ".config", "systemd", "user"),
                 "/etc/systemd/user"):
        try:
            for name in sorted(os.listdir(base)):
                if name.endswith((".service", ".timer", ".socket")):
                    candidates.append(os.path.join(base, name))
        except OSError:
            pass
    return candidates


def existing_backup_dirs():
    return sorted(
        d for d in os.listdir("/tmp")
        if d.startswith("kurodoctor-repair-backup-")
        and os.path.isdir(os.path.join("/tmp", d))
    )


# ---------------------------------------------------------------------------
# snapshot -- FIRST, always
# ---------------------------------------------------------------------------
def do_snapshot(dry_run):
    repair = "snapshot"
    backup_dir = os.path.join("/tmp", "kurodoctor-repair-backup-" + stamp())
    candidates = files_maybe_changed()
    before = "{} file(s) may be changed by later repairs".format(len(candidates))
    if dry_run:
        detail = (
            "Would create backup dir {} and copy each listed file into it "
            "(files over 1 MB are recorded by path + size + hash only, not "
            "copied). Temp/cache files are not backed up -- they are "
            "disposable. No package files are copied; installed package "
            "versions are recorded in the manifest instead. "
            "Files that would be backed up: {}. "
            "Nothing changed.".format(
                backup_dir,
                ", ".join(candidates) if candidates else "(none found)"))
        res = result(repair, "dry_run", before,
                     "no change (dry run)", detail)
        write_audit(repair, backup_dir, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    # Real run: create the backup dir first. If it cannot be written,
    # say so plainly and STOP -- nothing else in this run proceeds.
    try:
        os.makedirs(backup_dir)
    except OSError as exc:
        detail = ("FAILED to create the backup dir {}: {}. STOPPING -- "
                  "no repair will run without a snapshot first.".format(
                      backup_dir, exc))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no backup made",
                     detail)
        write_audit(repair, backup_dir, before,
                    "no change -- no backup made", "failed", detail,
                    dry_run=False)
        return emit(res, dry_run)

    manifest_files = []
    copied = 0
    recorded_only = 0
    for path in candidates:
        entry = {"path": path}
        try:
            size = os.path.getsize(path)
            entry["size_bytes"] = size
            entry["sha256"] = sha256_of(path)
        except OSError as exc:
            entry["error"] = str(exc)
            manifest_files.append(entry)
            continue
        if size <= SMALL_FILE_LIMIT:
            try:
                shutil.copy2(path, os.path.join(
                    backup_dir, os.path.basename(path)))
                entry["backed_up_to"] = os.path.join(
                    backup_dir, os.path.basename(path))
                copied += 1
            except OSError as exc:
                entry["error"] = "copy failed: {}".format(exc)
        else:
            entry["backed_up_to"] = None
            entry["note"] = ("over 1 MB -- recorded by path + size + hash "
                             "only, not copied")
            recorded_only += 1
        manifest_files.append(entry)

    # Record installed package versions (names only, no system files).
    packages = []
    try:
        out = subprocess.run(["dpkg-query", "-W", "-f=${Package} ${Version}\n"],
                             capture_output=True, text=True, timeout=60)
        if out.returncode == 0:
            packages = [line for line in out.stdout.splitlines() if line]
    except (OSError, subprocess.SubprocessError):
        packages = []

    manifest = {
        "timestamp": now_iso(),
        "backup_dir": backup_dir,
        "files": manifest_files,
        "installed_packages_recorded": len(packages),
    }
    try:
        with open(os.path.join(backup_dir, "manifest.json"), "w",
                  encoding="utf-8") as fh:
            json.dump(manifest, fh, indent=2)
        with open(os.path.join(backup_dir, "packages.txt"), "w",
                  encoding="utf-8") as fh:
            fh.write("\n".join(packages) + ("\n" if packages else ""))
    except OSError as exc:
        detail = ("FAILED to write the snapshot manifest in {}: {}. "
                  "STOPPING -- the backup is incomplete, so no repair "
                  "will run.".format(backup_dir, exc))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before,
                     "backup dir created but manifest incomplete", detail)
        write_audit(repair, backup_dir, before,
                    "backup dir created but manifest incomplete", "failed",
                    detail, dry_run=False)
        return emit(res, dry_run)

    after = ("backup dir {}; {} file(s) copied, {} recorded by hash only"
             .format(backup_dir, copied, recorded_only))
    detail = ("Snapshot saved to {}. {} file(s) copied, {} recorded by "
              "path + size + hash only, {} installed package version(s) "
              "recorded. If a later repair goes wrong, these files can "
              "be put back from here.".format(backup_dir, copied,
                                              recorded_only, len(packages)))
    print("KUROdoctor: " + detail)
    res = result(repair, "ok", before, after, detail)
    write_audit(repair, backup_dir, before, after, "ok", detail,
                dry_run=False)
    return emit(res, dry_run)


def ensure_snapshot(dry_run):
    """A non-snapshot repair run with --go takes a snapshot first when
    none exists yet in /tmp. Returns (ok, backup_dir_or_error)."""
    if existing_backup_dirs():
        return True, "/tmp/" + existing_backup_dirs()[-1]
    print("KUROdoctor: no snapshot exists yet in this run -- "
          "taking one first, before any repair.")
    # Run the snapshot for real (not dry-run) and check its outcome.
    code = do_snapshot(dry_run=False)
    if code == 0:
        found = existing_backup_dirs()
        return True, "/tmp/" + found[-1] if found else "(unknown)"
    return False, "snapshot failed -- stopping"


# ---------------------------------------------------------------------------
# apt-repair -- list upgradable; install ONLY named packages
# ---------------------------------------------------------------------------
def list_upgradable():
    """Names of upgradable packages, read-only. Empty list when apt is
    missing or nothing is upgradable."""
    try:
        out = subprocess.run(["apt", "list", "--upgradable"],
                             capture_output=True, text=True, timeout=120)
    except (OSError, subprocess.SubprocessError):
        return None
    if out.returncode != 0:
        return None
    names = []
    for line in out.stdout.splitlines():
        line = line.strip()
        if not line or line.startswith("Listing"):
            continue
        name = line.split("/")[0].strip()
        if name:
            names.append(name)
    return names


def package_version(name):
    try:
        out = subprocess.run(["dpkg-query", "-W", "-f=${Version}", name],
                             capture_output=True, text=True, timeout=30)
        if out.returncode == 0 and out.stdout.strip():
            return out.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    return "not installed"


def do_apt_repair(dry_run, packages):
    repair = "apt-repair"
    target = ", ".join(packages) if packages else "(none named)"
    upgradable = list_upgradable()
    if upgradable is None:
        before = "upgradable-package list unavailable (apt not found or failed)"
    elif not upgradable:
        before = "no upgradable packages found"
    else:
        before = ("{} upgradable package(s) found: {}"
                  .format(len(upgradable), ", ".join(upgradable[:20])))

    if dry_run:
        if packages:
            detail = ("Would install/upgrade ONLY these named package(s): "
                      "{}. Their current versions: {}. Nothing else would "
                      "be installed or upgraded -- never a blind full "
                      "upgrade. Nothing changed.".format(
                          target,
                          "; ".join("{}={}".format(p, package_version(p))
                                    for p in packages)))
        else:
            detail = ("Would list upgradable packages only and install "
                      "nothing. {} Nothing changed.".format(before))
        res = result(repair, "dry_run", before, "no change (dry run)", detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    if not packages:
        detail = ("No packages named. Nothing installed -- pass "
                  "--package <name> (repeatable) with the exact package "
                  "name(s) from the diagnosis report. Never a blind full "
                  "upgrade.")
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", before, "no change", detail)
        write_audit(repair, target, before, "no change", "skipped",
                    detail, dry_run=False)
        return emit(res, dry_run)

    if shutil.which("apt-get") is None:
        detail = "apt-get is not on this machine. Nothing installed."
        print("KUROdoctor: " + detail)
        res = result(repair, "failed", before, "no change -- apt-get missing",
                     detail)
        write_audit(repair, target, before, "no change -- apt-get missing",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before apt-repair: {}. STOPPING -- "
                  "nothing installed.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    before_versions = "; ".join("{}={}".format(p, package_version(p))
                                for p in packages)
    print("KUROdoctor: installing/upgrading ONLY: {} (snapshot: {})"
          .format(target, snap))
    try:
        proc = subprocess.run(
            ["apt-get", "install", "-y", "--only-upgrade"] + packages,
            capture_output=True, text=True, timeout=900)
    except subprocess.SubprocessError as exc:
        detail = "apt-get failed to run: {}. Nothing installed.".format(exc)
        res = result(repair, "failed", before_versions, "no change", detail)
        write_audit(repair, target, before_versions, "no change", "failed",
                    detail, dry_run=False)
        return emit(res, dry_run)
    after_versions = "; ".join("{}={}".format(p, package_version(p))
                               for p in packages)
    if proc.returncode == 0:
        detail = ("Installed/upgraded ONLY the named package(s): {}. "
                  "Before: {}. After: {}. No other package was touched."
                  .format(target, before_versions, after_versions))
        print("KUROdoctor: " + detail)
        res = result(repair, "ok", before_versions, after_versions, detail)
        write_audit(repair, target, before_versions, after_versions, "ok",
                    detail, dry_run=False)
        return emit(res, dry_run)
    detail = ("apt-get failed (exit {}): {}. Before: {}. After: {}."
              .format(proc.returncode, (proc.stderr or proc.stdout).strip()[-500:],
                      before_versions, after_versions))
    print("KUROdoctor: " + detail, file=sys.stderr)
    res = result(repair, "failed", before_versions, after_versions, detail)
    write_audit(repair, target, before_versions, after_versions, "failed",
                detail, dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# temp-cleanup -- /tmp and ~/.cache only, before/after byte counts
# ---------------------------------------------------------------------------
def temp_roots():
    home = os.path.expanduser("~")
    return ["/tmp", os.path.join(home, ".cache")]


def collect_temp_files():
    """Regular files under /tmp and ~/.cache that temp-cleanup may
    remove. Skips KUROdoctor's own backup/quarantine dirs, sockets and
    other non-regular files, and files changed in the last hour
    (treated as in use). Never walks ~/Documents, ~/Pictures, or any
    other user folder."""
    now = datetime.datetime.now().astimezone().timestamp()
    found = []
    for root in temp_roots():
        for dirpath, dirnames, filenames in os.walk(root, topdown=True,
                                                    followlinks=False):
            # Never descend into our own backup/quarantine dirs.
            dirnames[:] = [d for d in dirnames
                           if not d.startswith("kurodoctor-repair-backup-")
                           and not d.startswith("kurodoctor-quarantine-")]
            for name in filenames:
                path = os.path.join(dirpath, name)
                try:
                    st = os.lstat(path)
                except OSError:
                    continue
                import stat as statmod
                if not statmod.S_ISREG(st.st_mode):
                    continue
                if now - st.st_mtime < RECENT_FILE_SECONDS:
                    continue
                found.append((path, st.st_size))
    return found


def do_temp_cleanup(dry_run):
    repair = "temp-cleanup"
    target = "/tmp, ~/.cache"
    files = collect_temp_files()
    total_bytes = sum(size for _, size in files)
    before = ("{} temp/cache file(s) eligible for cleanup, {} bytes total "
              "in /tmp and ~/.cache (files changed in the last hour and "
              "KUROdoctor backup/quarantine dirs excluded)"
              .format(len(files), total_bytes))
    if dry_run:
        detail = ("Would delete {} temp/cache file(s) ({} bytes) from /tmp "
                  "and ~/.cache only. The folders themselves stay; files "
                  "in use (changed in the last hour) are left alone. No "
                  "documents, photos, or any other user files are touched. "
                  "Nothing changed.".format(len(files), total_bytes))
        res = result(repair, "dry_run", before, "no change (dry run)", detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before temp-cleanup: {}. STOPPING -- "
                  "nothing deleted.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    removed = 0
    freed = 0
    left = 0
    for path, size in files:
        try:
            os.remove(path)
            removed += 1
            freed += size
        except OSError:
            left += 1
    remaining = collect_temp_files()
    remaining_bytes = sum(size for _, size in remaining)
    after = ("{} temp/cache file(s) left, {} bytes total in /tmp and "
             "~/.cache".format(len(remaining), remaining_bytes))
    detail = ("Removed {} temp/cache file(s), freeing {} bytes, from /tmp "
              "and ~/.cache only. {} file(s) could not be removed and "
              "were left alone. No documents, photos, or other user "
              "files were touched.".format(removed, freed, left))
    print("KUROdoctor: " + detail)
    res = result(repair, "ok", before, after, detail)
    write_audit(repair, target, before, after, "ok", detail, dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# startup-cleanup -- disable ONLY named systemd user units / autostart entries
# ---------------------------------------------------------------------------
def find_startup_targets(names):
    """Exact-name matches only. Returns (found, not_found) where found
    entries are dicts: {name, kind, path_or_unit}."""
    home = os.path.expanduser("~")
    found = []
    wanted = set(names)

    # systemd user units: list unit files, match exact unit name.
    units = []
    try:
        out = subprocess.run(["systemctl", "--user", "list-unit-files",
                              "--no-legend", "--no-pager"],
                             capture_output=True, text=True, timeout=60)
        if out.returncode == 0:
            for line in out.stdout.splitlines():
                parts = line.split()
                if parts:
                    units.append(parts[0])
    except (OSError, subprocess.SubprocessError):
        units = []
    for unit in units:
        if unit in wanted:
            found.append({"name": unit, "kind": "systemd-user-unit",
                          "source": unit})

    # Autostart .desktop files (user + system), matched by exact filename.
    for base in (os.path.join(home, ".config", "autostart"),
                 "/etc/xdg/autostart"):
        try:
            for name in sorted(os.listdir(base)):
                if name in wanted and name.endswith(".desktop"):
                    found.append({"name": name, "kind": "autostart-desktop",
                                  "source": os.path.join(base, name)})
        except OSError:
            pass

    found_names = {entry["name"] for entry in found}
    not_found = [name for name in names if name not in found_names]
    return found, not_found


def do_startup_cleanup(dry_run, targets):
    repair = "startup-cleanup"
    target = ", ".join(targets) if targets else "(none named)"

    if not targets:
        detail = ("No startup items named. Nothing disabled -- pass "
                  "--target <exact name> (repeatable) with the exact "
                  "name(s) from the diagnosis report. Only named items "
                  "are ever disabled.")
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", "startup items unchanged",
                     "no change", detail)
        write_audit(repair, target, "startup items unchanged", "no change",
                    "skipped", detail, dry_run=dry_run)
        return emit(res, dry_run)

    found, not_found = find_startup_targets(targets)
    before = ("named items found: {} of {} named ({})"
              .format(len(found), len(targets), target))
    if not found:
        detail = ("None of the named startup items ({}) were found among "
                  "systemd user units or autostart entries. Nothing "
                  "disabled -- check the exact spelling in the diagnosis "
                  "report.".format(target))
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", before, "no change", detail)
        write_audit(repair, target, before, "no change", "skipped",
                    detail, dry_run=dry_run)
        return emit(res, dry_run)

    plan = "; ".join("{} [{}]".format(e["name"], e["kind"]) for e in found)
    if dry_run:
        detail = ("Would disable {} startup item(s): {}. systemd user "
                  "units would be disabled with 'systemctl --user "
                  "disable'; autostart entries would be disabled by "
                  "setting Hidden=true in the user's autostart copy. "
                  "Not found (left alone): {}. Nothing changed, and no "
                  "item you did not name is touched."
                  .format(len(found), plan,
                          ", ".join(not_found) if not_found else "none"))
        res = result(repair, "dry_run", before, "no change (dry run)", detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before startup-cleanup: {}. STOPPING "
                  "-- nothing disabled.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    disabled = []
    failed = []
    home = os.path.expanduser("~")
    for entry in found:
        if entry["kind"] == "systemd-user-unit":
            try:
                proc = subprocess.run(
                    ["systemctl", "--user", "disable", entry["name"]],
                    capture_output=True, text=True, timeout=60)
                if proc.returncode == 0:
                    disabled.append(entry["name"])
                    print("KUROdoctor: disabled startup unit '{}' "
                          "(systemctl --user disable).".format(entry["name"]))
                else:
                    failed.append("{}: {}".format(
                        entry["name"], (proc.stderr or proc.stdout).strip()))
            except (OSError, subprocess.SubprocessError) as exc:
                failed.append("{}: {}".format(entry["name"], exc))
        else:  # autostart-desktop: Hidden=true in the user's copy.
            user_dir = os.path.join(home, ".config", "autostart")
            user_path = os.path.join(user_dir, entry["name"])
            try:
                os.makedirs(user_dir, exist_ok=True)
                lines = []
                if os.path.exists(user_path):
                    with open(user_path, encoding="utf-8",
                              errors="replace") as fh:
                        lines = fh.read().splitlines()
                elif os.path.exists(entry["source"]):
                    with open(entry["source"], encoding="utf-8",
                              errors="replace") as fh:
                        lines = fh.read().splitlines()
                lines = [ln for ln in lines
                         if not ln.strip().startswith("Hidden=")]
                if "[Desktop Entry]" not in lines:
                    lines.insert(0, "[Desktop Entry]")
                lines.append("Hidden=true")
                with open(user_path, "w", encoding="utf-8") as fh:
                    fh.write("\n".join(lines) + "\n")
                disabled.append(entry["name"])
                print("KUROdoctor: disabled autostart entry '{}' "
                      "(Hidden=true in {}).".format(entry["name"], user_path))
            except OSError as exc:
                failed.append("{}: {}".format(entry["name"], exc))

    after = ("disabled: {}; failed: {}; not found: {}"
             .format(len(disabled), len(failed), len(not_found)))
    if not failed and disabled:
        detail = ("Disabled {} named startup item(s): {}. Their old "
                  "state is in the snapshot backup. Not found (left "
                  "alone): {}. No other startup item was changed."
                  .format(len(disabled), ", ".join(disabled),
                          ", ".join(not_found) if not_found else "none"))
        res = result(repair, "ok", before, after, detail)
        write_audit(repair, target, before + " | " + plan, after, "ok",
                    detail, dry_run=False)
        return emit(res, dry_run)
    detail = ("Disabled {} item(s) ({}); failed to disable {}: {}. Not "
              "found (left alone): {}.".format(
                  len(disabled), ", ".join(disabled), len(failed),
                  "; ".join(failed),
                  ", ".join(not_found) if not_found else "none"))
    print("KUROdoctor: " + detail, file=sys.stderr)
    res = result(repair, "failed", before, after, detail)
    write_audit(repair, target, before + " | " + plan, after, "failed",
                detail, dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# malware-quarantine -- clamscan if present; MOVE infected files, never delete
# ---------------------------------------------------------------------------
def do_malware_quarantine(dry_run):
    repair = "malware-quarantine"
    home = os.path.expanduser("~")
    target = "clamscan on {}".format(home)
    quarantine_dir = os.path.join("/tmp",
                                  "kurodoctor-quarantine-" + stamp())
    before = "scan not run yet in this run"

    if shutil.which("clamscan") is None:
        detail = ("clamscan is not installed on this machine, so no scan "
                  "ran. Status: unavailable. This module does NOT install "
                  "it -- install a scanner first, or rely on the "
                  "diagnosis sweep's process check instead. No files "
                  "were touched.")
        print("KUROdoctor: " + detail)
        res = result(repair, "failed", before,
                     "no change -- clamscan unavailable", detail)
        write_audit(repair, target, before,
                    "no change -- clamscan unavailable", "failed", detail,
                    dry_run=dry_run)
        return emit(res, dry_run)

    if dry_run:
        detail = ("Would run 'clamscan -r -i --no-summary {}' (home "
                  "directory only, up to 30 minutes), then MOVE each "
                  "infected file it reports to a quarantine dir under "
                  "/tmp/kurodoctor-quarantine-<timestamp>/ -- MOVE, never "
                  "delete -- and log each move. If clamscan finds "
                  "nothing, nothing moves. Nothing changed."
                  .format(home))
        res = result(repair, "dry_run", before, "no change (dry run)", detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before malware-quarantine: {}. "
                  "STOPPING -- no scan ran.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    print("KUROdoctor: running clamscan on {} -- this can take a while "
          "(up to 30 minutes).".format(home))
    try:
        proc = subprocess.run(
            ["clamscan", "-r", "-i", "--no-summary", home],
            capture_output=True, text=True, timeout=SCAN_TIMEOUT_SECONDS)
        output = proc.stdout or ""
    except subprocess.TimeoutExpired:
        detail = ("clamscan timed out after {} seconds. No files were "
                  "moved. Run the scan again when the machine is less "
                  "busy.".format(SCAN_TIMEOUT_SECONDS))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- scan timed out",
                     detail)
        write_audit(repair, target, before, "no change -- scan timed out",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)
    except (OSError, subprocess.SubprocessError) as exc:
        detail = "clamscan failed to run: {}. No files were moved.".format(exc)
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- scan failed",
                     detail)
        write_audit(repair, target, before, "no change -- scan failed",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    # clamscan exit 0 = clean, 1 = infected files found, 2 = error.
    infected = []
    for line in output.splitlines():
        if line.strip().endswith(": FOUND"):
            path = line.rsplit(": FOUND", 1)[0].strip()
            if path:
                infected.append(path)

    if proc.returncode == 2:
        detail = ("clamscan reported an error (exit 2): {}. No files "
                  "were moved.".format(output.strip()[-500:]))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- scan error",
                     detail)
        write_audit(repair, target, before, "no change -- scan error",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    if not infected:
        after = "scan finished; 0 infected files found"
        detail = ("clamscan finished clean: 0 infected files found in {}. "
                  "Nothing moved.".format(home))
        print("KUROdoctor: " + detail)
        res = result(repair, "ok", before, after, detail)
        write_audit(repair, target, before, after, "ok", detail,
                    dry_run=False)
        return emit(res, dry_run)

    try:
        os.makedirs(quarantine_dir)
    except OSError as exc:
        detail = ("Found {} infected file(s) but FAILED to create the "
                  "quarantine dir {}: {}. STOPPING -- infected files "
                  "were left where they are, nothing was deleted."
                  .format(len(infected), quarantine_dir, exc))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before,
                     "no change -- quarantine dir could not be made", detail)
        write_audit(repair, target, before,
                    "no change -- quarantine dir could not be made",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    moved = []
    failed_moves = []
    for path in infected:
        dest = os.path.join(quarantine_dir, os.path.basename(path))
        counter = 1
        while os.path.exists(dest):
            stem, ext = os.path.splitext(os.path.basename(path))
            dest = os.path.join(quarantine_dir,
                                "{}_{}{}".format(stem, counter, ext))
            counter += 1
        try:
            shutil.move(path, dest)
            moved.append((path, dest))
            print("KUROdoctor: quarantined (MOVED, not deleted): {} -> {}"
                  .format(path, dest))
        except OSError as exc:
            failed_moves.append("{}: {}".format(path, exc))
    after = ("scan finished; {} infected file(s) found, {} moved to {}, "
             "{} move(s) failed".format(len(infected), len(moved),
                                        quarantine_dir, len(failed_moves)))
    move_list = "; ".join("{} -> {}".format(src, dst) for src, dst in moved)
    detail = ("clamscan found {} infected file(s) in {}. {} moved to "
              "quarantine ({}). Nothing was deleted. Failed moves: {}. "
              "Tell the owner in plain language before anything else is "
              "done with the quarantined files.".format(
                  len(infected), home, len(moved), quarantine_dir,
                  "; ".join(failed_moves) if failed_moves else "none"))
    status = "ok" if not failed_moves else "failed"
    res = result(repair, status, before, after, detail)
    write_audit(repair, target, before, after + " | moves: " + move_list,
                status, detail, dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# service-control -- ADMIN ONLY: systemctl on named units only
# ---------------------------------------------------------------------------
SERVICE_ACTIONS = ("start", "stop", "restart", "enable", "disable")
SERVICE_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9@._-]*$")


def _systemctl_state(name):
    """(is-active, is-enabled) for a unit, read-only, best effort."""
    active = enabled = "unknown"
    for query, slot in (("is-active", 0), ("is-enabled", 1)):
        try:
            out = subprocess.run(["systemctl", query, name],
                                 capture_output=True, text=True, timeout=15)
            val = (out.stdout or "").strip()
            if slot == 0:
                active = val or "unknown"
            else:
                enabled = val or "unknown"
        except (OSError, subprocess.SubprocessError):
            pass
    return active, enabled


def do_service_control(dry_run, action, services):
    repair = "service-control"
    target = ", ".join(services) if services else "(none named)"
    if action not in SERVICE_ACTIONS:
        detail = ("service-control needs --action "
                  "start|stop|restart|enable|disable. Nothing changed.")
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "skipped", "service state unchanged",
                     "no change", detail)
        write_audit(repair, target, "service state unchanged", "no change",
                    "skipped", detail, dry_run=dry_run)
        return emit(res, dry_run)
    bad = [s for s in services if not SERVICE_NAME_RE.match(s)]
    if bad:
        detail = ("Refusing service name(s) {!r} -- not plain service "
                  "unit names. Nothing changed.".format(bad))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "skipped", "service state unchanged",
                     "no change", detail)
        write_audit(repair, target, "service state unchanged", "no change",
                    "skipped", detail, dry_run=dry_run)
        return emit(res, dry_run)
    if not services:
        detail = ("No services named. Nothing changed -- pass --target "
                  "<exact unit name> (repeatable) with the exact "
                  "service name(s) from the diagnosis report.")
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", "service state unchanged",
                     "no change", detail)
        write_audit(repair, target, "service state unchanged", "no change",
                    "skipped", detail, dry_run=dry_run)
        return emit(res, dry_run)
    before = "; ".join("{}: active={}, enabled={}".format(
        s, *_systemctl_state(s)) for s in services)
    if dry_run:
        detail = ("Would run 'systemctl {}' on ONLY these service(s): "
                  "{}. Current state: {}. Nothing changed."
                  .format(action, target, before))
        res = result(repair, "dry_run", before, "no change (dry run)",
                     detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)
    if os.geteuid() != 0:
        detail = ("service-control needs admin (root): systemctl on "
                  "system units refuses without it. Run the agent as "
                  "root via the launcher elevation, then retry. "
                  "Nothing was changed.")
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "skipped", "service state unchanged",
                     "no change -- needs admin", detail)
        write_audit(repair, target, "service state unchanged",
                    "no change -- needs admin", "skipped", detail,
                    dry_run=dry_run)
        return emit(res, dry_run)
    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before service-control: {}. STOPPING "
                  "-- nothing changed.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)
    done, failed = [], []
    for name in services:
        try:
            proc = subprocess.run(["systemctl", action, name],
                                  capture_output=True, text=True, timeout=120)
        except (OSError, subprocess.SubprocessError) as exc:
            failed.append("{}: {}".format(name, exc))
            continue
        if proc.returncode == 0:
            done.append(name)
            print("KUROdoctor: systemctl {} {} -- ok.".format(action, name))
        else:
            failed.append("{}: {}".format(
                name, (proc.stderr or proc.stdout).strip()[-300:]))
    after = "; ".join("{}: active={}, enabled={}".format(
        s, *_systemctl_state(s)) for s in services)
    if not failed and done:
        detail = ("systemctl {} ran on {} service(s): {}. Before: {}. "
                  "After: {}. No other service was touched."
                  .format(action, len(done), ", ".join(done), before, after))
        print("KUROdoctor: " + detail)
        res = result(repair, "ok", before, after, detail)
        write_audit(repair, target, before, after, "ok", detail,
                    dry_run=False)
        return emit(res, dry_run)
    detail = ("systemctl {} succeeded for {} ({}); failed for {}: {}. "
              "Before: {}. After: {}.".format(
                  action, len(done), ", ".join(done) if done else "none",
                  len(failed), "; ".join(failed), before, after))
    print("KUROdoctor: " + detail, file=sys.stderr)
    res = result(repair, "failed", before, after, detail)
    write_audit(repair, target, before, after, "failed", detail,
                dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# pacman-repair -- ADMIN ONLY: install / remove named packages only
# ---------------------------------------------------------------------------
def _root_writable():
    """True only when / is mounted read-write (SteamOS default is ro)."""
    try:
        with open("/proc/mounts", encoding="utf-8",
                  errors="replace") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) >= 4 and parts[1] == "/":
                    return "ro" not in parts[3].split(",")
    except OSError:
        pass
    return False


def _pacman_version(name):
    try:
        out = subprocess.run(["pacman", "-Q", name],
                             capture_output=True, text=True, timeout=30)
        if out.returncode == 0 and out.stdout.strip():
            return out.stdout.strip().split(None, 1)[1]
    except (OSError, subprocess.SubprocessError):
        pass
    return "not installed"


def do_pacman_repair(dry_run, packages, remove):
    repair = "pacman-repair"
    verb = "remove" if remove else "install"
    target = ", ".join(packages) if packages else "(none named)"
    if not packages:
        detail = ("No packages named. Nothing {}d -- pass --package "
                  "<name> (repeatable) with the exact package name(s) "
                  "from the diagnosis report. Never a blind full "
                  "upgrade.".format(verb))
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", "packages unchanged",
                     "no change", detail)
        write_audit(repair, target, "packages unchanged", "no change",
                    "skipped", detail, dry_run=dry_run)
        return emit(res, dry_run)
    before = "; ".join("{}={}".format(p, _pacman_version(p))
                       for p in packages)
    if dry_run:
        detail = ("Would {} ONLY these named package(s): {}. Their "
                  "current versions: {}. Nothing else would be "
                  "installed, removed, or upgraded -- never a blind "
                  "full upgrade, never -Syu. Nothing changed.".format(
                      verb, target, before))
        res = result(repair, "dry_run", before, "no change (dry run)",
                     detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)
    if shutil.which("pacman") is None:
        detail = "pacman is not on this machine. Nothing installed."
        print("KUROdoctor: " + detail)
        res = result(repair, "failed", "packages unchanged",
                     "no change -- pacman missing", detail)
        write_audit(repair, target, "packages unchanged",
                    "no change -- pacman missing", "failed", detail,
                    dry_run=dry_run)
        return emit(res, dry_run)
    if os.geteuid() != 0:
        detail = ("pacman-repair needs admin (root). Run the agent as "
                  "root via the launcher elevation, then retry. "
                  "Nothing was changed.")
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "skipped", "packages unchanged",
                     "no change -- needs admin", detail)
        write_audit(repair, target, "packages unchanged",
                    "no change -- needs admin", "skipped", detail,
                    dry_run=dry_run)
        return emit(res, dry_run)
    if not _root_writable():
        detail = ("Refusing: the root filesystem is read-only (SteamOS "
                  "default). Pacman cannot {} a package while the "
                  "system partition is read-only. The owner must first "
                  "run `sudo steamos-readonly disable` in Konsole "
                  "himself -- this agent never runs it. Nothing was "
                  "changed.".format(verb))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "skipped", "packages unchanged",
                     "no change -- read-only root", detail)
        write_audit(repair, target, "packages unchanged",
                    "no change -- read-only root", "skipped", detail,
                    dry_run=dry_run)
        return emit(res, dry_run)
    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before pacman-repair: {}. STOPPING -- "
                  "nothing installed.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)
    argv = (["pacman", "-Rns", "--noconfirm"] if remove
            else ["pacman", "-S", "--noconfirm", "--needed"]) + packages
    print("KUROdoctor: pacman {} ONLY: {} (snapshot: {})".format(
        verb, target, snap))
    try:
        proc = subprocess.run(argv, capture_output=True, text=True,
                              timeout=900)
    except subprocess.SubprocessError as exc:
        detail = "pacman failed to run: {}. Nothing changed.".format(exc)
        res = result(repair, "failed", before, "no change", detail)
        write_audit(repair, target, before, "no change", "failed",
                    detail, dry_run=False)
        return emit(res, dry_run)
    after = "; ".join("{}={}".format(p, _pacman_version(p))
                      for p in packages)
    if proc.returncode == 0:
        detail = ("pacman {}d ONLY the named package(s): {}. Before: {}. "
                  "After: {}. No other package was touched."
                  .format(verb, target, before, after))
        print("KUROdoctor: " + detail)
        res = result(repair, "ok", before, after, detail)
        write_audit(repair, target, before, after, "ok", detail,
                    dry_run=False)
        return emit(res, dry_run)
    detail = ("pacman failed (exit {}): {}. Before: {}. After: {}."
              .format(proc.returncode,
                      (proc.stderr or proc.stdout).strip()[-500:],
                      before, after))
    print("KUROdoctor: " + detail, file=sys.stderr)
    res = result(repair, "failed", before, after, detail)
    write_audit(repair, target, before, after, "failed", detail,
                dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def build_parser():
    parser = argparse.ArgumentParser(
        prog="repair-linux-1.3.6.py",
        description=(
            "KUROdoctor Linux repair module. One repair at a time, after "
            "the owner has heard the plain-language report and said go. "
            "--dry-run previews a repair and changes nothing; --go is "
            "required for any real change. No reinstall, no wipe, no "
            "reboot. Never touches user documents or photos."))
    parser.add_argument("--repair", choices=sorted(REPAIRS),
                        help="repair to run (one at a time)")
    parser.add_argument("--list", action="store_true",
                        help="print the available repairs, one plain line each")
    parser.add_argument("--dry-run", action="store_true",
                        help="preview only: print what WOULD happen, change nothing")
    parser.add_argument("--go", action="store_true",
                        help="owner go: allow this repair to make real changes")
    parser.add_argument("--target", action="append", default=[],
                        help="exact name of a startup item to disable "
                             "(repeatable, startup-cleanup only)")
    parser.add_argument("--package", action="append", default=[],
                        help="exact name of a package to install/upgrade "
                             "(repeatable, apt-repair / pacman-repair only)")
    parser.add_argument("--action", choices=sorted(SERVICE_ACTIONS),
                        default=None,
                        help="systemctl action for service-control "
                             "(start|stop|restart|enable|disable)")
    parser.add_argument("--remove", action="store_true",
                        help="pacman-repair: remove the named packages "
                             "instead of installing them")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.list:
        for name in sorted(REPAIRS):
            print("{}: {}".format(name, REPAIRS[name]))
        return 0

    if not args.repair:
        parser.print_help()
        print("\nKUROdoctor: pick one repair with --repair <name>, or "
              "--list to see them. Nothing was done.", file=sys.stderr)
        return 2

    # Validate package names: plain apt package names only, so a stray
    # shell metacharacter can never ride along (subprocess takes a list
    # anyway -- this is belt and braces, and the error is plain).
    name_re = re.compile(r"^[a-z0-9][a-z0-9+.\-]*$")
    for pkg in args.package:
        if not name_re.match(pkg):
            print("KUROdoctor: refusing package name {!r} -- not a plain "
                  "package name. Nothing installed.".format(pkg),
                  file=sys.stderr)
            return 2

    if args.repair == "service-control":
        for name in args.target:
            if not SERVICE_NAME_RE.match(name):
                print("KUROdoctor: refusing service name {!r} -- not a "
                      "plain service unit name. Nothing changed."
                      .format(name), file=sys.stderr)
                return 2

    if not args.dry_run and not args.go:
        print("KUROdoctor: refusing to run '{}' -- no owner go. Pass "
              "--go after the owner says go for this repair, or "
              "--dry-run to preview it without changing anything. "
              "Nothing was done.".format(args.repair), file=sys.stderr)
        res = result(args.repair, "skipped",
                     "repair not started",
                     "no change -- owner go not given",
                     "Refused: owner go not given. Pass --go after the "
                     "owner says go, or --dry-run to preview.")
        print(json.dumps(res, indent=2))
        return 2

    if args.repair == "snapshot":
        return do_snapshot(dry_run=args.dry_run)
    if args.repair == "apt-repair":
        return do_apt_repair(dry_run=args.dry_run, packages=args.package)
    if args.repair == "temp-cleanup":
        return do_temp_cleanup(dry_run=args.dry_run)
    if args.repair == "startup-cleanup":
        return do_startup_cleanup(dry_run=args.dry_run, targets=args.target)
    if args.repair == "malware-quarantine":
        return do_malware_quarantine(dry_run=args.dry_run)
    if args.repair == "service-control":
        return do_service_control(dry_run=args.dry_run,
                                  action=args.action,
                                  services=args.target)
    if args.repair == "pacman-repair":
        return do_pacman_repair(dry_run=args.dry_run,
                                packages=args.package,
                                remove=args.remove)
    return 2


if __name__ == "__main__":
    sys.exit(main())
