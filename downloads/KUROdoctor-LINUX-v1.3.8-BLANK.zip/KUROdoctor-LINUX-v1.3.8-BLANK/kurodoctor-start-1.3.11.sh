#!/usr/bin/env bash
# KUROdoctor v1.3.11 -- Linux / SteamOS (Steam Deck) launcher.
# Run this in Desktop Mode, from Konsole. It checks python3 and the
# agent file, then runs the agent from the home directory.
#
# v1.3.11 runs the agent as ADMIN (root) when it can, like the Windows
# doctor -- so the agent can see everything (kernel log errors,
# SMART drive health, every user's processes) and do the root
# repairs the owner approves. Elevation flow, in order:
#   1. Already root (id -u = 0): run the agent directly.
#   2. kdesu present (KDE / Deck Desktop Mode): graphical prompt --
#      `kdesu -c "python3 <agent> <args>"`. the owner types HIS OWN
#      password in the KDE prompt.
#   3. kdesu absent but sudo present: terminal sudo --
#      `sudo -E python3 <agent> <args>`. the owner types HIS OWN password
#      at the sudo prompt.
#   4. Elevation declined or failed (kdesu cancelled, sudo wrong
#      password / not permitted, or no elevation tool at all): run
#      the agent UNPRIVILEGED with a clear printed banner -- dmesg,
#      SMART and the full process list stay unavailable, but the
#      doctor still works. Never a crash.
# The launcher NEVER stores, logs, echoes, or auto-types the owner's
# password, and NEVER auto-elevates silently: no password piped to
# sudo, no password on any command line, no password in any file.
# iPhones are excluded -- this agent never touches one, ever.
set -u

# Resolve the agent folder FIRST, before changing directory: dirname
# of $0 is relative to where the launcher was started from.
AGENT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT="$AGENT_DIR/kuro-doctor-agent-linux-1.3.11.py"
CONFIG="$AGENT_DIR/relay-config.json"

cd "$HOME" || exit 1

echo "KUROdoctor v1.3.11 (Linux / SteamOS) -- starting..."
echo "Agent folder: $AGENT_DIR"

if ! command -v python3 >/dev/null 2>&1; then
    echo "KUROdoctor: python3 was not found on this machine."
    echo "SteamOS Desktop Mode normally has python3 already. If yours does"
    echo "not, install it first, then run this launcher again."
    echo "Report NOT saved -- it did not reach the relay."
    exit 1
fi

if [ ! -f "$AGENT" ]; then
    echo "KUROdoctor: the agent file was not found:"
    echo "  $AGENT"
    echo "Copy the whole linux folder (agent, repair-linux-1.3.6.py,"
    echo "relay-config.json, this launcher) into your home directory"
    echo "and run the launcher from there."
    echo "Report NOT saved -- it did not reach the relay."
    exit 1
fi

if [ ! -f "$CONFIG" ]; then
    echo "KUROdoctor: relay-config.json was not found next to the agent."
    echo "It must sit in the same folder as the agent file."
    echo "Report NOT saved -- it did not reach the relay."
    exit 1
fi

# Run the agent WITHOUT admin, with the banner the owner must see.
# Used only when elevation was declined, failed, or is unavailable.
run_unprivileged() {
    echo "KUROdoctor: Running WITHOUT admin -- dmesg, SMART and full process list unavailable."
    echo "KUROdoctor: To run as admin, set a sudo password (passwd in"
    echo "Konsole) and run this launcher again, then approve the prompt."
    python3 "$AGENT" "$@"
}

STATUS=0
if [ "$(id -u)" -eq 0 ]; then
    echo "KUROdoctor: running as admin (root)."
    python3 "$AGENT" "$@"
    STATUS=$?
elif command -v kdesu >/dev/null 2>&1; then
    echo "KUROdoctor: asking for admin access (graphical prompt)..."
    echo "KUROdoctor: type YOUR password in the prompt -- the launcher"
    echo "never sees, stores, or types it for you."
    # Safely quoted command line for kdesu -c (handles spaces in paths).
    CMD=$(printf '%q ' python3 "$AGENT" "$@")
    if kdesu -c "$CMD"; then
        STATUS=$?
    else
        echo "KUROdoctor: admin access was declined or failed."
        run_unprivileged "$@"
        STATUS=$?
    fi
elif command -v sudo >/dev/null 2>&1; then
    echo "KUROdoctor: asking for admin access -- type YOUR password at"
    echo "the sudo prompt below. The launcher never sees, stores, or"
    echo "types it for you."
    if sudo -E python3 "$AGENT" "$@"; then
        STATUS=$?
    else
        echo "KUROdoctor: admin access was declined or failed."
        run_unprivileged "$@"
        STATUS=$?
    fi
else
    echo "KUROdoctor: no elevation tool found (neither kdesu nor sudo)."
    run_unprivileged "$@"
    STATUS=$?
fi

if [ $STATUS -eq 2 ]; then
    echo "KUROdoctor stopped: the relay address is not set yet."
    echo "Open relay-config.json, put your Cloudflare worker URL in"
    echo "\"relay_url\", save it, and run this launcher again."
    echo "Report NOT saved -- it did not reach the relay."
elif [ $STATUS -ne 0 ]; then
    echo "KUROdoctor stopped with exit code $STATUS."
    echo "Report NOT saved -- it did not reach the relay."
else
    echo "KUROdoctor stopped cleanly."
fi
exit $STATUS
