# KUROdoctor v1.3.11 — Steam Deck TEST PLAN (one page, for the owner)

Run these in order, on the Deck, in **Desktop Mode → Konsole**.
Copy the agent's printed lines back exactly — that is the report.

## 0. Before you start

- The `linux/` folder is in your home directory (e.g. `~/kurodoctor/`)
  with all four files together: agent, `repair-linux-1.3.6.py`,
  `relay-config.json`, launcher.
- `relay-config.json` has your worker URL in `relay_url` (if it is
  still blank, the agent will say so plainly and stop — that is normal,
  just fill it in first).
- iPhones are not part of this test — this agent never touches one.

## 1. Run the launcher — WITH admin (the kdesu step)

This is the new v1.3.6 part. First, make sure a sudo password is set
(`passwd` in Konsole) — without one the prompt cannot succeed.

```
cd ~/kurodoctor
chmod +x kurodoctor-start-1.3.11.sh
./kurodoctor-start-1.3.11.sh
```

**What you should see:** the launcher prints `asking for admin
access (graphical prompt)...`, then a KDE password prompt pops up.
**Type YOUR OWN password into that prompt** — the launcher never
sees, stores, or types it for you. Then the agent starts as root:

```
KUROdoctor: running as admin (root).
KUROdoctor agent v1.3.11 starting, relay=https://...
steamos=true root_readonly=true admin=true uid=0 home=/home/deck
sending report: model=... steamos=true root_readonly=true disks=[...] smart=...
report delivered
polling https://.../doctor/command -- 1s while active, 10s idle; on-demand reporting only (boot report once, no heartbeat)
live feed: change-only frames to /doctor/frame (max 1 per 5s, 60s liveness)
```

`report delivered` is the line that matters. `admin=true uid=0` is
the proof it is running as root. Leave Konsole open — the agent
keeps running and polling.

## 2. Root sweep check

Muse checks the report on the relay side. **Success looks like:** the
report is there, version `1.3.11`, with a `sweep` holding all
**11 sections**: the 8 from before (smart, disk_space,
startup_items, processes, temps, pending_updates, boot_time,
malware_scan) plus the 3 new root-only ones:

- `kernel_log` — `status: "ok"`, with `error_lines` / `total_lines`
  and a sample of the latest kernel error lines (from `dmesg`).
- `smart_root` — `status: "ok"` with drive health, OR
  `smartctl_missing` with the install hint (`sudo pacman -S
  smartmontools`). Missing smartctl is a "tell Muse what to
  install" answer, not a failure of the agent.
- `processes_all` — `status: "ok"`, with a process `count`, the
  `users` list, and top 10 by CPU and memory — including other
  users' processes, which the plain `processes` section cannot see.

Note anything else that says `unavailable` and **which tool it names**
(e.g. `screenshot_unavailable`, `xdotool`) — that tells us what the
Deck doesn't have installed.

## 3. Decline once on purpose — the fallback-banner check

Stop the agent (Ctrl+C in Konsole), then run the launcher again —
and this time **cancel the KDE password prompt** (close it without
typing anything).

**Success looks like:**

```
KUROdoctor: admin access was declined or failed.
KUROdoctor: Running WITHOUT admin -- dmesg, SMART and full process list unavailable.
```

The agent still starts and still reports — it is a working doctor
without admin, just a blinder one. Muse checks the report: the 3
root sections (`kernel_log`, `smart_root`, `processes_all`) now say
`unavailable` with reason `needs admin`, and the other 8 sections
are still `ok`. If any root section shows real data in this run,
that is wrong — copy the lines and report it.

Then run the launcher a third time and approve the prompt, so the
rest of the test runs as admin.

## 4. One exec returns

Muse sends a harmless command from the relay side:

```
exec: uname -a        (timeout 30s)
```

**Success looks like:** a `started` ack first (`status: "running"`),
then a completion ack with the `uname -a` output (Linux, the Deck's
hostname, kernel version). If the completion ack never comes, copy
whatever the agent printed in Konsole after the command was sent.

## 5. One screenshot returns

Muse sends:

```
screenshot
```

**Success looks like:** an ack with `tool` naming what took it
(spectacle is the expected one on the Deck — it ships with the
Deck and writes JPEG directly), `format: "jpeg"`, and the picture
visible on Muse's side.

v1.3.8: the agent runs as root, but the capture itself runs AS the
session owner (`deck`) — root asking KWin for a screenshot is
ignored on Wayland (proven live 2026-11-22). If the as-user drop
fails for any reason, the agent retries the same tool directly as
root, so a screenshot can never come back worse than v1.3.6 did.

If it comes back `screenshot_unavailable`, copy the `detail` line —
it names which tools are missing. The agent never installs one
itself; that is a "tell Muse what to install" answer, not a failure
of the agent.

## 6. Live feed eyes

While the agent is running, Muse checks the live feed from the relay
side: `GET <url>/doctor/frame`. **Success looks like:** a frame
arrives (JPEG, ≤40 KB) showing the Deck's current screen, and a new
frame appears only after the screen actually changes — leave the
screen still for a minute and no new frame should post; move a window
and one should follow within seconds (at most 1 frame per 5 seconds).

**Wayland caveat (v1.3.7 fix, v1.3.8 frame fix):** the Deck screenshot chain is grim
→ spectacle → scrot → import → xwd, and spectacle is the tool the
Deck actually ships. v1.3.6 failed live on 2026-11-22 because the
root agent asked KWin for the screenshot itself and was ignored
(spectacle exits 1: "On Wayland, Spectacle requires KDE Plasma's
KWin compositor, which does not seem to be available"). v1.3.7 runs
the capture AS the session owner (`deck`) with the session env
passed through, falling back to a direct-as-root attempt for the
same tool if the drop fails — and the screenshot itself is now
proven live. But v1.3.7's live feed still failed: spectacle's raw
JPEG (275,527 bytes, ~367,000 base64 chars) was rejected by the
relay frame room (400 too_large over 100,000 chars), and `convert`
is absent on the Deck. v1.3.8 scales frames with ffmpeg
(/usr/bin/ffmpeg, present on the Deck) when `convert` is absent
— 50% / 25% / 12.5% at the 40KB cap, run as the session owner.
**This step is the live proof that matters** — it has never passed on a real Deck yet. If no frames
post at all, copy the agent's
`live feed: frame failed: ...` line from Konsole and report it — that
is the expected failure to report, not something to work around
silently. Do not install a screenshot tool to fix it; that is a
"tell Muse what is missing" answer.

One probe in Konsole answers what is still unknown about the Deck:

```
which spectacle convert ffmpeg
```

Copy both lines back. Spectacle is expected (it ships on the Deck);
`convert` (ImageMagick) is absent on the Deck (proven live
2026-11-22) and `ffmpeg` is present — that is exactly the
combination v1.3.8 is built for, so nothing needs installing for
the eyes to work.

**Queue check (v1.3.8):** send two commands in a row (e.g.
`checkup`, then a screenshot) — the second must execute, not sit
behind the first. In v1.3.7 the queue wedged on a stuck head
after one command (exec 485e1d91) and the second command never
ran until a human posted /doctor/received by hand; v1.3.8
re-posts /doctor/received for an already-seen head instead of
skipping it forever, and never executes on the skip path.

## 7. USB phone doctor

This is the v1.3.5 part. It needs `adb` on the Deck first:

```
sudo pacman -S android-tools
adb version
```

If pacman complains the filesystem is read-only, that is the
SteamOS gate, not a bug: the owner runs `sudo steamos-readonly
disable` first (their choice), installs, and can re-enable with
`sudo steamos-readonly enable` afterwards. `sudo` also needs the
owner to have set a password first (`passwd` in Konsole).

On the phone: turn on **USB debugging** (Settings → Developer
options — tap the build number 7 times in About phone if Developer
options is not there yet). Plug the phone into the Deck over USB.
The phone asks "Allow USB debugging?" — tap **Allow** and tick
**"Always allow from this computer"** so it only asks once.

Check from Konsole before Muse sends anything:

```
adb devices
```

**Success looks like:** one line with your phone's serial and
`device` after it. If it says `unauthorized`, tap Allow on the
phone and run it again. If nothing is listed, the cable is not
connected or USB debugging is off.

Then Muse sends, from the relay side:

```
phone_checkup
```

**Success looks like:** one ack with the phone's model (SM-S938B
for the S25 Ultra), Android version, SDK, storage, battery %,
RAM, and app count. If it comes back `adb_missing`, adb is not
installed — see above. If it comes back `unauthorized`, tap Allow
on the phone and send it again. Nothing ran on the phone in
either case.

Then — only after you say go for a specific app — Muse sends:

```
phone_repair: clear_cache on <one app you name>
```

**Success looks like:** an ack with `status: "ok"`, the kind and
package, and before/after state (installed, disabled, running).
`clear_cache` only clears that app's cache — it cannot delete
documents or photos. If it comes back `protected_package`, that
app is in the protected set (system UI, phone, settings,
installer, Play services, the doctor app itself) and the agent
refused it — that is the agent working as designed.

## 8. Service-restart dry check — and the read-only note

**Dry check first (changes nothing).** In Konsole, with the agent
stopped, run the repair module in dry-run mode:

```
python3 repair-linux-1.3.6.py --dry-run --repair service-control --action restart --target sshd.service
```

**Success looks like:** exit code 0 and a JSON result with
`"status": "dry_run"` and a detail starting `Would run 'systemctl
restart' on ONLY these service(s): sshd.service.` and ending
`Nothing changed.` A dry run writes nothing to disk — not even the
audit log.

**A real restart only after you name a service and say go.** If
you want a live check, name one service you are happy to restart
and say go for that exact one — Muse sends it through the relay
(`repair` service restart), and the ack should come back `ok`
with before/after state (active/enabled before and after). If the
agent is not running as admin, it refuses with `needs_admin` and
nothing runs — that is the gate working, not a failure.

**The read-only note:** a package install is expected to REFUSE
while the SteamOS root filesystem is read-only — do not treat
that refusal as a failure. The refusal is the SteamOS gate
working. Installing only becomes possible after YOU turn
read-only off yourself (`sudo steamos-readonly disable` in
Konsole — the agent never runs it), and only for a package you
name. Do not turn read-only off just for this test.

## 9. Launch an app + mouse clicks (v1.3.9)

This step needs the `launch` relay patch deployed first
(`relay/worker-launch-patch-v1.3.9.js` — built, not live yet).
Until it is deployed the relay answers `launch` with
`unknown_cmd`; that is the relay telling you the patch is not
there, not an agent failure.

Then — only after you say go for a specific app — Muse sends:

```
launch: desktop=/var/lib/flatpak/exports/share/applications/net.cozic.joplin_desktop.desktop
```

**Success looks like:** Joplin opens on the Deck as you (your
notes, your data — not root's), and the ack says
`started: true` with `as_user` naming your session user.
If it comes back `not_an_app`, the .desktop file is not in a
real application directory. If it comes back `blocked`, the
app's Exec line failed the same blocklist exec uses — that is
the agent working as designed. If it comes back `no_session`,
the agent cannot see a graphical session user.

Then Muse sends a mouse click (this needs `xdotool` — if it
is not installed the agent says `unavailable` loudly):

```
mouse: left_click at the launcher icon, bottom-left of the taskbar
```

**Success looks like:** the application launcher opens on
screen. If it comes back `mouse_failed` with "Can't open
display", xdotool cannot reach the Wayland session (it needs
an XWayland DISPLAY) — copy the exact detail back; that is
the expected failure to report, not something to work around
silently.

## 10. Full access with your go (v1.3.10)

Every sub-step here runs ONLY after you say go for that exact
action and that exact target — say the words, name the thing.
Muse shows you what is about to happen first; your go is for
that exact action on that exact target, nothing else.

**Launch the real Joplin AppImage.** Muse sends:

```
launch: executable=/home/deck/Downloads/Joplin-3.7.24.AppImage, args=["--ozone-platform=x11"]
```

**Success looks like:** Joplin opens on the Deck as you (your
notes, your data — not root's), and the ack says
`started: true` with `as_user` naming your session user and
`args` carrying `--ozone-platform=x11`. If it comes back
`not_an_app`, the file is not an executable under your home or
`/opt`. If it comes back `blocked`, the path or the args failed
the same blocklist exec uses. If it comes back `no_session`,
the agent cannot see a graphical session user.

**Remove one protected file you name.** Say go for the exact
file (for example the leftover Joplin flatpak data folder
under your home), and Muse sends the `rm` with your go
stamped on that exact path. **Success looks like:** the ack
says `started: true` and restates the exact path, and the file
is gone. Without your go the same `rm` comes back `blocked` —
that is the agent working as designed.

**Uninstall Joplin's flatpak with its data.** Say go for the
exact app id, and Muse sends:

```
flatpak uninstall --system -y --delete-data net.cozic.joplin_desktop
```

**Success looks like:** the app and its data are gone, and
the ack does not say `blocked`. (v1.3.9 refused this on a
false positive — the word "delete" in the flag plus "desktop"
in the app id.)

**A wipe stays refused without your go.** Muse sends a wipe
of a drive you have NOT named, with no go stamped on it.
**Success looks like:** the ack comes back `blocked` and
nothing is wiped. Never say go for a wipe unless you mean
that exact drive or partition — the agent restates the exact
target in the ack when your go authorises one, and it never
wipes a different target than the one you named.

## What to report back

1. The launcher lines from step 1 (copy them exactly), including
   what the kdesu prompt looked like and the `admin=true uid=0` line.
2. The root sweep from step 2: `kernel_log` error_lines/total_lines,
   `smart_root` ok or `smartctl_missing`, `processes_all` count/users
   — or the exact `needs admin` lines if a section was unavailable.
3. The decline run from step 3: the exact banner lines, and that the
   3 root sections said `needs admin` while the other 8 stayed ok.
4. Whether the `uname -a` output came back in step 4.
5. Whether the screenshot came back in step 5 (and which tool took it),
   or the exact `screenshot_unavailable` detail if it didn't.
6. Whether the live feed showed the Deck's screen at
   `GET /doctor/frame` in step 6 (and whether frames posted only when
   the screen changed), or the exact `live feed: frame failed:` line
   if none posted.
7. What `adb devices` showed, and what the `phone_checkup` ack
   said (model, Android version, battery %, app count) — or the
   exact error (`adb_missing`, `no_device`, `unauthorized`) if
   it did not come back.
8. Whether the `phone_repair` clear_cache came back `ok` with
   before/after state (and which app), or the exact error if
   it did not.
9. The service dry-run result from step 8 (exit 0, `dry_run`,
   "Nothing changed"), and — only if you asked for one — the live
   restart result. Plus whether any package install refused on
   the read-only gate, and the exact refusal line.

10. Whether the `launch` of Joplin came back `started: true`
    with `as_user` naming your session user and Joplin actually
    opened — or the exact error (`not_an_app`, `blocked`,
    `no_session`, `unknown_cmd`) if it did not.
11. Whether the `mouse` left_click opened the launcher — or
    the exact error (`unavailable`, `mouse_failed` with its
    detail) if it did not.

12. Step 10 (full access with your go): whether the Joplin
    AppImage launched with `started: true`, `as_user` naming
    your session user, and the `--ozone-platform=x11` arg in
    the ack — or the exact error (`not_an_app`, `blocked`,
    `no_session`, `unknown_cmd`); whether the `rm` of the file
    you named came back `started: true` restating that exact
    path; whether the `flatpak uninstall --delete-data` came
    back unblocked; and whether the wipe with no go came back
    `blocked` with nothing wiped.

Typing is not in this test — it needs `xdotool`, and if it isn't
installed the agent will say so loudly when Muse tries.
Other repairs and uninstalls are not in this test either —
those only run after you say go for a specific one.
