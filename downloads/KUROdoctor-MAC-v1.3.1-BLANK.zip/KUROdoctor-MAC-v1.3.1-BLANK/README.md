# KUROdoctor v1.3.2 — macOS (BLANK)

The Mac side of KUROdoctor, with nothing of the original owner's filled in.

## What's in here
- `kuro-doctor-agent-macos-1.3.2.py` — the agent (stdlib-only Python 3). Diagnoses first, then takes commands from the relay.
- `repair-macos.py` — the repair module (snapshot-first; dry-run never changes anything).
- `kurodoctor-start-1.3.2.command` — the launcher. Double-click it in Finder.
- `relay-config.json` — `{"relay_url": ""}` — blank until you fill in your own Cloudflare worker URL.
- `SETUP.md` — setup guide, written for another Muse to walk its owner through it.

## What it does
Blind diagnostic sweep first (drive health, disk space, startup, processes, temps, pending updates, boot time, malware scan), then it polls your relay for commands from your Muse: run commands, read files, screenshots, clean, repair, deep hardware exam, uninstall, install. Everything shown to you first, nothing runs without your ok.

## Honest status
This agent has never run on a real Mac yet. It parses clean and its sweep runs without crashing when Mac tools are missing, but the real Mac paths (diskutil, system_profiler, launchctl, softwareupdate) have only ever been read, never run on hardware. You are the first real run — say so plainly, and report what happens.

## How it stays blank
The agent has no relay URL baked in anywhere. If `relay_url` is blank, it prints a plain message and stops — it never guesses an address. Put your own Cloudflare worker URL in `relay-config.json` and double-click the launcher.
