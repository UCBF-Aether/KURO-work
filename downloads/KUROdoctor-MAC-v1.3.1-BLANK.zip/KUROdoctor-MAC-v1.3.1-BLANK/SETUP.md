# KUROdoctor v1.3.2 agent + v1.4.0 relay — macOS setup

A guide for the Muse instance helping the owner get the Mac agent
running. Read it top to bottom, do one step, verify it, then move on.
Nothing here runs on a real Mac until step 4, and the agent has never
run on a real Mac yet — say that plainly to the owner. Agent v1.3.2; the relay is v1.4.0 (token + Authenticator app
approval — see Step 1).

## What is in this folder

| File | What it is |
|---|---|
| `kuro-doctor-agent-macos-1.3.2.py` | The agent (stdlib-only Python 3). Diagnoses first, then takes commands from the relay. |
| `kurodoctor-start-1.3.2.command` | Double-click launcher. Checks python3 + the agent file, then runs it. |
| `relay-config.json` | The relay URL. Blank by default — the agent refuses to run until it is set. |
| `repair-macos.py` | The repair module the agent calls as a subprocess. Do not edit; the agent never duplicates its logic. |
| `SETUP.md` | This file. |

## Step 1 — Ask the owner for these

1. **Their Cloudflare Worker URL** for the KUROdoctor relay, e.g.
   `https://<their-worker>.<their-subdomain>.workers.dev`. This is the
   one thing the agent cannot guess.
2. Only if the relay itself is not deployed yet: the **worker name**,
   **Cloudflare account ID**, and the **KV namespace ID** for the
   doctor KV (keys `doctor:latest`, `doctor:queue`, `doctor:ack`,
   `doctor:screenshot`). The relay must be **v1.4.0** — agent and
   relay move together. A v1.3.0-or-older agent against a v1.3.2 relay
   runs only the first queued command and then stalls (it never sends
   the receipt that pops the queue). The relay deploy lives in the
   Windows blank pack's `relay/` folder (or the FULL blank pack's
   `windows/relay/`); its `SETUP.md` walks through it.
3. **The Authenticator app** — the owner installs
   `KUROdoctor-Authenticator-1.1.apk` (included in this pack) and
   pairs it (the pairing guide is in the separate
   `KUROdoctor-Authenticator-BLANK.zip`'s `SETUP.md`). v1.4.0 needs two
   factors before a command is accepted: (1) the Muse-held write
   token — every `POST /doctor/command` must carry header
   `X-Doctor-Token` matching the worker secret `DOCTOR_TOKEN`
   (`401 bad_token` without it; the token lives only with the
   owner's Muse, never in this pack); (2) an unlocked session —
   the owner approves a session in the app (`423 locked` without
   it; an unlock lasts 8 hours). If no device is paired at all, the
   relay runs token-only (safety valve) so a fresh setup is never
   bricked before pairing.

## Step 2 — Put the URL in relay-config.json

Open `relay-config.json` and paste the URL as `relay_url`, keeping
the quotes:

```json
{"relay_url": "https://<their-worker>.<their-subdomain>.workers.dev"}
```

Leave the `_comment` key alone. Do not share this file — the URL is
theirs.

## Step 3 — Check the relay answers (before touching the Mac)

Every command post below needs the Muse-held token header
(`-H "X-Doctor-Token: $DOCTOR_TOKEN"`); without it the relay
answers `401 bad_token`. With a device paired and no approved
session it answers `423 locked` — approve a session in the
Authenticator app first.

```sh
curl -s https://<their-worker>.<their-subdomain>.workers.dev/doctor/command
```

Expected with an empty queue: `{"cmd":null}`. Then a smoke test:

```sh
curl -s -X POST https://<their-worker>.<their-subdomain>.workers.dev/doctor/command \
  -H 'Content-Type: application/json' -H "X-Doctor-Token: $DOCTOR_TOKEN" -d '{"cmd":"ping","id":"smoke-1"}'
# expected: {"ok":true,"id":"smoke-1","position":1}

curl -s https://<their-worker>.<their-subdomain>.workers.dev/doctor/command
# expected: {"cmd":"ping","id":"smoke-1"}   (head, NOT popped)

curl -s -X POST https://<their-worker>.<their-subdomain>.workers.dev/doctor/received \
  -H 'Content-Type: application/json' -d '{"id":"smoke-1"}'
# expected: {"ok":true}   (now popped; a second receipt gets 400 unknown_id)
```

If any of these fail, fix the relay first — the agent cannot help
until the relay answers.

## Step 4 — Run it on the Mac

1. Put all four files in one folder on the Mac.
2. Double-click `kurodoctor-start-1.3.2.command`. (First time,
   macOS may ask to allow it — right-click → Open if it refuses a
   plain double-click.)
3. The agent runs its blind sweep first, then sends a boot report.
   What the owner should see in the window:
   `sending report: model=... disks=[...] smart=...` then
   `report delivered`, then `polling .../doctor/command (adaptive:
   1s while active, 10s when idle; ...)`.
4. If the URL is blank, the agent instead prints a plain message
   saying the relay URL is not set, and stops (exit code 2). That is
   the correct behaviour — set the URL and run it again.
5. If no report reached the relay, nothing was saved there — a
   report is only saved when it reaches the relay.

## Step 5 — Mouse/type needs one permission

Mouse and type control need Accessibility permission, or they return
`unavailable` loudly instead of working: System Settings →
Privacy & Security → Accessibility → turn on **Terminal** (the app
the agent runs in). Screenshot may also ask for Screen Recording
permission for Terminal the first time — grant it the same way.
Never type into a password or login field — that is an operator
rule, not a technical limit.

## Things the owner should know

- **Snapshot rule:** before any repair, the agent tries
  `tmutil snapshot` (a local Time Machine snapshot, needs no
  confirmation). If that fails, the repair **refuses loudly**
  (`status: refused`, `detail: snapshot_unavailable`) and changes
  nothing. macOS has no Windows-style restore points; the snapshot
  is the rollback point.
- **Repair mapping:** `system_files` → named updates only + a
  disk-check report; `startup` → named launchd items only; `temp` →
  temp/cache cleanup; `defender_scan` → Gatekeeper status, and with
  named files it *moves* them to quarantine, never deletes them.
  There is no bundled on-device scanner; nothing here invents one.
- **Uninstall:** kinds `app` and `brew` only. The agent checks for
  running processes from the target first — if any are running it
  refuses (`target_running`) and deletes nothing. An `.app` is moved
  to Trash, never `rm -rf`'d.
- **Polling / request math:** 1s while work is happening, 10s when
  idle; heartbeat every 60s. Idle ≈ 8,640 polls + 1,440 heartbeats
  ≈ 10k requests/day (vs ~86k/day at a flat 1s poll).
- **iPhones are excluded, always.** This agent is for a Mac only.
- **No real-Mac run has happened yet.** The agent was verified by
  syntax check and Linux dry runs only (where the macOS tools are
  absent, so the sweep honestly reports them unavailable). The first
  real Mac run is still a test — watch the window, keep the first
  session to diagnose-only commands (`ping`, `sysinfo`, `df`) before
  trying `repair`, `exec`, `uninstall`, or `install`.
