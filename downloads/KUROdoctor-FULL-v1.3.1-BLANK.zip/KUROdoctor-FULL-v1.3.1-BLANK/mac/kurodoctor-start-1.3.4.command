#!/bin/sh
# KUROdoctor launcher for macOS -- v1.3.4
# Double-click this file to run the KUROdoctor agent. It checks for
# python3 and for the agent file, then runs the agent in this window.
# To stop the agent, press Control-C in this window.
#
# The agent talks to the KUROdoctor relay (your Cloudflare Worker).
# Its URL lives in relay-config.json next to this file -- paste it
# there first. If the URL is blank, the agent says so in plain
# language and stops before doing anything.
#
# Honest closing note, same as the Windows launcher: if no report
# reached the relay, nothing was saved there -- a report is only
# saved when it reaches the relay.

cd "$(dirname "$0")" || {
    echo "KUROdoctor: could not move into the agent folder. Nothing ran."
    read -r -p "Press Return to close this window. " _dummy
    exit 1
}

if ! command -v python3 >/dev/null 2>&1; then
    echo "KUROdoctor: python3 was not found on this Mac."
    echo "Install the macOS Command Line Tools (or Python 3 from python.org), then double-click this file again."
    echo "Nothing ran, nothing was changed."
    read -r -p "Press Return to close this window. " _dummy
    exit 1
fi

if [ ! -f "kuro-doctor-agent-macos-1.3.4.py" ]; then
    echo "KUROdoctor: the agent file kuro-doctor-agent-macos-1.3.4.py is missing from this folder."
    echo "Put this launcher back in the same folder as the agent file and try again."
    echo "Nothing ran, nothing was changed."
    read -r -p "Press Return to close this window. " _dummy
    exit 1
fi

if [ ! -f "relay-config.json" ]; then
    echo "KUROdoctor: relay-config.json is missing from this folder."
    echo "It should sit next to the agent file, with your Cloudflare Worker URL in it."
    echo "Nothing ran, nothing was changed."
    read -r -p "Press Return to close this window. " _dummy
    exit 1
fi

if [ ! -f "repair-macos.py" ]; then
    echo "KUROdoctor: note -- repair-macos.py is missing from this folder."
    echo "The agent will still run and diagnose, but repair commands will refuse (repair module missing) until you put repair-macos.py back next to the agent."
fi

echo "KUROdoctor v1.3.4 (macOS) starting..."
echo "Press Control-C in this window to stop it."
echo ""
python3 "kuro-doctor-agent-macos-1.3.4.py"
STATUS=$?
echo ""
if [ "$STATUS" -eq 2 ]; then
    echo "KUROdoctor stopped before doing anything: the relay URL is not set yet."
    echo "Open relay-config.json (in this folder) and paste your Cloudflare Worker URL as \"relay_url\", then double-click this file again."
elif [ "$STATUS" -ne 0 ]; then
    echo "KUROdoctor stopped with exit code $STATUS."
else
    echo "KUROdoctor stopped."
fi
echo "If no report reached the relay, nothing was saved there -- a report is only saved when it reaches the relay."
read -r -p "Press Return to close this window. " _dummy
exit "$STATUS"
