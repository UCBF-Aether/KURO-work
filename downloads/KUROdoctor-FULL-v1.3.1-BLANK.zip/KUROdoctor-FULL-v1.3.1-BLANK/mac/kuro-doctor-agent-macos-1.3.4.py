#!/usr/bin/env python3
"""KUROdoctor agent v1.3.4 -- macOS patient.

NEVER RUN ON A MAC -- needs a real Mac test. This file has never
executed on macOS; every macOS tool call in it is written from the
documented macOS command-line interfaces (diskutil, system_profiler,
pmset, launchctl, softwareupdate, sysctl, ps, log, tmutil, screencapture,
sips, osascript) and is guarded so a missing tool or a failed call only
ever produces {"status": "unavailable", "reason": ...} for that section --
never a crash. Verified on the build VM only by py_compile and by
--help / --sweep-only / --deep-only dry runs on Linux (where the macOS
tools are absent, so the sections honestly report unavailable -- that
is expected, and is NOT a Mac run).

Built on agent/kuro-doctor-agent-macos.py (v1, same blind sweep
sections, same report shape, same relay I/O style), extended to the
SHARED RELAY CONTRACT v1.3.2 that the Windows/Linux agents implement.
Agent and relay must move together (see BACK-COMPAT below).

v1.3.4 (this file) mirrors the PROVEN Windows v1.3.4 eyes + type-focus
fix (HP end-to-end proof, Nov 20, 2026: live frames via POST/GET
/doctor/frame, type `process` focus landing "hello" in Notepad++):
  - send_frame_tick(): change-only live-feed frames to POST
    /doctor/frame (screencapture + sips JPEG, 40KB cap, 1 post per
    5s max, 60s liveness re-post). No token -- the agent holds none,
    same as Windows. Called once per poll iteration.
  - cmd_type() accepts an optional `process` field: the named app is
    brought to front and verified frontmost BEFORE any keystroke;
    no such process / no visible window -> "no_window", bring-to-front
    failure -> "focus_failed", and NOTHING is typed. Without
    `process`, the current frontmost app is used unless it is the
    agent's own Terminal, in which case the most recently launched
    app with a visible window is used instead.

RELAY CONFIG (no hardcoded URL anywhere in this file):
    The relay base URL comes from relay-config.json sitting next to
    this script: {"relay_url": "<your worker URL>"}. The environment
    variable KURODOCTOR_RELAY overrides it, for testing only -- the
    FILE is the shipped mechanism. If the URL is blank or the file is
    missing, the agent prints a plain-language message telling the
    owner to set it and exits cleanly (exit code 2, no traceback, no
    silent failure). There is NO hardcoded fallback URL in this file.

RELAY CONTRACT v1.3.2 (KV keys: doctor:latest, doctor:queue,
doctor:ack, doctor:screenshot; the old single-slot doctor:command key
is RETIRED):
    POST /doctor/report    boot / heartbeat report
    GET  /doctor/command   returns the queue HEAD without popping, or
                           {"cmd": null} when the queue is empty
    POST /doctor/received  {"id": ...} pops that id from the queue
                           (400 unknown_id if absent)
    POST /doctor/ack      {"id", "done", "at", "result"}
    POST /doctor/frame    v1.3.4: live-feed frame {image_b64, width,
                           height, bytes}, no token, 40KB cap
    type gains an optional `process` field in v1.3.4 (relay validates
    it: string, 1-200 chars, no control chars -> 400 bad_process).
    The agent MUST post /doctor/received immediately after GETting a
    new command, BEFORE executing it. If that receipt post fails, the
    command is NOT executed this cycle -- it stays queued and will be
    re-served on the next poll (exactly-once beats at-most-once
    guessing). SeenIds dedup (per process) stays as a backstop.
    POST /doctor/command appends to the queue (400 queue_full at 10).

ACK HYGIENE (agent-side, before any ack is posted):
    Every ack string field is sanitized to ASCII (non-ASCII becomes
    '?', control characters except newline/tab/CR are stripped), each
    string field is capped at 4096 characters (appending
    "... [truncated]"), and the whole ack JSON is capped at ~16KB.
    If a full ack POST fails after retries, the agent falls back to
    one minimal ack {id, done, at, result: {"error":
    "ack_content_rejected"}}. Acks are retried up to 3 times, 2s
    apart. A failed ack post must never silently drop a result.

ALLOW-LIST (commands this agent accepts):
    ping, sysinfo, smart, df, ls, cat, dmesg, exec, screenshot,
    mouse, type, clean, repair, deep, uninstall, install. Anything else acks
    done:false with error "unknown_cmd".

ASYNC COMMANDS (exec, repair, deep, uninstall, install):
    These run in background threads (threading.Thread, stdlib -- the
    sanest stdlib route: no extra processes to babysit, and the
    worker can hold a subprocess handle so a timeout can kill it).
    The handler returns IMMEDIATELY with a 'started' ack
    (done:true, result {started:true, status:"running"}); the poll
    loop checks the pending jobs every cycle and posts a COMPLETION
    ack with the real result when the job finishes. A job that runs
    past its timeout is killed where a subprocess handle exists
    (exec / repair / deep all run as subprocesses); a job with no
    killable subprocess gets a timed_out completion ack and is
    orphaned (its late result is discarded, never double-acked).
    Jobs ALWAYS ack, including on timeout, with partial output where
    any was captured. Any result carrying an "error" key acks
    done:false.

POLLING (adaptive) + REQUEST MATH:
    1 second while active (a command was seen in the last 60s, or
    jobs are pending), else 10 seconds. Heartbeat report every ~60s.
    Idle: ~8,640 polls/day + ~1,440 heartbeats/day = ~10k requests/
    day. At a flat 1s poll it would be ~86k/day -- close to a
    Cloudflare free-tier daily cap, which is why the agent backs off
    to 10s when idle. Fast polling runs only while work is happening.

BACK-COMPAT NOTE:
    A v1.3.1-or-older agent against a v1.3.2 relay runs only the
    FIRST queued command: it never sends /doctor/received, so the
    head is never popped and the queue stalls behind it. Agent and
    relay must move together -- upgrade both, or neither.

EXEC BLOCKLIST (macOS equivalents, word-boundary matching ONLY):
    Refused, acked done:false with error "blocked", never run:
      - sudo rm -rf (sudo + rm + an rf-style flag)
      - rm -rf aimed at / , ~ or $HOME
      - diskutil erase / eraseDisk / eraseVolume / partitionDisk
      - mkfs, and dd writing to a disk device (of=/dev/disk* or
        of=/dev/rdisk*)
      - shutdown / reboot / halt
      - password changes: the passwd command itself, and dscl with a
        passwd argument
      - lock-screen bypass (either word order)
      - rm aimed at ~/Documents, ~/Pictures, ~/Desktop or
        ~/Downloads (temp and cache paths are allowed)
    Matching is word-boundary regex, NEVER substring matching: the
    word "Information" must never trip a rule (there is no rule
    whose word appears inside it), and a path like /etc/passwd must
    never trip the passwd rule (passwd is only refused when it is
    the command being run, not when it appears inside a path).
    Credential-dumping tool names are NOT in this file at all -- the
    relay enforces those server-side, and naming them here would
    only trip on-device scanners. This file deliberately names none
    of them.

OWNER_OVERRIDE (exec only, narrow rule, same shape as Windows):
    owner_override=true lifts the Desktop refusal ONLY for deleting
    .lnk / .alias shortcut files under ~/Desktop -- macOS shortcuts
    are .alias files, and the rule covers them. It lifts nothing
    else: no -r / -R / --recursive flag, no wildcards (* or ?), no
    Documents / Pictures / Downloads, no other folder. An override
    command that breaks any of those limits is still refused.

REPAIR -- SNAPSHOT RULE (macOS has no Windows restore points):
    Before ANY repair runs, the agent attempts `tmutil snapshot`
    (best-effort, needs no confirmation). If a local snapshot is
    created, its name/date is recorded and the repair proceeds. If
    tmutil is unavailable or the snapshot fails, the repair REFUSES
    loudly with status "refused" and detail "snapshot_unavailable"
    -- it NEVER silently proceeds without a snapshot and NEVER
    finishes with no effect and no error. The repair module itself
    (repair-macos.py, called as a subprocess) ALSO takes its own
    manifest backup first; the tmutil snapshot is the agent-level
    gate on top of that.

REPAIR -- FUNCTION MAPPING (agent function -> repair-macos.py repair):
    system_files  -> softwareupdate-repair (ONLY updates the owner
                     names with names=) + a disk-check report on /
    startup       -> startup-cleanup (named launchd labels only)
    temp          -> temp-cleanup (/tmp + ~/Library/Caches only)
    defender_scan -> malware-quarantine (Gatekeeper status report;
                     with names= it MOVES only the named files from
                     /tmp, ~/Library/Caches or ~/Downloads to
                     quarantine -- never deletes them). There is no
                     on-device scanner bundled; the Gatekeeper line
                     plus the quarantine move is what this module
                     actually offers -- nothing is invented here.
    names= must be an array of strings, each 1-50 chars, no * or ?.
    Unknown function -> error "bad_function". The repair runs as a
    subprocess: python3 repair-macos.py --go --repair <mapped>
    [--target ...] [--package ...], so its audit log and its own
    snapshot still apply.

SCREENSHOT (native route, not a red-team pattern):
    screencapture -x -t png to a temp file, then sips scales /
    compresses it to JPEG at or under 200KB (descending widths and
    quality steps). If sips is absent and the PNG is already at or
    under 200KB it is returned as PNG; if sips is absent and the PNG
    is over the cap, the command honestly reports
    screenshot_too_large instead of faking a JPEG. Pixels go in the
    ack's image_b64, same interface as the Windows agent. First run
    on a Mac may ask for Screen Recording permission for Terminal
    (System Settings -> Privacy & Security -> Screen Recording).

MOUSE / TYPE (osascript + System Events / CoreGraphics):
    Click at x/y, keystroke text. This REQUIRES the owner to grant
    Accessibility permission (System Settings -> Privacy & Security
    -> Accessibility -> Terminal). Without it, mouse/type return
    "unavailable" LOUDLY with the permission step in the detail --
    never a silent failure. Operator rule, always: never type into
    a password or login field.
    v1.3.4: type takes an optional `process` (e.g. "TextEdit"): the
    agent brings that app to front and verifies it is frontmost
    before typing; no such process or no visible window ->
    "no_window", bring-to-front failure -> "focus_failed", and
    NOTHING is typed. Without `process`, the current frontmost app
    is the target unless it is Terminal (the agent's own terminal),
    in which case the most recently launched app with a visible
    window is used instead (see _focus_for_type).

CLEAN: Trash + ~/Library/Caches + /tmp ONLY, with before/after MB.
    Regular files only; files changed in the last hour are left
    alone; KUROdoctor's own backup/quarantine dirs are skipped.

DEEP (read-only): diskutil info per disk, system_profiler hardware,
    pmset battery, sysctl + vm_stat memory, and error-line counts
    from the last 24h of the unified log. Every section is
    independent; a failed section reports "unavailable" and never
    blocks the others.

UNINSTALL (kinds app | brew only; any other kind -> ack error
    "bad_kind", nothing executed):
    RUNNING-PROCESS PRECHECK FIRST -- processes whose path is under
    the target .app bundle or whose name matches the target are
    listed; if any are running the command refuses with
    "target_running" and deletes nothing. app = move the .app bundle
    to Trash (never rm -rf), then verify it is gone. brew =
    `brew uninstall <name>` if brew exists, then verify it is gone.
    Per-item results; a name is a plain name (<=200 chars, no
    backslash, no slash, no "..").

INSTALL (kind brew only; any other kind -> ack error "bad_kind",
    nothing executed):
    Prechecks BEFORE anything runs: brew present? (missing brew
    refuses with "brew_missing" and the install step -- get Homebrew
    from https://brew.sh first); already installed? (`brew list`
    shows it -- acks done with "already installed" and runs nothing).
    Audit-logged before running. Then `brew install <name>`, and
    the exit code is NEVER trusted alone: the agent verifies with
    `brew list` afterwards and reports verified true/false in the
    completion ack. A name is a plain name (<=200 chars, no
    backslash, no slash, no ".."), validated exactly like uninstall.

The doctor ALWAYS goes in blind: on first connect -- before any
command is polled and before the user is asked anything -- the agent
runs a full diagnostic sweep on its own (drive health, disk space,
startup items, running processes, temperatures, pending updates,
boot time, plus a malware-scan section that is honestly unavailable)
and puts the results in the boot report. The user's guess ("it's
riddled with viruses") is optional context only, never the diagnosis.

Stdlib only -- no pip dependencies. Python 3.

Usage:
    python3 kuro-doctor-agent-macos-1.3.4.py            # normal: report, then poll forever
    python3 kuro-doctor-agent-macos-1.3.4.py --once     # one poll cycle, then exit
    python3 kuro-doctor-agent-macos-1.3.4.py --report-only  # send the boot report, exit
    python3 kuro-doctor-agent-macos-1.3.4.py --sweep-only   # run the blind sweep,
                                                           # print the JSON, exit
    python3 kuro-doctor-agent-macos-1.3.4.py --deep-only    # run the deep exam,
                                                           # print the JSON, exit
"""

import argparse
import base64
import hashlib
import json
import os
import plistlib
import platform
import re
import shutil
import socket
import stat
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone

VERSION = "1.3.4"
AGENT = "kuro-doctor-macos"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPAIR_SCRIPT = os.path.join(SCRIPT_DIR, "repair-macos.py")
CONFIG_FILE = os.path.join(SCRIPT_DIR, "relay-config.json")
AUDIT_LOG = os.path.join(SCRIPT_DIR, "kuro-doctor-audit.log")

POLL_INTERVAL_ACTIVE = 1    # seconds between polls while work is happening
POLL_INTERVAL_IDLE = 10     # seconds between polls when idle
ACTIVE_WINDOW = 60          # seconds after a command during which we stay fast
HEARTBEAT_INTERVAL = 60     # seconds between heartbeat reports
CAT_MAX_BYTES = 100 * 1024  # 100 KB cap on cat
EXEC_MAX_OUTPUT_BYTES = 20 * 1024  # 20 KB cap on exec output (stdout+stderr)
EXEC_DEFAULT_TIMEOUT = 60   # default exec timeout in seconds
EXEC_MAX_TIMEOUT = 300      # exec timeout clamp: 1-300 s
DEEP_DEFAULT_TIMEOUT = 1800  # default deep timeout, clamped 60-3600 s
UNINSTALL_DEFAULT_TIMEOUT = 120  # default uninstall timeout, clamped 60-300 s
INSTALL_DEFAULT_TIMEOUT = 120    # default install timeout, clamped 60-300 s
REPAIR_DEFAULT_TIMEOUT = 1800    # repair (updates) can take a long time
ACK_FIELD_MAX = 4096        # max chars per ack string field
ACK_TOTAL_MAX = 16 * 1024   # ~16 KB cap on the whole ack JSON
SCREENSHOT_MAX_BYTES = 200 * 1024  # 200 KB cap on screenshot payloads
FRAME_MAX_BYTES = 40 * 1024  # 40 KB cap on live-feed frames (v1.3.4)
FRAME_POST_MIN_INTERVAL = 5  # seconds: hard cap, 1 frame post per 5s
FRAME_LIVENESS_INTERVAL = 60  # seconds: re-post unchanged frame this often

# Relay base URL: loaded in main() from relay-config.json (or the
# KURODOCTOR_RELAY env override for testing). There is deliberately
# NO default here -- a blank/missing URL is a clean exit 2, never a
# silent fallback to some other relay.
RELAY = None
BOOT_ID = str(uuid.uuid4())


# ---------------------------------------------------------------- logging

def log(msg):
    """Timestamped log line to stderr (stdout stays clean for --sweep-only / --deep-only JSON)."""
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(f"[{ts}] {msg}", flush=True, file=sys.stderr)


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def write_audit(message):
    """Append one audit line next to the script. Audit failure never breaks a command."""
    try:
        with open(AUDIT_LOG, "a", encoding="ascii", errors="replace") as fh:
            fh.write(f"[{now_iso()}] {message}\n")
    except OSError:
        pass


# ---------------------------------------------------------------- relay config

def load_relay_url():
    """Relay URL: KURODOCTOR_RELAY env override wins (testing only);
    otherwise relay-config.json next to the script. Returns the URL
    string, or "" when blank/missing (caller exits cleanly)."""
    env_url = os.environ.get("KURODOCTOR_RELAY", "").strip()
    if env_url:
        return env_url.rstrip("/")
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return ""
    if not isinstance(data, dict):
        return ""
    url = data.get("relay_url", "")
    if not isinstance(url, str):
        return ""
    return url.strip().rstrip("/")


def relay_not_configured_message():
    return (
        "KUROdoctor: no relay URL set, so nothing was sent anywhere.\n"
        "Open relay-config.json (next to this script) and paste your\n"
        "Cloudflare Worker URL as \"relay_url\", e.g.\n"
        "https://<your-worker>.<your-subdomain>.workers.dev\n"
        "(or set KURODOCTOR_RELAY for testing).\n"
        "Then run this agent again. Nothing was changed on this Mac."
    )


# ---------------------------------------------------------------- ack hygiene

def _sanitize_string(value):
    """One string field: ASCII only (non-ASCII -> '?'), control chars
    stripped except newline/tab/CR, capped at ACK_FIELD_MAX chars."""
    if not isinstance(value, str):
        return value
    value = value.encode("ascii", "replace").decode("ascii")
    value = "".join(
        ch for ch in value
        if ch in ("\n", "\t", "\r") or (ord(ch) >= 32 and ord(ch) != 127)
    )
    if len(value) > ACK_FIELD_MAX:
        value = value[:ACK_FIELD_MAX] + "... [truncated]"
    return value


def sanitize_ack_value(value):
    """Recursively sanitize every string inside an ack payload."""
    if isinstance(value, str):
        return _sanitize_string(value)
    if isinstance(value, dict):
        return {k: sanitize_ack_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [sanitize_ack_value(v) for v in value]
    return value


def cap_ack_total(ack):
    """Cap the whole ack JSON at ~ACK_TOTAL_MAX bytes. If it is still
    too big after per-field caps, shrink the largest 'output' string
    first; if that is not enough, fall back to a minimal result."""
    ack = sanitize_ack_value(ack)
    try:
        encoded = json.dumps(ack).encode("utf-8")
    except (TypeError, ValueError):
        return {"id": ack.get("id"), "done": False, "at": now_iso(),
                "result": {"error": "ack_content_rejected"}}
    if len(encoded) <= ACK_TOTAL_MAX:
        return ack
    result = ack.get("result")
    if isinstance(result, dict) and isinstance(result.get("output"), str):
        # Shrink the output field until the ack fits (or it is gone).
        budget = max(0, ACK_TOTAL_MAX - len(encoded) + len(result["output"]))
        result["output"] = result["output"][:budget] + "... [truncated]"
        ack["result"] = result
        encoded = json.dumps(ack).encode("utf-8")
        if len(encoded) <= ACK_TOTAL_MAX:
            return ack
    return {"id": ack.get("id"), "done": ack.get("done", False),
            "at": now_iso(),
            "result": {"error": "ack_content_rejected",
                       "detail": "ack payload exceeded the size cap"}}


def minimal_ack(cmd_id, done):
    """The fallback ack: small, plain, always postable."""
    return {"id": cmd_id, "done": bool(done), "at": now_iso(),
            "result": {"error": "ack_content_rejected"}}


# ---------------------------------------------------------------- relay I/O

def relay_post(path, payload):
    """POST JSON to the relay. Returns parsed JSON (or {}), or None on error."""
    url = RELAY + path
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json",
                 "User-Agent": f"KUROdoctor-macos/{VERSION}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", "replace")
            if not body.strip():
                return {}
            try:
                return json.loads(body)
            except json.JSONDecodeError:
                return {"_raw": body}
    except urllib.error.HTTPError as e:
        log(f"relay POST {path} -> HTTP {e.code}")
        return None
    except Exception as e:  # network down, DNS failure, relay unreachable...
        log(f"relay POST {path} failed: {e}")
        return None


def relay_get(path):
    """GET from the relay. Returns parsed JSON (or {}), or None on error."""
    url = RELAY + path
    req = urllib.request.Request(
        url, headers={"User-Agent": f"KUROdoctor-macos/{VERSION}"}, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", "replace")
            if not body.strip():
                return {}
            try:
                return json.loads(body)
            except json.JSONDecodeError:
                return {"_raw": body}
    except urllib.error.HTTPError as e:
        # 204 / 404 with "no command waiting" is normal, not an error.
        if e.code in (204, 404):
            return {}
        log(f"relay GET {path} -> HTTP {e.code}")
        return None
    except Exception as e:
        log(f"relay GET {path} failed: {e}")
        return None


def post_ack(ack):
    """Post an ack with hygiene + retries. Up to 3 attempts, 2s apart;
    if the full ack never lands, fall back to one minimal ack. Returns
    True when something was delivered, False otherwise. Never raises."""
    ack = cap_ack_total(ack)
    cmd_id = ack.get("id")
    for attempt in range(1, 4):
        result = relay_post("/doctor/ack", ack)
        if result is not None:
            log(f"acked id={cmd_id} done={ack.get('done')} (attempt {attempt})")
            return True
        log(f"ack for id={cmd_id} NOT delivered (attempt {attempt} of 3)")
        if attempt < 3:
            time.sleep(2)
    log(f"ack for id={cmd_id} FAILED after 3 attempts -- trying one minimal ack")
    fallback = minimal_ack(cmd_id, ack.get("done", False))
    result = relay_post("/doctor/ack", fallback)
    if result is not None:
        log(f"minimal ack delivered for id={cmd_id}")
        return True
    log(f"minimal ack for id={cmd_id} also failed -- the result may be lost at the relay")
    return False


def post_received(cmd_id):
    """POST /doctor/received {id}: pops the command off the relay
    queue. Returns True when the relay accepted the receipt."""
    result = relay_post("/doctor/received", {"id": cmd_id})
    return result is not None


# ---------------------------------------------------------------- helpers

def _run(cmd, timeout=15):
    """Run a command, return stdout on success, '' on any failure.

    Never raises. A nonzero exit counts as failure (no usable output).
    """
    try:
        out = subprocess.run(cmd, capture_output=True, text=True,
                             timeout=timeout)
        return out.stdout if out.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def _run_full(cmd, timeout=15):
    """Run a command, return (returncode, stdout, stderr). Never raises;
    returncode None means the tool could not even start."""
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout)
        return proc.returncode, proc.stdout or "", proc.stderr or ""
    except subprocess.TimeoutExpired as e:
        out = e.stdout.decode("utf-8", "replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        err = e.stderr.decode("utf-8", "replace") if isinstance(e.stderr, bytes) else (e.stderr or "")
        return None, out, (err + " [timed out]").strip()
    except (OSError, subprocess.SubprocessError) as e:
        return None, "", str(e)


def _sysctl(name):
    """One sysctl value, or '' if the key/tool is missing."""
    out = _run(["sysctl", "-n", name], timeout=10)
    return out.strip()


def _unavailable(reason):
    return {"status": "unavailable", "reason": reason}


def local_ip():
    """Best-effort primary IPv4 address (no traffic is actually sent)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
        finally:
            s.close()
    except OSError:
        return None


def boot_time_epoch():
    """Seconds since epoch at boot, from kern.boottime, or None."""
    out = _sysctl("kern.boottime")
    # "{ sec = 1763240000, usec = 0 } Thu Nov 15 ..."
    m = re.search(r"sec\s*=\s*(\d+)", out)
    if m:
        try:
            return int(m.group(1))
        except ValueError:
            return None
    return None


def uptime_seconds():
    """Uptime in seconds, from kern.boottime, or None."""
    boot = boot_time_epoch()
    if boot is None:
        return None
    return max(0, int(time.time() - boot))


# ---------------------------------------------------------------- device info

def device_model():
    """Best-effort device model string.

    sysctl hw.model gives the machine identifier (e.g. MacBookPro18,3);
    system_profiler gives the marketing name when it runs in time.
    """
    model_id = _sysctl("hw.model")
    out = _run(["system_profiler", "SPHardwareDataType"], timeout=20)
    marketing = ""
    for line in out.splitlines():
        if "Model Name:" in line:
            marketing = line.split(":", 1)[1].strip()
            break
    if marketing and model_id and marketing != model_id:
        return f"{marketing} ({model_id})"
    return marketing or model_id or platform.machine()


def list_disks():
    """Whole-disk device paths, e.g. ['/dev/disk0', '/dev/disk1']."""
    disks = []
    # Preferred: diskutil list -plist (structured, no text scraping).
    out = _run(["diskutil", "list", "-plist"], timeout=15)
    if out:
        try:
            data = plistlib.loads(out.encode("utf-8"))
            for disk in data.get("AllDisksAndPartitions", []):
                dev = disk.get("DeviceIdentifier")
                if dev and not re.search(r"s\d+$", dev):
                    # Whole disks are "diskN"; partitions are "diskNsM".
                    disks.append("/dev/" + dev)
            if disks:
                return sorted(set(disks))
        except (ValueError, plistlib.InvalidFileException):
            pass
    # Fallback: parse `diskutil list` text -- "/dev/disk0 (internal):"
    out = _run(["diskutil", "list"], timeout=15)
    for line in out.splitlines():
        m = re.match(r"^/dev/(disk\d+)\s", line)
        if m:
            disks.append("/dev/" + m.group(1))
    return sorted(set(disks))


def diskutil_info(device):
    """Parsed `diskutil info <device>` key/value pairs, or {} on failure."""
    out = _run(["diskutil", "info", device], timeout=15)
    info = {}
    for line in out.splitlines():
        if ":" in line:
            key, val = line.split(":", 1)
            info[key.strip()] = val.strip()
    return info


def network_state():
    """Interfaces and addresses, best effort, no external tools required."""
    interfaces = {}
    try:
        for _idx, name in socket.if_nameindex():
            interfaces[name] = {"addresses": []}
    except OSError:
        pass
    # `ifconfig` gives the real addresses when the tool exists.
    out = _run(["ifconfig"], timeout=10)
    current = None
    for line in out.splitlines():
        m = re.match(r"^(\S+):\s", line)
        if m:
            current = m.group(1)
            if current not in interfaces:
                interfaces[current] = {"addresses": []}
            continue
        if current:
            m = re.search(r"\binet6?\s+([0-9a-fA-F:.]+)", line)
            if m and m.group(1) not in interfaces[current]["addresses"]:
                interfaces[current]["addresses"].append(m.group(1))
            m = re.search(r"\bether\s+([0-9a-f:]{17})", line)
            if m:
                interfaces[current]["mac"] = m.group(1)
            m = re.search(r"\bstatus:\s+(\S+)", line)
            if m:
                interfaces[current]["state"] = m.group(1)
    hostname = socket.gethostname()
    return {"hostname": hostname, "interfaces": interfaces}


def battery_state():
    """Battery info from `pmset -g batt`, or {} if unavailable (desktop)."""
    out = _run(["pmset", "-g", "batt"], timeout=10)
    if not out:
        return {}
    # " -InternalBattery-0 (id=...)  87%; discharging; 4:12 remaining present: true"
    info = {}
    m = re.search(r"(\d+)%", out)
    if m:
        info["percent"] = int(m.group(1))
    if "charging" in out.lower():
        info["state"] = "charging"
    elif "discharging" in out.lower():
        info["state"] = "discharging"
    elif "charged" in out.lower():
        info["state"] = "charged"
    m = re.search(r"(\d+):(\d+)\s+remaining", out)
    if m:
        info["remaining_minutes"] = int(m.group(1)) * 60 + int(m.group(2))
    return info


def smart_summary(device=None):
    """Short SMART summary per disk.

    Primary source on macOS is `diskutil info` ("SMART Status: Verified"
    where the drive reports it). smartctl is used when installed for
    the fuller picture. If neither can say anything, the section is
    unavailable -- never invented.
    """
    disks = [device] if device else list_disks()
    results = []
    smartctl = shutil.which("smartctl")
    for disk in disks:
        entry = {"disk": disk}
        info = diskutil_info(disk)
        if info:
            entry["model"] = (info.get("Device / Media Name")
                              or info.get("Media Name"))
            entry["serial"] = info.get("Disk / Partition UUID") or None
            entry["smart_status_diskutil"] = info.get("SMART Status")
            entry["solid_state"] = info.get("Solid State")
            entry["size"] = info.get("Disk Size")
        if smartctl is not None:
            try:
                out = subprocess.run(
                    ["smartctl", "-a", "--json", disk],
                    capture_output=True, text=True, timeout=30)
                try:
                    data = json.loads(out.stdout)
                except json.JSONDecodeError:
                    entry["error"] = "unparsable_output"
                    results.append(entry)
                    continue
                passed = None
                status = "unknown"
                if isinstance(data.get("smart_status"), dict):
                    passed = data["smart_status"].get("passed")
                    status = "passed" if passed else "FAILED"
                temp = None
                if isinstance(data.get("temperature"), dict):
                    temp = data["temperature"].get("current")
                entry.update({
                    "model": entry.get("model") or data.get("model_name"),
                    "serial": entry.get("serial") or data.get("serial_number"),
                    "status": status,
                    "smart_passed": passed,
                    "temperature_c": temp,
                    "power_on_hours": (
                        data.get("power_on_time") or {}).get("hours"),
                })
            except (OSError, subprocess.SubprocessError) as e:
                entry["error"] = str(e)
        else:
            # No smartctl: diskutil's SMART Status is the only evidence.
            smart_status = entry.get("smart_status_diskutil")
            if smart_status:
                entry["status"] = ("passed" if smart_status.lower()
                                   in ("verified", "ok")
                                   else "FAILED" if "fail" in
                                   smart_status.lower() else "unknown")
                entry["smart_passed"] = entry["status"] == "passed"
        results.append(entry)
    if not results:
        return {"status": "no_disks",
                "summary": "No disks found to check."}
    if not any("status" in r for r in results):
        return {"status": "unavailable",
                "summary": "No SMART data available: smartctl is not "
                           "installed and diskutil reports no SMART status "
                           "for these disks."}
    bad = [r["disk"] for r in results if r.get("status") == "FAILED"]
    if bad:
        summary = "WARNING: SMART reports a failing drive: " + ", ".join(bad)
    else:
        summary = "SMART: " + ", ".join(
            f"{r['disk']} {r.get('status', 'unknown')}" for r in results)
    return {"status": "ok", "summary": summary, "disks": results}


def disk_space():
    """Disk space for each mounted filesystem (df -k style)."""
    mounts = []
    out = _run(["df", "-k"], timeout=15)
    lines = out.splitlines()
    for line in lines[1:]:  # skip the header
        parts = line.split()
        # Filesystem 1024-blocks Used Available Capacity Mounted on
        if len(parts) < 6:
            continue
        try:
            total_kb = int(parts[1])
            used_kb = int(parts[2])
            free_kb = int(parts[3])
        except ValueError:
            continue
        mount = parts[-1]
        mounts.append({
            "mount": mount,
            "total_gb": round(total_kb / 1e6, 2),
            "used_gb": round(used_kb / 1e6, 2),
            "free_gb": round(free_kb / 1e6, 2),
        })
    if not mounts:  # fallback: just the root filesystem
        try:
            usage = shutil.disk_usage("/")
            mounts.append({"mount": "/", "total_gb": round(usage.total / 1e9, 2),
                           "used_gb": round(usage.used / 1e9, 2),
                           "free_gb": round(usage.free / 1e9, 2)})
        except OSError as e:
            return {"error": str(e)}
    return {"mounts": mounts}


def build_report():
    """The boot / heartbeat report payload.

    The blind sweep runs here, on first connect, before any command is
    polled -- its results ride in the boot report. Later heartbeats
    reuse the cached sweep (get_sweep), so the sweep never re-runs.
    """
    disks = list_disks()
    df = disk_space()
    return {
        "agent": AGENT,
        "version": VERSION,
        "agent_version": VERSION,
        "boot_id": BOOT_ID,
        "at": now_iso(),
        "timestamp": now_iso(),
        "hostname": socket.gethostname(),
        "uptime_s": uptime_seconds(),
        "ip": local_ip(),
        "device": {
            "model": device_model(),
            "hostname": socket.gethostname(),
            "os": f"{platform.system()} {platform.release()}",
            "kernel": platform.version(),
            "arch": platform.machine(),
        },
        "disks": disks,
        "disk_space": df,
        "smart": smart_summary(),
        "network": network_state(),
        "sweep": get_sweep(),
    }


def send_report():
    report = build_report()
    log(f"sending report: model={report['device']['model']} "
        f"disks={report['disks']} smart={report['smart'].get('status')}")
    result = relay_post("/doctor/report", report)
    if result is None:
        log("report NOT delivered (relay unreachable) -- nothing was saved at the relay")
        return False
    log("report delivered")
    return True


# ---------------------------------------------------------------- blind sweep
# The doctor ALWAYS goes in blind. On first connect -- before any command
# is polled and before the user is asked anything -- the agent runs a full
# diagnostic sweep on its own and reports what IT finds. The user's guess
# ("it's riddled with viruses") is optional context only, never the
# diagnosis. Every section is independent: one that cannot run reports
# {"status": "unavailable", "reason": ...} and never blocks the others
# or the boot report.
#
# macOS honesty notes:
# - temps: no public sysctl temperature key exists on macOS, and
#   powermetrics needs sudo -- the agent never requires sudo, so temps
#   is unavailable unless a sysctl key actually yields a temperature.
# - malware_scan: no on-device scanner is bundled. XProtect is a
#   system service, not a scan this agent ran -- the section says so and
#   never claims a scan ran. The processes section is the fallback
#   evidence.
# - pending_updates: `softwareupdate -l` LISTS ONLY. Nothing is ever
#   installed or downloaded.

SWEEP_VERSION = 1

_SWEEP_CACHE = None


def sweep_smart():
    """Drive health (SMART) -- reuses smart_summary(), normalised."""
    s = smart_summary()
    if s.get("status") != "ok":
        return _unavailable(s.get("summary") or s.get("status")
                            or "unknown")
    return {"status": "ok", "summary": s.get("summary"),
            "disks": s.get("disks", [])}


def sweep_disk_space():
    """Disk space per mount, with use_pct added."""
    df = disk_space()
    if "error" in df:
        return _unavailable(df["error"])
    mounts = []
    for m in df.get("mounts", []):
        total = m.get("total_gb") or 0
        used = m.get("used_gb") or 0
        mounts.append({
            "mount": m["mount"],
            "total_gb": total,
            "used_gb": used,
            "free_gb": m.get("free_gb"),
            "use_pct": round(used / total * 100, 1) if total else 0,
        })
    return {"status": "ok", "mounts": mounts}


def _launchd_items_from_dir(directory, source):
    """LaunchAgent/Daemon plist files in one directory.

    Reads Label + Program/ProgramArguments from each .plist with the
    stdlib plist parser. A plist that will not parse still counts as an
    item (name = filename, command empty) -- the file exists, so it is
    reported, not silently dropped.
    """
    items = []
    if not os.path.isdir(directory):
        return items
    try:
        names = sorted(os.listdir(directory))
    except OSError:
        return items
    for fname in names:
        if not fname.endswith(".plist"):
            continue
        path = os.path.join(directory, fname)
        label = fname[:-len(".plist")]
        command = ""
        try:
            with open(path, "rb") as f:
                data = plistlib.load(f)
            if isinstance(data, dict):
                label = data.get("Label") or label
                args = data.get("ProgramArguments")
                if isinstance(args, list) and args:
                    command = " ".join(str(a) for a in args)
                elif isinstance(data.get("Program"), str):
                    command = data["Program"]
        except (OSError, plistlib.InvalidFileException, ValueError):
            pass
        items.append({"name": label, "command": command,
                      "source": source, "plist": path})
    return items


def sweep_startup():
    """Startup items: launchd plists + `launchctl list` (user agents).

    Sources, in order: ~/Library/LaunchAgents, /Library/LaunchAgents,
    /Library/LaunchDaemons, /System/Library/LaunchDaemons (read-only
    listing), plus the user's currently loaded agents from launchctl.
    Nothing is loaded, unloaded, or changed -- read only.
    """
    items = []
    saw_source = False
    home = os.path.expanduser("~")
    for directory, source in (
            (os.path.join(home, "Library", "LaunchAgents"), "LaunchAgents-user"),
            ("/Library/LaunchAgents", "LaunchAgents-system"),
            ("/Library/LaunchDaemons", "LaunchDaemons"),
            ("/System/Library/LaunchDaemons", "LaunchDaemons-system")):
        found = _launchd_items_from_dir(directory, source)
        if os.path.isdir(directory):
            saw_source = True
        items.extend(found)
    # launchctl list: the user's loaded agents (names only; a loaded
    # agent with no plist on disk is still worth reporting).
    out = _run(["launchctl", "list"], timeout=15)
    if out:
        saw_source = True
        known = {i["name"] for i in items}
        for line in out.splitlines():
            parts = line.split()
            # "PID\tStatus\tLabel" -- header line is "PID Status Label".
            if len(parts) >= 3 and parts[0] != "PID":
                label = parts[2]
                if label not in known:
                    items.append({"name": label, "command": "",
                                  "source": "launchctl-loaded"})
                    known.add(label)
    if not saw_source:
        return _unavailable("no startup sources readable "
                            "(no LaunchAgents/LaunchDaemons dirs, "
                            "no launchctl)")
    return {"status": "ok", "count": len(items), "items": items[:50]}


def sweep_processes():
    """Process count + top 10 by CPU and by memory (via ps)."""
    procs = []
    out = _run(["ps", "-axo", "pid,comm,%cpu,rss"], timeout=15)
    for line in out.splitlines()[1:]:  # skip the header
        parts = line.split()
        if len(parts) < 4:
            continue
        try:
            procs.append({
                "pid": int(parts[0]),
                "name": parts[1],
                "cpu_pct": float(parts[2]),
                "mem_mb": round(int(parts[3]) / 1024.0, 1),
            })
        except ValueError:
            continue
    if not procs:
        return _unavailable("ps produced no process list")
    top_cpu = sorted(procs, key=lambda p: p["cpu_pct"],
                     reverse=True)[:10]
    top_mem = sorted(procs, key=lambda p: p["mem_mb"],
                     reverse=True)[:10]
    return {"status": "ok", "count": len(procs),
            "top_cpu": top_cpu, "top_memory": top_mem}


def sweep_temps():
    """Temperatures: sysctl keys that actually yield a temperature.

    macOS exposes no public sysctl temperature key, and powermetrics
    needs sudo -- this agent never requires sudo and never runs
    powermetrics. The section scans `sysctl -a` for any key mentioning
    "temp" with a numeric value in a plausible Celsius range; if none
    exists it reports unavailable honestly instead of inventing a
    reading.
    """
    sensors = []
    out = _run(["sysctl", "-a"], timeout=15)
    for line in out.splitlines():
        if "temp" not in line.lower():
            continue
        # "machdep.xcpm.cpu_thermal_level: 12" is a level, not a temp --
        # only accept keys whose name says temperature, with a value
        # that looks like degrees Celsius (0..125).
        if "thermal" in line.lower():
            continue
        m = re.match(r"^([^:]+):\s*(-?[0-9.]+)\s*$", line.strip())
        if not m:
            continue
        try:
            value = float(m.group(2))
        except ValueError:
            continue
        if 0 <= value <= 125:
            sensors.append({"name": m.group(1).strip(),
                            "temp_c": value})
    if not sensors:
        return _unavailable("no temperature sensor readable without "
                            "sudo: no sysctl temperature key on this Mac, "
                            "and powermetrics requires sudo (never run)")
    return {"status": "ok", "sensors": sensors}


def sweep_pending_updates():
    """Pending updates via `softwareupdate -l` (LIST ONLY, never install)."""
    if shutil.which("softwareupdate") is None:
        return _unavailable("softwareupdate not present")
    out = _run(["softwareupdate", "-l"], timeout=60)
    if not out:
        return _unavailable("softwareupdate -l produced no output")
    if "No new software available" in out:
        return {"status": "ok", "count": 0, "updates": [],
                "reboot_required": False}
    updates = []
    reboot_required = False
    for line in out.splitlines():
        # "* Label: macOS Sonoma 14.5 Update ..." / "   Title: ..., Version: ..."
        m = re.match(r"^\s*\*\s+Label:\s+(.+)$", line)
        if m:
            updates.append(m.group(1).strip())
            if "[restart]" in line.lower():
                reboot_required = True
    if not updates:
        # Output existed but had no parseable labels -- say so plainly.
        return _unavailable("softwareupdate -l output had no parseable "
                            "update labels")
    return {"status": "ok", "count": len(updates),
            "updates": updates[:20],
            "reboot_required": reboot_required}


def sweep_boot_time():
    """Uptime always (kern.boottime); macOS exposes no boot duration,
    so last_boot_s is omitted rather than invented."""
    uptime_s = uptime_seconds()
    section = {"status": "ok", "uptime_s": uptime_s}
    boot = boot_time_epoch()
    if boot is not None:
        section["booted_at"] = datetime.fromtimestamp(
            boot, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return section


def sweep_malware_scan(processes_section):
    """Malware scan section of the boot report -- honestly unavailable.

    No on-device scanner is bundled, and XProtect is a system
    service, not a scan this agent ran -- so no scan is claimed. The
    processes section is the fallback evidence. No background scan is
    started and no follow-up report is sent for this section.
    """
    note = ("no scanner installed; rely on the processes section")
    if isinstance(processes_section, dict) \
            and processes_section.get("status") == "ok":
        note += (f" -- {processes_section.get('count')} processes "
                 f"running")
        top = processes_section.get("top_cpu") or []
        if top:
            note += f", top CPU: {top[0].get('name')}"
    return {"status": "unavailable", "scanner": None,
            "reason": "scanner_unavailable: no on-device scanner "
                      "bundled",
            "process_anomaly_note": note}


def run_blind_sweep():
    """Run the blind sweep: the doctor diagnoses on its own, first thing
    on connect, before any command is polled and before the user is
    asked anything. Every section is independent -- a section that
    cannot run reports unavailable and never blocks the others or the
    boot report."""
    processes = sweep_processes()
    return {
        "sweep_version": SWEEP_VERSION,
        "smart": sweep_smart(),
        "disk_space": sweep_disk_space(),
        "startup_items": sweep_startup(),
        "processes": processes,
        "temps": sweep_temps(),
        "pending_updates": sweep_pending_updates(),
        "boot_time": sweep_boot_time(),
        "malware_scan": sweep_malware_scan(processes),
    }


def get_sweep():
    """The cached blind sweep -- run once on first connect, reused by
    every later heartbeat report so the sweep never re-runs."""
    global _SWEEP_CACHE
    if _SWEEP_CACHE is None:
        _SWEEP_CACHE = run_blind_sweep()
    return _SWEEP_CACHE


# ---------------------------------------------------------------- deep exam
# READ-ONLY hardware deep exam. Every section is independent: one that
# cannot run reports {"status": "unavailable", "reason": ...} and never
# blocks the others. Nothing here writes, deletes, or changes anything.
# Runs as a subprocess of the agent itself (--deep-only) so the async
# job holding it can be killed on timeout.

def deep_disks():
    """diskutil info per whole disk."""
    disks = list_disks()
    if not disks:
        return _unavailable("no disks found (diskutil list gave nothing)")
    return {"status": "ok", "disks": [
        {"device": d, "info": diskutil_info(d)} for d in disks]}


def deep_battery():
    """pmset battery + cycle count / condition from system_profiler
    power data, best effort. Desktops report unavailable honestly."""
    batt = battery_state()
    if not batt:
        return _unavailable("no battery reported by pmset -g batt "
                            "(desktop Mac, or pmset unavailable)")
    section = {"status": "ok", "pmset": batt}
    out = _run(["system_profiler", "SPPowerDataType"], timeout=30)
    for line in out.splitlines():
        m = re.match(r"^\s*(Cycle Count|Condition|Maximum Capacity):\s*(.+)$",
                     line)
        if m:
            section[m.group(1).lower().replace(" ", "_")] = m.group(2).strip()
    return section


def deep_memory():
    """Total/free memory (sysctl + vm_stat) + top 10 by memory."""
    mem_total_mb = mem_free_mb = None
    memsize = _sysctl("hw.memsize")
    if memsize:
        try:
            mem_total_mb = int(memsize) // (1024 * 1024)
        except ValueError:
            pass
    out = _run(["vm_stat"], timeout=10)
    page_size = 16384  # Apple Silicon default; corrected below if stated
    free_pages = None
    for line in out.splitlines():
        m = re.match(r"^Mach Virtual Memory Statistics:.*page size of (\d+)",
                     line)
        if m:
            try:
                page_size = int(m.group(1))
            except ValueError:
                pass
        m = re.match(r"^Pages free:\s+(\d+)", line)
        if m:
            try:
                free_pages = int(m.group(1))
            except ValueError:
                pass
    if free_pages is not None:
        mem_free_mb = free_pages * page_size // (1024 * 1024)
    procs = sweep_processes()
    section = {"status": "ok", "total_mb": mem_total_mb,
               "free_mb": mem_free_mb}
    if mem_total_mb:
        section["free_pct"] = round(mem_free_mb / mem_total_mb * 100, 1) \
            if mem_free_mb is not None else None
    if isinstance(procs, dict) and procs.get("status") == "ok":
        section["top_memory"] = procs.get("top_memory", [])
    return section


def deep_log_errors():
    """Error-line counts from the last 24h of the unified log.

    Streams `log show --last 24h --style compact` and counts lines
    mentioning "error" (case-insensitive), keeping the first 20 as
    samples. The stream is capped (200,000 lines, 120s) so a huge log
    cannot eat the machine. This is NOT the kernel ring buffer --
    that needs root on macOS -- and the result says so.
    """
    if shutil.which("log") is None:
        return _unavailable("the `log` tool is not present")
    deadline = time.monotonic() + 120
    scanned = 0
    error_lines = 0
    samples = []
    try:
        proc = subprocess.Popen(
            ["log", "show", "--last", "24h", "--style", "compact"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    except OSError as e:
        return _unavailable(f"could not start `log show`: {e}")
    try:
        for line in proc.stdout:
            scanned += 1
            if "error" in line.lower():
                error_lines += 1
                if len(samples) < 20:
                    samples.append(line.rstrip("\n")[:500])
            if scanned >= 200000 or time.monotonic() > deadline:
                proc.kill()
                break
        proc.wait(timeout=10)
    except (OSError, subprocess.SubprocessError) as e:
        return _unavailable(f"`log show` failed: {e}")
    finally:
        if proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass
    return {"status": "ok",
            "source": "log show --last 24h (user-visible unified log; "
                      "kernel ring buffer needs root on macOS)",
            "scanned_lines": scanned,
            "error_lines": error_lines,
            "sample_error_lines": samples,
            "capped": scanned >= 200000}


def run_deep_exam():
    """The deep exam: every section independent, failure tolerated."""
    sections = {}
    for name, fn in (
            ("smart", smart_summary),
            ("disks", deep_disks),
            ("battery", deep_battery),
            ("memory", deep_memory),
            ("log_errors_24h", deep_log_errors)):
        try:
            sections[name] = fn()
        except Exception as e:  # one section must never kill the exam
            sections[name] = _unavailable(f"section raised: {e}")
    return {"deep_version": 1, "at": now_iso(), "sections": sections}


# ---------------------------------------------------------------- sync commands

def cmd_sysinfo(_args):
    uname = platform.uname()
    cpu_model = _sysctl("machdep.cpu.brand_string") or "unknown"
    cpu_count = os.cpu_count() or 0
    mem_total_mb = mem_free_mb = None
    memsize = _sysctl("hw.memsize")
    if memsize:
        try:
            mem_total_mb = int(memsize) // (1024 * 1024)
        except ValueError:
            pass
    # Free memory: vm_stat "Pages free" * page size.
    out = _run(["vm_stat"], timeout=10)
    page_size = 16384  # Apple Silicon default; corrected below if stated
    free_pages = None
    for line in out.splitlines():
        m = re.match(r"^Mach Virtual Memory Statistics:.*page size of (\d+)",
                     line)
        if m:
            try:
                page_size = int(m.group(1))
            except ValueError:
                pass
        m = re.match(r"^Pages free:\s+(\d+)", line)
        if m:
            try:
                free_pages = int(m.group(1))
            except ValueError:
                pass
    if free_pages is not None:
        mem_free_mb = free_pages * page_size // (1024 * 1024)
    return {
        "uname": {"system": uname.system, "node": uname.node,
                  "release": uname.release, "version": uname.version,
                  "machine": uname.machine},
        "cpu": {"model": cpu_model, "count": cpu_count},
        "ram_mb": {"total": mem_total_mb, "available": mem_free_mb},
        "battery": battery_state(),
        "disks": list_disks(),
        "network": network_state(),
    }


def cmd_smart(args):
    device = args.get("device")
    if device is not None:
        if not isinstance(device, str) or not device.startswith("/dev/"):
            return {"error": "bad_device",
                    "detail": "smart device must start with /dev/"}
        return smart_summary(device=device)
    return smart_summary()


def cmd_df(_args):
    return disk_space()


def cmd_ls(args):
    path = args.get("path")
    if not path or not isinstance(path, str):
        return {"error": "bad_path", "detail": "ls needs a string 'path'"}
    if not os.path.isabs(path):
        return {"error": "bad_path",
                "detail": f"ls path must be absolute: {path}"}
    if not os.path.isdir(path):
        return {"error": "bad_path", "detail": f"not a directory: {path}"}
    try:
        entries = []
        for name in sorted(os.listdir(path)):
            full = os.path.join(path, name)
            try:
                st = os.lstat(full)
                kind = ("dir" if stat.S_ISDIR(st.st_mode)
                        else "link" if stat.S_ISLNK(st.st_mode) else "file")
                entries.append({"name": name, "type": kind, "size": st.st_size})
            except OSError:
                entries.append({"name": name, "type": "unknown", "size": None})
        return {"path": path, "entries": entries}
    except OSError as e:
        return {"error": "bad_path", "detail": str(e)}


def cmd_cat(args):
    path = args.get("path")
    if not path or not isinstance(path, str):
        return {"error": "bad_path", "detail": "cat needs a string 'path'"}
    if not os.path.isabs(path):
        return {"error": "bad_path",
                "detail": f"cat path must be absolute: {path}"}
    if not os.path.isfile(path):
        return {"error": "bad_path", "detail": f"no such file: {path}"}
    try:
        size = os.path.getsize(path)
    except OSError as e:
        return {"error": "bad_path", "detail": str(e)}
    if size > CAT_MAX_BYTES:
        return {"error": "file_too_large",
                "detail": f"{path} is {size} bytes, over the "
                          f"{CAT_MAX_BYTES}-byte limit"}
    try:
        with open(path, "rb") as f:
            data = f.read()
        return {"path": path, "size": size,
                "encoding": "base64",
                "content": base64.b64encode(data).decode("ascii")}
    except OSError as e:
        return {"error": "bad_path", "detail": str(e)}


def cmd_dmesg(args):
    """Recent system log lines via `log show` (no sudo).

    macOS has no unprivileged kernel ring buffer: `dmesg` needs root
    and the kernel log needs entitlements. `log show` returns the
    user-visible unified log instead -- honest about what it is, and
    never faked. `lines` is optional (default 100, clamped 1-500).
    """
    lines = args.get("lines", 100)
    try:
        lines = int(lines)
    except (TypeError, ValueError):
        lines = 100
    lines = max(1, min(500, lines))
    if shutil.which("log") is None:
        return {"error": "dmesg_unavailable",
                "detail": "the `log` tool is not present; kernel log "
                          "requires root on macOS"}
    try:
        out = subprocess.run(
            ["log", "show", "--last", "5m", "--style", "compact"],
            capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError) as e:
        return {"error": "dmesg_unavailable", "detail": str(e)}
    if out.returncode != 0:
        return {"error": "dmesg_unavailable",
                "detail": "log show failed (kernel log requires root "
                          "on macOS; user-visible log unavailable)"}
    all_lines = out.stdout.splitlines()
    return {"lines": all_lines[-lines:], "total_lines": len(all_lines),
            "source": "log show --last 5m (user-visible unified log; "
                      "kernel ring buffer needs root on macOS)"}


# ---------------------------------------------------------------- exec blocklist
# The authoritative agent-side exec blocklist. exec_blocked() returns
# None when a command string is allowed, or a short reason string
# naming the matched rule when it must be refused.
#
# EVERY pattern here is word-boundary regex -- never substring
# matching. That is the whole point: the word "Information" must
# never trip a rule (no rule word appears inside it), a path like
# /etc/passwd must never trip the passwd rule (passwd is only refused
# when it is the command being run, not when it appears inside a
# path), and "format" inside a longer word must never match.
# Credential-dumping tool names are enforced at the RELAY, not here,
# and this file deliberately names none of them.

_PROTECTED_DIRS = ("Documents", "Pictures", "Desktop", "Downloads")
_PROTECTED_PATH_RE = re.compile(
    r"(?:~|\$HOME|/Users/[^/\s]+)/+(Documents|Pictures|Desktop|Downloads)\b")


def _has_rm_rf_flag(text):
    """True when any single-dash flag token carries both r and f
    (e.g. -rf, -fr, -r -f is two tokens -- handled by the caller
    checking each token; -rf covers the dangerous form)."""
    for tok in re.split(r"\s+", text):
        if tok.startswith("-") and not tok.startswith("--") and len(tok) > 1:
            flags = tok[1:]
            if "r" in flags and "f" in flags:
                return True
    return False


def _has_recursive_flag(text):
    for tok in re.split(r"\s+", text):
        if tok in ("-r", "-R", "--recursive"):
            return True
        if tok.startswith("-") and not tok.startswith("--") and len(tok) > 1:
            if "r" in tok[1:] or "R" in tok[1:]:
                return True
    return False


def _rm_targets_root(text):
    """True when / , ~ , $HOME or /* appears as a standalone rm target."""
    for tok in re.split(r"\s+", text):
        if tok in ("/", "~", "$HOME", "/*", "/."):
            return True
    return False


def _desktop_shortcut_override_ok(text):
    """The owner_override narrow rule: True only when EVERY protected
    path in the command is a .lnk / .alias file under ~/Desktop, with
    no recursive flag and no wildcard anywhere in the command."""
    if _has_recursive_flag(text):
        return False
    if "*" in text or "?" in text:
        return False
    matches = list(_PROTECTED_PATH_RE.finditer(text))
    if not matches:
        return False
    for m in matches:
        if m.group(1) != "Desktop":
            return False
        # The path token this match sits in must end in .lnk or .alias.
        rest = text[m.end():]
        tail = re.split(r"\s", rest, maxsplit=1)[0]
        if not (tail.endswith(".lnk") or tail.endswith(".alias")):
            return False
    return True


def exec_blocked(command, owner_override=False):
    """Return None if the exec command is allowed, else a reason string."""
    if not isinstance(command, str) or not command.strip():
        return None
    text = command
    # sudo rm -rf
    if (re.search(r"\bsudo\b", text, re.IGNORECASE)
            and re.search(r"\brm\b", text, re.IGNORECASE)
            and _has_rm_rf_flag(text)):
        return "blocked: sudo rm -rf"
    # rm -rf aimed at / , ~ or $HOME
    if (re.search(r"\brm\b", text, re.IGNORECASE)
            and _has_rm_rf_flag(text)
            and _rm_targets_root(text)):
        return "blocked: rm -rf on a root/home target"
    # diskutil erase / eraseDisk / eraseVolume / partitionDisk
    if re.search(r"\bdiskutil\b[^\n]*\berase\w*\b", text, re.IGNORECASE):
        return "blocked: diskutil erase"
    if re.search(r"\bdiskutil\b[^\n]*\bpartitionDisk\b", text, re.IGNORECASE):
        return "blocked: diskutil partitionDisk"
    # mkfs
    if re.search(r"\bmkfs\b", text, re.IGNORECASE):
        return "blocked: mkfs"
    # dd writing to a disk device
    if re.search(r"\bdd\b[^\n]*\bof\s*=\s*/dev/(?:disk|rdisk)\w*\b",
                 text, re.IGNORECASE):
        return "blocked: dd to a disk device"
    # shutdown / reboot / halt
    if re.search(r"\b(shutdown|reboot|halt)\b", text, re.IGNORECASE):
        return "blocked: shutdown/reboot/halt"
    # password changes: the passwd command itself (only as a command,
    # never inside a path), and dscl with a passwd argument
    if re.search(r"(?:^|[;&|]\s*|\bsudo\s+)passwd\b", text,
                 re.IGNORECASE | re.MULTILINE):
        return "blocked: passwd (password change)"
    if re.search(r"\bdscl\b[^\n]*\b-?passwd\b", text, re.IGNORECASE):
        return "blocked: dscl password change"
    # lock-screen bypass, either word order
    if re.search(r"lock.?screen[^\n]*bypass|bypass[^\n]*lock.?screen",
                 text, re.IGNORECASE):
        return "blocked: lock-screen bypass"
    # rm aimed at protected user folders (temp/cache paths are allowed)
    if re.search(r"\brm\b", text, re.IGNORECASE):
        if _PROTECTED_PATH_RE.search(text):
            if owner_override and _desktop_shortcut_override_ok(text):
                return None  # the narrow override: Desktop .lnk/.alias only
            return ("blocked: deletion under user-profile Documents, "
                    "Pictures, Desktop, or Downloads")
    return None


def _clamp_timeout(value, default, minimum, maximum):
    try:
        value = int(value)
    except (TypeError, ValueError):
        return default
    return max(minimum, min(maximum, value))


def run_exec_job(job):
    """Worker for an async exec job. Runs /bin/sh -c <command> with a
    timeout, captures stdout+stderr capped at 20KB, and always sets
    job["result"] -- including on timeout, with partial output."""
    command = job["command"]
    timeout_s = job["timeout_s"]
    proc = None
    try:
        proc = subprocess.Popen(["/bin/sh", "-c", command],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True)
        job["proc"] = proc
        try:
            output, _ = proc.communicate(timeout=timeout_s)
            output = output or ""
            job["result"] = {
                "command": command,
                "exit_code": proc.returncode,
                "timed_out": False,
                "output": output[-EXEC_MAX_OUTPUT_BYTES:],
            }
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except OSError:
                pass
            try:
                output, _ = proc.communicate(timeout=10)
            except (OSError, subprocess.SubprocessError):
                output = ""
            output = output or ""
            job["result"] = {
                "command": command,
                "exit_code": None,
                "timed_out": True,
                "output": output[-EXEC_MAX_OUTPUT_BYTES:],
                "error": "timeout",
                "detail": (f"exec ran past its {timeout_s}s timeout and "
                           f"was stopped; partial output is shown"),
            }
    except (OSError, subprocess.SubprocessError) as e:
        job["result"] = {"command": command, "exit_code": None,
                         "timed_out": False, "output": "",
                         "error": "exec_failed", "detail": str(e)}
    finally:
        job["finished"] = True


def validate_exec(cmd_obj):
    """Validate an exec command object. Returns (command, timeout_s,
    owner_override, error_dict_or_None). The audit log line is written
    here, BEFORE the blocklist check and BEFORE anything runs, so a
    refused command is on the record too."""
    command = cmd_obj.get("command")
    if not command or not isinstance(command, str):
        return None, None, False, {"error": "bad_command",
                                   "detail": "exec needs a string 'command'"}
    if len(command) > 20000:
        return None, None, False, {"error": "bad_command",
                                   "detail": "exec command is over the "
                                             "20000-character limit"}
    timeout_s = _clamp_timeout(cmd_obj.get("timeout_s"), EXEC_DEFAULT_TIMEOUT,
                               1, EXEC_MAX_TIMEOUT)
    owner_override = bool(cmd_obj.get("owner_override", False))
    cmd_id = cmd_obj.get("id")
    write_audit(f"exec id={cmd_id} timeout_s={timeout_s} "
                f"owner_override={owner_override} command={command}")
    blocked = exec_blocked(command, owner_override=owner_override)
    if blocked is not None:
        log(f"exec refused (id={cmd_id}): {blocked}")
        write_audit(f"exec id={cmd_id} refused: {blocked}")
        return None, None, False, {"error": "blocked", "detail": blocked}
    return command, timeout_s, owner_override, None


# ---------------------------------------------------------------- screenshot

def _png_dimensions(path):
    """Width/height from a PNG IHDR chunk, or (None, None)."""
    try:
        with open(path, "rb") as fh:
            header = fh.read(33)
        if len(header) < 33 or header[:8] != b"\x89PNG\r\n\x1a\n":
            return None, None
        width, height = struct.unpack(">II", header[16:24])
        return width, height
    except (OSError, struct.error):
        return None, None


def cmd_screenshot(_args):
    """Screenshot via the native `screencapture` tool, scaled /
    compressed to JPEG at or under 200KB with `sips` when available.

    This is the standard macOS screen-capture route, not a red-team
    pattern. First run on a Mac may ask for Screen Recording
    permission for Terminal (System Settings -> Privacy & Security
    -> Screen Recording); without it screencapture fails loudly here.
    """
    if shutil.which("screencapture") is None:
        return {"error": "screenshot_unavailable",
                "detail": "the `screencapture` tool is not present on "
                          "this Mac"}
    tmp_png = None
    tmp_jpg = None
    try:
        fd, tmp_png = tempfile.mkstemp(suffix=".png",
                                      prefix="kurodoctor-shot-")
        os.close(fd)
        rc, _out, err = _run_full(["screencapture", "-x", "-t", "png",
                                   tmp_png], timeout=30)
        if rc != 0:
            return {"error": "screenshot_failed",
                    "detail": ("screencapture failed: "
                               + (err.strip()[-500:] or "no detail")
                               + ". If this Mac asked for Screen Recording "
                                 "permission for Terminal, grant it in "
                                 "System Settings -> Privacy & Security "
                                 "-> Screen Recording and try again.")}
        try:
            size = os.path.getsize(tmp_png)
        except OSError as e:
            return {"error": "screenshot_failed", "detail": str(e)}
        width, height = _png_dimensions(tmp_png)
        if shutil.which("sips") is not None:
            # Descending widths + quality steps until at or under cap.
            fd, tmp_jpg = tempfile.mkstemp(suffix=".jpg",
                                          prefix="kurodoctor-shot-")
            os.close(fd)
            for target_width, quality in (
                    (1920, "best"), (1920, "normal"),
                    (1280, "normal"), (1280, "low"),
                    (800, "low"), (640, "low")):
                rc, _out, _err = _run_full(
                    ["sips", "-s", "format", "jpeg",
                     "-s", "formatOptions", quality,
                     "-Z", str(target_width), tmp_png,
                     "--out", tmp_jpg], timeout=60)
                if rc != 0:
                    continue
                try:
                    jpg_size = os.path.getsize(tmp_jpg)
                except OSError:
                    continue
                if jpg_size <= SCREENSHOT_MAX_BYTES:
                    with open(tmp_jpg, "rb") as fh:
                        data = fh.read()
                    return {"width": width, "height": height,
                            "bytes": len(data), "format": "jpeg",
                            "image_b64": base64.b64encode(data).decode("ascii")}
            return {"error": "screenshot_too_large",
                    "detail": ("the screenshot could not be compressed "
                               "to 200KB or under with sips, even at "
                               "640px / low quality")}
        # No sips: return the PNG as-is if it fits, else say so plainly.
        if size <= SCREENSHOT_MAX_BYTES:
            with open(tmp_png, "rb") as fh:
                data = fh.read()
            return {"width": width, "height": height,
                    "bytes": len(data), "format": "png",
                    "image_b64": base64.b64encode(data).decode("ascii")}
        return {"error": "screenshot_too_large",
                "detail": ("sips is not available to scale this "
                           f"screenshot down, and the PNG is {size} bytes, "
                           "over the 200KB cap")}
    finally:
        for path in (tmp_png, tmp_jpg):
            if path:
                try:
                    os.remove(path)
                except OSError:
                    pass


# ---------------------------------------------------------------- live feed (v1.3.4)

# Mirror of the Windows v1.3.4 Send-KDDoctorFrameTick: change-only
# live-feed frames to POST /doctor/frame, called once per poll
# iteration. Same capture path as cmd_screenshot (screencapture +
# sips), but at feed settings: sips "low" is the closest named
# quality sips offers to the Windows feed's JPEG q40 (sips takes
# named qualities, not numbers), descending widths until the frame
# fits the 40KB cap. If sips cannot get under 40KB, NO frame is
# posted -- the tick logs once and skips, never an oversized post.
# SHA-256 change-only compare, hard cap 1 post per 5 seconds even
# when the screen keeps changing, liveness re-post every 60s when
# nothing changed. No token -- the agent holds none, same as
# Windows. Intervals use time.monotonic() (immune to clock jumps --
# the HP's dead CMOS battery is the standing example of why wall
# time is the wrong clock for this). This section NEVER throws into
# the agent loop.

FRAME_CAPTURE_STEPS = ((1280, "normal"), (800, "low"), (640, "low"))

_FRAME_LAST_HASH = None
_FRAME_LAST_POST_AT = None  # time.monotonic() of the last post
_FRAME_POST_COUNT = 0
_FRAME_LAST_ERROR_AT = None  # time.monotonic() of the last logged failure


def _jpeg_dimensions(path):
    """Width/height from a JPEG SOF0/SOF2 marker, or (None, None)."""
    try:
        with open(path, "rb") as fh:
            data = fh.read()
    except OSError:
        return None, None
    if len(data) < 4 or data[0] != 0xFF or data[1] != 0xD8:
        return None, None
    i = 2
    while i + 3 < len(data):
        if data[i] != 0xFF:
            return None, None
        marker = data[i + 1]
        if marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7 or marker == 0x01:
            i += 2
            continue
        seg_len = struct.unpack(">H", data[i + 2:i + 4])[0]
        if seg_len < 2 or i + seg_len > len(data):
            return None, None
        if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                      0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
            height, width = struct.unpack(">HH", data[i + 5:i + 9])
            return width, height
        i += 2 + seg_len
    return None, None


def _capture_frame_jpeg():
    """Capture the screen as a JPEG at or under FRAME_MAX_BYTES.

    Same capture path as cmd_screenshot (screencapture -x -t png,
    then sips descending widths/qualities), at feed settings.
    Returns {"width", "height", "bytes", "image_b64"} -- width/height
    are the ACTUAL frame dimensions, read back from the JPEG -- or
    {"error", "detail"} when nothing fits / nothing could be captured.
    Never raises; temp files are always removed.
    """
    if shutil.which("screencapture") is None:
        return {"error": "frame_failed",
                "detail": "the `screencapture` tool is not present on "
                          "this Mac"}
    tmp_png = None
    tmp_jpg = None
    try:
        fd, tmp_png = tempfile.mkstemp(suffix=".png",
                                      prefix="kurodoctor-frame-")
        os.close(fd)
        rc, _out, err = _run_full(["screencapture", "-x", "-t", "png",
                                   tmp_png], timeout=30)
        if rc != 0:
            return {"error": "frame_failed",
                    "detail": ("screencapture failed: "
                               + (err.strip()[-500:] or "no detail"))}
        png_width, png_height = _png_dimensions(tmp_png)
        if shutil.which("sips") is not None:
            fd, tmp_jpg = tempfile.mkstemp(suffix=".jpg",
                                          prefix="kurodoctor-frame-")
            os.close(fd)
            for target_width, quality in FRAME_CAPTURE_STEPS:
                rc, _out, _err = _run_full(
                    ["sips", "-s", "format", "jpeg",
                     "-s", "formatOptions", quality,
                     "-Z", str(target_width), tmp_png,
                     "--out", tmp_jpg], timeout=60)
                if rc != 0:
                    continue
                try:
                    jpg_size = os.path.getsize(tmp_jpg)
                except OSError:
                    continue
                if jpg_size <= FRAME_MAX_BYTES:
                    with open(tmp_jpg, "rb") as fh:
                        data = fh.read()
                    width, height = _jpeg_dimensions(tmp_jpg)
                    if width is None:
                        # Fall back to the size sips was asked for:
                        # -Z scales the longest side to target_width.
                        if png_width and png_height:
                            scale = min(1.0, target_width
                                        / max(png_width, png_height))
                            width = max(1, round(png_width * scale))
                            height = max(1, round(png_height * scale))
                        else:
                            return {"error": "frame_failed",
                                    "detail": "could not read the frame "
                                              "dimensions"}
                    return {"width": width, "height": height,
                            "bytes": len(data),
                            "image_b64": base64.b64encode(data).decode("ascii")}
            return {"error": "frame_failed",
                    "detail": ("the frame could not be compressed to "
                               "40KB or under with sips, even at "
                               "640px / low quality")}
        # No sips: return the PNG as-is if it fits, else say so plainly.
        if png_width is None or png_height is None:
            return {"error": "frame_failed",
                    "detail": "could not read the screenshot dimensions"}
        try:
            size = os.path.getsize(tmp_png)
        except OSError as e:
            return {"error": "frame_failed", "detail": str(e)}
        if size <= FRAME_MAX_BYTES:
            with open(tmp_png, "rb") as fh:
                data = fh.read()
            return {"width": png_width, "height": png_height,
                    "bytes": len(data),
                    "image_b64": base64.b64encode(data).decode("ascii")}
        return {"error": "frame_failed",
                "detail": ("sips is not available to scale this frame "
                           f"down, and the PNG is {size} bytes, "
                           "over the 40KB cap")}
    finally:
        for path in (tmp_png, tmp_jpg):
            if path:
                try:
                    os.remove(path)
                except OSError:
                    pass


def _frame_log_failure(detail):
    """One failure log line per minute at most -- a failing feed must
    never spam one line per frame."""
    global _FRAME_LAST_ERROR_AT
    now = time.monotonic()
    if (_FRAME_LAST_ERROR_AT is None
            or now - _FRAME_LAST_ERROR_AT >= 60):
        _FRAME_LAST_ERROR_AT = now
        log(f"live feed: frame failed: {detail}")


def send_frame_tick():
    """One live-feed tick: capture + post a change-only frame.

    Called once per poll iteration from main(). Does nothing when no
    relay URL is configured. Never raises, never throws into the
    agent loop. Logs the first successful post once and failures
    (rate-limited to one line per minute), never one line per frame.
    """
    global _FRAME_LAST_HASH, _FRAME_LAST_POST_AT, _FRAME_POST_COUNT
    if not RELAY:
        return
    try:
        now = time.monotonic()
        due_liveness = True
        if _FRAME_LAST_POST_AT is not None:
            since_post = now - _FRAME_LAST_POST_AT
            if since_post < FRAME_POST_MIN_INTERVAL:
                return
            due_liveness = since_post >= FRAME_LIVENESS_INTERVAL
        # Capture only when a post may be due (at most one capture
        # per 5 seconds); the change check happens after the hash.
        cap = _capture_frame_jpeg()
        if "error" in cap:
            _frame_log_failure(cap.get("detail", "capture failed"))
            return
        data = base64.b64decode(cap["image_b64"])
        frame_hash = hashlib.sha256(data).hexdigest()
        if frame_hash == _FRAME_LAST_HASH and not due_liveness:
            return
        if cap["bytes"] > FRAME_MAX_BYTES:
            # Belt and braces: the capture enforces the cap already.
            _frame_log_failure(
                f"frame is {cap['bytes']} bytes, over the 40KB cap "
                "-- not posted")
            return
        payload = {"image_b64": cap["image_b64"],
                   "width": cap["width"], "height": cap["height"],
                   "bytes": cap["bytes"]}
        result = relay_post("/doctor/frame", payload)
        if result is None:
            # relay_post already logged the failure; stay silent here
            # so one failed post is one log line, not two.
            return
        _FRAME_LAST_HASH = frame_hash
        _FRAME_LAST_POST_AT = now
        _FRAME_POST_COUNT += 1
        if _FRAME_POST_COUNT == 1:
            log(f"live feed: first frame posted ({cap['bytes']} bytes)")
    except Exception as e:  # never break the agent loop
        _frame_log_failure(f"tick error: {e}")


# ---------------------------------------------------------------- mouse / type

ACCESSIBILITY_NOTE = (
    "Mouse/type control needs Accessibility permission: System "
    "Settings -> Privacy & Security -> Accessibility -> turn on "
    "Terminal (the app this agent runs in). Without it, macOS refuses "
    "the control event. Grant it and try again.")

_MOUSE_ACTIONS = ("move", "left_click", "right_click", "double_click")


def _osascript_error(stderr):
    """Map an osascript failure to (error, detail), calling out the
    Accessibility permission step when the failure says so."""
    err = (stderr or "").strip()
    low = err.lower()
    if ("not authorized" in low or "assistive" in low
            or "accessibility" in low or "not allowed" in low
            or "not permitted" in low):
        return "unavailable", ("macOS refused the control event. "
                                + ACCESSIBILITY_NOTE
                                + f" (osascript said: {err[-300:]})")
    return None, err


def _screen_size():
    """Screen size (width, height) from the Finder desktop bounds, or
    (None, None) when it cannot be read (coords are then used as-is)."""
    if shutil.which("osascript") is None:
        return None, None
    rc, out, _err = _run_full(
        ["osascript", "-e",
         'tell application "Finder" to get bounds of window of desktop'],
        timeout=15)
    if rc != 0:
        return None, None
    m = re.search(r"\{\s*0,\s*0,\s*(\d+),\s*(\d+)\s*\}", out)
    if not m:
        return None, None
    return int(m.group(1)), int(m.group(2))


def cmd_mouse(args):
    """Mouse control via osascript + CoreGraphics synthetic events.

    Requires the Accessibility permission (see ACCESSIBILITY_NOTE).
    Without it this returns "unavailable" loudly, never silently.
    """
    try:
        x = int(args.get("x"))
        y = int(args.get("y"))
    except (TypeError, ValueError):
        return {"error": "bad_coords",
                "detail": "mouse needs integer 'x' and 'y'"}
    action = args.get("action", "left_click")
    if action not in _MOUSE_ACTIONS:
        return {"error": "bad_action",
                "detail": f"unknown mouse action: {action!r} (want one of "
                          f"{', '.join(_MOUSE_ACTIONS)})"}
    width, height = _screen_size()
    if width is not None and height is not None:
        if not (0 <= x < width and 0 <= y < height):
            return {"error": "bad_coords",
                    "detail": f"({x}, {y}) is outside the {width}x{height} screen"}
    if shutil.which("osascript") is None:
        return {"error": "unavailable",
                "detail": "osascript is not present on this Mac. "
                          + ACCESSIBILITY_NOTE}
    script = [
        'use framework "CoreGraphics"',
        f"current application's CGWarpMouseCursorPosition({{{x}, {y}}})",
    ]
    if action in ("left_click", "double_click"):
        down = "current application's kCGEventLeftMouseDown"
        up = "current application's kCGEventLeftMouseUp"
        button = "current application's kCGMouseButtonLeft"
    elif action == "right_click":
        down = "current application's kCGEventRightMouseDown"
        up = "current application's kCGEventRightMouseUp"
        button = "current application's kCGMouseButtonRight"
    else:  # move: warping the cursor is the whole action
        down = up = button = None
    clicks = 2 if action == "double_click" else 1
    for _ in range(clicks):
        if down is not None:
            script.append(
                f"set downEvent to current application's "
                f"CGEventCreateMouseEvent(missing value, {down}, "
                f"{{{x}, {y}}}, {button})")
            script.append(
                f"set upEvent to current application's "
                f"CGEventCreateMouseEvent(missing value, {up}, "
                f"{{{x}, {y}}}, {button})")
            script.append("current application's CGEventPost(current "
                          "application's kCGHIDEventTap, downEvent)")
            script.append("current application's CGEventPost(current "
                          "application's kCGHIDEventTap, upEvent)")
            script.append("delay 0.05")
    cmd = ["osascript"]
    for line in script:
        cmd += ["-e", line]
    rc, _out, err = _run_full(cmd, timeout=15)
    if rc != 0:
        error, detail = _osascript_error(err)
        if error == "unavailable":
            return {"error": "unavailable", "detail": detail}
        return {"error": "mouse_failed",
                "detail": f"osascript failed: {detail[-500:] or 'no detail'}"}
    return {"x": x, "y": y, "action": action}


def _applescript_escape(value):
    """Escape a string for use inside a double-quoted AppleScript literal."""
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _frontmost_process():
    """(name, pid) of the frontmost app, or None when it cannot be read.

    One osascript call, two statements: the name, then the unix id.
    pid is None when the id line does not parse -- the name is what
    the focus checks compare.
    """
    if shutil.which("osascript") is None:
        return None
    rc, out, _err = _run_full(
        ["osascript", "-e",
         'tell application "System Events" to get name of first process whose frontmost is true',
         "-e",
         'tell application "System Events" to get unix id of first process whose frontmost is true'],
        timeout=15)
    if rc != 0:
        return None
    lines = [ln.strip() for ln in out.strip().splitlines() if ln.strip()]
    if not lines:
        return None
    pid = None
    if len(lines) > 1:
        try:
            pid = int(lines[1])
        except ValueError:
            pid = None
    return lines[0], pid


def _focus_process(name):
    """Bring the named app to front and verify it is frontmost.

    Returns {"name", "pid"} on success, or {"error", "detail"}:
    "no_window" (no such process, or it has no visible window),
    "focus_failed" (bring-to-front did not land, or the app could
    not even be queried), "unavailable" (osascript missing /
    Accessibility denied). Never types -- the caller types only
    after this returns success.
    """
    if shutil.which("osascript") is None:
        return {"error": "unavailable",
                "detail": "osascript is not present on this Mac. "
                          + ACCESSIBILITY_NOTE}
    esc = _applescript_escape(name)
    # 1. The process must exist AND have a visible window -- an app
    #    with no window is nothing to type into (mirrors the Windows
    #    "visible main window" requirement).
    rc, out, err = _run_full(
        ["osascript", "-e",
         f'tell application "System Events" to count (every window of process "{esc}" whose visible is true)'],
        timeout=15)
    if rc != 0:
        error, detail = _osascript_error(err)
        if error == "unavailable":
            return {"error": "unavailable", "detail": detail}
        low = (err or "").lower()
        if ("can't get process" in low or "doesn't exist" in low
                or "not exist" in low):
            return {"error": "no_window",
                    "detail": f"no visible window for process: {name}"}
        return {"error": "focus_failed",
                "detail": f"could not query windows of process: {name} "
                          f"(osascript said: {(err or '').strip()[-300:] or 'no detail'})"}
    try:
        visible = int(out.strip().splitlines()[0].strip())
    except (ValueError, IndexError):
        visible = 0
    if visible <= 0:
        return {"error": "no_window",
                "detail": f"no visible window for process: {name}"}
    # 2. Bring it to front.
    rc, _out, err = _run_full(
        ["osascript", "-e",
         f'tell application "System Events" to set frontmost of process "{esc}" to true'],
        timeout=15)
    if rc != 0:
        error, detail = _osascript_error(err)
        if error == "unavailable":
            return {"error": "unavailable", "detail": detail}
        return {"error": "focus_failed",
                "detail": f"could not bring to front: {name} "
                          f"(osascript said: {(err or '').strip()[-300:] or 'no detail'})"}
    # 3. Verify it actually is frontmost now.
    front = _frontmost_process()
    if front is None:
        return {"error": "focus_failed",
                "detail": f"could not verify the frontmost app after focusing {name}"}
    front_name, front_pid = front
    if front_name.lower() != name.lower():
        return {"error": "focus_failed",
                "detail": f"could not bring to front: {name} "
                          f"(frontmost is now {front_name})"}
    return {"name": front_name, "pid": front_pid}


# Process names of terminal emulators the agent itself may run in.
# If one of these is frontmost when type arrives with no `process`,
# keys would land in the agent's own terminal, so the fallback in
# _newest_visible_app runs instead. Other terminal hosts (VS Code's
# integrated terminal, Alacritty, ...) are NOT detected -- their
# process names are not terminals by any API macOS offers, and
# guessing at them would refuse legitimate targets. If the agent is
# ever run from one, type without `process` lands in that terminal;
# pass `process` explicitly to be sure.
_TERMINAL_PROCESS_NAMES = ("Terminal", "iTerm2")


def _newest_visible_app(exclude_names=(), exclude_pids=()):
    """Most recently launched app with a visible window.

    System Events cannot report launch time, so the ordering comes
    from `ps` start times (one call, parsed whole), and System Events
    is only asked -- newest first, at most 10 candidates -- for the
    app name and visible-window count of each pid (by unix id, which
    is an exact match). The pick is brought to front and verified
    like _focus_process. Returns {"name", "pid"} or
    {"error", "detail"} ("no_window" / "focus_failed" /
    "unavailable").

    Honest limits: a pid whose app has no AppleScript-visible window
    is skipped; `ps` start times are second-resolution, so two apps
    launched in the same second order arbitrarily; and a fast-moving
    desktop (apps launching/closing mid-scan) can make the pick stale
    by the time keys are sent -- the bring-to-front + verify step
    fails closed as focus_failed in that case instead of typing
    blind. What this CANNOT prove: that the picked app is the one
    the operator meant -- it is only the newest visible one. Pass
    `process` explicitly whenever the target matters.
    """
    if shutil.which("osascript") is None:
        return {"error": "unavailable",
                "detail": "osascript is not present on this Mac. "
                          + ACCESSIBILITY_NOTE}
    rc, out, _err = _run_full(["ps", "-ax", "-o", "pid=,lstart="],
                              timeout=15)
    started = {}
    if rc == 0:
        for line in out.splitlines():
            parts = line.split(None, 1)
            if len(parts) != 2:
                continue
            try:
                pid = int(parts[0])
                when = datetime.strptime(parts[1].strip(),
                                         "%a %b %d %H:%M:%S %Y")
            except ValueError:
                continue
            started[pid] = when
    if not started:
        return {"error": "no_window",
                "detail": "no suitable window to focus"}
    newest = sorted(started, key=lambda p: started[p], reverse=True)
    checked = 0
    for pid in newest:
        if pid in exclude_pids:
            continue
        if checked >= 10:
            break
        checked += 1
        rc, out, err = _run_full(
            ["osascript",
             "-e", 'tell application "System Events"',
             "-e", f"set _kd_p to first process whose unix id is {pid}",
             "-e", "set _kd_n to name of _kd_p",
             "-e", "set _kd_c to count of (windows of _kd_p whose visible is true)",
             "-e", 'return _kd_n & "|" & _kd_c',
             "-e", "end tell"],
            timeout=15)
        if rc != 0:
            error, detail = _osascript_error(err)
            if error == "unavailable":
                return {"error": "unavailable", "detail": detail}
            continue  # no such process any more, or not scriptable
        fields = out.strip().split("|")
        if len(fields) != 2:
            continue
        name = fields[0].strip()
        try:
            visible = int(fields[1].strip())
        except ValueError:
            continue
        if not name or name in exclude_names or visible <= 0:
            continue
        # Bring it to front and verify -- same bar as _focus_process.
        focused = _focus_process(name)
        if "error" in focused:
            return focused
        return focused
    return {"error": "no_window",
            "detail": "no suitable window to focus"}


def _focus_for_type(process):
    """Resolve the app keystrokes should land in.

    With `process`: bring that app to front + verify (see
    _focus_process). Without it: the current frontmost app, unless
    it is a terminal (the agent's own terminal) -- then the most
    recently launched app with a visible window (see
    _newest_visible_app), brought to front + verified. The frontmost
    app in the no-process branch needs no bring-to-front: it is
    already where keys land, exactly as the Windows agent returns
    the foreground window as-is in that branch. Returns {"name",
    "pid"} or {"error", "detail"}.
    """
    if process is not None:
        return _focus_process(process)
    front = _frontmost_process()
    if front is not None:
        front_name, front_pid = front
        if front_name not in _TERMINAL_PROCESS_NAMES:
            return {"name": front_name, "pid": front_pid}
        return _newest_visible_app(
            exclude_names=_TERMINAL_PROCESS_NAMES,
            exclude_pids={front_pid} if front_pid is not None else set())
    # Frontmost could not be read at all -- fall back the same way;
    # if nothing is found the caller fails closed with no_window.
    return _newest_visible_app(exclude_names=_TERMINAL_PROCESS_NAMES)


def cmd_type(args):
    """Type text via osascript + System Events keystroke.

    Requires the Accessibility permission (see ACCESSIBILITY_NOTE).
    Operator rule, always: never type into a password or login field.
    v1.3.4: optional `process` focuses that app first (see
    _focus_for_type); on any focus error NOTHING is typed.
    """
    text = args.get("text")
    if not isinstance(text, str) or not text:
        return {"error": "bad_text",
                "detail": "type needs a non-empty string 'text'"}
    if len(text) > 1000:
        return {"error": "bad_text",
                "detail": "type text is over the 1000-character limit"}
    if any(ord(c) < 32 and c not in ("\n", "\t", "\r") for c in text):
        return {"error": "bad_text",
                "detail": "type text contains control characters "
                          "(only newline/tab allowed)"}
    # v1.3.4: optional `process`, validated like the relay does
    # (string, 1-200 chars, no control chars -> bad_process).
    process = args.get("process")
    if process is not None:
        if (not isinstance(process, str) or not process
                or len(process) > 200
                or any(ord(c) < 32 for c in process)):
            return {"error": "bad_process",
                    "detail": "type 'process' must be a string of "
                              "1-200 characters with no control "
                              "characters"}
    if shutil.which("osascript") is None:
        return {"error": "unavailable",
                "detail": "osascript is not present on this Mac. "
                          + ACCESSIBILITY_NOTE}
    # Focus FIRST. If no window can be focused, type NOTHING.
    focus = _focus_for_type(process)
    if "error" in focus:
        return focus
    escaped = text.replace("\\", "\\\\").replace('"', '\\"')
    rc, _out, err = _run_full(
        ["osascript", "-e",
         f'tell application "System Events" to keystroke "{escaped}"'],
        timeout=15)
    if rc != 0:
        error, detail = _osascript_error(err)
        if error == "unavailable":
            return {"error": "unavailable", "detail": detail}
        return {"error": "type_failed",
                "detail": f"osascript failed: {detail[-500:] or 'no detail'}"}
    return {"typed_chars": len(text),
            "process": focus["name"],
            "focused_process": focus["name"],
            "focused_pid": focus.get("pid")}


# ---------------------------------------------------------------- clean

CLEAN_LOCATIONS = ("trash", "caches", "tmp")


def _clean_roots():
    home = os.path.expanduser("~")
    return {
        "trash": os.path.join(home, ".Trash"),
        "caches": os.path.join(home, "Library", "Caches"),
        "tmp": "/tmp",
    }


def _measure_tree(root):
    """Total bytes of regular files under root (best effort)."""
    total = 0
    for dirpath, dirnames, filenames in os.walk(root, topdown=True,
                                                followlinks=False):
        dirnames[:] = [d for d in dirnames
                       if not d.startswith("kurodoctor-repair-backup-")
                       and not d.startswith("kurodoctor-quarantine-")]
        for name in filenames:
            path = os.path.join(dirpath, name)
            try:
                st = os.lstat(path)
            except OSError:
                continue
            if stat.S_ISREG(st.st_mode):
                total += st.st_size
    return total


def cmd_clean(_args):
    """Named trash clearing ONLY, synchronous (fast).

    Allowed locations, and ONLY these: the Trash (~/.Trash),
    ~/Library/Caches, and /tmp. Anything outside the list is refused
    by construction -- Documents / Pictures / Desktop / Downloads are
    never matched, and nothing is ever deleted by image or video
    extension. Measured before/after per location (file count + MB).
    Files changed in the last hour are left alone (treated as in
    use), and KUROdoctor's own backup/quarantine dirs are skipped.
    """
    roots = _clean_roots()
    now = time.time()
    results = {}
    total_before = total_after = 0
    for label in CLEAN_LOCATIONS:
        root = roots[label]
        before = _measure_tree(root) if os.path.isdir(root) else 0
        removed = 0
        if os.path.isdir(root):
            for dirpath, dirnames, filenames in os.walk(
                    root, topdown=True, followlinks=False):
                dirnames[:] = [d for d in dirnames
                               if not d.startswith("kurodoctor-repair-backup-")
                               and not d.startswith("kurodoctor-quarantine-")]
                for name in filenames:
                    path = os.path.join(dirpath, name)
                    try:
                        st = os.lstat(path)
                    except OSError:
                        continue
                    if not stat.S_ISREG(st.st_mode):
                        continue
                    if now - st.st_mtime < 3600:
                        continue  # in use (changed in the last hour)
                    try:
                        os.remove(path)
                        removed += 1
                    except OSError:
                        continue
        after = _measure_tree(root) if os.path.isdir(root) else 0
        results[label] = {
            "before_mb": round(before / 1e6, 2),
            "after_mb": round(after / 1e6, 2),
            "files_removed": removed,
        }
        total_before += before
        total_after += after
    return {
        "before_mb": round(total_before / 1e6, 2),
        "after_mb": round(total_after / 1e6, 2),
        "freed_mb": round((total_before - total_after) / 1e6, 2),
        "items": results,
    }


# ---------------------------------------------------------------- repair
# The agent calls repair-macos.py as a subprocess (never duplicated
# into this file): python3 repair-macos.py --go --repair <mapped>
# [--target ...] [--package ...]. The repair module's own audit log,
# its own manifest snapshot, and its owner-go flag still apply inside.
#
# REPAIR FUNCTION MAPPING (agent function -> repair-macos.py repair):
#   system_files  -> softwareupdate-repair (named updates only) +
#                    a disk-check report on /
#   startup       -> startup-cleanup (named launchd labels only)
#   temp          -> temp-cleanup
#   defender_scan -> malware-quarantine (Gatekeeper status; with
#                    names= it MOVES only the named files)
#
# SNAPSHOT RULE (see header): `tmutil snapshot` runs FIRST. If it
# fails or tmutil is missing, the repair REFUSES with status
# "refused" / detail "snapshot_unavailable" and nothing runs.

REPAIR_MAP = {
    "system_files": "softwareupdate-repair",
    "startup": "startup-cleanup",
    "temp": "temp-cleanup",
    "defender_scan": "malware-quarantine",
}


def validate_repair_names(names):
    """names= must be a list of strings, each 1-50 chars, no * or ?.
    Returns an error dict, or None when the names are valid."""
    if names is None:
        return None
    if not isinstance(names, list):
        return {"error": "bad_names",
                "detail": "repair 'names' must be an array of strings"}
    for name in names:
        if not isinstance(name, str) or not (1 <= len(name) <= 50):
            return {"error": "bad_names",
                    "detail": "each repair name must be a string of "
                              "1-50 characters"}
        if "*" in name or "?" in name:
            return {"error": "bad_names",
                    "detail": "repair names must not contain wildcards "
                              "(* or ?)"}
    return None


def take_local_snapshot():
    """Attempt `tmutil snapshot` (best-effort, needs no confirmation).
    Returns (ok, info): ok True with {"snapshot": ..., "date": ...}
    when a local snapshot was created; ok False with
    {"reason": "snapshot_unavailable", "detail": ...} otherwise."""
    if shutil.which("tmutil") is None:
        return False, {"reason": "snapshot_unavailable",
                       "detail": "tmutil is not available on this Mac, "
                                 "so no local snapshot could be taken"}
    rc, out, err = _run_full(["tmutil", "snapshot"], timeout=120)
    if rc != 0:
        return False, {"reason": "snapshot_unavailable",
                       "detail": ("`tmutil snapshot` failed: "
                                  + (err.strip()[-500:] or out.strip()[-500:]
                                     or "no detail"))}
    date = ""
    m = re.search(r"date:\s*(.+)", out)
    if m:
        date = m.group(1).strip()
    return True, {"snapshot": "local snapshot",
                  "date": date or "created just now",
                  "detail": out.strip()[-500:]}


def _extract_json_object(text):
    """The repair module prints plain lines AND a JSON result object;
    pull the JSON object out of the mixed output."""
    text = text or ""
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except ValueError:
        pass
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        try:
            data = json.loads(text[start:end + 1])
            if isinstance(data, dict):
                return data
        except ValueError:
            pass
    return None


def _run_repair_module(argv, timeout_s, job=None):
    """Run repair-macos.py with argv (after --go), capture its JSON
    result. Returns a result dict; always returns something, never
    raises. job is set so a timeout kill can reach the subprocess."""
    if not os.path.isfile(REPAIR_SCRIPT):
        return {"repair": argv[1] if len(argv) > 1 else "?",
                "status": "failed", "before": "", "after": "",
                "detail": "repair module not found next to the agent "
                          "(repair-macos.py is missing)",
                "error": "repair_module_missing"}
    proc = None
    try:
        proc = subprocess.Popen(
            [sys.executable, REPAIR_SCRIPT, "--go"] + argv,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if job is not None:
            job["proc"] = proc
        try:
            out, err = proc.communicate(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except OSError:
                pass
            try:
                out, err = proc.communicate(timeout=10)
            except (OSError, subprocess.SubprocessError):
                out, err = "", ""
            return {"repair": argv[1] if len(argv) > 1 else "?",
                    "status": "timeout", "before": "", "after": "",
                    "detail": (f"repair ran past its {timeout_s}s timeout "
                               "and was stopped"),
                    "error": "timeout", "timed_out": True,
                    "output": (out or "")[-2000:]}
        parsed = _extract_json_object(out)
        if parsed is not None:
            return parsed
        return {"repair": argv[1] if len(argv) > 1 else "?",
                "status": "failed" if proc.returncode else "ok",
                "before": "", "after": "",
                "detail": ("repair module output could not be parsed as "
                           "JSON; raw output tail: "
                           + (out or "")[-1000:]
                           + ((" stderr: " + err[-500:]) if err else ""))}
    except (OSError, subprocess.SubprocessError) as e:
        return {"repair": argv[1] if len(argv) > 1 else "?",
                "status": "failed", "before": "", "after": "",
                "detail": f"could not start the repair module: {e}",
                "error": "repair_failed"}
    finally:
        if job is not None:
            job["proc"] = None


def run_repair_job(job):
    """Worker for an async repair job. The snapshot gate already ran
    at dispatch; this runs the mapped repair module step(s) and always
    sets job["result"]."""
    function = job["function"]
    names = job["names"]
    timeout_s = job["timeout_s"]
    snapshot = job.get("snapshot") or {}
    try:
        if function == "system_files":
            # Step 1: named updates only (no names = list-only, the
            # module skips installing anything). Step 2: disk-check
            # report on / (report only -- the module never repairs).
            argv = ["--repair", "softwareupdate-repair"]
            for label in names:
                argv += ["--package", label]
            step1 = _run_repair_module(argv, timeout_s, job=job)
            step2 = _run_repair_module(["--repair", "disk-check"],
                                       min(timeout_s, 900), job=job)
            statuses = [step1.get("status"), step2.get("status")]
            if all(s == "ok" for s in statuses):
                overall = "ok"
            elif any(s in ("failed", "timeout") for s in statuses):
                overall = "failed"
            else:
                overall = "skipped"
            job["result"] = {
                "function": function,
                "repair": "system_files",
                "status": overall,
                "snapshot": snapshot,
                "steps": {"softwareupdate_repair": step1,
                          "disk_check": step2},
                "before": step1.get("before", ""),
                "after": step2.get("after", ""),
                "detail": ("softwareupdate-repair: "
                           + str(step1.get("detail", ""))[:2000]
                           + " | disk-check: "
                           + str(step2.get("detail", ""))[:2000]),
            }
            if overall != "ok":
                job["result"]["error"] = "repair_failed"
            return
        mapped = REPAIR_MAP[function]
        argv = ["--repair", mapped]
        if function == "startup":
            for name in names:
                argv += ["--target", name]
        elif function == "defender_scan":
            for name in names:
                argv += ["--target", name]
        step = _run_repair_module(argv, timeout_s, job=job)
        result = {"function": function, "repair": mapped,
                  "status": step.get("status", "failed"),
                  "snapshot": snapshot,
                  "before": step.get("before", ""),
                  "after": step.get("after", ""),
                  "detail": step.get("detail", "")}
        if step.get("status") != "ok":
            result["error"] = "repair_failed"
        job["result"] = result
    except Exception as e:  # a worker must never die without a result
        job["result"] = {"function": function, "repair": function,
                         "status": "failed", "snapshot": snapshot,
                         "before": "", "after": "",
                         "detail": f"repair worker raised: {e}",
                         "error": "repair_failed"}
    finally:
        job["finished"] = True


def validate_repair(cmd_obj):
    """Validate a repair command. Returns (function, names, timeout_s,
    snapshot_info, error_dict_or_None). The tmutil snapshot gate runs
    HERE, synchronously at dispatch: a refused repair never starts a
    job and never changes anything."""
    function = cmd_obj.get("function")
    if not function or not isinstance(function, str):
        return None, None, None, None, {"error": "bad_function",
                                        "detail": "repair needs a string "
                                                  "'function'"}
    if function not in REPAIR_MAP:
        return None, None, None, None, {
            "error": "bad_function",
            "detail": f"unknown repair function: {function} (want one of "
                      f"{', '.join(sorted(REPAIR_MAP))})"}
    names = cmd_obj.get("names", [])
    name_error = validate_repair_names(names)
    if name_error is not None:
        return None, None, None, None, name_error
    if function == "startup" and not names:
        return None, None, None, None, {"error": "bad_names",
                                        "detail": "startup repair needs at "
                                                  "least one named launchd "
                                                  "label"}
    timeout_s = _clamp_timeout(cmd_obj.get("timeout_s"), REPAIR_DEFAULT_TIMEOUT,
                               60, 3600)
    # Snapshot gate: macOS has no Windows restore points, so a local
    # Time Machine snapshot is the rollback point. No snapshot, no
    # repair -- refused loudly, never silent.
    ok, snapshot = take_local_snapshot()
    if not ok:
        log(f"repair refused (function={function}): snapshot unavailable")
        return None, None, None, None, {
            "function": function, "status": "refused",
            "detail": "snapshot_unavailable",
            "error": "snapshot_unavailable"}
    return function, names, timeout_s, snapshot, None


# ---------------------------------------------------------------- uninstall

UNINSTALL_KINDS = ("app", "brew")


def _list_processes():
    """[(pid, name, args)] from `ps -axo pid,comm,args`, best effort."""
    procs = []
    out = _run(["ps", "-axo", "pid,comm,args"], timeout=15)
    for line in out.splitlines()[1:]:
        parts = line.split(None, 2)
        if len(parts) < 2:
            continue
        try:
            pid = int(parts[0])
        except ValueError:
            continue
        procs.append((pid, parts[1], parts[2] if len(parts) > 2 else ""))
    return procs


def validate_uninstall_name(name):
    """A name is a plain name: string <=200 chars, no backslash, no
    slash, no '..'. Returns an error dict, or None."""
    if not isinstance(name, str) or not name:
        return {"error": "bad_name",
                "detail": "uninstall needs a string 'name'"}
    if len(name) > 200:
        return {"error": "bad_name",
                "detail": "uninstall name is over the 200-character limit"}
    if "\\" in name or "/" in name or ".." in name:
        return {"error": "bad_name",
                "detail": "uninstall name must be a plain name (no "
                          "backslash, no slash, no '..')"}
    return None


def resolve_app_bundle(name):
    """Find the .app bundle for a plain app name in /Applications or
    ~/Applications. Returns the bundle path, or None."""
    base = name[:-4] if name.endswith(".app") else name
    home = os.path.expanduser("~")
    for root in ("/Applications",
                 os.path.join(home, "Applications")):
        candidate = os.path.join(root, base + ".app")
        if os.path.isdir(candidate):
            return candidate
    return None


def find_running_for_app(bundle_path, app_name):
    """Processes whose path is under the target .app bundle or whose
    name matches the target. Returns [(pid, name)] (possibly empty)."""
    base = os.path.basename(bundle_path) if bundle_path else app_name
    stem = base[:-4] if base.endswith(".app") else base
    running = []
    for pid, comm, args in _list_processes():
        if pid == os.getpid():
            continue
        if bundle_path and bundle_path in args:
            running.append((pid, comm))
        elif comm.lower() == stem.lower():
            running.append((pid, comm))
    return running


def find_running_for_brew(name):
    """Processes whose command name matches the brew formula name."""
    running = []
    for pid, comm, args in _list_processes():
        if pid == os.getpid():
            continue
        if comm.lower() == name.lower():
            running.append((pid, comm))
    return running


def run_uninstall_job(job):
    """Worker for an async uninstall job. The running-process precheck
    ran at dispatch AND runs again here, right before anything is
    touched. Always sets job["result"]. The uninstall kind (app/brew)
    lives in job["uninstall_kind"]; job["kind"] is the job-tracking
    label ("uninstall")."""
    kind = job.get("uninstall_kind") or job.get("kind")
    name = job["name"]
    try:
        if kind == "app":
            bundle = resolve_app_bundle(name)
            if bundle is None:
                job["result"] = {"kind": kind, "name": name,
                                 "status": "failed",
                                 "error": "not_found",
                                 "detail": (f"no .app bundle named {name!r} "
                                            "found in /Applications or "
                                            "~/Applications")}
                return
            running = find_running_for_app(bundle, name)
            if running:
                job["result"] = {"kind": kind, "name": name,
                                 "status": "refused",
                                 "error": "target_running",
                                 "detail": ("refused: these processes are "
                                            "still running from "
                                            f"{bundle}: "
                                            + ", ".join(
                                                f"{n} (pid {p})"
                                                for p, n in running)
                                            + ". Quit them first; nothing "
                                              "was deleted.")}
                return
            trash = os.path.join(os.path.expanduser("~"), ".Trash")
            dest = os.path.join(trash, os.path.basename(bundle))
            counter = 1
            while os.path.exists(dest):
                stem = os.path.basename(bundle)[:-4]
                dest = os.path.join(trash, f"{stem}_{counter}.app")
                counter += 1
            try:
                os.rename(bundle, dest)
            except OSError:
                try:
                    shutil.move(bundle, dest)
                except OSError as e:
                    job["result"] = {"kind": kind, "name": name,
                                     "status": "failed",
                                     "error": "uninstall_failed",
                                     "detail": f"could not move {bundle} "
                                               f"to Trash: {e}"}
                    return
            if os.path.exists(bundle):
                job["result"] = {"kind": kind, "name": name,
                                 "status": "failed",
                                 "error": "uninstall_failed",
                                 "detail": (f"{bundle} is still there after "
                                            "the move to Trash -- verify "
                                            "by hand")}
                return
            job["result"] = {"kind": kind, "name": name, "status": "ok",
                             "detail": (f"moved {bundle} to Trash "
                                        f"({dest}); the bundle is gone "
                                        "from /Applications. Nothing was "
                                        "deleted outright -- it can be put "
                                        "back from the Trash.")}
            return
        # kind == "brew"
        if shutil.which("brew") is None:
            job["result"] = {"kind": kind, "name": name, "status": "failed",
                             "error": "brew_missing",
                             "detail": "Homebrew (`brew`) is not installed "
                                       "on this Mac"}
            return
        running = find_running_for_brew(name)
        if running:
            job["result"] = {"kind": kind, "name": name, "status": "refused",
                             "error": "target_running",
                             "detail": ("refused: these processes are still "
                                        f"running {name}: "
                                        + ", ".join(f"{n} (pid {p})"
                                                    for p, n in running)
                                        + ". Quit them first; nothing was "
                                          "uninstalled.")}
            return
        proc = subprocess.Popen(["brew", "uninstall", name],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True)
        job["proc"] = proc
        try:
            out, err = proc.communicate(timeout=job["timeout_s"])
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except OSError:
                pass
            out, err = proc.communicate(timeout=10)
            job["result"] = {"kind": kind, "name": name, "status": "timeout",
                             "error": "timeout", "timed_out": True,
                             "detail": (f"`brew uninstall {name}` ran past "
                                        f"its {job['timeout_s']}s timeout "
                                        "and was stopped"),
                             "output": (out or "")[-2000:]}
            return
        finally:
            job["proc"] = None
        # Verify it is gone.
        rc, _out, _err = _run_full(["brew", "list", "--formula", name],
                                   timeout=30)
        if rc == 0:
            job["result"] = {"kind": kind, "name": name, "status": "failed",
                             "error": "uninstall_failed",
                             "detail": (f"`brew uninstall {name}` finished "
                                        "but `brew list` still shows it "
                                        "installed"),
                             "output": (out or "")[-2000:]}
            return
        job["result"] = {"kind": kind, "name": name, "status": "ok",
                         "detail": (f"`brew uninstall {name}` finished and "
                                    "`brew list` no longer shows it."),
                         "output": (out or "")[-2000:]}
    except Exception as e:  # a worker must never die without a result
        job["result"] = {"kind": kind, "name": name, "status": "failed",
                         "error": "uninstall_failed",
                         "detail": f"uninstall worker raised: {e}"}
    finally:
        job["finished"] = True


def validate_uninstall(cmd_obj):
    """Validate an uninstall command, including the running-process
    PRECHECK (before any job starts). Returns (kind, name, timeout_s,
    error_dict_or_None)."""
    kind = cmd_obj.get("kind")
    if not kind or not isinstance(kind, str):
        return None, None, None, {"error": "bad_kind",
                                  "detail": "uninstall needs a string "
                                            "'kind'"}
    if kind not in UNINSTALL_KINDS:
        return None, None, None, {
            "error": "bad_kind",
            "detail": f"this agent only uninstalls kinds "
                      f"{', '.join(UNINSTALL_KINDS)}; {kind!r} is not "
                      "supported on macOS (nothing executed)"}
    if "appid" in cmd_obj and cmd_obj.get("appid") is not None:
        # appid is steam-only; steam is not an accepted kind here.
        if not isinstance(cmd_obj.get("appid"), int) \
                or isinstance(cmd_obj.get("appid"), bool):
            return None, None, None, {"error": "bad_appid",
                                      "detail": "uninstall 'appid' must be "
                                                "an integer (steam only)"}
    name = cmd_obj.get("name")
    name_error = validate_uninstall_name(name)
    if name_error is not None:
        return None, None, None, name_error
    timeout_s = _clamp_timeout(cmd_obj.get("timeout_s"),
                               UNINSTALL_DEFAULT_TIMEOUT, 60, 300)
    # Running-process precheck FIRST -- before any job, before
    # anything is touched.
    if kind == "app":
        bundle = resolve_app_bundle(name)
        if bundle is not None:
            running = find_running_for_app(bundle, name)
            if running:
                return None, None, None, {
                    "kind": kind, "name": name,
                    "error": "target_running",
                    "detail": ("refused: these processes are still running "
                               f"from {bundle}: "
                               + ", ".join(f"{n} (pid {p})"
                                           for p, n in running)
                               + ". Quit them first; nothing was deleted.")}
    else:
        running = find_running_for_brew(name)
        if running:
            return None, None, None, {
                "kind": kind, "name": name,
                "error": "target_running",
                "detail": ("refused: these processes are still running "
                           f"{name}: "
                           + ", ".join(f"{n} (pid {p})"
                                       for p, n in running)
                           + ". Quit them first; nothing was uninstalled.")}
    return kind, name, timeout_s, None


# ---------------------------------------------------------------- install

INSTALL_KINDS = ("brew",)


def _brew_formula_installed(name):
    """True when `brew list --formula <name>` exits 0 (formula
    present). Never raises; a missing brew or a failed call counts
    as not installed."""
    rc, _out, _err = _run_full(["brew", "list", "--formula", name],
                               timeout=30)
    return rc == 0


def validate_install_name(name):
    """A name is a plain name: string <=200 chars, no backslash, no
    slash, no '..'. Returns an error dict, or None. Identical rule
    to validate_uninstall_name."""
    if not isinstance(name, str) or not name:
        return {"error": "bad_name",
                "detail": "install needs a string 'name'"}
    if len(name) > 200:
        return {"error": "bad_name",
                "detail": "install name is over the 200-character limit"}
    if "\\" in name or "/" in name or ".." in name:
        return {"error": "bad_name",
                "detail": "install name must be a plain name (no "
                          "backslash, no slash, no '..')"}
    return None


def run_install_job(job):
    """Worker for an async install job (brew only). The brew-present
    and already-installed prechecks ran at dispatch AND run again
    here, right before anything is executed. Always sets
    job["result"]. The install kind (brew) lives in
    job["install_kind"]; job["kind"] is the job-tracking label
    ("install"). The exit code is never trusted alone: the job
    verifies with `brew list` afterwards and reports verified
    true/false."""
    kind = job.get("install_kind") or job.get("kind")
    name = job["name"]
    try:
        # kind == "brew" (the only kind validate_install accepts)
        if shutil.which("brew") is None:
            job["result"] = {"kind": kind, "name": name, "status": "failed",
                             "error": "brew_missing", "verified": False,
                             "detail": "Homebrew (`brew`) is not installed "
                                       "on this Mac -- install Homebrew "
                                       "first (https://brew.sh), then retry "
                                       "this command"}
            return
        if _brew_formula_installed(name):
            job["result"] = {"kind": kind, "name": name, "status": "ok",
                             "already_installed": True, "verified": True,
                             "detail": (f"{name} is already installed "
                                        "(`brew list` shows it) -- nothing "
                                        "was run")}
            return
        proc = subprocess.Popen(["brew", "install", name],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True)
        job["proc"] = proc
        try:
            out, err = proc.communicate(timeout=job["timeout_s"])
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except OSError:
                pass
            try:
                out, err = proc.communicate(timeout=10)
            except (OSError, subprocess.SubprocessError):
                # The killed brew may have left a child holding the
                # pipes open; do not let that turn a clean timeout
                # into a worker exception (same guard as exec/deep).
                out, err = "", ""
            job["result"] = {"kind": kind, "name": name, "status": "timeout",
                             "error": "timeout", "timed_out": True,
                             "verified": False,
                             "detail": (f"`brew install {name}` ran past "
                                        f"its {job['timeout_s']}s timeout "
                                        "and was stopped"),
                             "output": (out or "")[-2000:]}
            return
        finally:
            job["proc"] = None
        # Verify it is installed -- never trust the exit code alone.
        if not _brew_formula_installed(name):
            job["result"] = {"kind": kind, "name": name, "status": "failed",
                             "error": "install_failed", "verified": False,
                             "detail": (f"`brew install {name}` finished "
                                        "but `brew list` does not show it "
                                        "installed"),
                             "output": (out or "")[-2000:]}
            return
        job["result"] = {"kind": kind, "name": name, "status": "ok",
                         "verified": True,
                         "detail": (f"`brew install {name}` finished and "
                                    "`brew list` shows it installed."),
                         "output": (out or "")[-2000:]}
    except Exception as e:  # a worker must never die without a result
        job["result"] = {"kind": kind, "name": name, "status": "failed",
                         "error": "install_failed", "verified": False,
                         "detail": f"install worker raised: {e}"}
    finally:
        job["finished"] = True


def validate_install(cmd_obj):
    """Validate an install command, including the brew-present
    PRECHECK (before any job starts). Returns (kind, name, timeout_s,
    error_dict_or_None). The audit log line is written here, BEFORE
    the precheck and BEFORE anything runs, so a refused command is
    on the record too (same shape as validate_exec)."""
    kind = cmd_obj.get("kind")
    if not kind or not isinstance(kind, str):
        return None, None, None, {"error": "bad_kind",
                                  "detail": "install needs a string "
                                            "'kind'"}
    if kind not in INSTALL_KINDS:
        return None, None, None, {
            "error": "bad_kind",
            "detail": f"this agent only installs kind "
                      f"{', '.join(INSTALL_KINDS)}; {kind!r} is not "
                      "supported on macOS (nothing executed)"}
    name = cmd_obj.get("name")
    name_error = validate_install_name(name)
    if name_error is not None:
        return None, None, None, name_error
    timeout_s = _clamp_timeout(cmd_obj.get("timeout_s"),
                               INSTALL_DEFAULT_TIMEOUT, 60, 300)
    cmd_id = cmd_obj.get("id")
    write_audit(f"install id={cmd_id} kind={kind} name={name} "
                f"timeout_s={timeout_s}")
    # Brew-present precheck FIRST -- before any job, before anything
    # is executed.
    if shutil.which("brew") is None:
        return None, None, None, {
            "kind": kind, "name": name,
            "error": "brew_missing",
            "detail": "Homebrew (`brew`) is not installed on this Mac "
                      "-- install Homebrew first (https://brew.sh), "
                      "then retry this command"}
    return kind, name, timeout_s, None


# ---------------------------------------------------------------- async jobs
# exec / repair / deep / uninstall / install run in background threads so the poll
# loop stays responsive during long jobs. A handler starts its job,
# registers it in PENDING_JOBS, and returns IMMEDIATELY with a
# 'started' ack. check_pending_jobs() runs every poll cycle: a finished
# job posts a COMPLETION ack with the real result; a job past its
# timeout plus a 60s grace window gets a timed_out completion ack and
# is orphaned (its late result is discarded, never double-acked).
# The relay stores only the latest ack, so the completion ack
# overwriting the 'started' ack is correct and expected.
# Job dicts: {id, kind, thread, proc, started_at, timeout_s, result,
#             finished, timed_out_acked, ...per-kind fields}

PENDING_JOBS = {}
PENDING_JOBS_LOCK = threading.Lock()
JOB_TIMEOUT_GRACE = 60  # seconds past timeout before we orphan a stuck job


def start_job(job):
    """Register a job and start its worker thread (daemon, so --once
    can still exit). The worker always sets job["result"]."""
    job["finished"] = False
    job["timed_out_acked"] = False
    job["proc"] = None
    worker = job["worker"]
    thread = threading.Thread(target=worker, args=(job,), daemon=True)
    job["thread"] = thread
    with PENDING_JOBS_LOCK:
        PENDING_JOBS[job["id"]] = job
    thread.start()
    return job


def _job_done(result):
    """done for a completion ack: False when the result carries an
    'error' key, or a repair/uninstall/install status other than 'ok', or an
    exec that timed out / exited nonzero."""
    if not isinstance(result, dict):
        return False
    if "error" in result:
        return False
    if result.get("status") in ("failed", "refused", "skipped", "timeout"):
        return False
    if result.get("timed_out"):
        return False
    if "exit_code" in result and result.get("exit_code") != 0:
        return False
    return True


def check_pending_jobs():
    """Check every pending job: post a completion ack for finished
    ones; post a timed_out ack and orphan ones stuck past timeout +
    grace. Returns the number of jobs still pending."""
    now = time.monotonic()
    finished_ids = []
    with PENDING_JOBS_LOCK:
        jobs = list(PENDING_JOBS.values())
    for job in jobs:
        cmd_id = job["id"]
        if job.get("finished") and job.get("result") is not None:
            result = job["result"]
            ack = {"id": cmd_id, "done": _job_done(result), "at": now_iso(),
                   "result": result}
            post_ack(ack)
            finished_ids.append(cmd_id)
            continue
        elapsed = now - job["started_at"]
        if elapsed > job["timeout_s"] + JOB_TIMEOUT_GRACE \
                and not job.get("timed_out_acked"):
            job["timed_out_acked"] = True
            proc = job.get("proc")
            if proc is not None:
                try:
                    proc.kill()
                except OSError:
                    pass
            ack = {"id": cmd_id, "done": False, "at": now_iso(),
                   "result": {"error": "timeout", "timed_out": True,
                              "detail": (f"job {job['kind']} ran past its "
                                         f"{job['timeout_s']}s timeout "
                                         "(plus grace) and was stopped; "
                                         "any late result is discarded")}}
            post_ack(ack)
            finished_ids.append(cmd_id)
            log(f"job id={cmd_id} ({job['kind']}) timed out and was orphaned")
    with PENDING_JOBS_LOCK:
        for cmd_id in finished_ids:
            PENDING_JOBS.pop(cmd_id, None)
    with PENDING_JOBS_LOCK:
        return len(PENDING_JOBS)


def pending_job_count():
    with PENDING_JOBS_LOCK:
        return len(PENDING_JOBS)


# ---------------------------------------------------------------- commands

# Map of command name -> handler. Handlers take the args dict and return
# a result dict. They must never raise: execute_command wraps them.
SYNC_HANDLERS = {
    "ping": lambda args: {"ok": True},
    "sysinfo": cmd_sysinfo,
    "smart": cmd_smart,
    "df": cmd_df,
    "ls": cmd_ls,
    "cat": cmd_cat,
    "dmesg": cmd_dmesg,
    "screenshot": cmd_screenshot,
    "mouse": cmd_mouse,
    "type": cmd_type,
    "clean": cmd_clean,
}

ASYNC_COMMANDS = ("exec", "repair", "deep", "uninstall", "install")


def run_deep_job(job):
    """Worker for an async deep job: re-runs this agent with
    --deep-only as a subprocess (killable on timeout) and parses its
    JSON output. Always sets job["result"]."""
    timeout_s = job["timeout_s"]
    proc = None
    try:
        proc = subprocess.Popen(
            [sys.executable, os.path.abspath(__file__), "--deep-only"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        job["proc"] = proc
        try:
            out, err = proc.communicate(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            try:
                proc.kill()
            except OSError:
                pass
            try:
                out, err = proc.communicate(timeout=10)
            except (OSError, subprocess.SubprocessError):
                out, err = "", ""
            job["result"] = {"error": "timeout", "timed_out": True,
                             "detail": (f"deep exam ran past its "
                                        f"{timeout_s}s timeout and was "
                                        "stopped")}
            return
        try:
            data = json.loads(out)
            if isinstance(data, dict):
                job["result"] = data
                return
        except ValueError:
            pass
        job["result"] = {"error": "deep_failed",
                         "detail": ("deep exam output could not be parsed "
                                    "as JSON; stderr tail: "
                                    + (err or "")[-500:])}
    except (OSError, subprocess.SubprocessError) as e:
        job["result"] = {"error": "deep_failed", "detail": str(e)}
    finally:
        job["finished"] = True


def execute_command(cmd_obj):
    """Run one command object. Returns (cmd_id, ack_payload_or_None).

    Sync commands return their ack payload directly. Async commands
    return a 'started' ack payload (the completion ack is posted by
    check_pending_jobs). Returns (cmd_id, None) only when the command
    was received but must NOT be executed this cycle (receipt failed
    -- handled by the caller, which acks nothing).
    """
    cmd_id = cmd_obj.get("id")
    name = cmd_obj.get("cmd")
    if not isinstance(name, str) or not name:
        return cmd_id, {"id": cmd_id, "done": False, "at": now_iso(),
                        "result": {"error": "unknown_cmd",
                                   "detail": "command has no 'cmd' string"}}
    if name == "exec":
        command, timeout_s, _override, error = validate_exec(cmd_obj)
        if error is not None:
            return cmd_id, {"id": cmd_id, "done": False, "at": now_iso(),
                            "result": error}
        job = {"id": cmd_id, "kind": "exec", "worker": run_exec_job,
               "command": command, "timeout_s": timeout_s,
               "started_at": time.monotonic(), "result": None}
        start_job(job)
        return cmd_id, {"id": cmd_id, "done": True, "at": now_iso(),
                        "result": {"command": command, "started": True,
                                   "status": "running", "timed_out": False,
                                   "output": ""}}
    if name == "repair":
        function, names, timeout_s, snapshot, error = validate_repair(cmd_obj)
        if error is not None:
            return cmd_id, {"id": cmd_id, "done": False, "at": now_iso(),
                            "result": error}
        job = {"id": cmd_id, "kind": "repair", "worker": run_repair_job,
               "function": function, "names": names,
               "timeout_s": timeout_s, "snapshot": snapshot,
               "started_at": time.monotonic(), "result": None}
        start_job(job)
        return cmd_id, {"id": cmd_id, "done": True, "at": now_iso(),
                        "result": {"function": function, "started": True,
                                   "status": "running", "timed_out": False,
                                   "output": "",
                                   "snapshot": snapshot}}
    if name == "deep":
        timeout_s = _clamp_timeout(cmd_obj.get("timeout_s"),
                                   DEEP_DEFAULT_TIMEOUT, 60, 3600)
        job = {"id": cmd_id, "kind": "deep", "worker": run_deep_job,
               "timeout_s": timeout_s,
               "started_at": time.monotonic(), "result": None}
        start_job(job)
        return cmd_id, {"id": cmd_id, "done": True, "at": now_iso(),
                        "result": {"started": True, "status": "running",
                                   "timed_out": False, "output": ""}}
    if name == "uninstall":
        kind, uname, timeout_s, error = validate_uninstall(cmd_obj)
        if error is not None:
            return cmd_id, {"id": cmd_id, "done": False, "at": now_iso(),
                            "result": error}
        job = {"id": cmd_id, "kind": "uninstall",
               "uninstall_kind": kind,
               "worker": run_uninstall_job,
               "name": uname, "timeout_s": timeout_s,
               "started_at": time.monotonic(), "result": None}
        start_job(job)
        return cmd_id, {"id": cmd_id, "done": True, "at": now_iso(),
                        "result": {"kind": kind, "name": uname,
                                   "started": True, "status": "running",
                                   "timed_out": False, "output": ""}}
    if name == "install":
        kind, iname, timeout_s, error = validate_install(cmd_obj)
        if error is not None:
            return cmd_id, {"id": cmd_id, "done": False, "at": now_iso(),
                            "result": error}
        # Already-installed precheck -- ack done, run nothing.
        if _brew_formula_installed(iname):
            return cmd_id, {"id": cmd_id, "done": True, "at": now_iso(),
                            "result": {"kind": kind, "name": iname,
                                       "status": "ok",
                                       "already_installed": True,
                                       "verified": True,
                                       "detail": (f"{iname} is already "
                                                  "installed (`brew list` "
                                                  "shows it) -- nothing "
                                                  "was run")}}
        job = {"id": cmd_id, "kind": "install",
               "install_kind": kind,
               "worker": run_install_job,
               "name": iname, "timeout_s": timeout_s,
               "started_at": time.monotonic(), "result": None}
        start_job(job)
        return cmd_id, {"id": cmd_id, "done": True, "at": now_iso(),
                        "result": {"kind": kind, "name": iname,
                                   "started": True, "status": "running",
                                   "timed_out": False, "output": ""}}
    handler = SYNC_HANDLERS.get(name)
    if handler is None:
        log(f"unknown command: {name!r} (id={cmd_id})")
        return cmd_id, {"id": cmd_id, "done": False, "at": now_iso(),
                        "result": {"error": "unknown_cmd",
                                   "detail": f"no such command: {name}"}}
    try:
        result = handler(cmd_obj)
    except Exception as e:  # a handler must never take the agent down
        log(f"command {name!r} (id={cmd_id}) raised: {e}")
        return cmd_id, {"id": cmd_id, "done": False, "at": now_iso(),
                        "result": {"error": "handler_error", "detail": str(e)}}
    if isinstance(result, dict) and "error" in result:
        # Refusals are deliberate, reported outcomes -- ack done:false
        # so the operator sees the refusal, but the agent stays healthy.
        return cmd_id, {"id": cmd_id, "done": False, "at": now_iso(),
                        "result": result}
    return cmd_id, {"id": cmd_id, "done": True, "at": now_iso(),
                    "result": result if isinstance(result, dict)
                    else {"value": result}}


def extract_commands(payload):
    """Normalise a GET /doctor/command response into a list of command dicts.

    Accepts a bare command {"cmd": ..., "id": ...}, {"command": {...}},
    {"commands": [...]}, or an empty / no-command body ({} / {"cmd": null}).
    """
    if not isinstance(payload, dict):
        return []
    if payload.get("commands") and isinstance(payload["commands"], list):
        return [c for c in payload["commands"] if isinstance(c, dict)]
    inner = payload.get("command")
    if isinstance(inner, dict):
        return [inner]
    if payload.get("cmd"):
        return [payload]
    return []


def poll_once(seen_ids, logged_skips):
    """One poll cycle: fetch the queue head, receipt it, run it, ack it.

    The receipt (POST /doctor/received) goes out IMMEDIATELY after
    GETting a new command and BEFORE executing it. If the receipt
    post fails, the command is NOT executed this cycle -- it stays
    queued and will be re-served. Returns the number of commands
    executed.
    """
    payload = relay_get("/doctor/command")
    if payload is None:
        return 0  # relay unreachable; logged inside relay_get
    commands = extract_commands(payload)
    executed = 0
    for cmd_obj in commands:
        cmd_id = cmd_obj.get("id")
        if cmd_id is None:
            # A command with no id cannot be receipted; run it once
            # per process using a synthetic id from its content.
            cmd_id = "no-id-" + str(abs(hash(json.dumps(
                cmd_obj, sort_keys=True, default=str))) % 10**10)
            cmd_obj = dict(cmd_obj)
            cmd_obj["id"] = cmd_id
        if cmd_id in seen_ids:
            if cmd_id not in logged_skips:
                log(f"skipping duplicate command id={cmd_id}")
                logged_skips.add(cmd_id)
            continue
        seen_ids.add(cmd_id)
        logged_skips.discard(cmd_id)
        name = cmd_obj.get("cmd")
        # Receipt FIRST, before executing anything.
        if not post_received(cmd_id):
            log(f"receipt for id={cmd_id} NOT delivered -- not executing "
                f"yet, command stays queued")
            seen_ids.discard(cmd_id)
            continue
        log(f"executing command {name!r} (id={cmd_id})")
        _cid, ack = execute_command(cmd_obj)
        if ack is None:
            continue
        executed += 1
        if not post_ack(ack):
            log(f"ack for id={cmd_id} NOT delivered (relay unreachable)")
    return executed


# ---------------------------------------------------------------- main

def main(argv=None):
    global RELAY
    parser = argparse.ArgumentParser(description="KUROdoctor agent v1.3.4 (macOS)")
    parser.add_argument("--once", action="store_true",
                        help="run one poll cycle and exit")
    parser.add_argument("--report-only", action="store_true",
                        help="send the boot report and exit")
    parser.add_argument("--sweep-only", action="store_true",
                        help="run the blind sweep, print the JSON, exit")
    parser.add_argument("--deep-only", action="store_true",
                        help="run the deep exam, print the JSON, exit")
    args = parser.parse_args(argv)

    # Dry-run modes need no relay at all -- they never touch it.
    if args.sweep_only:
        print(json.dumps(run_blind_sweep(), indent=2))
        log("sweep-only mode: exiting")
        return 0
    if args.deep_only:
        print(json.dumps(run_deep_exam(), indent=2))
        log("deep-only mode: exiting")
        return 0

    RELAY = load_relay_url()
    if not RELAY:
        # Plain language, clean exit 2, no traceback, nothing sent.
        print(relay_not_configured_message())
        return 2

    log(f"KUROdoctor agent {AGENT} v{VERSION} starting, relay={RELAY}")
    log("live feed: change-only frames to /doctor/frame "
        "(max 1 per 5s, 60s liveness)")

    # Boot report first, always -- even if the relay is down we keep going
    # and retry it as a heartbeat later. The blind sweep runs inside
    # build_report, before any command is polled.
    send_report()

    if args.report_only:
        log("report-only mode: exiting")
        return 0

    seen_ids = set()
    logged_skips = set()
    last_heartbeat = time.monotonic()
    last_command_at = 0.0  # monotonic time a command was last seen

    if args.once:
        executed = poll_once(seen_ids, logged_skips)
        if executed:
            last_command_at = time.monotonic()
        send_frame_tick()  # v1.3.4: one live-feed tick per iteration
        check_pending_jobs()
        if pending_job_count():
            log("once mode: async jobs are still running -- their "
                "completion acks will NOT be delivered in --once mode")
        log("once mode: exiting")
        return 0

    log(f"polling {RELAY}/doctor/command (adaptive: {POLL_INTERVAL_ACTIVE}s "
        f"while active, {POLL_INTERVAL_IDLE}s when idle; heartbeat every "
        f"{HEARTBEAT_INTERVAL}s)")
    while True:
        try:
            executed = poll_once(seen_ids, logged_skips)
            if executed:
                last_command_at = time.monotonic()
        except Exception as e:  # the loop itself must never die
            log(f"poll cycle raised (continuing): {e}")
        try:
            send_frame_tick()  # v1.3.4: one live-feed tick per iteration
        except Exception as e:  # the tick itself never raises; belt and braces
            log(f"frame tick raised (continuing): {e}")
        check_pending_jobs()
        if time.monotonic() - last_heartbeat >= HEARTBEAT_INTERVAL:
            send_report()
            last_heartbeat = time.monotonic()
        active = (pending_job_count() > 0
                  or time.monotonic() - last_command_at < ACTIVE_WINDOW)
        time.sleep(POLL_INTERVAL_ACTIVE if active else POLL_INTERVAL_IDLE)


if __name__ == "__main__":
    sys.exit(main())
