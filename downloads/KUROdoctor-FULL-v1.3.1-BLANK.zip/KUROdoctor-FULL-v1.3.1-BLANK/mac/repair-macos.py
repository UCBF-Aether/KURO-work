#!/usr/bin/env python3
"""KUROdoctor -- macOS repair module (stdlib only, Python 3).

NEVER RUN ON A MAC -- needs a real Mac test. This Linux VM has no
diskutil, softwareupdate, launchctl, tmutil, or spctl, so every macOS
tool path in this file is guarded: a missing tool only ever reports
itself unavailable with a plain reason, never a crash. This file has
never executed on macOS; every macOS tool call in it is written from
the documented macOS command-line interfaces and the proven calls in
agent/kuro-doctor-agent-macos.py (diskutil, system_profiler, pmset,
launchctl, softwareupdate -l list-only, sysctl, log show).

Plain-English protocol (the Doctor's Protocol, docs/doctor-protocol.md):
  1. Diagnose FIRST. Nothing in this file diagnoses -- it only repairs,
     and only after the owner has heard the plain-language report and
     said go for that specific repair.
  2. Report first, owner go per repair. No repair changes anything
     unless the caller passes --go -- the flag the caller passes only
     after the owner says go for that repair. --dry-run never needs
     --go and never changes anything: it only prints what WOULD happen.
  3. Files rescued first. Repairs never touch user documents or photos
     (never ~/Documents, ~/Pictures, ~/Desktop, or any user
     documents/photos).
  4. Snapshot / rollback before changes. The `snapshot` repair runs
     FIRST, always: it checks Time Machine first (read-only), writes
     a manifest, and backs up every file the other repairs may change
     into /tmp/kurodoctor-repair-backup-<ts>/. If the backup cannot be
     written, this module says so plainly and STOPS -- no other repair
     in that run proceeds. A non-snapshot repair run with --go takes a
     snapshot first itself when none exists yet in /tmp.
  5. Audit log of everything done. Every real repair writes one entry
     (timestamp, repair name, target, before/after, result) to
     repair-audit.log next to this script, and prints a small JSON
     result object ({repair, status, before, after, detail}) to stdout.
     A dry run writes NOTHING to disk -- not even the audit log; it
     prints the audit entry it WOULD have written instead.
  6. Never auto-run on connect. Nothing here runs by itself. One
     repair at a time, chosen with --repair <name>, after the owner's go.
  7. No reinstall, no wipe, no reboot without the owner's explicit go
     for that step. There is NO reboot or shutdown call in this file
     at all, no reinstall, and no wipe -- this module repairs in place
     only, and it never does a blind full software update. Nothing in
     this file ever asks for administrator rights through sudo: any
     step that would need them reports itself unavailable with a plain
     reason and stops that repair.

What this module does NOT do (named next steps, not in this slice):
  - Android deep repair. That patient gets its own repair module from
    the other worker; this file is Mac only.
  - diskutil repairVolume / repairDisk. The `disk-check` repair
    REPORTS ONLY: if verifyVolume finds errors, fixing the disk needs
    the owner's explicit go plus a snapshot first -- a future step,
    not this file.
  - No lock-screen / password bypass, no root / jailbreak, no remote
    screen takeover, no touching a device unless its owner installed
    or ran the agent and said go. No iPhones, ever.
  - No temperature repair: macOS exposes no temperature fix this
    module can run without administrator rights, so temperatures stay
    a diagnose-only section in the agent.

Usage:
  python3 repair-macos.py --help
  python3 repair-macos.py --list
  python3 repair-macos.py --dry-run --repair snapshot
  python3 repair-macos.py --dry-run --repair softwareupdate-repair
  python3 repair-macos.py --go --repair softwareupdate-repair --package "macOS Sonoma 14.5 Update"
  python3 repair-macos.py --go --repair temp-cleanup
  python3 repair-macos.py --go --repair startup-cleanup --target com.example.agent
  python3 repair-macos.py --go --repair disk-check
  python3 repair-macos.py --go --repair disk-check --target "/Volumes/My Disk"
  python3 repair-macos.py --go --repair malware-quarantine --target /tmp/suspicious-file

100% our own code and text. No bundled tools, no third-party agent.
Only the tools already on the Mac are used (diskutil, softwareupdate,
launchctl, tmutil, spctl, sysctl); nothing is installed by this module
except updates the owner names with --package.
"""

import argparse
import datetime
import hashlib
import json
import os
import plistlib
import re
import shutil
import stat
import subprocess
import sys

# Files larger than this are recorded in the snapshot manifest by
# path + size + hash only, never copied (a repair backup must stay small).
SMALL_FILE_LIMIT = 1024 * 1024  # 1 MB

# Temp/cache files changed in the last hour are treated as in use and
# left alone by temp-cleanup.
RECENT_FILE_SECONDS = 3600

# softwareupdate installs can take a long time on a real Mac.
UPDATE_TIMEOUT_SECONDS = 1800

REPAIRS = {
    "snapshot": (
        "Check Time Machine (read-only), back up the files other "
        "repairs may change, and write a manifest, before anything is "
        "touched."
    ),
    "softwareupdate-repair": (
        "List available updates; install ONLY updates the owner names "
        "with --package, never a blind full install."
    ),
    "temp-cleanup": (
        "Clean temp and cache files in /tmp and ~/Library/Caches only, "
        "with before/after byte counts."
    ),
    "startup-cleanup": (
        "Disable ONLY the startup items the owner names with --target, "
        "by exact launchd label."
    ),
    "disk-check": (
        "Report ONLY: run diskutil verifyVolume on the named volume "
        "(default /) and print the result. Never repairs the disk."
    ),
    "malware-quarantine": (
        "Report Gatekeeper status, then MOVE only files the owner "
        "names with --target from temp/cache/download locations to "
        "quarantine -- never delete them."
    ),
}


def now_iso():
    return datetime.datetime.now().astimezone().isoformat()


def stamp():
    return datetime.datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")


def audit_log_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "repair-audit.log")


def write_audit(repair, target, before, after, status, detail, dry_run):
    """Write one audit-log entry. In a dry run, print it instead and
    write nothing to disk -- a dry run changes nothing at all."""
    entry = {
        "timestamp": now_iso(),
        "repair": repair,
        "target": target,
        "before": before,
        "after": after,
        "result": status,
        "detail": detail,
    }
    if dry_run:
        print("[dry run] audit entry that WOULD be written to "
              "repair-audit.log:")
        print(json.dumps(entry, indent=2))
        return entry
    line = json.dumps(entry)
    try:
        with open(audit_log_path(), "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError as exc:
        print("KUROdoctor: WARNING -- could not write the audit log "
              "({}). The entry was: {}".format(exc, line),
              file=sys.stderr)
    return entry


def result(repair, status, before, after, detail):
    """One JSON result object, printed to stdout by the caller."""
    return {
        "repair": repair,
        "status": status,
        "before": before,
        "after": after,
        "detail": detail,
    }


def emit(res, dry_run):
    """Print the result object as JSON. Exit code: 0 on ok/dry_run,
    1 on failed, 2 on skipped/refused (nothing was done)."""
    print(json.dumps(res, indent=2))
    if res["status"] == "ok" or res["status"] == "dry_run":
        return 0
    if res["status"] == "failed":
        return 1
    return 2


def sha256_of(path):
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_tool(cmd, timeout=60):
    """Run one macOS tool by argument list (never a shell string).

    Returns (ok, stdout, stderr). Never raises: a missing tool, a
    failed run, or a timeout all come back as ok=False with a plain
    reason in stderr. A nonzero exit counts as not-ok (no usable
    output is claimed)."""
    if shutil.which(cmd[0]) is None:
        return False, "", "tool not present on this machine: {}".format(cmd[0])
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout)
        return proc.returncode == 0, proc.stdout or "", proc.stderr or ""
    except (OSError, subprocess.SubprocessError) as exc:
        return False, "", str(exc)


def time_machine_state():
    """Time Machine state, read-only (tmutil destinationinfo /
    latestbackup). Returns a plain-language string for before/after.

    Three honest outcomes: a destination with a latest backup, no
    destination configured (local manifest backup only), or tmutil
    itself unavailable."""
    if shutil.which("tmutil") is None:
        return ("tmutil not available on this machine -- no Time Machine "
                "state to report; local manifest backup only")
    ok_dest, out_dest, _ = run_tool(["tmutil", "destinationinfo"],
                                    timeout=30)
    name = ""
    mount = ""
    if ok_dest:
        for line in out_dest.splitlines():
            line = line.strip()
            if line.startswith("Name"):
                name = line.split(":", 1)[1].strip() if ":" in line else ""
            elif line.startswith("Mount Point"):
                mount = line.split(":", 1)[1].strip() if ":" in line else ""
    ok_latest, out_latest, _ = run_tool(["tmutil", "latestbackup"],
                                        timeout=30)
    latest = out_latest.strip() if ok_latest else ""
    if not name and not latest:
        return ("no Time Machine destination configured -- local manifest "
                "backup only")
    dest = name or "(unnamed destination)"
    if mount:
        dest += " ({})".format(mount)
    if latest:
        return "Time Machine destination: {}; latest backup: {}".format(
            dest, latest)
    return ("Time Machine destination: {}; no completed backup found yet "
            "-- local manifest backup only".format(dest))


def files_maybe_changed():
    """Files the other repairs may change. The snapshot backs these up.
    Temp/cache files are disposable by definition and are NOT backed up;
    installed updates are recorded by name, not by copying system files."""
    home = os.path.expanduser("~")
    candidates = []
    # launchd plists -- startup-cleanup may disable these.
    for base in (os.path.join(home, "Library", "LaunchAgents"),
                 "/Library/LaunchAgents",
                 "/Library/LaunchDaemons"):
        try:
            for name in sorted(os.listdir(base)):
                if name.endswith(".plist"):
                    candidates.append(os.path.join(base, name))
        except OSError:
            pass
    return candidates


def existing_backup_dirs():
    try:
        names = os.listdir("/tmp")
    except OSError:
        return []
    return sorted(
        d for d in names
        if d.startswith("kurodoctor-repair-backup-")
        and os.path.isdir(os.path.join("/tmp", d))
    )


# ---------------------------------------------------------------------------
# snapshot -- FIRST, always
# ---------------------------------------------------------------------------
def list_available_updates():
    """Labels of available updates from `softwareupdate -l` (LIST ONLY).
    Returns None when softwareupdate is missing or the list cannot be
    read; otherwise a list of exact labels (possibly empty)."""
    ok, out, _ = run_tool(["softwareupdate", "-l"], timeout=120)
    if not ok:
        return None
    if "No new software available" in out:
        return []
    labels = []
    for line in out.splitlines():
        m = re.match(r"^\s*\*\s+Label:\s+(.+?)\s*$", line)
        if m:
            labels.append(m.group(1))
    return labels


def do_snapshot(dry_run):
    repair = "snapshot"
    backup_dir = os.path.join("/tmp", "kurodoctor-repair-backup-" + stamp())
    candidates = files_maybe_changed()
    tm_state = time_machine_state()
    before = ("{} file(s) may be changed by later repairs. {}"
              .format(len(candidates), tm_state))
    if dry_run:
        detail = (
            "Would create backup dir {} and copy each listed file into it "
            "(files over 1 MB are recorded by path + size + hash only, not "
            "copied). Temp/cache files are not backed up -- they are "
            "disposable. No update files are copied; available update "
            "labels are recorded in the manifest instead. {}. Files that "
            "would be backed up: {}. Nothing changed.".format(
                backup_dir, tm_state,
                ", ".join(candidates) if candidates else "(none found)"))
        res = result(repair, "dry_run", before,
                     "no change (dry run)", detail)
        write_audit(repair, backup_dir, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    # Real run: create the backup dir first. If it cannot be written,
    # say so plainly and STOP -- nothing else in this run proceeds.
    try:
        os.makedirs(backup_dir)
    except OSError as exc:
        detail = ("FAILED to create the backup dir {}: {}. STOPPING -- "
                  "no repair will run without a snapshot first. {}"
                  .format(backup_dir, exc, tm_state))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no backup made",
                     detail)
        write_audit(repair, backup_dir, before,
                    "no change -- no backup made", "failed", detail,
                    dry_run=False)
        return emit(res, dry_run)

    manifest_files = []
    copied = 0
    recorded_only = 0
    for path in candidates:
        entry = {"path": path}
        try:
            size = os.path.getsize(path)
            entry["size_bytes"] = size
            entry["sha256"] = sha256_of(path)
        except OSError as exc:
            entry["error"] = str(exc)
            manifest_files.append(entry)
            continue
        if size <= SMALL_FILE_LIMIT:
            try:
                shutil.copy2(path, os.path.join(
                    backup_dir, os.path.basename(path)))
                entry["backed_up_to"] = os.path.join(
                    backup_dir, os.path.basename(path))
                copied += 1
            except OSError as exc:
                entry["error"] = "copy failed: {}".format(exc)
        else:
            entry["backed_up_to"] = None
            entry["note"] = ("over 1 MB -- recorded by path + size + hash "
                             "only, not copied")
            recorded_only += 1
        manifest_files.append(entry)

    # Record available update labels (names only, no system files).
    updates = list_available_updates()
    manifest = {
        "timestamp": now_iso(),
        "backup_dir": backup_dir,
        "time_machine": tm_state,
        "files": manifest_files,
        "available_updates": updates if updates is not None else [],
        "available_updates_listed": updates is not None,
    }
    try:
        with open(os.path.join(backup_dir, "manifest.json"), "w",
                  encoding="utf-8") as fh:
            json.dump(manifest, fh, indent=2)
        with open(os.path.join(backup_dir, "pending-updates.txt"), "w",
                  encoding="utf-8") as fh:
            if updates:
                fh.write("\n".join(updates) + "\n")
            elif updates is None:
                fh.write("(softwareupdate list unavailable)\n")
            else:
                fh.write("(no updates available)\n")
    except OSError as exc:
        detail = ("FAILED to write the snapshot manifest in {}: {}. "
                  "STOPPING -- the backup is incomplete, so no repair "
                  "will run. {}".format(backup_dir, exc, tm_state))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before,
                     "backup dir created but manifest incomplete", detail)
        write_audit(repair, backup_dir, before,
                    "backup dir created but manifest incomplete", "failed",
                    detail, dry_run=False)
        return emit(res, dry_run)

    after = ("backup dir {}; {} file(s) copied, {} recorded by hash only. {}"
             .format(backup_dir, copied, recorded_only, tm_state))
    detail = ("Snapshot saved to {}. {} file(s) copied, {} recorded by "
              "path + size + hash only, {} available update label(s) "
              "recorded. {}. If a later repair goes wrong, these files "
              "can be put back from here.".format(
                  backup_dir, copied, recorded_only,
                  len(updates) if updates is not None else 0, tm_state))
    print("KUROdoctor: " + detail)
    res = result(repair, "ok", before, after, detail)
    write_audit(repair, backup_dir, before, after, "ok", detail,
                dry_run=False)
    return emit(res, dry_run)


def ensure_snapshot(dry_run):
    """A non-snapshot repair run with --go takes a snapshot first when
    none exists yet in /tmp. Returns (ok, backup_dir_or_error)."""
    if existing_backup_dirs():
        return True, "/tmp/" + existing_backup_dirs()[-1]
    print("KUROdoctor: no snapshot exists yet in this run -- "
          "taking one first, before any repair.")
    # Run the snapshot for real (not dry-run) and check its outcome.
    code = do_snapshot(dry_run=False)
    if code == 0:
        found = existing_backup_dirs()
        return True, "/tmp/" + found[-1] if found else "(unknown)"
    return False, "snapshot failed -- stopping"


# ---------------------------------------------------------------------------
# softwareupdate-repair -- list available; install ONLY named updates
# ---------------------------------------------------------------------------
# Update labels are plain display names (e.g. "macOS Sonoma 14.5
# Update"): letters, digits, spaces, dots, hyphens, underscores and
# parentheses only, starting with a letter or digit. Anything with a
# shell metacharacter in it is refused outright -- subprocess takes an
# argument list anyway, so this is belt and braces, and the error is
# plain. A named update must also appear in the `softwareupdate -l`
# list: an update that is not listed is never installed.
UPDATE_LABEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 .\-_()]*$")


def valid_update_label(name):
    if not isinstance(name, str):
        return False
    name = name.strip()
    if not name or len(name) > 200:
        return False
    if name != name.strip():
        return False
    if ".." in name:
        return False
    return bool(UPDATE_LABEL_RE.match(name))


def do_softwareupdate_repair(dry_run, packages):
    repair = "softwareupdate-repair"
    target = ", ".join(packages) if packages else "(none named)"
    available = list_available_updates()
    if available is None:
        before = ("available-update list unavailable (softwareupdate not "
                  "found, or `softwareupdate -l` failed)")
    elif not available:
        before = "no updates available (softwareupdate -l found none)"
    else:
        before = ("{} update(s) available: {}"
                  .format(len(available), ", ".join(available)))

    if dry_run:
        if packages:
            detail = ("Would install ONLY these named update(s): {}. "
                      "They must each appear in the `softwareupdate -l` "
                      "list first -- an update that is not listed is "
                      "never installed. Nothing else would be installed "
                      "or downloaded -- never a blind full install. "
                      "Available now: {}. Nothing changed.".format(
                          target,
                          ", ".join(available) if available else
                          "(list unavailable)"))
        else:
            detail = ("Would list available updates only and install "
                      "nothing. {} Nothing changed.".format(before))
        res = result(repair, "dry_run", before, "no change (dry run)", detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    if not packages:
        detail = ("No updates named. Nothing installed -- pass "
                  "--package <exact update label> (repeatable) with the "
                  "exact label(s) from the diagnosis report or from "
                  "`softwareupdate -l`. Never a blind full install.")
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", before, "no change", detail)
        write_audit(repair, target, before, "no change", "skipped",
                    detail, dry_run=False)
        return emit(res, dry_run)

    if shutil.which("softwareupdate") is None:
        detail = ("softwareupdate is not on this machine. Nothing "
                  "installed.")
        print("KUROdoctor: " + detail)
        res = result(repair, "failed", before, "no change -- softwareupdate "
                     "missing", detail)
        write_audit(repair, target, before,
                    "no change -- softwareupdate missing", "failed", detail,
                    dry_run=False)
        return emit(res, dry_run)

    if available is None:
        detail = ("`softwareupdate -l` gave no usable list, so no named "
                  "update could be checked against it. Nothing installed "
                  "-- run the list again when the Mac is online and try "
                  "again.")
        print("KUROdoctor: " + detail)
        res = result(repair, "failed", before,
                     "no change -- update list unavailable", detail)
        write_audit(repair, target, before,
                    "no change -- update list unavailable", "failed", detail,
                    dry_run=False)
        return emit(res, dry_run)

    not_listed = [p for p in packages if p not in available]
    if not_listed:
        detail = ("These named update(s) are NOT in the available-updates "
                  "list, so nothing was installed: {}. Available now: {}. "
                  "Check the exact spelling in `softwareupdate -l`."
                  .format(", ".join(not_listed),
                          ", ".join(available) if available else "(none)"))
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", before, "no change", detail)
        write_audit(repair, target, before, "no change", "skipped",
                    detail, dry_run=False)
        return emit(res, dry_run)

    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before softwareupdate-repair: {}. "
                  "STOPPING -- nothing installed.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    print("KUROdoctor: installing ONLY: {} (snapshot: {})"
          .format(target, snap))
    installed = []
    failed = []
    for label in packages:
        ok_run, out, err = run_tool(
            ["softwareupdate", "--install", label],
            timeout=UPDATE_TIMEOUT_SECONDS)
        if ok_run:
            installed.append(label)
            print("KUROdoctor: installed update '{}'.".format(label))
        else:
            reason = (err or out or "unknown error").strip()
            failed.append("{}: {}".format(label, reason[-500:]))
            print("KUROdoctor: install of '{}' failed: {}"
                  .format(label, reason[-500:]), file=sys.stderr)
    after_versions = "installed: {}; failed: {}".format(
        len(installed), len(failed))
    if installed and not failed:
        detail = ("Installed ONLY the named update(s): {}. Before: {}. "
                  "After: {}. No other update was touched. The Mac may "
                  "ask to restart to finish an update -- that is the "
                  "owner's call, this module never restarts the Mac."
                  .format(target, before, after_versions))
        print("KUROdoctor: " + detail)
        res = result(repair, "ok", before, after_versions, detail)
        write_audit(repair, target, before, after_versions, "ok",
                    detail, dry_run=False)
        return emit(res, dry_run)
    detail = ("Installed {} update(s) ({}); failed to install {}: {}. "
              "Before: {}. After: {}. An install that fails with a "
              "permissions error needs the owner's administrator rights "
              "on the Mac itself -- this module never asks for them and "
              "never retries with them.".format(
                  len(installed), ", ".join(installed), len(failed),
                  "; ".join(failed), before, after_versions))
    print("KUROdoctor: " + detail, file=sys.stderr)
    res = result(repair, "failed", before, after_versions, detail)
    write_audit(repair, target, before, after_versions, "failed",
                detail, dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# temp-cleanup -- /tmp and ~/Library/Caches only, before/after byte counts
# ---------------------------------------------------------------------------
def temp_roots():
    home = os.path.expanduser("~")
    return ["/tmp", os.path.join(home, "Library", "Caches")]


def collect_temp_files():
    """Regular files under /tmp and ~/Library/Caches that temp-cleanup
    may remove. Skips KUROdoctor's own backup/quarantine dirs, sockets
    and other non-regular files, and files changed in the last hour
    (treated as in use). Never walks ~/Documents, ~/Pictures,
    ~/Desktop, or any other user folder."""
    now = datetime.datetime.now().astimezone().timestamp()
    found = []
    for root in temp_roots():
        for dirpath, dirnames, filenames in os.walk(root, topdown=True,
                                                    followlinks=False):
            # Never descend into our own backup/quarantine dirs.
            dirnames[:] = [d for d in dirnames
                           if not d.startswith("kurodoctor-repair-backup-")
                           and not d.startswith("kurodoctor-quarantine-")]
            for name in filenames:
                path = os.path.join(dirpath, name)
                try:
                    st = os.lstat(path)
                except OSError:
                    continue
                if not stat.S_ISREG(st.st_mode):
                    continue
                if now - st.st_mtime < RECENT_FILE_SECONDS:
                    continue
                found.append((path, st.st_size))
    return found


def do_temp_cleanup(dry_run):
    repair = "temp-cleanup"
    target = "/tmp, ~/Library/Caches"
    files = collect_temp_files()
    total_bytes = sum(size for _, size in files)
    before = ("{} temp/cache file(s) eligible for cleanup, {} bytes total "
              "in /tmp and ~/Library/Caches (files changed in the last "
              "hour and KUROdoctor backup/quarantine dirs excluded)"
              .format(len(files), total_bytes))
    if dry_run:
        detail = ("Would delete {} temp/cache file(s) ({} bytes) from /tmp "
                  "and ~/Library/Caches only. The folders themselves stay; "
                  "files in use (changed in the last hour) are left alone. "
                  "No documents, photos, or any other user files are "
                  "touched. Nothing changed.".format(len(files), total_bytes))
        res = result(repair, "dry_run", before, "no change (dry run)", detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before temp-cleanup: {}. STOPPING -- "
                  "nothing deleted.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    removed = 0
    freed = 0
    left = 0
    for path, size in files:
        try:
            os.remove(path)
            removed += 1
            freed += size
        except OSError:
            left += 1
    remaining = collect_temp_files()
    remaining_bytes = sum(size for _, size in remaining)
    after = ("{} temp/cache file(s) left, {} bytes total in /tmp and "
             "~/Library/Caches".format(len(remaining), remaining_bytes))
    detail = ("Removed {} temp/cache file(s), freeing {} bytes, from /tmp "
              "and ~/Library/Caches only. {} file(s) could not be removed "
              "and were left alone. No documents, photos, or other user "
              "files were touched.".format(removed, freed, left))
    print("KUROdoctor: " + detail)
    res = result(repair, "ok", before, after, detail)
    write_audit(repair, target, before, after, "ok", detail, dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# startup-cleanup -- disable ONLY named launchd jobs, by exact label
# ---------------------------------------------------------------------------
# launchd labels are reverse-DNS names: letters, digits, dots, hyphens
# and underscores only, starting with a letter or digit.
STARTUP_LABEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")

# launchd plist locations, user scope first. Only the user scope
# (~/Library/LaunchAgents) can be disabled without administrator
# rights; everything under /Library or /System/Library needs them, so
# this module never attempts those -- it reports them unavailable with
# a plain reason and stops that repair.
LAUNCHD_DIRS = (
    ("user", os.path.join(os.path.expanduser("~"), "Library",
                          "LaunchAgents")),
    ("system", "/Library/LaunchAgents"),
    ("system", "/Library/LaunchDaemons"),
    ("system", "/System/Library/LaunchDaemons"),
)


def plist_label(path):
    """The Label inside a launchd plist, or the filename stem when the
    plist will not parse (the file exists, so it still counts)."""
    stem = os.path.basename(path)
    if stem.endswith(".plist"):
        stem = stem[:-len(".plist")]
    try:
        with open(path, "rb") as fh:
            data = plistlib.load(fh)
        if isinstance(data, dict) and isinstance(data.get("Label"), str):
            return data["Label"]
    except (OSError, plistlib.InvalidFileException, ValueError):
        pass
    return stem


def loaded_launchd_labels():
    """Labels currently loaded, from `launchctl list` (read-only).
    Empty set when launchctl is missing or the list cannot be read."""
    ok, out, _ = run_tool(["launchctl", "list"], timeout=30)
    labels = set()
    if not ok:
        return labels
    for line in out.splitlines():
        parts = line.split()
        # "PID\tStatus\tLabel" -- header line is "PID Status Label".
        if len(parts) >= 3 and parts[0] != "PID":
            labels.add(parts[2])
    return labels


def find_startup_targets(names):
    """Exact-label matches only. Returns (found, not_found) where found
    entries are dicts: {label, scope, plist}. A label matches a plist
    either by its Label key or by its filename stem."""
    found = []
    wanted = set(names)
    for scope, base in LAUNCHD_DIRS:
        try:
            entries = sorted(os.listdir(base))
        except OSError:
            continue
        for fname in entries:
            if not fname.endswith(".plist"):
                continue
            path = os.path.join(base, fname)
            label = plist_label(path)
            stem = fname[:-len(".plist")]
            if label in wanted or stem in wanted:
                found.append({"label": label, "scope": scope,
                              "plist": path})
    found_labels = {e["label"] for e in found}
    not_found = [name for name in names if name not in found_labels]
    return found, not_found


def do_startup_cleanup(dry_run, targets):
    repair = "startup-cleanup"
    target = ", ".join(targets) if targets else "(none named)"

    if not targets:
        detail = ("No startup items named. Nothing disabled -- pass "
                  "--target <exact launchd label> (repeatable) with the "
                  "exact label(s) from the diagnosis report. Only named "
                  "items are ever disabled.")
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", "startup items unchanged",
                     "no change", detail)
        write_audit(repair, target, "startup items unchanged", "no change",
                    "skipped", detail, dry_run=dry_run)
        return emit(res, dry_run)

    # Apple system jobs are refused outright, before anything is looked
    # up or changed -- this module never disables com.apple.* jobs.
    refused_apple = [t for t in targets if t.startswith("com.apple.")]
    invalid = [t for t in targets
               if t not in refused_apple
               and not STARTUP_LABEL_RE.match(t)]
    valid = [t for t in targets
             if t not in refused_apple and t not in invalid]
    if refused_apple or invalid:
        if not valid:
            detail = ("Refused: nothing valid was named. Apple system "
                      "jobs refused: {}. Invalid labels refused: {}. "
                      "Nothing disabled.".format(
                          ", ".join(refused_apple) if refused_apple
                          else "none",
                          ", ".join(invalid) if invalid else "none"))
            print("KUROdoctor: " + detail)
            res = result(repair, "skipped",
                         "startup items unchanged", "no change", detail)
            write_audit(repair, target, "startup items unchanged",
                        "no change", "skipped", detail, dry_run=dry_run)
            return emit(res, dry_run)

    found, not_found = find_startup_targets(valid)
    loaded = loaded_launchd_labels()
    before = ("named items found: {} of {} named ({})"
              .format(len(found), len(valid), target))
    if not found:
        detail = ("None of the named startup items ({}) were found among "
                  "the launchd plist folders. Nothing disabled -- check "
                  "the exact label spelling in the diagnosis report. "
                  "Refused Apple system jobs: {}. Invalid labels: {}."
                  .format(", ".join(valid),
                          ", ".join(refused_apple) if refused_apple
                          else "none",
                          ", ".join(invalid) if invalid else "none"))
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", before, "no change", detail)
        write_audit(repair, target, before, "no change", "skipped",
                    detail, dry_run=dry_run)
        return emit(res, dry_run)

    # A system-scope plist needs administrator rights to unload, and
    # this module never asks for them -- so a run naming one stops
    # here, before any item is disabled, with a plain reason.
    system_entries = [e for e in found if e["scope"] == "system"]
    plan = "; ".join("{} [{} plist: {}]".format(
        e["label"], e["scope"], e["plist"]) for e in found)
    if system_entries:
        detail = ("STOPPED: these named item(s) live in a system launchd "
                  "folder and need administrator rights to disable: {}. "
                  "This module never asks for administrator rights, so "
                  "nothing was disabled -- not even the user items named "
                  "alongside them. Re-run naming only the user item(s), "
                  "or disable the system item(s) by hand on the Mac "
                  "with the owner's administrator rights. Plan was: {}."
                  .format("; ".join("{} [{}]".format(e["label"], e["plist"])
                                    for e in system_entries), plan))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before,
                     "no change -- system item needs administrator rights",
                     detail)
        write_audit(repair, target, before + " | " + plan,
                    "no change -- system item needs administrator rights",
                    "failed", detail, dry_run=dry_run)
        return emit(res, dry_run)

    if dry_run:
        detail = ("Would disable {} named startup item(s): {}. For each "
                  "one, if it is currently loaded it would be removed "
                  "with 'launchctl remove <label>', then disabled "
                  "persistently with 'launchctl unload -w <plist>' -- "
                  "the named plist only. Each item can be re-enabled "
                  "with 'launchctl load -w <plist>'. Not found (left "
                  "alone): {}. Refused Apple system jobs: {}. Invalid "
                  "labels: {}. Nothing changed, and no item you did not "
                  "name is touched.".format(
                      len(found), plan,
                      ", ".join(not_found) if not_found else "none",
                      ", ".join(refused_apple) if refused_apple else "none",
                      ", ".join(invalid) if invalid else "none"))
        res = result(repair, "dry_run", before, "no change (dry run)", detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before startup-cleanup: {}. STOPPING "
                  "-- nothing disabled.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    if shutil.which("launchctl") is None:
        detail = ("launchctl is not on this machine, so no startup item "
                  "could be disabled. Nothing changed.")
        print("KUROdoctor: " + detail)
        res = result(repair, "failed", before,
                     "no change -- launchctl missing", detail)
        write_audit(repair, target, before,
                    "no change -- launchctl missing", "failed", detail,
                    dry_run=False)
        return emit(res, dry_run)

    disabled = []
    failed = []
    for entry in found:
        label = entry["label"]
        plist = entry["plist"]
        # If it is loaded now, remove it from the current session first.
        if label in loaded:
            ok_remove, _out, err = run_tool(["launchctl", "remove", label],
                                            timeout=30)
            if not ok_remove:
                print("KUROdoctor: note -- 'launchctl remove {}' did not "
                      "finish cleanly ({}); continuing with unload -w."
                      .format(label, (err or "no detail").strip()),
                      file=sys.stderr)
        # Then disable it persistently, for the named plist only.
        ok_unload, _out, err = run_tool(
            ["launchctl", "unload", "-w", plist], timeout=30)
        if ok_unload:
            disabled.append(label)
            print("KUROdoctor: disabled startup item '{}' "
                  "(launchctl unload -w {}). Re-enable with "
                  "'launchctl load -w {}'.".format(label, plist, plist))
        else:
            failed.append("{}: {}".format(
                label, (err or "unload failed").strip()))

    after = ("disabled: {}; failed: {}; not found: {}"
             .format(len(disabled), len(failed), len(not_found)))
    if not failed and disabled:
        detail = ("Disabled {} named startup item(s): {}. Their old "
                  "state is in the snapshot backup ({}), and each one "
                  "can be re-enabled with 'launchctl load -w <plist>' "
                  "using the plist path in the audit entry. Not found "
                  "(left alone): {}. No other startup item was changed."
                  .format(len(disabled), ", ".join(disabled), snap,
                          ", ".join(not_found) if not_found else "none"))
        res = result(repair, "ok", before, after, detail)
        write_audit(repair, target, before + " | " + plan, after, "ok",
                    detail, dry_run=False)
        return emit(res, dry_run)
    detail = ("Disabled {} item(s) ({}); failed to disable {}: {}. Not "
              "found (left alone): {}.".format(
                  len(disabled), ", ".join(disabled), len(failed),
                  "; ".join(failed),
                  ", ".join(not_found) if not_found else "none"))
    print("KUROdoctor: " + detail, file=sys.stderr)
    res = result(repair, "failed", before, after, detail)
    write_audit(repair, target, before + " | " + plan, after, "failed",
                detail, dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# disk-check -- REPORT ONLY: diskutil verifyVolume, never repair
# ---------------------------------------------------------------------------
# A volume is an absolute path ("/", "/Volumes/My Disk") or a device
# path ("/dev/disk0s1"). Anything else -- relative paths, flags, shell
# metacharacters -- is refused.
VOLUME_RE = re.compile(r"^/[A-Za-z0-9 _.\-/]*$")


def valid_volume(name):
    if not isinstance(name, str) or not name:
        return False
    if name.startswith("-"):
        return False
    if any(c in name for c in ";&|$`\"'<>\\\n\r\t"):
        return False
    if ".." in name.split("/"):
        return False
    return bool(VOLUME_RE.match(name))


def do_disk_check(dry_run, targets):
    repair = "disk-check"
    volume = targets[0] if targets else "/"
    extra = targets[1:] if len(targets) > 1 else []
    target = volume

    if not valid_volume(volume):
        detail = ("Refused volume {!r} -- not an absolute volume or device "
                  "path. Nothing checked. Pass --target with a volume "
                  "like / or /Volumes/My Disk, or leave it off to check "
                  "/.".format(volume))
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", "volume not checked",
                     "no change", detail)
        write_audit(repair, target, "volume not checked", "no change",
                    "skipped", detail, dry_run=dry_run)
        return emit(res, dry_run)

    before = "volume {} not verified yet in this run".format(volume)
    if dry_run:
        detail = ("Would run 'diskutil verifyVolume {}' and print the "
                  "result. REPORT ONLY -- this never runs repairVolume "
                  "or repairDisk, and never changes the disk.{} Nothing "
                  "changed.".format(
                      volume,
                      " Extra --target values ignored: {}.".format(
                          ", ".join(extra)) if extra else ""))
        res = result(repair, "dry_run", before, "no change (dry run)", detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    if shutil.which("diskutil") is None:
        before = "diskutil not present on this machine"
        detail = ("diskutil is not on this machine, so the volume could "
                  "not be checked. Nothing changed, nothing was repaired.")
        print("KUROdoctor: " + detail)
        res = result(repair, "failed", before,
                     "no change -- diskutil missing", detail)
        write_audit(repair, target, before,
                    "no change -- diskutil missing", "failed", detail,
                    dry_run=False)
        return emit(res, dry_run)

    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before disk-check: {}. STOPPING -- "
                  "nothing checked.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    print("KUROdoctor: verifying volume {} (report only -- nothing will "
          "be repaired; snapshot: {})".format(volume, snap))
    ok_verify, out, err = run_tool(["diskutil", "verifyVolume", volume],
                                   timeout=900)
    combined = (out + ("\n" + err if err else "")).strip()
    shown = combined[-3000:]
    if len(combined) > 3000:
        shown = "(output trimmed to the last 3000 characters)\n" + shown
    if ok_verify and "error:" not in combined.lower():
        after = "volume {} verified: no errors reported".format(volume)
        detail = ("diskutil verifyVolume {} finished clean -- no errors "
                  "reported. REPORT ONLY: nothing was repaired and "
                  "nothing on the disk changed. Verify output:\n{}"
                  .format(volume, shown))
        print("KUROdoctor: " + detail)
        res = result(repair, "ok", before, after, detail)
        write_audit(repair, target, before, after, "ok", detail,
                    dry_run=False)
        return emit(res, dry_run)
    after = "volume {} verify reported errors".format(volume)
    detail = ("diskutil verifyVolume {} reported ERRORS. REPORT ONLY: "
              "nothing was repaired -- this file never runs repairVolume "
              "or repairDisk. Repairing the disk is a future step that "
              "needs the owner's explicit go plus a snapshot first "
              "(snapshot already taken: {}). Tell the owner in plain "
              "language before anything else is done. Verify output:\n{}"
              .format(volume, snap, shown))
    print("KUROdoctor: " + detail, file=sys.stderr)
    res = result(repair, "failed", before, after, detail)
    write_audit(repair, target, before, after, "failed", detail,
                dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# malware-quarantine -- Gatekeeper status, then MOVE named files only
# ---------------------------------------------------------------------------
def quarantine_roots():
    """Only files inside these roots may be quarantined: temp, cache,
    and download locations. ~/Documents, ~/Pictures, ~/Desktop, and
    every other user folder are never touched."""
    home = os.path.expanduser("~")
    return ["/tmp",
            os.path.join(home, "Library", "Caches"),
            os.path.join(home, "Downloads")]


def gatekeeper_status():
    """Gatekeeper status from `spctl --status` (read-only). XProtect is
    a built-in macOS service with no user-facing status command this
    module runs, so no XProtect scan is ever claimed -- the Gatekeeper
    line is the report, and it says so plainly."""
    if shutil.which("spctl") is None:
        return ("Gatekeeper status unavailable: spctl is not present on "
                "this machine. XProtect is a built-in macOS service "
                "with no user-facing status command this module runs, "
                "so no XProtect scan is claimed.")
    ok, out, err = run_tool(["spctl", "--status"], timeout=30)
    if ok and out.strip():
        return ("Gatekeeper (spctl --status): {}. XProtect is a built-in "
                "macOS service with no user-facing status command this "
                "module runs, so no XProtect scan is claimed."
                .format(out.strip()))
    return ("Gatekeeper status could not be read ({}). XProtect is a "
            "built-in macOS service with no user-facing status command "
            "this module runs, so no XProtect scan is claimed."
            .format((err or "no output").strip()))


def classify_quarantine_targets(targets):
    """Sort named targets into (movable, refused) where movable entries
    are {path, real} for existing regular files inside an allowed
    root, and refused entries are {path, reason} for everything else.
    Nothing is moved or deleted here -- this only classifies."""
    roots = [os.path.realpath(r) for r in quarantine_roots()]
    movable = []
    refused = []
    for path in targets:
        if not isinstance(path, str) or not os.path.isabs(path):
            refused.append({"path": path,
                            "reason": "not an absolute path"})
            continue
        if any(c in path for c in "\n\r\t"):
            refused.append({"path": path,
                            "reason": "path contains control characters"})
            continue
        real = os.path.realpath(path)
        inside = any(real == r or real.startswith(r + os.sep)
                     for r in roots)
        if not inside:
            refused.append({
                "path": path,
                "reason": ("outside the allowed locations (/tmp, "
                           "~/Library/Caches, ~/Downloads) -- never "
                           "touched")})
            continue
        try:
            st = os.lstat(real)
        except OSError:
            refused.append({"path": path, "reason": "file does not exist"})
            continue
        if stat.S_ISLNK(st.st_mode):
            refused.append({"path": path,
                            "reason": "a link, not a regular file -- left "
                                      "alone"})
            continue
        if not stat.S_ISREG(st.st_mode):
            refused.append({"path": path,
                            "reason": "not a regular file (a folder or "
                                      "special file) -- left alone"})
            continue
        movable.append({"path": path, "real": real})
    return movable, refused


def do_malware_quarantine(dry_run, targets):
    repair = "malware-quarantine"
    target = ", ".join(targets) if targets else "(none named)"
    quarantine_dir = os.path.join("/tmp",
                                  "kurodoctor-quarantine-" + stamp())
    gk = gatekeeper_status()
    before = gk

    if not targets:
        detail = ("No files named. Nothing moved -- pass --target "
                  "<absolute file path> (repeatable) with the exact "
                  "file(s) from the diagnosis report. Only files in "
                  "/tmp, ~/Library/Caches, or ~/Downloads are ever "
                  "moved, and only files you name. {}".format(gk))
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", before, "no change", detail)
        write_audit(repair, target, before, "no change", "skipped",
                    detail, dry_run=dry_run)
        return emit(res, dry_run)

    movable, refused = classify_quarantine_targets(targets)
    refused_note = ("Refused (left alone): {}"
                    .format("; ".join("{} ({})".format(r["path"], r["reason"])
                                     for r in refused))
                    if refused else "Refused: none")
    if dry_run:
        if movable:
            detail = ("Would MOVE {} named file(s) to a quarantine dir "
                      "under /tmp/kurodoctor-quarantine-<timestamp>/ "
                      "-- MOVE, never delete -- with a numbered name if "
                      "a file of the same name is already there: {}. {}. "
                      "{} Nothing changed.".format(
                          len(movable),
                          ", ".join(m["path"] for m in movable),
                          refused_note, gk))
        else:
            detail = ("Would move nothing: none of the named files can "
                      "be quarantined. {}. {} Nothing changed.".format(
                          refused_note, gk))
        res = result(repair, "dry_run", before, "no change (dry run)", detail)
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        return emit(res, dry_run)

    if not movable:
        detail = ("No named file could be quarantined. {}. {} Nothing "
                  "moved, nothing deleted.".format(refused_note, gk))
        print("KUROdoctor: " + detail)
        res = result(repair, "skipped", before, "no change", detail)
        write_audit(repair, target, before, "no change", "skipped",
                    detail, dry_run=False)
        return emit(res, dry_run)

    ok, snap = ensure_snapshot(dry_run=False)
    if not ok:
        detail = ("Snapshot failed before malware-quarantine: {}. "
                  "STOPPING -- no files moved.".format(snap))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before, "no change -- no snapshot",
                     detail)
        write_audit(repair, target, before, "no change -- no snapshot",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    try:
        os.makedirs(quarantine_dir)
    except OSError as exc:
        detail = ("FAILED to create the quarantine dir {}: {}. STOPPING "
                  "-- the named file(s) were left where they are, "
                  "nothing was deleted. {}".format(
                      quarantine_dir, exc, gk))
        print("KUROdoctor: " + detail, file=sys.stderr)
        res = result(repair, "failed", before,
                     "no change -- quarantine dir could not be made", detail)
        write_audit(repair, target, before,
                    "no change -- quarantine dir could not be made",
                    "failed", detail, dry_run=False)
        return emit(res, dry_run)

    moved = []
    failed_moves = []
    for entry in movable:
        path = entry["real"]
        dest = os.path.join(quarantine_dir, os.path.basename(path))
        counter = 1
        while os.path.exists(dest):
            stem, ext = os.path.splitext(os.path.basename(path))
            dest = os.path.join(quarantine_dir,
                                "{}_{}{}".format(stem, counter, ext))
            counter += 1
        try:
            shutil.move(path, dest)
            moved.append((path, dest))
            print("KUROdoctor: quarantined (MOVED, not deleted): {} -> {}"
                  .format(path, dest))
        except OSError as exc:
            failed_moves.append("{}: {}".format(path, exc))
    after = ("{} file(s) moved to {}, {} move(s) failed"
             .format(len(moved), quarantine_dir, len(failed_moves)))
    move_list = "; ".join("{} -> {}".format(src, dst) for src, dst in moved)
    detail = ("{} {} file(s) moved to quarantine ({}). Nothing was "
              "deleted. Failed moves: {}. {}. Tell the owner in plain "
              "language before anything else is done with the "
              "quarantined files.".format(
                  gk, len(moved), quarantine_dir,
                  "; ".join(failed_moves) if failed_moves else "none",
                  refused_note))
    status = "ok" if not failed_moves else "failed"
    res = result(repair, status, before, after, detail)
    write_audit(repair, target, before, after + " | moves: " + move_list,
                status, detail, dry_run=False)
    return emit(res, dry_run)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def build_parser():
    parser = argparse.ArgumentParser(
        prog="repair-macos.py",
        description=(
            "KUROdoctor macOS repair module. One repair at a time, after "
            "the owner has heard the plain-language report and said go. "
            "--dry-run previews a repair and changes nothing; --go is "
            "required for any real change. Never a blind full update. "
            "Never touches user documents or photos. Never asks for "
            "administrator rights."))
    parser.add_argument("--repair", choices=sorted(REPAIRS),
                        help="repair to run (one at a time)")
    parser.add_argument("--list", action="store_true",
                        help="print the available repairs, one plain line each")
    parser.add_argument("--dry-run", action="store_true",
                        help="preview only: print what WOULD happen, change nothing")
    parser.add_argument("--go", action="store_true",
                        help="owner go: allow this repair to make real changes")
    parser.add_argument("--target", action="append", default=[],
                        help="exact name of a startup item, volume, or file "
                             "to act on (repeatable; meaning depends on "
                             "the repair)")
    parser.add_argument("--package", action="append", default=[],
                        help="exact label of an update to install "
                             "(repeatable, softwareupdate-repair only)")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.list:
        for name in sorted(REPAIRS):
            print("{}: {}".format(name, REPAIRS[name]))
        return 0

    if not args.repair:
        parser.print_help()
        print("\nKUROdoctor: pick one repair with --repair <name>, or "
              "--list to see them. Nothing was done.", file=sys.stderr)
        return 2

    # Validate update labels: plain names only, so a stray shell
    # metacharacter can never ride along (subprocess takes a list
    # anyway -- this is belt and braces, and the error is plain).
    for pkg in args.package:
        if not valid_update_label(pkg):
            print("KUROdoctor: refusing update label {!r} -- not a plain "
                  "update label. Nothing installed.".format(pkg),
                  file=sys.stderr)
            return 2

    if not args.dry_run and not args.go:
        print("KUROdoctor: refusing to run '{}' -- no owner go. Pass "
              "--go after the owner says go for this repair, or "
              "--dry-run to preview it without changing anything. "
              "Nothing was done.".format(args.repair), file=sys.stderr)
        res = result(args.repair, "skipped",
                     "repair not started",
                     "no change -- owner go not given",
                     "Refused: owner go not given. Pass --go after the "
                     "owner says go, or --dry-run to preview.")
        print(json.dumps(res, indent=2))
        return 2

    if args.repair == "snapshot":
        return do_snapshot(dry_run=args.dry_run)
    if args.repair == "softwareupdate-repair":
        return do_softwareupdate_repair(dry_run=args.dry_run,
                                        packages=args.package)
    if args.repair == "temp-cleanup":
        return do_temp_cleanup(dry_run=args.dry_run)
    if args.repair == "startup-cleanup":
        return do_startup_cleanup(dry_run=args.dry_run, targets=args.target)
    if args.repair == "disk-check":
        return do_disk_check(dry_run=args.dry_run, targets=args.target)
    if args.repair == "malware-quarantine":
        return do_malware_quarantine(dry_run=args.dry_run,
                                     targets=args.target)
    return 2


if __name__ == "__main__":
    sys.exit(main())
