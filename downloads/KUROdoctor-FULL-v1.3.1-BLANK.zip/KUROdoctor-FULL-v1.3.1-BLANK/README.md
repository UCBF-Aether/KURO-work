# KUROdoctor FULL — v1.3.2 agents + v1.4.0 relay, all platforms, bring-your-own-Cloudflare

One pack, four platforms plus the approval app. Every platform
folder is self-contained: its own agent, its own blank relay config,
its own SETUP.md written so another Muse can guide its owner
through setup. **iPhones are excluded, always** — nothing in this
pack is built for iOS, and no iOS build is planned.

## Layout

| Folder | What it is |
|---|---|
| `windows/` | Windows agent v1.3.2 (blank variant) + screen v1.1 + launcher + repair module + relay deploy files (v1.4.0). Deploy the relay from here. |
| `mac/` | macOS agent v1.3.2 (Python 3, stdlib only) + launcher + repair module. |
| `linux/` | Linux / SteamOS (Steam Deck) agent v1.3.2 (Python 3, stdlib only) + launcher + repair module + Deck TEST-PLAN.md. |
| `android/` | KUROdoctor app v1.1 APK + v1.0 APK + ADB host tool + repair module + phone TEST-PLAN.md. Read `ANDROID-RELAY-CAVEAT.md` first. |
| `authenticator/` | KUROdoctor Authenticator app v1.1 SOURCE + pairing guide (build it with `build_authenticator.sh` if you want to build it yourself). The ready-to-install `KUROdoctor-Authenticator-1.1.apk` is also included at the root of this pack, next to this folder — install it first. The relay URL is entered at runtime in the app, never baked in. |
| `iso/` | Pointer file only — the rescue ISO is NOT in this pack (see below). |
| `docs/` | `remote-control.md` — the shared command contract for all platforms. |

## The relay: deploy once, share the URL

All four agents speak the same relay contract (queue, receipt,
never-400 ack, uninstall, install, owner override, adaptive polling). Deploy
the relay **once**, from `windows/relay/` — that folder holds the
base worker, the three patch files, the uploader, the secret/KV
helpers, and the deploy script
(`deploy-remote-endpoints-v1.4.0-blank.sh`). Follow
`windows/SETUP.md` step 1 for the deploy, then paste the same worker
URL into each platform's `relay-config.json` (`mac/`,
`linux/`, `windows/agent/`). Agent and relay must move together:
a v1.3.0-or-older agent against a v1.3.2 relay runs only the first
queued command (it never sends the receipt that pops the queue).

**v1.4.0 authentication — two factors, both checked on
`POST /doctor/command` only.** (1) The Muse-held write token:
every command post must carry header `X-Doctor-Token` matching the
worker secret `DOCTOR_TOKEN` (`401 bad_token` without it). The token
lives only with the owner's Muse. (2) The Authenticator app
approval: the owner pairs the app in `authenticator/` (its own
`SETUP.md` is the pairing guide) and taps Approve for a session
(`423 locked` without it; an unlock lasts 8 hours). If no device
is paired at all, the relay runs token-only (safety valve) so a
fresh setup is never bricked before pairing.

## What changed in v1.4.0 (relay only — no agent changes)

- **Muse-held write token:** `POST /doctor/command` requires header
  `X-Doctor-Token` matching the worker secret `DOCTOR_TOKEN`
  (missing/wrong/unconfigured → `401 bad_token`). The deploy script
  generates the token, stores it as a worker secret, and prints it
  once for the owner's Muse to keep. No agent needs the token.
- **Authenticator app approval:** `POST /doctor/session/request`
  (token required) creates a pending approval; the paired app polls
  `GET /doctor/session/pending` and the owner taps Approve (relay
  sets an 8-hour unlock) or Deny. `POST /doctor/session/decision`
  needs the device key the relay issued at pairing
  (`POST /doctor/session/pair` with the one-time pairing code).
  Rate limit: 3 session requests per hour. The only unlock path is
  the app tap — no codes, no SMS, no email.
- **Safety valve:** with no device paired at all, commands need
  only the token. Once a device is paired, both factors are
  required.
- **Everything else unchanged:** queue, receipt, ack hygiene,
  uninstall, install, owner override, blocklist, adaptive polling, and all
  other endpoints (agent poll, report, received, acks) behave
  exactly as v1.3.2.

## What changed in v1.3.1 (all platforms)

- **Command queue:** the relay holds a FIFO queue (max 10, 400
  `queue_full`) instead of one overwritable slot. The agent posts
  `/doctor/received` immediately after seeing a command, before
  executing it. If the receipt fails, the agent does NOT execute
  that cycle — it retries on the next poll.
- **Ack hygiene:** agents sanitize ack strings to ASCII and cap
  fields; the relay never 400s on ack content (bad JSON is salvaged
  into a minimal `ack_unparseable` ack). A repair result can never
  be silently lost again.
- **Uninstall command:** `steam | msi | appx | app | brew |
  flatpak | pacman`. Every agent checks for running processes first
  and refuses cleanly (`target_running`) instead of failing halfway.
- **Adaptive polling:** 1s while a command is active, 10s when idle,
  heartbeat every ~60s. Idle ≈ 10,000 Cloudflare requests/day, down
  from ~86,000 at a flat 1s poll.
- **Exec blocklist:** `format` / `wipe` now match as whole words, so
  "Information" no longer false-blocks. Desktop `.lnk` deletes need
  an explicit `owner_override` on the exec command — and only for
  `.lnk` files under a Desktop folder.
- **Repair never silently no-ops:** Windows sets the restore-point
  frequency to 0 and accepts a restore point from the last 24h as
  the snapshot; macOS takes a `tmutil` snapshot first and refuses
  loudly if none is available.
- **Screenshot:** Windows capture rewritten to raw Win32 GDI BitBlt
  (no `CopyFromScreen`) so Defender no longer flags it as an Empire
  screenshot tool. Same interface (JPEG ≤200 KB in the ack).

## Verification status — read honestly

- **Windows v1.3.0** was live-verified on a real HP laptop.
  **v1.3.2 is code-verified only** until it is deployed and run:
  hashes, BOM/CRLF/ASCII checks, banned-literal grep zero,
  `node --check` on the merged relay, `bash -n` on the scripts.
  No PowerShell exists on the build machine, so no .ps1 file has
  ever executed. The relay has never run live.
- **Mac:** never run on a real Mac. Syntax check + functional dry
  run on Linux only (macOS tools absent there, so the sweep honestly
  reports them unavailable).
- **Linux / Steam Deck:** never run on a real Deck. `py_compile` +
  `bash -n` only; no container runtime on the build machine, so no
  container smoke test either. The Deck TEST-PLAN.md is the first
  real run.
- **Android:** the APKs have never run on a real phone. Signature
  checked with `apksigtool` (not Google's `apksigner`/`aapt` — those
  are not installed on the build machine). The phone TEST-PLAN.md is
  the first real run, on a Samsung S25 Ultra.
- **The rescue ISO** stays as-is, QEMU-only, never verified on real
  hardware. It is 310 MB, so this pack carries a pointer file in
  `iso/`, not the ISO itself.

## Two things to flag to the owner

1. **Linux `sudo -n pacman` exception.** The Linux agent never uses
   sudo — except for one documented case: a `pacman` uninstall runs
   `sudo -n pacman` only when BOTH gates pass (root filesystem
   writable AND working passwordless sudo). Both gates refuse by
   default on a stock Steam Deck, where root is read-only. See
   `linux/SETUP.md` step 3.
2. **Android app's baked-in relay URL.** The v1.1 APK still points
   at the original owner's relay (baked into `Relay.java`, shipped
   as built, not rebuilt). Do not use it as your own doctor app
   until a future build makes the URL a setting. See
   `android/ANDROID-RELAY-CAVEAT.md`. The ADB host tool touches no
   relay and is unaffected. The **Authenticator app does NOT have
   this problem**: its relay URL is entered at runtime in the app,
   never baked in — an APK built from `authenticator/` is
   blank-safe.

## Rules that never change

- Show-first / ok-gate: every fix is proposed in chat first and runs
  only after the owner says go to that exact fix.
- No reboot, shutdown, wipe, format, or reinstall without the
  owner's explicit ok for that named step.
- No lock-screen / password bypass, no saved-credential digging, no
  other people's machines, no iPhones, ever.
- Never delete user documents or photos.
- Nothing in this pack is priced, published, or sent anywhere.
