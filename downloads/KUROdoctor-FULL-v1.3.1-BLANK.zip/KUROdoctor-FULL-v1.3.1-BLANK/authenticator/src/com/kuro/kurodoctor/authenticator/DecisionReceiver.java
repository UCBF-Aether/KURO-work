package com.kuro.kurodoctor.authenticator;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.json.JSONObject;

/**
 * KUROdoctor Authenticator v1.1 - notification action receiver.
 *
 * Handles the Approve / Deny buttons on the session-request
 * notification (posted by WatchService) so the owner can answer
 * without opening the app. Runs the decision against the relay
 * on a background thread, cancels the notification on success,
 * and toasts the result. On failure the notification stays up so
 * the owner can tap again (or open the app and answer there).
 *
 * Explicit intents only (manifest: exported=false); the receiver
 * holds no secrets - the relay URL and device key arrive in the
 * intent from the service that posted the notification.
 */
public class DecisionReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action == null) return;
        final String decision;
        if (WatchService.ACTION_APPROVE.equals(action)) {
            decision = "approve";
        } else if (WatchService.ACTION_DENY.equals(action)) {
            decision = "deny";
        } else {
            return;
        }
        final String url = intent.getStringExtra(MainActivity.KEY_RELAY_URL);
        final String key = intent.getStringExtra(MainActivity.KEY_DEVICE_KEY);
        final int notifId = intent.getIntExtra(WatchService.EXTRA_NOTIF_ID, 2);
        if (url == null || url.isEmpty() || key == null || key.isEmpty()) return;
        final Context appCtx = context.getApplicationContext();
        new Thread(() -> {
            try {
                JSONObject res = RelayClient.decide(url, key, decision);
                final boolean unlocked = res.optBoolean("unlocked", false);
                final String msg = "approve".equals(decision)
                        ? (unlocked ? "Approved. Session unlocked for 8 hours."
                                : "Approved, but the relay says the session is not unlocked.")
                        : "Denied. Session stays locked.";
                new Handler(Looper.getMainLooper()).post(() ->
                        Toast.makeText(appCtx, msg, Toast.LENGTH_LONG).show());
                NotificationManager nm = (NotificationManager)
                        appCtx.getSystemService(Context.NOTIFICATION_SERVICE);
                nm.cancel(notifId);
            } catch (RelayClient.RelayException e) {
                new Handler(Looper.getMainLooper()).post(() ->
                        Toast.makeText(appCtx,
                                "Could not send: " + e.getMessage(),
                                Toast.LENGTH_LONG).show());
                // Notification stays up so the owner can tap again.
            }
        }).start();
    }
}
