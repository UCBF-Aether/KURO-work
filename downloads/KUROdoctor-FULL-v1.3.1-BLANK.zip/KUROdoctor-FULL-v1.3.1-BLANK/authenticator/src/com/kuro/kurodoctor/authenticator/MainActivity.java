package com.kuro.kurodoctor.authenticator;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

/**
 * KUROdoctor Authenticator — one job: let the owner approve or deny
 * a doctor session. Nothing else. No location, no SOS, no family
 * features, no push — the app polls the relay (outbound only, same
 * pattern as the doctor agent).
 *
 * Two screens in one Activity:
 *   UNPAIRED — two fields (relay URL, pairing code) + Pair button.
 *     The relay URL is typed in by the owner at runtime and stored
 *     in this app's private preferences. It is NEVER a compile-time
 *     constant: there is no URL in this source at all.
 *   PAIRED — session status (Locked / Unlocked / Approval requested),
 *     Approve + Deny buttons (enabled only while a request is
 *     pending), Refresh, Change relay URL, Unpair.
 *
 * Polling: every 5 seconds while paired and visible — GET
 * /doctor/session/pending + GET /doctor/session/status. Approve sets
 * the relay's 8-hour unlock; Deny clears the request and stays
 * locked. The pairing code is used once and never stored. The
 * device key is stored locally and sent as X-Device-Key. The app
 * never sees the DOCTOR_TOKEN.
 *
 * v1.1 — background watch (WatchService): a foreground service
 * keeps polling GET /doctor/session/pending every 5 seconds even
 * with the app closed and raises a LOCAL notification the moment
 * a session request appears (high importance, sound + vibration,
 * Approve/Deny buttons right on it). No Firebase, no FCM — the
 * app polls the relay itself and notifies itself, the BrentGuard
 * way. The service starts on pairing and on app open, restarts
 * after a reboot (BootReceiver), and stops on unpair. Android 13+
 * needs the POST_NOTIFICATIONS runtime permission, asked for on
 * first launch and after pairing.
 */
public class MainActivity extends Activity {

    // Public so WatchService / DecisionReceiver / BootReceiver can
    // read the same private preferences (same package, same app).
    public static final String PREFS = "kurodoctor_auth";
    public static final String KEY_RELAY_URL = "relay_url";
    public static final String KEY_DEVICE_KEY = "device_key";
    private static final long POLL_MS = 5000;

    private SharedPreferences prefs;
    private Handler handler;
    private Runnable poller;
    private boolean polling = false;

    private TextView titleText;
    private TextView statusText;
    private TextView pendingText;
    private LinearLayout pairingBox;
    private LinearLayout mainBox;
    private EditText urlEdit;
    private EditText codeEdit;
    private Button pairButton;
    private Button approveButton;
    private Button denyButton;
    private Button refreshButton;
    private Button changeUrlButton;
    private Button unpairButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        handler = new Handler(Looper.getMainLooper());

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        titleText = new TextView(this);
        titleText.setText("KUROdoctor Authenticator");
        titleText.setTextSize(22);
        titleText.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(titleText);

        statusText = new TextView(this);
        statusText.setTextSize(16);
        statusText.setPadding(0, pad, 0, 0);
        root.addView(statusText);

        // ---- pairing box ----
        pairingBox = new LinearLayout(this);
        pairingBox.setOrientation(LinearLayout.VERTICAL);
        TextView pairLabel = new TextView(this);
        pairLabel.setText("Pair with your relay");
        pairLabel.setTextSize(16);
        pairingBox.addView(pairLabel);
        TextView urlLabel = new TextView(this);
        urlLabel.setText("Relay URL (paste the full address your Muse gave you):");
        pairingBox.addView(urlLabel);
        urlEdit = new EditText(this);
        urlEdit.setHint("Relay URL");
        urlEdit.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_URI);
        pairingBox.addView(urlEdit);
        TextView codeLabel = new TextView(this);
        codeLabel.setText("Pairing code (your Muse gave you this once):");
        pairingBox.addView(codeLabel);
        codeEdit = new EditText(this);
        codeEdit.setHint("Pairing code");
        codeEdit.setInputType(InputType.TYPE_CLASS_TEXT);
        pairingBox.addView(codeEdit);
        pairButton = new Button(this);
        pairButton.setText("Pair");
        pairButton.setOnClickListener(v -> onPairClicked());
        pairingBox.addView(pairButton);
        root.addView(pairingBox);

        // ---- main box ----
        mainBox = new LinearLayout(this);
        mainBox.setOrientation(LinearLayout.VERTICAL);
        pendingText = new TextView(this);
        pendingText.setTextSize(16);
        pendingText.setPadding(0, pad, 0, 0);
        mainBox.addView(pendingText);
        approveButton = new Button(this);
        approveButton.setText("Approve");
        approveButton.setOnClickListener(v -> onDecideClicked("approve"));
        mainBox.addView(approveButton);
        denyButton = new Button(this);
        denyButton.setText("Deny");
        denyButton.setOnClickListener(v -> onDecideClicked("deny"));
        mainBox.addView(denyButton);
        refreshButton = new Button(this);
        refreshButton.setText("Check now");
        refreshButton.setOnClickListener(v -> pollNow());
        mainBox.addView(refreshButton);
        changeUrlButton = new Button(this);
        changeUrlButton.setText("Change relay URL");
        changeUrlButton.setOnClickListener(v -> onChangeUrlClicked());
        mainBox.addView(changeUrlButton);
        unpairButton = new Button(this);
        unpairButton.setText("Unpair this device");
        unpairButton.setOnClickListener(v -> onUnpairClicked());
        mainBox.addView(unpairButton);
        root.addView(mainBox);

        setContentView(scroll);
        showScreen();
        ensureNotificationPermission();
        WatchService.startIfPaired(this);
    }

    /** Android 13+ needs the POST_NOTIFICATIONS runtime permission
     *  before the phone can buzz on a session request. Ask once;
     *  if the owner says no, the app still works open, it just
     *  cannot alert with the app closed. */
    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private String relayUrl() {
        return prefs.getString(KEY_RELAY_URL, "");
    }

    private String deviceKey() {
        return prefs.getString(KEY_DEVICE_KEY, "");
    }

    private boolean isPaired() {
        return !relayUrl().isEmpty() && !deviceKey().isEmpty();
    }

    private void showScreen() {
        if (isPaired()) {
            pairingBox.setVisibility(View.GONE);
            mainBox.setVisibility(View.VISIBLE);
            statusText.setText("Paired with your relay.\n" + relayUrl()
                    + "\nBackground watch is on — the phone will buzz on a session request.");
            pendingText.setText("Checking for approval requests...");
            approveButton.setEnabled(false);
            denyButton.setEnabled(false);
        } else {
            pairingBox.setVisibility(View.VISIBLE);
            mainBox.setVisibility(View.GONE);
            statusText.setText("Not paired yet. Paste your relay URL and pairing code below.");
            String savedUrl = relayUrl();
            if (!savedUrl.isEmpty()) urlEdit.setText(savedUrl);
        }
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    private void onPairClicked() {
        final String url = urlEdit.getText().toString().trim();
        final String code = codeEdit.getText().toString().trim();
        if (url.isEmpty() || code.isEmpty()) {
            toast("Paste both the relay URL and the pairing code.");
            return;
        }
        pairButton.setEnabled(false);
        statusText.setText("Pairing...");
        new Thread(() -> {
            try {
                String key = RelayClient.pair(url, code);
                prefs.edit()
                        .putString(KEY_RELAY_URL, url)
                        .putString(KEY_DEVICE_KEY, key)
                        .apply();
                runOnUiThread(() -> {
                    codeEdit.setText("");
                    pairButton.setEnabled(true);
                    showScreen();
                    toast("Paired. This phone can now approve doctor sessions.");
                    ensureNotificationPermission();
                    WatchService.startIfPaired(MainActivity.this);
                    startPolling();
                });
            } catch (RelayClient.RelayException e) {
                runOnUiThread(() -> {
                    pairButton.setEnabled(true);
                    statusText.setText("Pairing failed: " + e.getMessage());
                });
            }
        }).start();
    }

    private void onDecideClicked(final String decision) {
        approveButton.setEnabled(false);
        denyButton.setEnabled(false);
        final String url = relayUrl();
        final String key = deviceKey();
        new Thread(() -> {
            try {
                JSONObject res = RelayClient.decide(url, key, decision);
                final boolean unlocked = res.optBoolean("unlocked", false);
                runOnUiThread(() -> {
                    pendingText.setText(unlocked
                            ? "Approved. Session unlocked for 8 hours."
                            : "Denied. Session stays locked.");
                    pollNow();
                });
            } catch (RelayClient.RelayException e) {
                runOnUiThread(() -> {
                    pendingText.setText("Could not send: " + e.getMessage());
                    pollNow();
                });
            }
        }).start();
    }

    private void onChangeUrlClicked() {
        // A different relay means a different device key: clear the
        // key and go back to pairing with the URL prefilled.
        prefs.edit().remove(KEY_DEVICE_KEY).apply();
        stopPolling();
        WatchService.stop(this);
        showScreen();
    }

    private void onUnpairClicked() {
        prefs.edit().remove(KEY_RELAY_URL).remove(KEY_DEVICE_KEY).apply();
        stopPolling();
        WatchService.stop(this);
        urlEdit.setText("");
        codeEdit.setText("");
        showScreen();
        toast("Unpaired. This phone can no longer approve sessions.");
    }

    /** One poll round: pending request + session status. */
    private void pollNow() {
        if (!isPaired()) return;
        final String url = relayUrl();
        final String key = deviceKey();
        new Thread(() -> {
            try {
                JSONObject pending = RelayClient.getPending(url, key);
                JSONObject status = RelayClient.getStatus(url, key);
                final boolean hasPending = pending.optBoolean("pending", false);
                final String createdAt = pending.optString("created_at", "");
                final boolean unlocked = status.optBoolean("unlocked", false);
                runOnUiThread(() -> {
                    if (hasPending) {
                        pendingText.setText("Approval requested"
                                + (createdAt.isEmpty() ? "" : " at " + createdAt)
                                + ".\nTap Approve to let Muse work, or Deny to refuse.");
                        approveButton.setEnabled(true);
                        denyButton.setEnabled(true);
                    } else {
                        pendingText.setText("No approval request right now.");
                        approveButton.setEnabled(false);
                        denyButton.setEnabled(false);
                    }
                    statusText.setText("Paired with your relay.\n" + url
                            + "\nSession: " + (unlocked ? "UNLOCKED" : "LOCKED")
                            + "\nBackground watch is on — the phone will buzz on a session request.");
                });
            } catch (RelayClient.RelayException e) {
                runOnUiThread(() -> statusText.setText(
                        "Paired with your relay.\n" + url
                                + "\nCould not reach the relay: " + e.getMessage()
                                + "\nBackground watch is on — the phone will buzz on a session request."));
            }
        }).start();
    }

    private void startPolling() {
        if (polling) return;
        polling = true;
        poller = new Runnable() {
            @Override
            public void run() {
                if (!polling) return;
                pollNow();
                handler.postDelayed(this, POLL_MS);
            }
        };
        handler.post(poller);
    }

    private void stopPolling() {
        polling = false;
        if (poller != null) handler.removeCallbacks(poller);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isPaired()) {
            pollNow();
            startPolling();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopPolling();
    }
}
