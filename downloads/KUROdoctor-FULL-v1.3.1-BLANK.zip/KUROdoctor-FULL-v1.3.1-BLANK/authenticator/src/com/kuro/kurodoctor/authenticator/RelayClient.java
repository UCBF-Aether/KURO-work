package com.kuro.kurodoctor.authenticator;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * KUROdoctor Authenticator — relay client.
 *
 * Talks to the owner's own Cloudflare relay (the KUROdoctor v1.4.0
 * session endpoints). The relay URL is ALWAYS supplied at runtime —
 * it comes from the app's settings (typed in by the owner during
 * pairing) and is passed in as a parameter. There is NO compile-time
 * URL, no default URL, and no placeholder URL anywhere in this file
 * or anywhere in the app: the app cannot reach any relay until the
 * owner types one in. That is the whole point — unlike the doctor
 * app, whose relay URL was baked into Relay.java, this app is
 * blank-safe by construction, and an APK built from it is blank-safe
 * too.
 *
 * Endpoints used (all v1.4.0):
 *   POST /doctor/session/pair      {pairing_code} -> {device_key}
 *   GET  /doctor/session/pending   X-Device-Key -> {pending, session_id, created_at}
 *   POST /doctor/session/decision  X-Device-Key {decision} -> {unlocked}
 *   GET  /doctor/session/status    X-Device-Key -> {unlocked, pending}
 *
 * The app NEVER sees the DOCTOR_TOKEN (that lives only with Muse)
 * and never sends it. It holds only its own device key, issued by
 * the relay at pairing time.
 */
public class RelayClient {

    public static class RelayException extends Exception {
        public RelayException(String message) {
            super(message);
        }
    }

    /** Trim + strip trailing slashes. Refuses a URL with no scheme
     *  (the owner must paste the full address). No scheme or host
     *  is ever supplied here — only validated. */
    private static String normalize(String relayUrl) throws RelayException {
        if (relayUrl == null) throw new RelayException("No relay URL set.");
        String u = relayUrl.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        if (u.isEmpty()) throw new RelayException("Relay URL is empty.");
        if (!u.contains("://")) {
            throw new RelayException("Paste the full relay URL, including its scheme.");
        }
        return u;
    }

    private static JSONObject request(String method, String url, String deviceKey,
                                      String bodyJson) throws RelayException {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(10000);
            c.setReadTimeout(10000);
            c.setRequestProperty("Accept", "application/json");
            if (deviceKey != null) c.setRequestProperty("X-Device-Key", deviceKey);
            if (bodyJson != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                byte[] bytes = bodyJson.getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = c.getOutputStream()) {
                    out.write(bytes);
                }
            }
            int status = c.getResponseCode();
            InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = "";
            if (in != null) {
                StringBuilder sb = new StringBuilder();
                try (BufferedReader r = new BufferedReader(
                        new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                }
                text = sb.toString();
            }
            if (status >= 400) {
                throw new RelayException("Relay answered " + status + ": " + text);
            }
            if (text.isEmpty()) return new JSONObject();
            return new JSONObject(text);
        } catch (RelayException e) {
            throw e;
        } catch (Exception e) {
            throw new RelayException("Could not reach the relay: " + e.getMessage());
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Pair with the relay. Returns the device key the relay issues.
     *  The pairing code is used once, then discarded — it is never
     *  stored. */
    public static String pair(String relayUrl, String pairingCode) throws RelayException {
        String base = normalize(relayUrl);
        if (pairingCode == null || pairingCode.trim().isEmpty()) {
            throw new RelayException("Pairing code is empty.");
        }
        try {
            JSONObject body = new JSONObject();
            body.put("pairing_code", pairingCode.trim());
            JSONObject res = request("POST", base + "/doctor/session/pair", null, body.toString());
            String key = res.optString("device_key", "");
            if (key.isEmpty()) throw new RelayException("Relay did not return a device key.");
            return key;
        } catch (RelayException e) {
            throw e;
        } catch (Exception e) {
            throw new RelayException(e.getMessage());
        }
    }

    /** Any pending approval request, or {pending:false}. */
    public static JSONObject getPending(String relayUrl, String deviceKey) throws RelayException {
        return request("GET", normalize(relayUrl) + "/doctor/session/pending", deviceKey, null);
    }

    /** Session state: {unlocked, pending}. Read-only. */
    public static JSONObject getStatus(String relayUrl, String deviceKey) throws RelayException {
        return request("GET", normalize(relayUrl) + "/doctor/session/status", deviceKey, null);
    }

    /** Answer a pending approval: "approve" or "deny".
     *  Returns {unlocked:true} on approve, {unlocked:false} on deny. */
    public static JSONObject decide(String relayUrl, String deviceKey,
                                    String decision) throws RelayException {
        try {
            JSONObject body = new JSONObject();
            body.put("decision", decision);
            return request("POST", normalize(relayUrl) + "/doctor/session/decision",
                    deviceKey, body.toString());
        } catch (RelayException e) {
            throw e;
        } catch (Exception e) {
            throw new RelayException(e.getMessage());
        }
    }
}
