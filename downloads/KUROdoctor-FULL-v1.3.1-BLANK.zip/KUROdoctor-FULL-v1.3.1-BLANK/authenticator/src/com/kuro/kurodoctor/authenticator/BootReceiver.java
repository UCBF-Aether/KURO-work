package com.kuro.kurodoctor.authenticator;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * KUROdoctor Authenticator v1.1 - boot receiver.
 *
 * Restarts the background watch service after a phone reboot, but
 * only if the app is already paired (WatchService.startIfPaired
 * checks). An unpaired phone starts nothing. No notification is
 * posted here - the service posts its own persistent "watching"
 * notification when it starts.
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            WatchService.startIfPaired(context);
        }
    }
}
