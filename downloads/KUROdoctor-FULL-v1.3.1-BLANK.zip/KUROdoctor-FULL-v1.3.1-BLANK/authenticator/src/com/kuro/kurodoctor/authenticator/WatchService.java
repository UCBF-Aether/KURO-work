package com.kuro.kurodoctor.authenticator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;

import org.json.JSONObject;

/**
 * KUROdoctor Authenticator v1.1 - background watch service.
 *
 * The BrentGuard way: NO Firebase, NO FCM, NO push server. The app
 * polls the relay itself (outbound only, same pattern as the doctor
 * agent) and raises a LOCAL notification when a session request
 * appears. The service runs as a foreground service so it keeps
 * polling every 5 seconds even when the app is closed; Android
 * shows a small persistent "Watching for session requests"
 * notification while it runs. It restarts after a reboot
 * (BootReceiver) and stops when the app is unpaired.
 *
 * The session-request notification (high importance, sound +
 * vibration) opens the app on tap and carries Approve / Deny
 * action buttons (DecisionReceiver) so the owner can answer
 * without opening the app. Each session_id is notified once:
 * the last notified id is kept in preferences, so a restart or
 * a re-poll never buzzes twice for the same request.
 *
 * The service never sees the DOCTOR_TOKEN and holds no secrets
 * beyond the device key the relay issued at pairing (already
 * stored in the app's private preferences).
 */
public class WatchService extends Service {

    public static final String ACTION_APPROVE =
            "com.kuro.kurodoctor.authenticator.APPROVE";
    public static final String ACTION_DENY =
            "com.kuro.kurodoctor.authenticator.DENY";
    public static final String EXTRA_SESSION_ID = "session_id";
    public static final String EXTRA_NOTIF_ID = "notif_id";

    private static final String CHANNEL_WATCH = "kurodoctor_watch";
    private static final String CHANNEL_SESSION = "kurodoctor_session";
    private static final int NOTIF_ID_WATCH = 1;
    private static final int NOTIF_ID_SESSION = 2;
    private static final long POLL_MS = 5000;
    private static final String KEY_LAST_NOTIFIED = "last_notified_session";

    private HandlerThread thread;
    private Handler handler;
    private Runnable poller;
    private boolean running = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels();
        thread = new HandlerThread("kurodoctor-watch");
        thread.start();
        handler = new Handler(thread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID_WATCH, watchNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID_WATCH, watchNotification());
        }
        if (!running) {
            running = true;
            poller = new Runnable() {
                @Override
                public void run() {
                    if (!running) return;
                    pollOnce();
                    handler.postDelayed(this, POLL_MS);
                }
            };
            handler.post(poller);
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (poller != null) handler.removeCallbacks(poller);
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
    }

    private boolean isPaired() {
        SharedPreferences p = prefs();
        return !p.getString(MainActivity.KEY_RELAY_URL, "").isEmpty()
                && !p.getString(MainActivity.KEY_DEVICE_KEY, "").isEmpty();
    }

    private void createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel watch = new NotificationChannel(CHANNEL_WATCH,
                "Background watch", NotificationManager.IMPORTANCE_LOW);
        watch.setDescription(
                "Shows while the Authenticator is watching for session requests.");
        watch.setSound(null, null);
        watch.enableVibration(false);
        nm.createNotificationChannel(watch);
        NotificationChannel session = new NotificationChannel(CHANNEL_SESSION,
                "Session requests", NotificationManager.IMPORTANCE_HIGH);
        session.setDescription("Alerts when Muse requests a doctor session.");
        session.enableVibration(true);
        nm.createNotificationChannel(session);
    }

    private Notification watchNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_WATCH)
                .setContentTitle("KUROdoctor Authenticator")
                .setContentText("Watching for session requests")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void pollOnce() {
        if (!isPaired()) {
            stopSelf();
            return;
        }
        SharedPreferences p = prefs();
        final String url = p.getString(MainActivity.KEY_RELAY_URL, "");
        final String key = p.getString(MainActivity.KEY_DEVICE_KEY, "");
        try {
            JSONObject pending = RelayClient.getPending(url, key);
            if (!pending.optBoolean("pending", false)) return;
            final String sessionId = pending.optString("session_id", "");
            if (sessionId.isEmpty()) return;
            String last = p.getString(KEY_LAST_NOTIFIED, "");
            if (sessionId.equals(last)) return;
            p.edit().putString(KEY_LAST_NOTIFIED, sessionId).apply();
            notifySession(url, key, sessionId);
        } catch (RelayClient.RelayException e) {
            // Relay unreachable this round; try again next round.
        }
    }

    private void notifySession(String url, String key, String sessionId) {
        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent approve = new Intent(this, DecisionReceiver.class);
        approve.setAction(ACTION_APPROVE);
        approve.putExtra(MainActivity.KEY_RELAY_URL, url);
        approve.putExtra(MainActivity.KEY_DEVICE_KEY, key);
        approve.putExtra(EXTRA_SESSION_ID, sessionId);
        approve.putExtra(EXTRA_NOTIF_ID, NOTIF_ID_SESSION);
        PendingIntent approvePi = PendingIntent.getBroadcast(this, 1, approve,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent deny = new Intent(this, DecisionReceiver.class);
        deny.setAction(ACTION_DENY);
        deny.putExtra(MainActivity.KEY_RELAY_URL, url);
        deny.putExtra(MainActivity.KEY_DEVICE_KEY, key);
        deny.putExtra(EXTRA_SESSION_ID, sessionId);
        deny.putExtra(EXTRA_NOTIF_ID, NOTIF_ID_SESSION);
        PendingIntent denyPi = PendingIntent.getBroadcast(this, 2, deny,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(this, CHANNEL_SESSION)
                .setContentTitle("KUROdoctor session request")
                .setContentText(
                        "Muse is asking to work on your computer. Tap to approve or deny.")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentIntent(openPi)
                .setAutoCancel(true)
                .addAction(new Notification.Action.Builder(
                        android.graphics.drawable.Icon.createWithResource(
                                this, android.R.drawable.ic_menu_send),
                        "Approve", approvePi).build())
                .addAction(new Notification.Action.Builder(
                        android.graphics.drawable.Icon.createWithResource(
                                this, android.R.drawable.ic_menu_close_clear_cancel),
                        "Deny", denyPi).build())
                .build();
        nm.notify(NOTIF_ID_SESSION, n);
    }

    /** Start the watch service if the app is paired. Safe to call anytime. */
    public static void startIfPaired(Context ctx) {
        SharedPreferences p =
                ctx.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        if (p.getString(MainActivity.KEY_RELAY_URL, "").isEmpty()
                || p.getString(MainActivity.KEY_DEVICE_KEY, "").isEmpty()) return;
        Intent i = new Intent(ctx, WatchService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(i);
        } else {
            ctx.startService(i);
        }
    }

    /** Stop the watch service. Call on unpair / relay change. */
    public static void stop(Context ctx) {
        ctx.stopService(new Intent(ctx, WatchService.class));
    }
}
