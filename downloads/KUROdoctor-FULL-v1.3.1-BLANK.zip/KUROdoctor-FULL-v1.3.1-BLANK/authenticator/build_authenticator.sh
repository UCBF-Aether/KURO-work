#!/bin/bash
# KUROdoctor Authenticator v1.1 — manual APK build (no Gradle; plugins
# can't download through the proxy). aapt2 + javac + d8 + zipalign +
# apksigner. Same proven pattern as the doctor app's build_doctor.sh.
# Signing keystore: $KURODOCTOR_KEYSTORE, else a debug.keystore next
# to this script (generated on first build if absent) — so the script
# is self-contained for any owner. Point KURODOCTOR_KEYSTORE at the
# doctor app's debug.keystore to share one signing cert with it.
#
# No Shizuku, no extra libraries — the app is two Java files and one
# manifest. The relay URL is entered at RUNTIME by the owner (in-app
# setting); nothing is baked into the APK, so an APK built from this
# source is blank-safe.
set -e
export JAVA_HOME=${JAVA_HOME:-$HOME/jdk17}
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_HOME=${ANDROID_HOME:-$HOME/android-sdk}
BT="$ANDROID_HOME/build-tools/34.0.0"
PJ="$ANDROID_HOME/platforms/android-34/android.jar"
ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/build"
OUT="$ROOT/delivery"
KEYSTORE="${KURODOCTOR_KEYSTORE:-$ROOT/debug.keystore}"
# If no keystore exists, generate one (standard Android debug-keystore
# values, non-interactive). Each owner gets their own signing cert —
# that is fine: the cert only has to stay stable across updates of
# the SAME app on the SAME phone. Set KURODOCTOR_KEYSTORE to reuse an
# existing keystore instead (e.g. the doctor app's debug.keystore).
if [ ! -f "$KEYSTORE" ]; then
  "$JAVA_HOME/bin/keytool" -genkeypair -keystore "$KEYSTORE" -alias androiddebugkey \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass android -keypass android \
    -dname "CN=KUROdoctor, OU=KUROdoctor, O=KUROdoctor, C=US" -noprompt
  echo "generated keystore: $KEYSTORE"
fi
rm -rf "$BUILD" && mkdir -p "$BUILD/compiled" "$BUILD/gen" "$BUILD/classes" "$BUILD/dex" "$OUT"

"$BT/aapt2" compile --dir "$ROOT/res" -o "$BUILD/compiled.zip"
"$BT/aapt2" link -o "$BUILD/app.unaligned.apk" \
  -I "$PJ" \
  --manifest "$ROOT/AndroidManifest.xml" \
  --java "$BUILD/gen" \
  --auto-add-overlay \
  --min-sdk-version 26 --target-sdk-version 34 \
  --version-code 2 --version-name "1.1" \
  "$BUILD/compiled.zip"

find "$ROOT/src" -name '*.java' > "$BUILD/sources.txt"
find "$BUILD/gen" -name '*.java' >> "$BUILD/sources.txt"
"$JAVA_HOME/bin/javac" -encoding UTF-8 -source 17 -target 17 -cp "$PJ" -d "$BUILD/classes" @"$BUILD/sources.txt"

"$JAVA_HOME/bin/jar" cf "$BUILD/classes.jar" -C "$BUILD/classes" .
"$BT/d8" --lib "$PJ" --output "$BUILD/dex" "$BUILD/classes.jar"
cp "$BUILD/dex/classes.dex" "$BUILD/classes.dex"
cd "$BUILD"
python3 -c "import zipfile; z=zipfile.ZipFile('app.unaligned.apk','a'); z.write('classes.dex'); z.close()"

"$BT/zipalign" -f 4 app.unaligned.apk app.apk
"$BT/apksigner" sign --ks "$KEYSTORE" --ks-pass pass:android --key-pass pass:android \
  --out "$OUT/KUROdoctor-Authenticator-1.1.apk" app.apk
"$BT/apksigner" verify "$OUT/KUROdoctor-Authenticator-1.1.apk" && echo "APK VERIFIED: $OUT/KUROdoctor-Authenticator-1.1.apk"
ls -lh "$OUT/KUROdoctor-Authenticator-1.1.apk"
sha256sum "$OUT/KUROdoctor-Authenticator-1.1.apk"
