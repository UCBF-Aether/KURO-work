# KUROdoctor Authenticator v1.1

The approval half of KUROdoctor v1.4.0 relay authentication. One job:
receive a session-approval request and let the owner tap **Approve**
or **Deny**. Nothing else. No location, no SOS, no family features,
no Firebase, no push server.

v1.1 adds the background watch: the app keeps polling with the app
closed and buzzes the phone the moment a session is requested
(see "Polling, not push" below).

## How it fits together

KUROdoctor v1.4.0 locks the relay with two factors, both checked on
`POST /doctor/command` only:

1. **Muse-held write token** — header `X-Doctor-Token` must match the
   worker secret `DOCTOR_TOKEN`. The token lives only with Muse; the
   owner never sees or types it. It proves a command post came from
   Muse.
2. **Authenticator app approval** — this app. Muse asks for a session
   (`POST /doctor/session/request`, token required) and the relay
   stores a pending approval. This app polls the relay and shows it;
   the owner taps Approve (the relay sets an 8-hour unlock) or Deny
   (stays locked). The tap proves the owner approved the session.

Both are required; they prove different things. If no authenticator
device is paired at all, the relay falls back to token-only mode, so
a fresh setup is never bricked before pairing. Once a device is
paired, both factors are required.

## Polling, not push

The app polls the relay every 5 seconds (outbound only, same
pattern as the doctor agent). No Firebase, no FCM setup, no
account, no server of its own. v1.0 polled only while the app
was open; v1.1 adds a foreground service (WatchService) that
keeps polling with the app closed and raises a LOCAL notification
(high importance, sound + vibration) the moment a pending
session appears, with Approve/Deny buttons right on it. The
service restarts after a reboot (BootReceiver) and stops on
unpair. Android 13+ needs the POST_NOTIFICATIONS runtime
permission for the buzz to show. Endpoints used:

| Call | What it does |
|---|---|
| `POST /doctor/session/pair` | Pair with the relay using the one-time pairing code; the relay returns a device key |
| `GET /doctor/session/pending` | Any pending approval request, or `{pending:false}` |
| `POST /doctor/session/decision` | `{decision:"approve"}` or `{decision:"deny"}` |
| `GET /doctor/session/status` | `{unlocked, pending}` for the status line |

## The relay URL is entered at RUNTIME — never baked in

This is the design rule that makes this app blank-safe. The doctor
app baked its relay URL into `Relay.java`, which is why a doctor APK
can never be blank. This app has **no URL anywhere in its source**:
the owner types their relay URL into the pairing screen, and it is
stored in the app's private preferences. A built APK from this
source is blank-safe too — it cannot reach any relay until the owner
types one in.

Verify it yourself:

```sh
grep -r -i "http" src/ res/ AndroidManifest.xml
```

The only match is the mandatory Android XML namespace declaration in
`AndroidManifest.xml` (`xmlns:android="http://schemas.android.com/..."`),
which every Android app carries and which points nowhere the app
connects to. There is no host, no endpoint, no default, and no
placeholder URL in the source.

## Files

| File | What it is |
|---|---|
| `src/com/kuro/kurodoctor/authenticator/MainActivity.java` | The one screen: pairing form + Approve/Deny + status, 5s polling; starts/stops the watch service, asks for the notification permission |
| `src/com/kuro/kurodoctor/authenticator/RelayClient.java` | Relay calls (pair / pending / decision / status), HttpURLConnection |
| `src/com/kuro/kurodoctor/authenticator/WatchService.java` | v1.1: foreground service, polls pending every 5s with the app closed, posts the session-request notification + the persistent "watching" one |
| `src/com/kuro/kurodoctor/authenticator/DecisionReceiver.java` | v1.1: Approve/Deny buttons on the notification, answers the relay without opening the app |
| `src/com/kuro/kurodoctor/authenticator/BootReceiver.java` | v1.1: restarts the watch service after a reboot (only if paired) |
| `AndroidManifest.xml` | Package `com.kuro.kurodoctor.authenticator`, INTERNET + POST_NOTIFICATIONS + FOREGROUND_SERVICE (+DATA_SYNC) + RECEIVE_BOOT_COMPLETED |
| `res/values/strings.xml` | App name only |
| `build_authenticator.sh` | Manual build (aapt2 + javac + d8 + zipalign + apksigner), no Gradle |
| `SETUP.md` | Pairing guide for the owner and their Muse |
| `README.md` | This file |

## Build

```sh
./build_authenticator.sh
```

Needs the same toolchain as the doctor app: `~/android-sdk`
(build-tools 34.0.0, platform android-34) and `~/jdk17`. Output:
`delivery/KUROdoctor-Authenticator-1.1.apk` (version-code 2,
version-name 1.1, target SDK 34, min SDK 26). Signing: the script
uses a `debug.keystore` next to itself (generating one on first
build if absent), or the path in `$KURODOCTOR_KEYSTORE` — e.g. the
doctor app's keystore if you want both apps on one cert. v1.1 is
built with the doctor keystore so it installs as an update over
v1.0 (same cert).

## What the app stores (and what it never holds)

- Stored locally (private preferences): the relay URL the owner
  typed, and the device key the relay issued at pairing.
- Used once, never stored: the pairing code.
- Never held at all: the `DOCTOR_TOKEN` (Muse-only), any password,
  any location, any contact.

## What was verified

- `build_authenticator.sh` compiles and signs cleanly (see build
  output in the delivery folder).
- Source grep: no hardcoded URL, no placeholder URL, no default URL
  (see above).
- **Not yet verified on a real phone:** v1.1's background watch and
  its notification — the buzz itself, the notification Approve/Deny
  buttons, the persistent "watching" notification, and the restart
  after a reboot — can only be proven live on the owner's phone.
  The v1.0 pairing flow, poll loop, and Approve/Deny tap were
  proven live against the v1.4.0 relay on Nov 20, 2026 (see GOAL.md);
  v1.1 keeps that code path unchanged and adds the service around it.
