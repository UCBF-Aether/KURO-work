#!/usr/bin/env python3
"""KUROdoctor ADB deep mode — PC-side host tool (v1.1).

Drives an Android phone over USB ADB from a host PC. This is the DEEP
mode companion to the KUROdoctor Android app (com.kuro.kurodoctor,
diagnose-only): where the app can only report, this tool can also do a
small whitelist of reversible-ish cleanups — but only on YOUR OWN phone,
only with the owner's explicit go, and only one package at a time.

SAFETY RULES (hard, by design):
  * List-first always. Default / --list only reads. It never changes
    anything on the phone.
  * Every change needs BOTH --go AND a named --package, one target at
    a time. No --go, no change. No target, no change.
  * --dry-run prints the exact adb command that WOULD run and executes
    nothing.
  * Only three changes are ever allowed (whitelist, nothing else):
      pm clear <pkg>                 — clear cache/data for one package
      pm disable-user --user 0 <pkg> — disable one package for user 0
      pm uninstall -k --user 0 <pkg> — uninstall for user 0, keep data
    There is no system removal, no flashing, no bootloader unlock, no
    root, no FRP / password / lock-screen bypass of any kind.
  * A blocklist of critical packages can NEVER be disabled, uninstalled
    or cleared. A few non-absolute entries can be overridden with
    --i-know-this-is-critical, but systemui / phone / settings / gms /
    gsf / launcher / keyboard stay blocked ALWAYS, override or not.
  * adb must ALREADY be installed (Android platform-tools) on this PC.
    This tool NEVER downloads, installs or fetches adb itself.
  * Never run this against another person's phone without that owner's
    explicit go.
  * adb is always run via subprocess with an argument list. Never
    shell=True, never a string-concatenated shell command.

Every action is logged with a timestamp to stdout AND to
kurodoctor-adb.log next to this script (timestamp + device + command
+ result).

Exit codes: 0 ok, 1 usage error / blocked package, 2 adb missing or
adb command failed.

Requires: Python 3 (stdlib only) + adb on PATH.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

VERSION = "1.1.0"
DEFAULT_TIMEOUT = 30
LOG_FILE = Path(__file__).resolve().parent / "kurodoctor-adb.log"
ADB_MISSING_MSG = "adb not found — install Android platform-tools and add it to PATH"

# ---------------------------------------------------------------------------
# Blocklist
# ---------------------------------------------------------------------------

# Exact packages that are never touched without --i-know-this-is-critical.
BLOCKED_PACKAGES = {
    "com.android.systemui",
    "com.android.phone",
    "com.android.settings",
    "com.android.launcher3",
    "com.google.android.gms",
    "com.google.android.gsf",
    "com.android.providers.settings",
    "com.android.providers.media",
    "com.android.inputmethod.latin",
    "com.google.android.inputmethod.latin",
    "com.samsung.android.messaging",
    "com.sec.android.app.launcher",
    "com.android.contacts",
    "com.android.dialer",
    "com.android.mms",
    "com.samsung.android.lool",
}

# Any package under these prefixes is blocked the same way.
BLOCKED_PREFIXES = (
    "com.android.",
    "com.google.android.",
    "com.sec.",
    "com.samsung.android.",
)

# Absolute-never: blocked ALWAYS, even with --i-know-this-is-critical.
# Keys are package names; values are the plain-language reason.
ABSOLUTE_NEVER = {
    "com.android.systemui": "System UI — the phone's screen, status bar and navigation. Removing it bricks the visible phone.",
    "com.android.phone": "Phone — the telephony stack. Removing it kills calls and mobile data.",
    "com.android.settings": "Settings — the phone's settings app. Removing it leaves no way to manage the phone.",
    "com.google.android.gms": "Google Play Services — almost every Google app and many third-party apps depend on it.",
    "com.google.android.gsf": "Google Services Framework — core Google account / push services.",
    "com.android.launcher3": "Launcher — the home screen. Removing it leaves no way to open apps.",
    "com.sec.android.app.launcher": "Launcher (Samsung) — the home screen. Removing it leaves no way to open apps.",
    "com.android.inputmethod.latin": "Keyboard (AOSP) — the on-screen keyboard. Removing it leaves no way to type.",
    "com.google.android.inputmethod.latin": "Keyboard (Gboard) — the on-screen keyboard. Removing it leaves no way to type.",
}

# Package names: lowercase letters, digits, dots, underscores only; must
# contain at least one dot; no leading/trailing dot; no empty segments;
# no shell metacharacters, spaces or slashes (regex enforces all of it).
PACKAGE_RE = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$")

# Allowed --action values and the adb shell words they map to.
ACTIONS = ("clear", "disable", "uninstall")

BATTERY_STATUS = {
    "1": "unknown", "2": "charging", "3": "discharging",
    "4": "not charging", "5": "full",
}
BATTERY_HEALTH = {
    "1": "unknown", "2": "good", "3": "overheat", "4": "dead",
    "5": "over voltage", "6": "unspecified failure", "7": "cold",
}


class UsageError(Exception):
    """Exit 1: bad usage or a blocked package."""


class AdbError(Exception):
    """Exit 2: adb missing, or an adb command failed."""


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def log_action(device, command, result):
    """Append one audit line to kurodoctor-adb.log (never crashes the run)."""
    line = "%s | device=%s | cmd=%s | result=%s\n" % (
        _utc_now(), device or "-", " ".join(command), result)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as fh:
            fh.write(line)
    except OSError as exc:
        print("warning: could not write log file %s: %s" % (LOG_FILE, exc),
              file=sys.stderr)
    print("[%s] %s" % (_utc_now(), line.strip()))


# ---------------------------------------------------------------------------
# adb plumbing — argument lists only, never shell=True
# ---------------------------------------------------------------------------

def find_adb():
    """Return the adb path, or raise AdbError with the plain message."""
    path = shutil.which("adb")
    if not path:
        raise AdbError(ADB_MISSING_MSG)
    return path


def run_adb(args, timeout, device=None):
    """Run one adb command. Returns CompletedProcess.

    Raises AdbError on timeout or if adb itself cannot start. A non-zero
    adb exit code is returned normally so callers can decide (list-mode
    sections degrade to 'unavailable'; actions treat it as failure).
    """
    cmd = ["adb"]
    if device:
        cmd += ["-s", device]
    cmd += list(args)
    try:
        return subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout)
    except subprocess.TimeoutExpired:
        raise AdbError("adb timed out after %ss: %s" % (timeout, " ".join(cmd)))
    except FileNotFoundError:
        raise AdbError(ADB_MISSING_MSG)
    except OSError as exc:
        raise AdbError("could not run adb: %s" % exc)


def run_adb_strict(args, timeout, device=None):
    """Run one adb command; raise AdbError (with adb's stderr) on failure."""
    proc = run_adb(args, timeout, device=device)
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()
        raise AdbError("adb failed (exit %d): %s%s" % (
            proc.returncode, " ".join(["adb"] + list(args)),
            (" — " + detail) if detail else ""))
    return proc


# ---------------------------------------------------------------------------
# Package validation + blocklist
# ---------------------------------------------------------------------------

def validate_package(pkg):
    """Raise UsageError unless pkg is a strict, safe package name."""
    if not pkg or not PACKAGE_RE.match(pkg):
        raise UsageError(
            "refusing package %r: package names must be lowercase letters, "
            "digits, dots and underscores, must contain at least one dot, "
            "and must not start with a dot" % (pkg,))
    return pkg


def block_reason(pkg):
    """Return the plain-language reason pkg is blocked, or None."""
    if pkg in ABSOLUTE_NEVER:
        return ABSOLUTE_NEVER[pkg]
    if pkg in BLOCKED_PACKAGES:
        return "critical system package — disabling, uninstalling or clearing it can break the phone."
    for prefix in BLOCKED_PREFIXES:
        if pkg.startswith(prefix):
            return ("under the blocked %s prefix — system / vendor package, "
                    "not a regular user app." % prefix)
    return None


def check_package(pkg, allow_critical):
    """Validate + blocklist-check one package.

    Raises UsageError with a plain message if the package is refused.
    Absolute-never packages are refused even with the override.
    """
    validate_package(pkg)
    if pkg in ABSOLUTE_NEVER:
        raise UsageError(
            "refusing %s: %s This package is blocked always, even with "
            "--i-know-this-is-critical." % (pkg, ABSOLUTE_NEVER[pkg]))
    reason = block_reason(pkg)
    if reason and not allow_critical:
        raise UsageError(
            "refusing %s: %s If you are certain, re-run with "
            "--i-know-this-is-critical." % (pkg, reason))
    if reason and allow_critical:
        print("WARNING: %s is blocklisted (%s) — proceeding only because "
              "--i-know-this-is-critical was passed." % (pkg, reason))
    return pkg


# ---------------------------------------------------------------------------
# Device discovery
# ---------------------------------------------------------------------------

def list_devices(timeout):
    """Return [(serial, state)] from `adb devices` (header line skipped)."""
    proc = run_adb_strict(["devices"], timeout)
    devices = []
    for line in proc.stdout.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) >= 2:
            devices.append((parts[0], parts[1]))
    return devices


def resolve_device(requested, timeout, for_action):
    """Pick the device to use.

    Returns the serial. Raises UsageError (exit 1) if several devices are
    attached and none was named, or the named one is not attached /
    not ready; raises AdbError (exit 2) if none is attached at all.
    """
    devices = list_devices(timeout)
    ready = [s for (s, st) in devices if st == "device"]
    if requested:
        if requested not in [s for (s, _st) in devices]:
            raise UsageError(
                "device %s is not attached (adb devices shows: %s). "
                "Plug the phone in and check USB debugging." % (
                    requested,
                    ", ".join("%s (%s)" % d for d in devices) or "none"))
        if for_action and requested not in ready:
            raise UsageError(
                "device %s is attached but not ready (state: %s). "
                "Check the phone screen for the USB-debugging prompt." % (
                    requested,
                    dict(devices)[requested]))
        return requested
    if not devices:
        raise AdbError("no Android device connected — plug the phone in, "
                       "turn on USB debugging, and accept the prompt on "
                       "the phone.")
    if for_action and len(ready) != 1:
        if len(ready) == 0:
            raise UsageError(
                "no device is ready (adb devices shows: %s). Check the "
                "phone screen for the USB-debugging prompt." % (
                    ", ".join("%s (%s)" % d for d in devices),))
        raise UsageError(
            "several devices are attached (%s) — re-run with "
            "--device <serial> to pick one." % ", ".join(ready))
    if len(devices) > 1 and not for_action:
        # List mode with several phones: caller handles the list itself.
        return None
    return ready[0] if ready else devices[0][0]


# ---------------------------------------------------------------------------
# List-mode parsers (best-effort: a section that cannot run reports
# unavailable and never blocks the rest, like the app's blind sweep)
# ---------------------------------------------------------------------------

def _parse_getprop(text):
    props = {}
    for match in re.finditer(r"\[(.+?)\]: \[(.*?)\]", text):
        props[match.group(1)] = match.group(2)
    return props


def _parse_battery(text):
    vals = {}
    for key in ("level", "scale", "status", "health", "temperature",
                "voltage", "plugged"):
        match = re.search(r"(?m)^\s*%s:\s*(\S+)\s*$" % key, text)
        if match:
            vals[key] = match.group(1)
    if "level" not in vals:
        return {"status": "unavailable",
                "reason": "dumpsys battery output did not contain a level"}
    try:
        level = int(vals["level"])
        scale = int(vals.get("scale", "100")) or 100
        pct = round(level * 100.0 / scale, 1)
    except ValueError:
        return {"status": "unavailable",
                "reason": "dumpsys battery level was not a number"}
    out = {"status": "ok", "level_pct": pct}
    if "status" in vals:
        out["charging_state"] = BATTERY_STATUS.get(vals["status"], vals["status"])
    if "health" in vals:
        out["health"] = BATTERY_HEALTH.get(vals["health"], vals["health"])
    if "temperature" in vals:
        try:
            out["temperature_c"] = int(vals["temperature"]) / 10.0
        except ValueError:
            pass
    if "voltage" in vals:
        try:
            out["voltage_mv"] = int(vals["voltage"])
        except ValueError:
            pass
    if "plugged" in vals:
        out["plugged"] = vals["plugged"]
    return out


def _parse_df(text):
    mounts = []
    for line in text.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 6:
            continue
        try:
            total_kb = int(parts[1])
            used_kb = int(parts[2])
            free_kb = int(parts[3])
        except ValueError:
            continue
        if total_kb <= 0:
            continue
        mounts.append({
            "mount": parts[5],
            "total_gb": round(total_kb * 1024 / 1e9, 2),
            "used_gb": round(used_kb * 1024 / 1e9, 2),
            "free_gb": round(free_kb * 1024 / 1e9, 2),
            "use_pct": round(used_kb * 100.0 / total_kb, 1),
        })
    if not mounts:
        return {"status": "unavailable", "reason": "df output had no usable mounts"}
    return {"status": "ok", "mounts": mounts}


def _parse_packages(text):
    pkgs = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("package:"):
            pkgs.append(line[len("package:"):].strip())
    return sorted(set(pkgs))


def _parse_uid_map(text):
    """pm list packages -U -> {uid: [package, ...]}."""
    mapping = {}
    for line in text.splitlines():
        match = re.match(r"\s*package:(\S+)\s+uid:(\d+)", line.strip())
        if match:
            mapping.setdefault(int(match.group(2)), []).append(match.group(1))
    return mapping


_SIZE_MULT = {"B": 1, "KB": 1024, "MB": 1024 ** 2, "GB": 1024 ** 3}


def _parse_diskstats(text):
    """dumpsys diskstats -> {pkg: {"cache_kb": x, "data_kb": y}}.

    Best-effort: output format varies by Android version. Handles both
    the 'Package: <pkg>' block form and single-line 'pkg ... cache: N MB'
    forms. Returns {} when nothing parses.
    """
    sizes = {}
    current = None
    for raw in text.splitlines():
        line = raw.strip()
        match = re.match(r"Package:\s*(\S+)", line)
        if match:
            current = match.group(1)
            sizes.setdefault(current, {})
            continue
        if re.fullmatch(r"[a-z][a-z0-9_.]*", line):
            current = line
            sizes.setdefault(current, {})
            continue
        pkg_here = current
        # Single-line form: "<pkg> ... cache: N MB". The first token must
        # contain a dot, so a continuation line like "code: 12MB data:
        # 45MB cache: 120MB" is never mistaken for a package name.
        single = re.match(r"([a-z][a-z0-9_.]*\.[a-z0-9_.]*)\b.*\bcache\s*[:=]", line)
        if single:
            pkg_here = single.group(1)
            sizes.setdefault(pkg_here, {})
        if pkg_here is None:
            continue
        for field in ("cache", "data"):
            found = re.search(r"%s\s*[:=]\s*([\d.]+)\s*([KMG]?B)" % field, line)
            if found:
                kb = float(found.group(1)) * _SIZE_MULT[found.group(2)] / 1024.0
                sizes[pkg_here][field + "_kb"] = round(kb, 1)
    return {pkg: v for pkg, v in sizes.items() if v}


def _parse_batterystats(text, uid_map):
    """Estimated-power section -> [{"package", "estimated_mah"}] top 10."""
    hogs = []
    in_section = False
    for line in text.splitlines():
        if "Estimated power use" in line:
            in_section = True
            continue
        if not in_section:
            continue
        if line.strip() == "":
            continue
        if not line.startswith((" ", "\t")):
            break  # next top-level section
        match = re.search(r"Uid\s+(\d+):\s+([\d.]+)", line)
        if match:
            uid = int(match.group(1))
            mah = float(match.group(2))
            for pkg in uid_map.get(uid, ["uid:%d" % uid]):
                hogs.append({"package": pkg, "estimated_mah": mah})
    hogs.sort(key=lambda h: h["estimated_mah"], reverse=True)
    return hogs[:10]


def _parse_ps(text):
    """ps -A -o PID,NAME,RSS -> top 10 by RSS (memory proxy for hogs)."""
    rows = []
    for line in text.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 3:
            continue
        try:
            rss_kb = int(parts[2])
        except ValueError:
            continue
        rows.append({"process": parts[1], "rss_kb": rss_kb})
    rows.sort(key=lambda r: r["rss_kb"], reverse=True)
    return rows[:10]


def collect_list(device, timeout):
    """Gather the read-only list-mode report for one device."""
    report = {"device": {"serial": device}}

    proc = run_adb(["shell", "getprop"], timeout, device=device)
    if proc.returncode == 0:
        props = _parse_getprop(proc.stdout)
        report["device"].update({
            "model": props.get("ro.product.model", "unknown"),
            "manufacturer": props.get("ro.product.manufacturer", "unknown"),
            "android_version": props.get("ro.build.version.release", "unknown"),
            "sdk": props.get("ro.build.version.sdk", "unknown"),
        })
    else:
        report["device"].update({"model": "unknown", "manufacturer": "unknown",
                                 "android_version": "unknown", "sdk": "unknown"})
        report.setdefault("notes", []).append("getprop failed: %s" % (proc.stderr or "").strip())

    proc = run_adb(["shell", "dumpsys", "battery"], timeout, device=device)
    report["battery"] = (_parse_battery(proc.stdout) if proc.returncode == 0
                         else {"status": "unavailable",
                               "reason": "dumpsys battery failed: %s" % (proc.stderr or "").strip()})

    proc = run_adb(["shell", "df"], timeout, device=device)
    report["disk_space"] = (_parse_df(proc.stdout) if proc.returncode == 0
                            else {"status": "unavailable",
                                  "reason": "df failed: %s" % (proc.stderr or "").strip()})

    proc = run_adb(["shell", "pm", "list", "packages", "-3"], timeout, device=device)
    if proc.returncode == 0:
        report["packages"] = _parse_packages(proc.stdout)
    else:
        report["packages"] = []
        report.setdefault("notes", []).append(
            "pm list packages failed: %s" % (proc.stderr or "").strip())
    report["package_count"] = len(report["packages"])

    # Per-package cache sizes, where adb exposes them (dumpsys diskstats).
    proc = run_adb(["shell", "dumpsys", "diskstats"], timeout, device=device)
    sizes = _parse_diskstats(proc.stdout) if proc.returncode == 0 else {}
    report["cache_sizes_kb"] = {pkg: v.get("cache_kb")
                                for pkg, v in sizes.items()
                                if v.get("cache_kb") is not None}
    if not sizes:
        report.setdefault("notes", []).append(
            "per-package cache sizes unavailable (dumpsys diskstats gave nothing usable)")
    storage = [{
        "package": pkg,
        "cache_kb": v.get("cache_kb", 0),
        "data_kb": v.get("data_kb", 0),
        "total_kb": round(v.get("cache_kb", 0) + v.get("data_kb", 0), 1),
    } for pkg, v in sizes.items()]
    storage.sort(key=lambda h: h["total_kb"], reverse=True)
    report["storage_hogs"] = storage[:10]

    # Battery hogs: measured estimate from batterystats when it parses,
    # else top processes by memory as a clearly-labelled proxy.
    uid_map = {}
    proc = run_adb(["shell", "pm", "list", "packages", "-U"], timeout, device=device)
    if proc.returncode == 0:
        uid_map = _parse_uid_map(proc.stdout)
    battery_hogs = []
    source = "unavailable"
    try:
        proc = run_adb(["shell", "dumpsys", "batterystats"], timeout, device=device)
        if proc.returncode == 0:
            battery_hogs = _parse_batterystats(proc.stdout, uid_map)
            if battery_hogs:
                source = "batterystats (estimated power use)"
    except AdbError:
        proc = None
    if not battery_hogs:
        proc = run_adb(["shell", "ps", "-A", "-o", "PID,NAME,RSS"], timeout, device=device)
        if proc.returncode == 0:
            battery_hogs = _parse_ps(proc.stdout)
            source = ("memory proxy — Android exposes no measured per-app "
                      "power over plain adb here; these are the biggest "
                      "processes by memory, not measured battery drain")
    report["battery_hogs"] = battery_hogs
    report["battery_hogs_source"] = source
    return report


def print_list_text(report):
    dev = report["device"]
    print("KUROdoctor ADB — list (read-only, nothing changed)")
    print("Device: %s %s (serial %s, Android %s, SDK %s)" % (
        dev.get("manufacturer", "?"), dev.get("model", "?"), dev.get("serial", "?"),
        dev.get("android_version", "?"), dev.get("sdk", "?")))
    print("")
    batt = report.get("battery", {})
    if batt.get("status") == "ok":
        line = "Battery: %s%%" % batt["level_pct"]
        if "charging_state" in batt:
            line += ", %s" % batt["charging_state"]
        if "temperature_c" in batt:
            line += ", %.1f C" % batt["temperature_c"]
        if "health" in batt:
            line += ", health %s" % batt["health"]
        print(line)
    else:
        print("Battery: unavailable — %s" % batt.get("reason", "?"))
    print("")
    disk = report.get("disk_space", {})
    if disk.get("status") == "ok":
        print("Storage:")
        for m in disk["mounts"]:
            print("  %s: %.2f GB total, %.2f GB used, %.2f GB free (%.1f%% used)" % (
                m["mount"], m["total_gb"], m["used_gb"], m["free_gb"], m["use_pct"]))
    else:
        print("Storage: unavailable — %s" % disk.get("reason", "?"))
    print("")
    print("Installed user packages (%d):" % report.get("package_count", 0))
    for pkg in report.get("packages", []):
        print("  %s" % pkg)
    print("")
    caches = report.get("cache_sizes_kb", {})
    if caches:
        print("Per-package cache sizes (from dumpsys diskstats):")
        for pkg, kb in sorted(caches.items(), key=lambda kv: kv[1], reverse=True)[:20]:
            print("  %s: %.1f KB cache" % (pkg, kb))
    else:
        print("Per-package cache sizes: unavailable on this device via adb.")
    print("")
    hogs = report.get("storage_hogs", [])
    if hogs:
        print("Storage hogs (biggest cache + data):")
        for h in hogs:
            print("  %s: %.1f KB total (cache %.1f KB, data %.1f KB)" % (
                h["package"], h["total_kb"], h["cache_kb"], h["data_kb"]))
    print("")
    print("Battery hogs (%s):" % report.get("battery_hogs_source", "?"))
    for h in report.get("battery_hogs", []):
        if "estimated_mah" in h:
            print("  %s: %.1f mAh estimated" % (h["package"], h["estimated_mah"]))
        else:
            print("  %s: %d KB RSS" % (h["process"], h["rss_kb"]))
    for note in report.get("notes", []):
        print("Note: %s" % note)


# ---------------------------------------------------------------------------
# Actions (whitelist only)
# ---------------------------------------------------------------------------

ACTION_SUMMARIES = {
    "clear": ("This will delete ALL saved data and cache for '%s' on device "
              "%s — app settings, logins and files stored inside the app. "
              "The app itself stays installed."),
    "disable": ("This will DISABLE '%s' for user 0 on device %s. The app "
                "will stop running and disappear from the launcher. It "
                "stays installed and can be re-enabled later."),
    "uninstall": ("This will UNINSTALL '%s' for user 0 on device %s, "
                  "keeping its data (-k). The app will be gone for user 0; "
                  "its saved data is kept. This is NOT a system removal."),
}


def build_action_command(action, pkg, device):
    """Return the exact adb argument list for a whitelisted action."""
    if action == "clear":
        shell = ["pm", "clear", pkg]
    elif action == "disable":
        shell = ["pm", "disable-user", "--user", "0", pkg]
    elif action == "uninstall":
        shell = ["pm", "uninstall", "-k", "--user", "0", pkg]
    else:  # argparse choices= guard; unreachable in practice
        raise UsageError("unknown action %r" % action)
    cmd = ["adb"]
    if device:
        cmd += ["-s", device]
    cmd += ["shell"] + shell
    return cmd


def do_action(action, pkg, device, timeout, go, dry_run):
    """Run (or preview) one whitelisted action. Returns exit code 0."""
    cmd = build_action_command(action, pkg, device)
    print(ACTION_SUMMARIES[action] % (pkg, device))
    if dry_run:
        print("DRY RUN — would run:")
        print("  " + " ".join(cmd))
        print("Nothing was executed.")
        log_action(device, cmd, "dry-run (not executed)")
        return 0
    if not go:
        raise UsageError(
            "refusing to %s %s without --go. Re-run with --go to do it, "
            "or --dry-run to preview the exact command first." % (action, pkg))
    print("Running: %s" % " ".join(cmd))
    # run_adb() builds its own ["adb", "-s", <device>] prefix; pass the
    # shell words after "shell" so the device flag is added exactly once.
    shell_words = cmd[cmd.index("shell") + 1:]
    proc = run_adb(["shell"] + shell_words, timeout, device=device)
    out = (proc.stdout or "").strip()
    err = (proc.stderr or "").strip()
    if proc.returncode != 0:
        result = "failed (exit %d)%s" % (proc.returncode, (" — " + err) if err else "")
        log_action(device, cmd, result)
        raise AdbError("adb failed (exit %d) while running %s: %s" % (
            proc.returncode, " ".join(cmd), err or out or "no output"))
    result = "ok (exit 0)%s" % ((" — " + out) if out else "")
    log_action(device, cmd, result)
    print("Done: %s %s on %s." % (action, pkg, device))
    if out:
        print(out)
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

class _Parser(argparse.ArgumentParser):
    def error(self, message):
        # argparse exits 2 by default; this tool's contract is 1 for usage.
        self.print_usage(sys.stderr)
        print("%s: error: %s" % (self.prog, message), file=sys.stderr)
        raise SystemExit(1)


def build_parser():
    parser = _Parser(
        prog="kurodoctor-adb.py",
        description=(
            "KUROdoctor ADB deep mode — list a phone over USB ADB, and "
            "with an explicit --go, clear / disable / uninstall ONE user "
            "package at a time. List-first, read-only by default. Only "
            "your OWN phone, only with the owner's go. No root, no "
            "flashing, no bootloader unlock, no FRP / password bypass. "
            "adb must already be installed (Android platform-tools); "
            "this tool never downloads or installs adb."))
    parser.add_argument("--version", action="version",
                        version="kurodoctor-adb.py " + VERSION)
    parser.add_argument("--list", action="store_true",
                        help="list mode (default): devices, model/Android "
                             "version, battery, storage, user packages, "
                             "hogs, per-package cache sizes. Makes no changes.")
    parser.add_argument("--device", metavar="SERIAL",
                        help="target one phone when several are attached "
                             "(required for actions when several are attached)")
    parser.add_argument("--package", action="append", metavar="PKG",
                        help="package to act on (one only, e.g. "
                             "com.example.junk). Required with --action.")
    parser.add_argument("--action", choices=ACTIONS,
                        help="whitelisted change: clear, disable, uninstall")
    parser.add_argument("--go", action="store_true",
                        help="required, with --package, to actually run a change")
    parser.add_argument("--dry-run", action="store_true",
                        help="print the exact adb command that WOULD run "
                             "and execute nothing (works with or without --go)")
    parser.add_argument("--i-know-this-is-critical", action="store_true",
                        help="override the blocklist for non-absolute "
                             "entries only. System UI / phone / settings / "
                             "Play Services / launcher / keyboard stay "
                             "blocked always.")
    parser.add_argument("--json", action="store_true",
                        help="print --list output as JSON (same shape as "
                             "the app sweep where it fits: device, battery, "
                             "disk_space, packages)")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT,
                        metavar="S",
                        help="timeout in seconds for every adb call "
                             "(default %d)" % DEFAULT_TIMEOUT)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)

    if args.timeout is None or args.timeout <= 0:
        print("error: --timeout must be a positive number of seconds",
              file=sys.stderr)
        return 1

    # adb must already be installed. --help / --version exit inside
    # parse_args, before this check, so they work without adb.
    try:
        find_adb()
    except AdbError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    try:
        # --go with no named target is always refused.
        if args.go and not args.package and not args.action:
            raise UsageError("--go needs a named target: pass --action and "
                             "--package <pkg> (one package at a time).")
        if args.package and not args.action:
            raise UsageError("--package needs an --action "
                             "(clear, disable or uninstall).")
        if args.action and not args.package:
            raise UsageError("--action %s needs a named --package <pkg>." % args.action)
        if args.package and len(args.package) > 1:
            raise UsageError("one package at a time — got %d: %s. Re-run "
                             "once per package." % (len(args.package),
                                                    ", ".join(args.package)))
        if args.json and args.action:
            raise UsageError("--json only works with --list.")

        # ---- list mode (default; read-only) ----
        if not args.action:
            devices = list_devices(args.timeout)
            if not devices:
                raise AdbError("no Android device connected — plug the phone "
                               "in, turn on USB debugging, and accept the "
                               "prompt on the phone.")
            if args.device:
                if args.device not in [s for (s, _st) in devices]:
                    raise UsageError(
                        "device %s is not attached (adb devices shows: %s)." % (
                            args.device,
                            ", ".join("%s (%s)" % d for d in devices)))
                targets = [args.device]
            else:
                targets = [s for (s, st) in devices if st == "device"] or \
                          [devices[0][0]]
            reports = [collect_list(serial, args.timeout) for serial in targets]
            if args.json:
                if len(reports) == 1:
                    print(json.dumps(reports[0], indent=2))
                else:
                    print(json.dumps({"devices": reports}, indent=2))
            else:
                for i, report in enumerate(reports):
                    if i:
                        print("")
                    print_list_text(report)
            return 0

        # ---- action mode (whitelist only) ----
        pkg = args.package[0]
        check_package(pkg, args.i_know_this_is_critical)
        device = resolve_device(args.device, args.timeout, for_action=True)
        return do_action(args.action, pkg, device, args.timeout,
                         args.go, args.dry_run)

    except UsageError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 1
    except AdbError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
