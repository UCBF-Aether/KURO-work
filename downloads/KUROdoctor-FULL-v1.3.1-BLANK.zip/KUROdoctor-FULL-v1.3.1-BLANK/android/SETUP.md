BLANK PACK NOTE — the KUROdoctor app (`KUROdoctor-1.2.apk`) is NOT in this pack: its relay URL is baked into the compiled app, so it can never be blank. See `ANDROID-APP-NOT-INCLUDED.txt`. The steps in this guide that install or run the app do not apply here. What works in this pack is the ADB host tool (`kurodoctor-adb.py`) and the PC-side repair script (`repair-android.py`) — both touch no relay.

# KUROdoctor v1.3.1 — Android setup guide

For another Muse instance guiding its owner through the Android piece.
Everything here was verified on disk only, except where noted. **v1.1.1
ran on a real phone** (a Samsung S25 Ultra, Android 16, 2026-11-19
— the crash fix is proven live). **v1.2 has never run on a real phone.**
Its first real run is the owner's.

## What is in this folder

| File | What it is | Size | SHA-256 |
| --- | --- | --- | --- |
| `KUROdoctor-1.2.apk` | The app, v1.2 (build 4) — install this one | 168,973 | `571bd5e9455707fbfae8a3c8ba95f3c1fd9aeab99e8581a5af5d5a3e69417859` |
| `SHIZUKU-SETUP.md` | Shizuku one-time setup (install, start via wireless debugging, grant permission) | — | — |
| `kurodoctor-adb.py` | ADB deep-mode host tool, v1.1.0 (828 lines, Python 3, stdlib only) | 34,378 | `d4a06f19f39ada7f3508959b150709d676852b0588c26ce90754d6244174055e` |
| `repair-android.py` | PC-side ADB deep repair, v4.0.0 (1,042 lines, Python 3, stdlib only) | 45,579 | `9cd6bd085543a8b4829f1a40348c99f95628e0285e901ba6b00232e0ccae450d` |

Verified on disk: the APK hash matches the pack record; signature
verified (v2 + v3, one signer, same certificate as v1.1.1);
package is `com.kuro.kurodoctor`, v1.2 is version-code 4 / version-name
"1.2"; the Shizuku provider (`rikka.shizuku.ShizukuProvider`) and the
`moe.shizuku.client.V3_SUPPORT` meta-data are in the built manifest;
both Python tools compile clean. Neither Python tool talks to the relay
at all, so neither needs any relay address configured.

## What to ask the owner for

- **Nothing about a web address for the app.** The relay address the app
  talks to is already baked into the v1.2 build. Just confirm with the
  owner that the relay they already set up is still up — the smoke test
  below proves it.
- For the smoke test only, ask the owner for **their relay base URL**
  (the one their own setup already uses). Paste it in place of
  `<RELAY-BASE-URL>` in the commands below. Do not guess it.
- Their Samsung phone (S25 Ultra) and, for the ADB part, a PC plus a USB
  cable.

## 1. Sideload the APK on the phone

1. Copy `KUROdoctor-1.2.apk` onto the phone (USB, or any file transfer
   the owner already uses).
2. On the phone, tap the APK file to install it.
3. Android will ask to **allow install from unknown sources** for the
   app doing the install (Files, browser, whichever opened the file).
   That is the expected prompt — allow it for that installer app only.
4. Tap **Install**, then **Open**.

How you know it worked: the home screen shows **Run Checkup**,
**View Report**, and **Updates** buttons. Open **Updates** — it must
read `KUROdoctor v1.2 (build 4)`.

No runtime permission pop-ups are expected: the nine install-time
permissions the app declares (internet, network state, Wi-Fi state,
foreground service, foreground-service data-sync, start after reboot,
request app uninstall, full app list, Shizuku API) are all granted at
install time on current Android. If the phone pops up any permission
dialog, screenshot it and report it — that is new information.
**Usage Access is the exception:** it is declared in the manifest but
is only granted when the owner switches it on in Settings (Repair
screen → "Usage Access", section 4 below). No pop-up asks for it.

## 2. Relay smoke test (from any PC with curl)

The app posts its checkup report to the relay the owner already set up
and polls it for commands. Prove the relay is up before the first run:

```sh
curl -s <RELAY-BASE-URL>/doctor/latest
```

Expected answers:

- **Before any checkup has ever run:** HTTP 404 with
  `{"ok": false, "error": "no_report"}` — that means the relay is up
  and simply has nothing stored yet. This is the normal pre-first-run
  answer.
- **After a checkup runs:** HTTP 200 with the stored report JSON
  (hostname, boot id, version, timestamp, `received_at`, and the
  `sweep` with the eight sections).

If curl fails to connect at all, stop: the relay is down or the URL is
wrong. Fix that first — the app will queue its report on the phone and
say "Relay not reachable yet", which is safe but means nothing arrives
until the relay is back.

## 3. First run on the phone

1. Tap **Run Checkup**. The status line reads "Running checkup…".
2. Wait for the result: the 8 app-level sections (smart, disk space,
   startup items, processes, temperatures, pending updates, boot time,
   malware scan) plus a 9th `deep` section when Shizuku is connected
   (full process list, every package, thermals, CPU, storage). Each
   section says `ok` or `unavailable` with a reason. Without Shizuku
   the `deep` section says `unavailable` and the 8 app-level sections
   are the report — that is the v1.1.1 fallback, working as designed.
3. **Expected, not a failure:** the malware-scan section says no
   on-device scanner ran — v1 bundles no scanner. A section that cannot
   run says `unavailable` and never blocks the others.
4. Success looks like: "Checkup done. Report delivered to the relay."
   If the relay was down it says "Relay not reachable yet — report
   queued on this phone and will retry." Re-run the smoke test in step 2
   to tell which one it should be.
5. Tap **Check for updates** on the Updates screen. With the relay up
   it says "You are on KUROdoctor v1.2, the current version. No update
   channel is configured yet — the relay is reachable, but there is no
   newer build to download." With no connection it says "Could not reach
   the relay to check."

## 4. Repair screen (after a checkup)

The Repair screen stays locked until a checkup has run — before that it
says "Repairs are locked until a checkup has run." After a checkup it
unlocks and offers: clear KUROdoctor's **own** cache only, biggest-apps
list (top 10 — **true totals** by app + data + cache when Usage Access
is on, APK size otherwise — each opening its system Settings page),
guided uninstall, suspicious-app flagging (**list-only** — it never
removes a flagged app), and a repair log. The relay can only read the
repair log and the repair list — no relay command can perform a repair.

### 4a. Usage Access (true app sizes)

On the Repair screen the status line says whether Usage Access is on.
If it is off, tap **"Usage Access (true app sizes)"** — Android opens
its Usage Access page; find KUROdoctor and switch it on. That is the
only thing that changes: KUROdoctor can then read per-app storage
totals. It still cannot read any app's files. Come back and the status
line says "Usage Access: on", and biggest-apps ranks by true totals.

### 4b. Shizuku (deep sweep + shell repairs)

Full one-time setup is in **`SHIZUKU-SETUP.md`**: install the Shizuku
app, start it via wireless debugging (no PC), grant KUROdoctor
permission from the Repair screen ("Shizuku status & permission").
When the status line says "connected, permission granted", the Repair
screen offers: a live **deep sweep** (full processes, packages,
thermals, CPU), **force-stop**, **disable bloat** (reversible in
Settings), **clear app data** (destructive — wipes logins/settings),
and **trim caches** system-wide. Every Shizuku repair is two taps
(pick the app, confirm in plain language) and is written to the repair
log. Protected packages (KUROdoctor itself, system server, System UI,
Phone, Settings, installer, Play services) are refused always.

## 5. ADB host tools (PC + USB cable, optional deep mode)

Requirements: a PC with **Python 3** and **Android platform-tools**
(`adb` on PATH — the tools never download adb themselves), a USB cable,
and on the phone **Developer options → USB debugging** on. The phone
will ask to authorize the PC the first time — accept it on the phone.

```sh
adb devices            # phone must show as "device", not "unauthorized"
python3 kurodoctor-adb.py --list
python3 repair-android.py --list
```

Both tools are **list-first**: `--list` only reads and changes nothing.
Every change needs `--go` **and** a named `--package` (one target at a
time), and `--dry-run` prints the exact `adb` command that would run
without running it. Allowed changes only:

- `kurodoctor-adb.py`: `--action clear | disable | uninstall`
- `repair-android.py`: `--action clear | disable | uninstall |
  restrict-background | trim-caches` (trim-caches is system-wide, no
  package target; it never deletes user files)

Example (dry run first, real run only with the owner's explicit go):

```sh
python3 kurodoctor-adb.py --dry-run --package com.example.app --action clear
python3 kurodoctor-adb.py --go --package com.example.app --action clear
```

Critical system packages (system UI, phone, settings, launcher,
keyboard, and similar) are blocklisted and can never be touched. Exit
codes: 0 ok, 1 usage error / blocked package, 2 adb missing or failed.
`kurodoctor-adb.py` logs to `kurodoctor-adb.log` next to itself;
`repair-android.py` writes one JSON audit entry per real action or
refusal to `repair-audit.log` next to itself (a dry run writes nothing).

## What is NOT covered here

- **iPhones are excluded.** There is no iOS build and no iPhone path in
  this pack — Android only.
- **No live testing of v1.2 has been done.** v1.1.1 ran on a real phone
  (a Samsung S25 Ultra, 2026-11-19) and its report reached the relay. v1.2
  itself — Usage Access totals, Shizuku deep sweep, Shizuku repairs —
  has only been verified on disk (build + manifest + dex inspection).
  The owner's first v1.2 run is the first real run — see `TEST-PLAN.md`.
