BLANK PACK NOTE — the KUROdoctor app (`KUROdoctor-1.2.apk`) is NOT in this pack: its relay URL is baked into the compiled app, so it can never be blank. See `ANDROID-APP-NOT-INCLUDED.txt`. The steps in this guide that install or run the app do not apply here. What works in this pack is the ADB host tool (`kurodoctor-adb.py`) and the PC-side repair script (`repair-android.py`) — both touch no relay.

# KUROdoctor v1.2 — test plan (first run on your phone)

**Read this first: v1.1.1 already ran on your phone and worked — the
crash is fixed and its report reached the relay. v1.2 is the same app
plus full access (see below). v1.2 itself has NEVER run on a real
phone until you run it. Everything so far was checked on a computer
only — the file is the right file and the signature is good, but no
human has ever opened v1.2 on a phone. You are the first real run. If
anything below looks different from what it says here, that is useful
— tell me exactly what you saw.**

## 1. Install it

- Install **`KUROdoctor-1.2.apk`** by tapping the file on your phone.
  It installs right over v1.1.1 — same signature, no need to uninstall
  first. Your checkup history and repair log carry over.
- When Android asks, **allow install from unknown sources** for the app
  doing the install (Files, or your browser — whichever opened the
  file). Allow it for that installer only.
- Tap **Install**, then **Open**.

**Success:** home screen with **Run Checkup**, **View Report**, and
**Updates**. Open **Updates** — it must say `KUROdoctor v1.2 (build 4)`.

## 2. Permissions — what the phone will (and won't) ask

The app declares 10 permissions. In plain words:

1. **Internet access** — reach the relay over the internet.
2. **See network state** — know whether the phone is online.
3. **See Wi-Fi state** — know the Wi-Fi connection state.
4. **Run a service in the foreground** — keep the checkup running while
   it works.
5. **Foreground service, data-sync type** — the Android 14+ permission
   that fixed the v1.1 crash.
6. **Start after reboot** — resume its background watch after a restart.
7. **Ask Android to uninstall an app** — only when you choose the
   guided uninstall yourself.
8. **See all installed apps** — the fix for "it only sees KUROdoctor":
   the app lists now show every app you installed.
9. **Usage Access (per-app storage)** — read how much storage each app
   really uses (app + data + cache). Declared, but NOT granted by
   installing: you switch it on yourself in Settings (step 5 below).
10. **Shizuku API** — talk to the Shizuku manager app, for the deep
    sweep and shell repairs. Only works once Shizuku itself is
    installed and started (step 6 below).

**Honest note:** the first eight and the tenth are granted
automatically when the app installs — Android should **not** pop up
any permission dialog for them. The only prompts to expect are the
unknown-sources one in step 1, and the Usage Access switch in step 5
(which is a Settings page you open yourself, not a pop-up). If any
permission box does pop up, screenshot it and tell me — that would
be new.

## 3. Run a checkup

- Tap **Run Checkup**. It should say "Running checkup…".
- Wait for the result. It checks **8 things**: smart (storage health),
  disk space, startup items, processes, temperatures, pending updates,
  boot time, malware scan — plus a 9th `deep` section if Shizuku is
  connected (step 6). Without Shizuku the `deep` section says
  "unavailable" and the 8 are the report — that is the fallback
  working as designed, not a failure.
- **Success:** "Checkup done. Report delivered to the relay."
- If it says **"Relay not reachable yet — report queued on this phone
  and will retry"**, the app is fine — the relay was down at that
  moment. Tell me and we'll check the relay.

**Two things that look like failures but aren't:**

- **Malware scan says no scanner ran.** Expected — v1 has no scanner
  built in. It says so plainly instead of pretending.
- **A section says "unavailable" with a reason.** Expected when the
  phone can't provide that reading. It never blocks the other sections.
  Just tell me which section and the reason it gives.

## 4. Try Repair (it unlocks after the checkup)

- Before a checkup, the Repair screen says "Repairs are locked until a
  checkup has run." After your checkup it unlocks.
- The status line at the top now shows three things: full app list
  (on), Usage Access (on/off), and Shizuku (see step 6).
- Try **clear own cache** — it clears only KUROdoctor's own cache and
  shows before/after sizes. It touches nothing else.
- Try the **biggest-apps list** (top 10) and the **suspicious-apps
  flag list**. Flagging is **list-only** — it never removes anything,
  it just shows you what to look at.

**Success:** each one shows its result on screen, and the repair log
records what it did.

## 5. Usage Access — true app sizes

- On the Repair screen, tap **"Usage Access (true app sizes)"**.
- Android opens its Usage Access page. Find **KUROdoctor** and
  switch it on. (Nothing else changes — it still cannot read any
  app's files.)
- Come back to the Repair screen: the status line says
  "Usage Access: on".
- Run **biggest-apps** again. This time it ranks by TRUE total
  storage (app + data + cache) and shows both the total and the APK
  size for each app. Before, it ranked by APK size only.

**Success:** the list order changes (a small app with huge data now
ranks above a big app with no data), and each row shows a total.

## 6. Shizuku — deep sweep + shell repairs

One-time setup is in **`SHIZUKU-SETUP.md`**. Short version:

1. Install the **Shizuku** app (Play Store, or GitHub
   RikkaApps/Shizuku → Releases).
2. Open Shizuku, tap **Start** (wireless debugging — no PC). It
   asks for a pairing code; get it from Developer options →
   Wireless debugging → "Pair device with pairing code".
3. In KUROdoctor → Repair → **"Shizuku status & permission"** →
   **"Request Shizuku permission"** → Allow on Shizuku's prompt.
4. The status line says "Shizuku: connected, permission granted".

Then try, in order:

- **Deep sweep** — shows the full process count, the full package
  count, thermals, and CPU. Success: numbers that cover the whole
  phone, not just what an ordinary app can see.
- **Force-stop an app** — pick one, confirm, it stops. It restarts
  when you open it again. Nothing is deleted.
- **Trim caches system-wide** — one tap, shows free space before
  and after.
- **Disable bloat** — pick a preinstalled app, confirm, it is
  hidden (re-enable it in Settings > Apps any time).
- **Clear an app's data** — LAST, and only on an app you do not
  mind resetting: it wipes that app's logins and settings. The
  confirm screen says so in plain words first.

**Success:** each one shows its result and the repair log records
it. If Shizuku is not started, every Shizuku button says so
plainly instead of doing anything — that is the fallback working
as designed.

## What to report back

- A screenshot (or the app's own result text) for each step, especially
  the checkup result.
- Anything that said **"unavailable"** and the reason it gave.
- Anything that looked different from this page, or any pop-up you
  didn't expect.
- On the Updates screen, tap **Check for updates** and tell me what it
  says (it should say you're on v1.2, the current version, with no
  update channel yet — and whether it could reach the relay).
- The Repair screen's status line: what does it say for Usage Access
  and for Shizuku?
- If you did step 6: did Deep sweep show full process/package counts?
  Did force-stop / trim-caches work?
