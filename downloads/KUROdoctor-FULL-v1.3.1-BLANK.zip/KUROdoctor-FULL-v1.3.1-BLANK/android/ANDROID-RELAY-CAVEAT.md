# Android — relay caveat (read this before installing)

The Android app is NOT in this pack. `KUROdoctor-1.2.apk` still points at
the original owner's Cloudflare relay — its relay URL is baked into
the app's source (`Relay.java`), so the APK can never be blank and is
left out here. See `ANDROID-APP-NOT-INCLUDED.txt`. A future build
that reads the relay URL from a setting instead of baking it in will
let the app join the blank pack.

What that means in practice:

- The excluded APK (`KUROdoctor-1.2.apk`, SHA-256 below) would try to talk
  to the original owner's relay, not yours, if installed. That is why
  it is not in this pack.
- The ADB host tool in this folder, `kurodoctor-adb.py`, does NOT
  touch the relay at all (verified: no relay reference anywhere in
  the file). It works over USB/ADB only and needs no config.
- `repair-android.py` is the on-device repair module the host tool
  drives. It also touches no relay.

What was verified about the excluded APK (disk only, no phone run):

- `KUROdoctor-1.2.apk` — SHA-256
  `571bd5e9455707fbfae8a3c8ba95f3c1fd9aeab99e8581a5af5d5a3e69417859`,
  168,973 bytes, package `com.kuro.kurodoctor`, version-code 4,
  version-name "1.2", minSdk 26, targetSdk 34.
- v1.0 (`KUROdoctor.apk`) was dropped from this pack: it has the same missing-permission crash as v1.1 on Android 14+, so it was never a valid fallback.
- Signature verified with `apksigner` (the build machine has the Android SDK):
  v2 + v3 signatures verified, 1 signer, same certificate as v1.1
  (CN KUROdoctor, O KURO, C US, RSA 2048, certificate
  SHA-256 `c1118d08…950d7c`).
- Permissions on v1.2 (10): INTERNET, ACCESS_NETWORK_STATE,
  ACCESS_WIFI_STATE, FOREGROUND_SERVICE, FOREGROUND_SERVICE_DATA_SYNC,
  RECEIVE_BOOT_COMPLETED, REQUEST_DELETE_PACKAGES, QUERY_ALL_PACKAGES,
  PACKAGE_USAGE_STATS (declared; granted only by the owner in Settings),
  moe.shizuku.manager.permission.API_V23. The first eight and the
  Shizuku one are install-time grants.
- v1.1 ran on a real phone for the first time on 2026-11-19 and crashed instantly (missing permission, fixed in v1.1.1). v1.1.1 then ran clean on the same phone (Samsung S25 Ultra, Android 16) and its report reached the relay. v1.2 has NOT run on a real phone yet — see `TEST-PLAN.md`.

## Shizuku — what the shell can and cannot do

v1.2 talks to the Shizuku manager app (vendored API 13.1.5, MIT —
the AAR hashes are recorded in the source tree's `android/libs/README.md` (not shipped in this pack)). The
shell runs as the shell user, never root. It CAN list all processes
and packages, read dumpsys output, force-stop apps, disable bloat,
clear app data, and trim caches — each only on the owner's tap, each
logged. It CANNOT read other apps' private files, change system
files, flash anything, or bypass the lock screen. Protected packages
(KUROdoctor itself, system server, System UI, Phone, Settings,
installer, Play services) are refused always, with no override.
Without Shizuku installed and started, v1.2 behaves exactly like
v1.1.1 — the deep section reports unavailable and the Shizuku
buttons say so instead of doing anything.
