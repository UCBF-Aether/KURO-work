#!/usr/bin/env python3
"""KUROdoctor Android deep repair — PC-side host tool (v4.0).

Drives an Android phone over USB ADB from a host PC. This is the DEEP
repair companion to the KUROdoctor Android app (com.kuro.kurodoctor,
diagnose-only, v1.1) and to the ADB deep-mode lister
(`../android/adb/kurodoctor-adb.py`, v1.1): where the app can only
report, this tool can also do a small whitelist of deep-safe cleanups
— but only on YOUR OWN phone, only with the owner's explicit go, and
only one package at a time.

SAFETY RULES (hard, by design):
  * List-first always. Default / --list only reads. It never changes
    anything on the phone, and it writes nothing to the audit log.
  * Every change needs BOTH --go AND one named --package AND one
    --action — except `trim-caches`, which is a system-wide cache
    trim and has no package target (it still needs --go and --action).
    No --go, no change. No target, no change. One action at a time.
  * --dry-run prints the exact adb command that WOULD run and the
    audit entry that WOULD be written, and executes nothing — it
    works with or without --go.
  * Only five changes are ever allowed (whitelist, nothing else):
      pm clear <pkg>                         — clear cache/data for one package
      pm disable-user --user 0 <pkg>         — disable one package for user 0
      pm uninstall -k --user 0 <pkg>         — uninstall for user 0, keep data
      cmd appops set --uid <pkg>
          RUN_IN_BACKGROUND ignore           — stop one package running in
                                               the background (owner-named
                                               package only; the owner can
                                               re-allow it in Settings)
      pm trim-caches <bytes>                 — ask the system to free cached
                                               data until at least <bytes>
                                               are free; never deletes user
                                               files
    There is no system removal, no flashing, no bootloader unlock, no
    root, no FRP / password / lock-screen bypass of any kind.
  * A blocklist of critical packages can NEVER be disabled, uninstalled,
    cleared or background-restricted. A few non-absolute entries can be
    overridden with --i-know-this-is-critical, but systemui / phone /
    settings / gms / gsf / launcher / keyboard stay blocked ALWAYS,
    override or not. The blocklist is copied verbatim from
    kurodoctor-adb.py — it is not weakened here.
  * adb must ALREADY be installed (Android platform-tools) on this PC.
    This tool NEVER downloads, installs or fetches adb itself.
  * Never run this against another person's phone without that owner's
    explicit go.
  * adb is always run via subprocess with an argument list. Never
    shell=True, never a string-concatenated shell command.

AUDIT (same discipline as repair-linux.py):
  * Every real action and every refusal writes one JSON entry
    (timestamp, repair, target, before, after, result, detail) to
    repair-audit.log next to this script, and prints a small JSON
    result object ({repair, status, before, after, detail}) to stdout.
  * A dry run writes NOTHING to disk — not even the audit log; it
    prints the audit entry it WOULD have written instead.
  * --list writes nothing to the audit log: it is read-only, and it
    must not change the phone. (Logging a list run locally is not
    done either, so a list leaves no trace at all.)

Exit codes: 0 ok, 1 usage error / blocked package, 2 adb missing or
adb command failed.

Requires: Python 3 (stdlib only) + adb on PATH.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

VERSION = "4.0.0"
DEFAULT_TIMEOUT = 30
DEFAULT_TRIM_BYTES = 1024 ** 3  # 1 GiB — pm trim-caches target
AUDIT_LOG = Path(__file__).resolve().parent / "repair-audit.log"
ADB_MISSING_MSG = "adb not found — install Android platform-tools and add it to PATH"

# ---------------------------------------------------------------------------
# Blocklist — copied VERBATIM from ../android/adb/kurodoctor-adb.py (v1.1).
# Do not weaken it here.
# ---------------------------------------------------------------------------

# Exact packages that are never touched without --i-know-this-is-critical.
BLOCKED_PACKAGES = {
    "com.android.systemui",
    "com.android.phone",
    "com.android.settings",
    "com.android.launcher3",
    "com.google.android.gms",
    "com.google.android.gsf",
    "com.android.providers.settings",
    "com.android.providers.media",
    "com.android.inputmethod.latin",
    "com.google.android.inputmethod.latin",
    "com.samsung.android.messaging",
    "com.sec.android.app.launcher",
    "com.android.contacts",
    "com.android.dialer",
    "com.android.mms",
    "com.samsung.android.lool",
}

# Any package under these prefixes is blocked the same way.
BLOCKED_PREFIXES = (
    "com.android.",
    "com.google.android.",
    "com.sec.",
    "com.samsung.android.",
)

# Absolute-never: blocked ALWAYS, even with --i-know-this-is-critical.
# Keys are package names; values are the plain-language reason.
ABSOLUTE_NEVER = {
    "com.android.systemui": "System UI — the phone's screen, status bar and navigation. Removing it bricks the visible phone.",
    "com.android.phone": "Phone — the telephony stack. Removing it kills calls and mobile data.",
    "com.android.settings": "Settings — the phone's settings app. Removing it leaves no way to manage the phone.",
    "com.google.android.gms": "Google Play Services — almost every Google app and many third-party apps depend on it.",
    "com.google.android.gsf": "Google Services Framework — core Google account / push services.",
    "com.android.launcher3": "Launcher — the home screen. Removing it leaves no way to open apps.",
    "com.sec.android.app.launcher": "Launcher (Samsung) — the home screen. Removing it leaves no way to open apps.",
    "com.android.inputmethod.latin": "Keyboard (AOSP) — the on-screen keyboard. Removing it leaves no way to type.",
    "com.google.android.inputmethod.latin": "Keyboard (Gboard) — the on-screen keyboard. Removing it leaves no way to type.",
}

# Package names: lowercase letters, digits, dots, underscores only; must
# contain at least one dot; no leading/trailing dot; no empty segments;
# no shell metacharacters, spaces or slashes (regex enforces all of it).
PACKAGE_RE = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$")

# Allowed --action values and the adb shell words they map to.
ACTIONS = ("clear", "disable", "uninstall", "restrict-background",
           "trim-caches")
# Actions that target one named package (trim-caches is system-wide).
PACKAGE_ACTIONS = ("clear", "disable", "uninstall", "restrict-background")

BATTERY_STATUS = {
    "1": "unknown", "2": "charging", "3": "discharging",
    "4": "not charging", "5": "full",
}
BATTERY_HEALTH = {
    "1": "unknown", "2": "good", "3": "overheat", "4": "dead",
    "5": "over voltage", "6": "unspecified failure", "7": "cold",
}


class UsageError(Exception):
    """Exit 1: bad usage or a blocked package."""


class AdbError(Exception):
    """Exit 2: adb missing, or an adb command failed."""


# ---------------------------------------------------------------------------
# Audit — same JSON shape as repair-linux.py: one JSON object per line
# in repair-audit.log next to this script.
# {timestamp, repair, target, before, after, result, detail}
# result is one of: ok, failed, dry_run, refused.
# ---------------------------------------------------------------------------

def now_iso():
    return datetime.now().astimezone().isoformat()


def write_audit(repair, target, before, after, result, detail, dry_run):
    """Write one audit-log entry. In a dry run, print it instead and
    write nothing to disk -- a dry run changes nothing at all."""
    entry = {
        "timestamp": now_iso(),
        "repair": repair,
        "target": target,
        "before": before,
        "after": after,
        "result": result,
        "detail": detail,
    }
    if dry_run:
        print("[dry run] audit entry that WOULD be written to "
              "repair-audit.log:")
        print(json.dumps(entry, indent=2))
        return entry
    line = json.dumps(entry)
    try:
        with open(AUDIT_LOG, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError as exc:
        print("KUROdoctor: WARNING -- could not write the audit log "
              "({}). The entry was: {}".format(exc, line),
              file=sys.stderr)
    return entry


def result_obj(repair, status, before, after, detail):
    """One JSON result object, printed to stdout by the caller."""
    return {
        "repair": repair,
        "status": status,
        "before": before,
        "after": after,
        "detail": detail,
    }


# ---------------------------------------------------------------------------
# adb plumbing — argument lists only, never shell=True
# ---------------------------------------------------------------------------

def find_adb():
    """Return the adb path, or raise AdbError with the plain message."""
    path = shutil.which("adb")
    if not path:
        raise AdbError(ADB_MISSING_MSG)
    return path


def run_adb(args, timeout, device=None):
    """Run one adb command. Returns CompletedProcess.

    Raises AdbError on timeout or if adb itself cannot start. A non-zero
    adb exit code is returned normally so callers can decide (list-mode
    sections degrade to 'unavailable'; actions treat it as failure).
    """
    cmd = ["adb"]
    if device:
        cmd += ["-s", device]
    cmd += list(args)
    try:
        return subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout)
    except subprocess.TimeoutExpired:
        raise AdbError("adb timed out after %ss: %s" % (timeout, " ".join(cmd)))
    except FileNotFoundError:
        raise AdbError(ADB_MISSING_MSG)
    except OSError as exc:
        raise AdbError("could not run adb: %s" % exc)


def run_adb_strict(args, timeout, device=None):
    """Run one adb command; raise AdbError (with adb's stderr) on failure."""
    proc = run_adb(args, timeout, device=device)
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()
        raise AdbError("adb failed (exit %d): %s%s" % (
            proc.returncode, " ".join(["adb"] + list(args)),
            (" — " + detail) if detail else ""))
    return proc


# ---------------------------------------------------------------------------
# Package validation + blocklist — copied VERBATIM from kurodoctor-adb.py.
# ---------------------------------------------------------------------------

def validate_package(pkg):
    """Raise UsageError unless pkg is a strict, safe package name."""
    if not pkg or not PACKAGE_RE.match(pkg):
        raise UsageError(
            "refusing package %r: package names must be lowercase letters, "
            "digits, dots and underscores, must contain at least one dot, "
            "and must not start with a dot" % (pkg,))
    return pkg


def block_reason(pkg):
    """Return the plain-language reason pkg is blocked, or None."""
    if pkg in ABSOLUTE_NEVER:
        return ABSOLUTE_NEVER[pkg]
    if pkg in BLOCKED_PACKAGES:
        return "critical system package — disabling, uninstalling or clearing it can break the phone."
    for prefix in BLOCKED_PREFIXES:
        if pkg.startswith(prefix):
            return ("under the blocked %s prefix — system / vendor package, "
                    "not a regular user app." % prefix)
    return None


def check_package(pkg, allow_critical):
    """Validate + blocklist-check one package.

    Raises UsageError with a plain message if the package is refused.
    Absolute-never packages are refused even with the override.
    """
    validate_package(pkg)
    if pkg in ABSOLUTE_NEVER:
        raise UsageError(
            "refusing %s: %s This package is blocked always, even with "
            "--i-know-this-is-critical." % (pkg, ABSOLUTE_NEVER[pkg]))
    reason = block_reason(pkg)
    if reason and not allow_critical:
        raise UsageError(
            "refusing %s: %s If you are certain, re-run with "
            "--i-know-this-is-critical." % (pkg, reason))
    if reason and allow_critical:
        print("WARNING: %s is blocklisted (%s) — proceeding only because "
              "--i-know-this-is-critical was passed." % (pkg, reason))
    return pkg


# ---------------------------------------------------------------------------
# Device discovery
# ---------------------------------------------------------------------------

def list_devices(timeout):
    """Return [(serial, state)] from `adb devices` (header line skipped)."""
    proc = run_adb_strict(["devices"], timeout)
    devices = []
    for line in proc.stdout.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) >= 2:
            devices.append((parts[0], parts[1]))
    return devices


def resolve_device(requested, timeout, for_action):
    """Pick the device to use.

    Returns the serial. Raises UsageError (exit 1) if several devices are
    attached and none was named, or the named one is not attached /
    not ready; raises AdbError (exit 2) if none is attached at all.
    """
    devices = list_devices(timeout)
    ready = [s for (s, st) in devices if st == "device"]
    if requested:
        if requested not in [s for (s, _st) in devices]:
            raise UsageError(
                "device %s is not attached (adb devices shows: %s). "
                "Plug the phone in and check USB debugging." % (
                    requested,
                    ", ".join("%s (%s)" % d for d in devices) or "none"))
        if for_action and requested not in ready:
            raise UsageError(
                "device %s is attached but not ready (state: %s). "
                "Check the phone screen for the USB-debugging prompt." % (
                    requested,
                    dict(devices)[requested]))
        return requested
    if not devices:
        raise AdbError("no Android device connected — plug the phone in, "
                       "turn on USB debugging, and accept the prompt on "
                       "the phone.")
    if for_action and len(ready) != 1:
        if len(ready) == 0:
            raise UsageError(
                "no device is ready (adb devices shows: %s). Check the "
                "phone screen for the USB-debugging prompt." % (
                    ", ".join("%s (%s)" % d for d in devices),))
        raise UsageError(
            "several devices are attached (%s) — re-run with "
            "--device <serial> to pick one." % ", ".join(ready))
    if len(devices) > 1 and not for_action:
        # List mode with several phones: caller handles the list itself.
        return None
    return ready[0] if ready else devices[0][0]


# ---------------------------------------------------------------------------
# List-mode parsers (best-effort: a section that cannot run reports
# unavailable and never blocks the rest, like the app's blind sweep).
# Copied from kurodoctor-adb.py so --list behaves identically.
# ---------------------------------------------------------------------------

def _parse_getprop(text):
    props = {}
    for match in re.finditer(r"\[(.+?)\]: \[(.*?)\]", text):
        props[match.group(1)] = match.group(2)
    return props


def _parse_battery(text):
    vals = {}
    for key in ("level", "scale", "status", "health", "temperature",
                "voltage", "plugged"):
        match = re.search(r"(?m)^\s*%s:\s*(\S+)\s*$" % key, text)
        if match:
            vals[key] = match.group(1)
    if "level" not in vals:
        return {"status": "unavailable",
                "reason": "dumpsys battery output did not contain a level"}
    try:
        level = int(vals["level"])
        scale = int(vals.get("scale", "100")) or 100
        pct = round(level * 100.0 / scale, 1)
    except ValueError:
        return {"status": "unavailable",
                "reason": "dumpsys battery level was not a number"}
    out = {"status": "ok", "level_pct": pct}
    if "status" in vals:
        out["charging_state"] = BATTERY_STATUS.get(vals["status"], vals["status"])
    if "health" in vals:
        out["health"] = BATTERY_HEALTH.get(vals["health"], vals["health"])
    if "temperature" in vals:
        try:
            out["temperature_c"] = int(vals["temperature"]) / 10.0
        except ValueError:
            pass
    if "voltage" in vals:
        try:
            out["voltage_mv"] = int(vals["voltage"])
        except ValueError:
            pass
    if "plugged" in vals:
        out["plugged"] = vals["plugged"]
    return out


def _parse_df(text):
    mounts = []
    for line in text.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 6:
            continue
        try:
            total_kb = int(parts[1])
            used_kb = int(parts[2])
            free_kb = int(parts[3])
        except ValueError:
            continue
        if total_kb <= 0:
            continue
        mounts.append({
            "mount": parts[5],
            "total_gb": round(total_kb * 1024 / 1e9, 2),
            "used_gb": round(used_kb * 1024 / 1e9, 2),
            "free_gb": round(free_kb * 1024 / 1e9, 2),
            "use_pct": round(used_kb * 100.0 / total_kb, 1),
        })
    if not mounts:
        return {"status": "unavailable", "reason": "df output had no usable mounts"}
    return {"status": "ok", "mounts": mounts}


def _parse_packages(text):
    pkgs = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("package:"):
            pkgs.append(line[len("package:"):].strip())
    return sorted(set(pkgs))


def _parse_uid_map(text):
    """pm list packages -U -> {uid: [package, ...]}."""
    mapping = {}
    for line in text.splitlines():
        match = re.match(r"\s*package:(\S+)\s+uid:(\d+)", line.strip())
        if match:
            mapping.setdefault(int(match.group(2)), []).append(match.group(1))
    return mapping


_SIZE_MULT = {"B": 1, "KB": 1024, "MB": 1024 ** 2, "GB": 1024 ** 3}


def _parse_diskstats(text):
    """dumpsys diskstats -> {pkg: {"cache_kb": x, "data_kb": y}}.

    Best-effort: output format varies by Android version. Handles both
    the 'Package: <pkg>' block form and single-line 'pkg ... cache: N MB'
    forms. Returns {} when nothing parses.
    """
    sizes = {}
    current = None
    for raw in text.splitlines():
        line = raw.strip()
        match = re.match(r"Package:\s*(\S+)", line)
        if match:
            current = match.group(1)
            sizes.setdefault(current, {})
            continue
        if re.fullmatch(r"[a-z][a-z0-9_.]*", line):
            current = line
            sizes.setdefault(current, {})
            continue
        pkg_here = current
        # Single-line form: "<pkg> ... cache: N MB". The first token must
        # contain a dot, so a continuation line like "code: 12MB data:
        # 45MB cache: 120MB" is never mistaken for a package name.
        single = re.match(r"([a-z][a-z0-9_.]*\.[a-z0-9_.]*)\b.*\bcache\s*[:=]", line)
        if single:
            pkg_here = single.group(1)
            sizes.setdefault(pkg_here, {})
        if pkg_here is None:
            continue
        for field in ("cache", "data"):
            found = re.search(r"%s\s*[:=]\s*([\d.]+)\s*([KMG]?B)" % field, line)
            if found:
                kb = float(found.group(1)) * _SIZE_MULT[found.group(2)] / 1024.0
                sizes[pkg_here][field + "_kb"] = round(kb, 1)
    return {pkg: v for pkg, v in sizes.items() if v}


def _parse_batterystats(text, uid_map):
    """Estimated-power section -> [{"package", "estimated_mah"}] top 10."""
    hogs = []
    in_section = False
    for line in text.splitlines():
        if "Estimated power use" in line:
            in_section = True
            continue
        if not in_section:
            continue
        if line.strip() == "":
            continue
        if not line.startswith((" ", "\t")):
            break  # next top-level section
        match = re.search(r"Uid\s+(\d+):\s+([\d.]+)", line)
        if match:
            uid = int(match.group(1))
            mah = float(match.group(2))
            for pkg in uid_map.get(uid, ["uid:%d" % uid]):
                hogs.append({"package": pkg, "estimated_mah": mah})
    hogs.sort(key=lambda h: h["estimated_mah"], reverse=True)
    return hogs[:10]


def _parse_ps(text):
    """ps -A -o PID,NAME,RSS -> top 10 by RSS (memory proxy for hogs)."""
    rows = []
    for line in text.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 3:
            continue
        try:
            rss_kb = int(parts[2])
        except ValueError:
            continue
        rows.append({"process": parts[1], "rss_kb": rss_kb})
    rows.sort(key=lambda r: r["rss_kb"], reverse=True)
    return rows[:10]


def collect_list(device, timeout):
    """Gather the read-only list-mode report for one device."""
    report = {"device": {"serial": device}}

    proc = run_adb(["shell", "getprop"], timeout, device=device)
    if proc.returncode == 0:
        props = _parse_getprop(proc.stdout)
        report["device"].update({
            "model": props.get("ro.product.model", "unknown"),
            "manufacturer": props.get("ro.product.manufacturer", "unknown"),
            "android_version": props.get("ro.build.version.release", "unknown"),
            "sdk": props.get("ro.build.version.sdk", "unknown"),
        })
    else:
        report["device"].update({"model": "unknown", "manufacturer": "unknown",
                                 "android_version": "unknown", "sdk": "unknown"})
        report.setdefault("notes", []).append("getprop failed: %s" % (proc.stderr or "").strip())

    proc = run_adb(["shell", "dumpsys", "battery"], timeout, device=device)
    report["battery"] = (_parse_battery(proc.stdout) if proc.returncode == 0
                         else {"status": "unavailable",
                               "reason": "dumpsys battery failed: %s" % (proc.stderr or "").strip()})

    proc = run_adb(["shell", "df"], timeout, device=device)
    report["disk_space"] = (_parse_df(proc.stdout) if proc.returncode == 0
                            else {"status": "unavailable",
                                  "reason": "df failed: %s" % (proc.stderr or "").strip()})

    proc = run_adb(["shell", "pm", "list", "packages", "-3"], timeout, device=device)
    if proc.returncode == 0:
        report["packages"] = _parse_packages(proc.stdout)
    else:
        report["packages"] = []
        report.setdefault("notes", []).append(
            "pm list packages failed: %s" % (proc.stderr or "").strip())
    report["package_count"] = len(report["packages"])

    # Per-package cache sizes, where adb exposes them (dumpsys diskstats).
    proc = run_adb(["shell", "dumpsys", "diskstats"], timeout, device=device)
    sizes = _parse_diskstats(proc.stdout) if proc.returncode == 0 else {}
    report["cache_sizes_kb"] = {pkg: v.get("cache_kb")
                                for pkg, v in sizes.items()
                                if v.get("cache_kb") is not None}
    if not sizes:
        report.setdefault("notes", []).append(
            "per-package cache sizes unavailable (dumpsys diskstats gave nothing usable)")
    storage = [{
        "package": pkg,
        "cache_kb": v.get("cache_kb", 0),
        "data_kb": v.get("data_kb", 0),
        "total_kb": round(v.get("cache_kb", 0) + v.get("data_kb", 0), 1),
    } for pkg, v in sizes.items()]
    storage.sort(key=lambda h: h["total_kb"], reverse=True)
    report["storage_hogs"] = storage[:10]

    # Battery hogs: measured estimate from batterystats when it parses,
    # else top processes by memory as a clearly-labelled proxy.
    uid_map = {}
    proc = run_adb(["shell", "pm", "list", "packages", "-U"], timeout, device=device)
    if proc.returncode == 0:
        uid_map = _parse_uid_map(proc.stdout)
    battery_hogs = []
    source = "unavailable"
    try:
        proc = run_adb(["shell", "dumpsys", "batterystats"], timeout, device=device)
        if proc.returncode == 0:
            battery_hogs = _parse_batterystats(proc.stdout, uid_map)
            if battery_hogs:
                source = "batterystats (estimated power use)"
    except AdbError:
        proc = None
    if not battery_hogs:
        proc = run_adb(["shell", "ps", "-A", "-o", "PID,NAME,RSS"], timeout, device=device)
        if proc.returncode == 0:
            battery_hogs = _parse_ps(proc.stdout)
            source = ("memory proxy — Android exposes no measured per-app "
                      "power over plain adb here; these are the biggest "
                      "processes by memory, not measured battery drain")
    report["battery_hogs"] = battery_hogs
    report["battery_hogs_source"] = source
    return report


def print_list_text(report):
    dev = report["device"]
    print("KUROdoctor Android repair — list (read-only, nothing changed)")
    print("Device: %s %s (serial %s, Android %s, SDK %s)" % (
        dev.get("manufacturer", "?"), dev.get("model", "?"), dev.get("serial", "?"),
        dev.get("android_version", "?"), dev.get("sdk", "?")))
    print("")
    batt = report.get("battery", {})
    if batt.get("status") == "ok":
        line = "Battery: %s%%" % batt["level_pct"]
        if "charging_state" in batt:
            line += ", %s" % batt["charging_state"]
        if "temperature_c" in batt:
            line += ", %.1f C" % batt["temperature_c"]
        if "health" in batt:
            line += ", health %s" % batt["health"]
        print(line)
    else:
        print("Battery: unavailable — %s" % batt.get("reason", "?"))
    print("")
    disk = report.get("disk_space", {})
    if disk.get("status") == "ok":
        print("Storage:")
        for m in disk["mounts"]:
            print("  %s: %.2f GB total, %.2f GB used, %.2f GB free (%.1f%% used)" % (
                m["mount"], m["total_gb"], m["used_gb"], m["free_gb"], m["use_pct"]))
    else:
        print("Storage: unavailable — %s" % disk.get("reason", "?"))
    print("")
    print("Installed user packages (%d):" % report.get("package_count", 0))
    for pkg in report.get("packages", []):
        print("  %s" % pkg)
    print("")
    caches = report.get("cache_sizes_kb", {})
    if caches:
        print("Per-package cache sizes (from dumpsys diskstats):")
        for pkg, kb in sorted(caches.items(), key=lambda kv: kv[1], reverse=True)[:20]:
            print("  %s: %.1f KB cache" % (pkg, kb))
    else:
        print("Per-package cache sizes: unavailable on this device via adb.")
    print("")
    hogs = report.get("storage_hogs", [])
    if hogs:
        print("Storage hogs (biggest cache + data):")
        for h in hogs:
            print("  %s: %.1f KB total (cache %.1f KB, data %.1f KB)" % (
                h["package"], h["total_kb"], h["cache_kb"], h["data_kb"]))
    print("")
    print("Battery hogs (%s):" % report.get("battery_hogs_source", "?"))
    for h in report.get("battery_hogs", []):
        if "estimated_mah" in h:
            print("  %s: %.1f mAh estimated" % (h["package"], h["estimated_mah"]))
        else:
            print("  %s: %d KB RSS" % (h["process"], h["rss_kb"]))
    for note in report.get("notes", []):
        print("Note: %s" % note)


# ---------------------------------------------------------------------------
# Actions (whitelist only)
# ---------------------------------------------------------------------------

ACTION_SUMMARIES = {
    "clear": ("This will delete ALL saved data and cache for '%s' on device "
              "%s — app settings, logins and files stored inside the app. "
              "The app itself stays installed."),
    "disable": ("This will DISABLE '%s' for user 0 on device %s. The app "
                "will stop running and disappear from the launcher. It "
                "stays installed and can be re-enabled later."),
    "uninstall": ("This will UNINSTALL '%s' for user 0 on device %s, "
                  "keeping its data (-k). The app will be gone for user 0; "
                  "its saved data is kept. This is NOT a system removal."),
    "restrict-background": ("This will stop '%s' running in the background "
                            "on device %s (RUN_IN_BACKGROUND ignore). The app "
                            "stays installed and still works when you open "
                            "it; it just cannot run on its own in the "
                            "background any more. The owner can re-allow it "
                            "in Settings, on the app's own page."),
    "trim-caches": ("This will ask the system on device %s to free cached "
                    "data until at least %s are free. It only touches "
                    "caches — it never deletes user files, photos, "
                    "documents or app data. How much is actually freed "
                    "depends on how much cache the phone is holding; the "
                    "system decides that at run time."),
}


def _fmt_bytes(n):
    """1_073_741_824 -> '1.00 GiB' (plain, for humans)."""
    for unit in ("bytes", "KiB", "MiB", "GiB", "TiB"):
        if n < 1024 or unit == "TiB":
            return "%s %s" % (round(n, 2) if unit != "bytes" else int(n), unit)
        n /= 1024.0
    return "%s bytes" % n


_TRIM_MULT = {"K": 1024, "M": 1024 ** 2, "G": 1024 ** 3}


def parse_trim_bytes(text):
    """Parse --bytes: plain bytes, or a number with a K/M/G suffix
    (1024-based). Raises UsageError on anything else."""
    if text is None:
        return DEFAULT_TRIM_BYTES
    match = re.fullmatch(r"(\d+)([KMG])?", str(text).strip().upper())
    if not match:
        raise UsageError(
            "--bytes must be a whole number of bytes, optionally with a "
            "K, M or G suffix (e.g. 1073741824, 512M, 1G) — got %r." % (text,))
    value = int(match.group(1))
    if match.group(2):
        value *= _TRIM_MULT[match.group(2)]
    if value <= 0:
        raise UsageError("--bytes must be more than zero.")
    return value


def build_action_command(action, pkg, device, trim_bytes=None):
    """Return the exact adb argument list for a whitelisted action."""
    if action == "clear":
        shell = ["pm", "clear", pkg]
    elif action == "disable":
        shell = ["pm", "disable-user", "--user", "0", pkg]
    elif action == "uninstall":
        shell = ["pm", "uninstall", "-k", "--user", "0", pkg]
    elif action == "restrict-background":
        shell = ["cmd", "appops", "set", "--uid", pkg,
                 "RUN_IN_BACKGROUND", "ignore"]
    elif action == "trim-caches":
        shell = ["pm", "trim-caches", str(trim_bytes)]
    else:  # argparse choices= guard; unreachable in practice
        raise UsageError("unknown action %r" % action)
    cmd = ["adb"]
    if device:
        cmd += ["-s", device]
    cmd += ["shell"] + shell
    return cmd


def _action_before_after(action, pkg, device, trim_bytes):
    """Plain-language before/after strings for the audit entry."""
    if action == "clear":
        return ("package '%s' installed with its saved data and cache on device %s"
                % (pkg, device),
                "package '%s' data and cache cleared on device %s"
                % (pkg, device))
    if action == "disable":
        return ("package '%s' enabled for user 0 on device %s"
                % (pkg, device),
                "package '%s' disabled for user 0 on device %s"
                % (pkg, device))
    if action == "uninstall":
        return ("package '%s' installed for user 0 on device %s"
                % (pkg, device),
                "package '%s' uninstalled for user 0 on device %s "
                "(data kept with -k)" % (pkg, device))
    if action == "restrict-background":
        return ("package '%s' allowed to run in the background on device %s"
                % (pkg, device),
                "package '%s' set to ignore background running "
                "(RUN_IN_BACKGROUND ignore) on device %s" % (pkg, device))
    # trim-caches: system-wide, no package target.
    return ("system cache held as-is on device %s; requested free-space "
            "target %d bytes (%s)" % (device, trim_bytes,
                                      _fmt_bytes(trim_bytes)),
            "system cache trim requested on device %s "
            "(pm trim-caches %d)" % (device, trim_bytes))


def do_action(action, pkg, device, timeout, go, dry_run, trim_bytes):
    """Run (or preview) one whitelisted action. Returns exit code 0.

    Dry-run prints the exact command and the audit entry it WOULD
    write, and executes nothing. A real run writes the audit entry
    and prints a JSON result object.
    """
    repair = "android-" + action
    target = pkg if pkg else "system cache (all packages)"
    cmd = build_action_command(action, pkg, device, trim_bytes)
    before, after = _action_before_after(action, pkg, device, trim_bytes)
    if action == "trim-caches":
        print(ACTION_SUMMARIES[action] % (device, _fmt_bytes(trim_bytes)))
    else:
        print(ACTION_SUMMARIES[action] % (pkg, device))
    if dry_run:
        print("DRY RUN — would run:")
        print("  " + " ".join(cmd))
        if action == "trim-caches":
            print("That asks Android to free cached data until at least %s "
                  "are free. The exact amount freed depends on how much "
                  "cache the phone is holding at the time — the system "
                  "decides it when it runs. No user files are ever deleted "
                  "by this command." % _fmt_bytes(trim_bytes))
        print("Nothing was executed.")
        detail = ("Dry run: would run '%s' on device %s. %s Nothing "
                  "changed." % (" ".join(cmd), device,
                                ACTION_SUMMARIES[action] % (
                                    device, _fmt_bytes(trim_bytes))
                                if action == "trim-caches"
                                else ACTION_SUMMARIES[action] % (pkg, device)))
        write_audit(repair, target, before, "no change (dry run)",
                    "dry_run", detail, dry_run=True)
        res = result_obj(repair, "dry_run", before, "no change (dry run)",
                         detail)
        print(json.dumps(res, indent=2))
        return 0
    if not go:
        raise UsageError(
            "refusing to %s %s without --go. Re-run with --go to do it, "
            "or --dry-run to preview the exact command first." % (
                action, target))
    print("Running: %s" % " ".join(cmd))
    # run_adb() builds its own ["adb", "-s", <device>] prefix; pass the
    # shell words after "shell" so the device flag is added exactly once.
    shell_words = cmd[cmd.index("shell") + 1:]
    proc = run_adb(["shell"] + shell_words, timeout, device=device)
    out = (proc.stdout or "").strip()
    err = (proc.stderr or "").strip()
    if proc.returncode != 0:
        after_fail = "no change — adb failed (exit %d)%s" % (
            proc.returncode, (" — " + err) if err else "")
        detail = ("'%s' failed on device %s (adb exit %d): %s Nothing was "
                  "changed by this tool beyond what adb itself may have "
                  "done before failing." % (
                      " ".join(cmd), device, proc.returncode,
                      err or out or "no output"))
        write_audit(repair, target, before, after_fail, "failed", detail,
                    dry_run=False)
        res = result_obj(repair, "failed", before, after_fail, detail)
        print(json.dumps(res, indent=2))
        raise AdbError("adb failed (exit %d) while running %s: %s" % (
            proc.returncode, " ".join(cmd), err or out or "no output"))
    after_ok = after + ((" — adb said: " + out) if out else "")
    detail = ("Ran '%s' on device %s. %s" % (
        " ".join(cmd), device, after_ok))
    if action == "restrict-background":
        detail += (" The owner can re-allow background running for this app "
                   "in Settings, on the app's own page.")
    write_audit(repair, target, before, after_ok, "ok", detail,
                dry_run=False)
    res = result_obj(repair, "ok", before, after_ok, detail)
    print(json.dumps(res, indent=2))
    print("Done: %s %s on %s." % (action, target, device))
    if out:
        print(out)
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

class _Parser(argparse.ArgumentParser):
    def error(self, message):
        # argparse exits 2 by default; this tool's contract is 1 for usage.
        self.print_usage(sys.stderr)
        print("%s: error: %s" % (self.prog, message), file=sys.stderr)
        raise SystemExit(1)


def build_parser():
    parser = _Parser(
        prog="repair-android.py",
        description=(
            "KUROdoctor Android deep repair — list a phone over USB ADB, "
            "and with an explicit --go, clear / disable / uninstall / "
            "background-restrict ONE user package at a time, or trim the "
            "system cache. List-first, read-only by default. Only your "
            "OWN phone, only with the owner's go. No root, no flashing, "
            "no bootloader unlock, no FRP / password bypass. adb must "
            "already be installed (Android platform-tools); this tool "
            "never downloads or installs adb."))
    parser.add_argument("--version", action="version",
                        version="repair-android.py " + VERSION)
    parser.add_argument("--list", action="store_true",
                        help="list mode (default): devices, model/Android "
                             "version, battery, storage, user packages, "
                             "hogs, per-package cache sizes. Makes no changes "
                             "and writes nothing to the audit log.")
    parser.add_argument("--device", metavar="SERIAL",
                        help="target one phone when several are attached "
                             "(required for actions when several are attached)")
    parser.add_argument("--package", action="append", metavar="PKG",
                        help="package to act on (one only, e.g. "
                             "com.example.junk). Required with --action, "
                             "except trim-caches, which is system-wide.")
    parser.add_argument("--action", choices=ACTIONS,
                        help="whitelisted change: clear, disable, "
                             "uninstall, restrict-background, trim-caches")
    parser.add_argument("--bytes", metavar="N", default=None,
                        help="trim-caches only: free-space target in bytes, "
                             "optionally with a K, M or G suffix "
                             "(default 1G)")
    parser.add_argument("--go", action="store_true",
                        help="required, with --package, to actually run a change")
    parser.add_argument("--dry-run", action="store_true",
                        help="print the exact adb command that WOULD run "
                             "and the audit entry that WOULD be written, "
                             "and execute nothing (works with or without --go)")
    parser.add_argument("--i-know-this-is-critical", action="store_true",
                        help="override the blocklist for non-absolute "
                             "entries only. System UI / phone / settings / "
                             "Play Services / launcher / keyboard stay "
                             "blocked always.")
    parser.add_argument("--json", action="store_true",
                        help="print --list output as JSON (same shape as "
                             "the app sweep where it fits: device, battery, "
                             "disk_space, packages)")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT,
                        metavar="S",
                        help="timeout in seconds for every adb call "
                             "(default %d)" % DEFAULT_TIMEOUT)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)

    if args.timeout is None or args.timeout <= 0:
        print("error: --timeout must be a positive number of seconds",
              file=sys.stderr)
        return 1

    # adb must already be installed. --help / --version exit inside
    # parse_args, before this check, so they work without adb.
    try:
        find_adb()
    except AdbError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    # Repair name / target for the refusal audit entry, if one is needed.
    repair_name = "android-" + args.action if args.action else "android-list"
    target_name = args.package[0] if args.package else "(none)"

    try:
        trim_bytes = parse_trim_bytes(args.bytes)
        if args.bytes is not None and args.action != "trim-caches":
            raise UsageError("--bytes only goes with --action trim-caches.")

        # --go with no named target is always refused (trim-caches is the
        # one system-wide action: it needs --go and --action, no package).
        if args.go and not args.package and not args.action:
            raise UsageError("--go needs a named target: pass --action and "
                             "--package <pkg> (one package at a time), or "
                             "--action trim-caches for a system cache trim.")
        if args.package and not args.action:
            raise UsageError("--package needs an --action "
                             "(clear, disable, uninstall, "
                             "restrict-background or trim-caches).")
        if args.action in PACKAGE_ACTIONS and not args.package:
            raise UsageError("--action %s needs a named --package <pkg>." % args.action)
        if args.package and len(args.package) > 1:
            raise UsageError("one package at a time — got %d: %s. Re-run "
                             "once per package." % (len(args.package),
                                                    ", ".join(args.package)))
        if args.json and args.action:
            raise UsageError("--json only works with --list.")

        # ---- list mode (default; read-only, no audit writes) ----
        if not args.action:
            devices = list_devices(args.timeout)
            if not devices:
                raise AdbError("no Android device connected — plug the phone "
                               "in, turn on USB debugging, and accept the "
                               "prompt on the phone.")
            if args.device:
                if args.device not in [s for (s, _st) in devices]:
                    raise UsageError(
                        "device %s is not attached (adb devices shows: %s)." % (
                            args.device,
                            ", ".join("%s (%s)" % d for d in devices)))
                targets = [args.device]
            else:
                targets = [s for (s, st) in devices if st == "device"] or \
                          [devices[0][0]]
            reports = [collect_list(serial, args.timeout) for serial in targets]
            if args.json:
                if len(reports) == 1:
                    print(json.dumps(reports[0], indent=2))
                else:
                    print(json.dumps({"devices": reports}, indent=2))
            else:
                for i, report in enumerate(reports):
                    if i:
                        print("")
                    print_list_text(report)
            return 0

        # ---- action mode (whitelist only) ----
        pkg = args.package[0] if args.package else None
        if args.action in PACKAGE_ACTIONS:
            check_package(pkg, args.i_know_this_is_critical)
        elif pkg is not None:
            # trim-caches is system-wide: a --package name is not used as
            # a target, so it is only format-checked, never acted on.
            validate_package(pkg)
            print("Note: --action trim-caches trims the whole system cache; "
                  "the named package %s is not a target and nothing is done "
                  "to it." % pkg)
        device = resolve_device(args.device, args.timeout, for_action=True)
        return do_action(args.action, pkg, device, args.timeout,
                         args.go, args.dry_run, trim_bytes)

    except UsageError as exc:
        # Refusals are audited (result "refused") in the same JSON shape
        # as real actions — a refusal is still something the owner
        # should be able to see in the log. Nothing was changed.
        write_audit(repair_name, target_name,
                    "no change -- refused before any action",
                    "no change", "refused", str(exc), dry_run=False)
        print("error: %s" % exc, file=sys.stderr)
        return 1
    except AdbError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
