# KUROdoctor v1.2 — Shizuku one-time setup

Shizuku is how KUROdoctor gets shell-level reach on a phone without
root. It is a separate app (by Rikka) that runs a privileged service;
KUROdoctor talks to that service over a binder. You install it once,
start it once, grant KUROdoctor permission once — and after that the
deep sweep and the Shizuku repairs on the Repair screen just work.

No root, no bootloader unlock, no computer needed after the first
setup. Shizuku runs as the **shell user**, not root: it can list all
processes and packages, read dumpsys output, force-stop apps, disable
bloat, clear app data, and trim caches. It cannot read other apps'
private files, change system files, flash anything, or bypass the
lock screen.

## 1. Install the Shizuku app

Either:

- **Play Store:** search "Shizuku" (by Rikka). Package name is
  `moe.shizuku.privileged.api` — that is the one KUROdoctor looks for.
- **GitHub:** `RikkaApps/Shizuku` → Releases → download the APK and
  install it (allow install from unknown sources for the installer
  app only, same as KUROdoctor itself).

## 2. Start Shizuku (wireless debugging, no PC)

The Shizuku app walks you through this on screen — the steps below
are the shape, and the app's own prompts are the authority if a menu
name differs slightly on your Android version.

1. On the phone: **Settings → About phone → tap "Build number" 7
   times.** That turns on Developer options.
2. **Settings → System → Developer options → Wireless debugging →
   ON.** (On Samsung: Settings → Developer options → Wireless
   debugging.)
3. Open the **Shizuku** app and tap **Start** (it says "Start via
   Wireless Debugging"). It will ask for a pairing code.
4. In **Developer options → Wireless debugging → "Pair device with
   pairing code"**, a 6-digit code appears on the phone — type it
   into Shizuku when it asks. Shizuku starts and shows **Running**.
5. That is the whole setup. No computer was involved.

**After a reboot** Shizuku stops and must be started again: open the
Shizuku app and tap Start. No re-pairing is needed — it remembers.
(Wireless debugging itself also switches off on reboot on some
phones; switch it back on in Developer options first if Shizuku
says it cannot start.)

**If wireless debugging will not work**, Shizuku also offers "Start
via connecting to a computer": a PC with `adb`, one USB cable, and
the command the Shizuku app shows you. Same result, more steps.

## 3. Grant KUROdoctor permission inside Shizuku

1. Open **KUROdoctor → Repair → "Shizuku status & permission"**.
2. Tap **"Request Shizuku permission"**. Shizuku shows its own
   grant dialog.
3. Tap **Allow** (or "Always allow"). That is the only permission
   that matters, and you can take it away any time in the Shizuku
   app under Authorized apps.

## 4. How you know it is working

On the Repair screen, the status line at the top says:

> Shizuku: connected, permission granted (service v…). Deep sweep
> and Shizuku repairs are available.

And:

- **"Deep sweep"** on the Repair screen shows the full process
  count, the full package count, thermals, and CPU.
- The next **Run Checkup** report gains a `deep` section with the
  same readings (visible in View Report → raw JSON).
- **"Biggest apps"** is unchanged by Shizuku — that one needs Usage
  Access instead (a separate button on the Repair screen).

## 5. What each status line means

| Status line | What it means | What to do |
| --- | --- | --- |
| Shizuku: not installed | The manager app is not on the phone | Step 1 above |
| Shizuku: installed but not started | Installed, service not running | Step 2 above |
| Shizuku: connected, but permission not granted | Running, KUROdoctor not allowed yet | Step 3 above |
| Shizuku: connected, permission granted | Ready | Nothing — use Deep sweep / repairs |

## 6. What the shell can and cannot do

**Can (as the shell user):** list every process (`ps -A`) and every
package (`pm list packages`); read `dumpsys thermalservice`,
`dumpsys cpuinfo`, and `df`; `am force-stop` a user app; `pm
disable-user` a non-protected app; `pm clear` a user app's data;
`pm trim-caches` system-wide.

**Cannot:** read another app's private files; write system files;
install or remove system apps; flash or repartition; read or change
passwords, lock-screen settings, or credentials; act on any other
person's device. There is no root here, and nothing in KUROdoctor
asks for it.

**Protected, always:** KUROdoctor itself, the system server
(`android`), System UI, Phone, Settings, the installer, Play
services, and the services framework. Shizuku repairs refuse those
packages no matter what — there is no override.

## 7. Troubleshooting

- **"Shizuku keeps stopping after a reboot"** — normal. Start it
  again from the Shizuku app (step 2, from "Open the Shizuku app").
- **"Wireless debugging is off"** — it switches off on reboot on
  some phones. Switch it back on in Developer options, then Start
  in Shizuku.
- **"Permission not granted" after allowing** — open the Shizuku app
  → Authorized apps → find KUROdoctor and check it is allowed.
  Re-tap "Request Shizuku permission" in KUROdoctor.
- **Deep sweep says "timed out"** — one of the `dumpsys` calls was
  slow. It is safe to re-run; each command gets 6 seconds and a
  slow one never blocks the checkup.
- **KUROdoctor was reinstalled** — the Shizuku grant is per install,
  so grant it again (step 3). The Shizuku setup itself (steps 1–2)
  does not need redoing.
