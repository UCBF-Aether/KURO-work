# KUROdoctor FULL — SETUP (all platforms, bring-your-own-Cloudflare)

**Who this is for:** you are a Muse helping your owner set up KUROdoctor.
The owner dropped this pack into you. This file is the map of the whole
pack — the per-platform setup guides do the actual work. **iPhones are
excluded, always** — nothing in this pack is built for iOS, and no iOS
build is planned.

**Versions in this pack:** agents — Windows and Linux v1.3.4 — relay v1.4.0
(token + Authenticator approval) over the v1.3.3 remote-control patch
+ the v1.3.4 live-feed frame room (already live), over the v1 doctor channel, Authenticator app v1.2. See "What changed in v1.3.4" below. Android doctor app v1.2 ships
only in the personal FULL pack — the blank FULL pack carries no Android
doctor APK (see `android/` below).

## What KUROdoctor is

A doctor for the owner's devices. An agent runs on a PC (or the
Android doctor app on a phone), phones home to the owner's own Cloudflare
Worker (the relay), and the owner's Muse sends it commands: checkup,
clean, repair, deep exam, uninstall, install. The agent goes in blind —
it runs a diagnostic sweep first and finds problems on its own. Every fix
is shown first in chat and runs only after the owner says go to that exact
fix. Nothing is ever fixed silently.

## What this pack contains

| Folder / file | What it is |
|---|---|
| `windows/` | Windows agent v1.3.4 + screen file + launcher + repair module + relay deploy files (v1.4.0). **Deploy the relay from here.** Its `SETUP.md` is the Windows setup guide. |
| `linux/` | Linux / SteamOS (Steam Deck) agent v1.3.4 (Python 3, stdlib only) + launcher + repair module + Deck TEST-PLAN.md. Its `SETUP.md` is the Linux setup guide. |
| `android/` | NO doctor APK in this blank pack — see `ANDROID-APP-NOT-INCLUDED.txt` (the v1.2 APK has its relay URL baked in, so it ships only in the personal FULL pack). Included instead: ADB host tool + repair module (both relay-free) + phone TEST-PLAN.md + Shizuku setup guide. Its `SETUP.md` is the Android setup guide — a different app with its own setup; read `ANDROID-RELAY-CAVEAT.md` first. |
| `authenticator/` | Authenticator app v1.2 SOURCE + build script (`build_authenticator.sh`). The ready-to-install `KUROdoctor-Authenticator-1.2.apk` is also included at the root of this pack — install it first, pair it per Step 2 of any platform `SETUP.md`. The relay URL is entered at runtime in the app, never baked in. |
| `iso/` | Pointer file only — the rescue ISO is NOT in this pack (see below). |
| `docs/` | `remote-control.md` — the shared command contract for all platforms. |
| `KUROdoctor-Authenticator-1.2.apk` | The Authenticator app, ready to install (root of this pack). |

**Start here:** pick the platform the owner is setting up first and read
that folder's `SETUP.md` — it is the complete guide, written so another
Muse can walk its owner through setup with no prior context:

- Windows → `windows/SETUP.md`
- Linux / Steam Deck → `linux/SETUP.md`
- Android doctor app → `android/SETUP.md` (own setup, kept separate)

Every platform folder is self-contained: its own agent, its own
`relay-config.json`, its own `SETUP.md`. Do not start from this file —
it is the map, not the guide.

## The relay: deploy once, share the URL

All agents speak the same relay contract (queue, receipt, never-400 ack,
uninstall, install, owner override, adaptive polling). Deploy the relay
**once**, from `windows/relay/` — that folder holds the base worker, the
three patch files, the uploader, the secret/KV helpers, and the deploy
script (`deploy-remote-endpoints-v1.4.0-blank.sh`). Follow
`windows/SETUP.md` Step 1 for the deploy, then paste the same worker URL
into each platform's `relay-config.json` (`linux/`,
`windows/agent/`). Agent and relay must move together: a v1.3.0-or-older
agent against a v1.3.3 relay runs only the first queued command (it never
sends the receipt that pops the queue).

**v1.4.0 authentication — two factors, both checked on
`POST /doctor/command` only.** (1) The Muse-held write token: every
command post must carry header `X-Doctor-Token` matching the worker
secret `DOCTOR_TOKEN` (`401 bad_token` without it). The token lives only
with the owner's Muse. (2) The Authenticator app approval: the owner
pairs the app (Step 2 of any platform `SETUP.md`) and taps Approve for a
session (`423 locked` without it; an unlock lasts 8 hours). If no device
is paired at all, the relay runs token-only (safety valve) so a fresh
setup is never bricked before pairing. The deploy script generates the
token, stores it as a worker secret, and prints it once for the owner's
Muse to keep, and generates the one-time pairing code (12 hex chars,
stored in KV, printed once). No agent needs the token.

**Safety facts:** treat the worker URL as sensitive until the deploy
finishes. The URL alone cannot post a command once v1.4.0 is live, but
the agent poll and the report read are unauthenticated by design. The
token + the app tap are what make the relay safe. Never re-send a Durable
Object migration for an already-registered class on redeploys (HTTP 400
code 10074); the blank deploy sends no migrations. Re-enable the
workers.dev subdomain after a deploy if the URL answers 404.

## What changed in v1.4.0 (relay only — no agent changes)

- **Muse-held write token:** `POST /doctor/command` requires header
  `X-Doctor-Token` matching the worker secret `DOCTOR_TOKEN`
  (missing/wrong/unconfigured → `401 bad_token`). The deploy script
  generates the token, stores it as a worker secret, and prints it
  once for the owner's Muse to keep. No agent needs the token.
- **Authenticator app approval:** `POST /doctor/session/request`
  (token required) creates a pending approval; the paired app polls
  `GET /doctor/session/pending` and the owner taps Approve (relay
  sets an 8-hour unlock) or Deny. `POST /doctor/session/decision`
  needs the device key the relay issued at pairing
  (`POST /doctor/session/pair` with the one-time pairing code).
  Rate limit: 3 session requests per hour. The only unlock path is
  the app tap — no codes, no SMS, no email.
- **Safety valve:** with no device paired at all, commands need
  only the token. Once a device is paired, both factors are
  required.
- **Everything else unchanged:** queue, receipt, ack hygiene,
  uninstall, install, owner override, blocklist, adaptive polling, and all
  other endpoints (agent poll, report, received, acks) behave
  exactly as v1.3.2.

## What changed in v1.3.4 (all agents — relay patch deployed and live)

- **Type focuses its window first (all agents):** the `type` command
  now accepts an optional `process` field (for example `"notepad++"`).
  When it is given, the agent focuses that program's window before
  typing, so typed text lands in the right window instead of wherever
  focus happened to be.
- **Live-feed frame sender (all agents):** the agent now sends
  change-only screen frames to the relay — at most 1 frame per 5
  seconds, and only when the screen actually changed. Frames go to a
  new relay room (`DoctorFrameRoom`, a SQLite-backed Durable Object:
  free-tier, in-memory only, zero KV writes), readable at
  `GET /doctor/frame`.
- **The live feed is LIVE now.** The relay is already v1.4.0 auth +
  v1.3.3 patch + v1.3.4 frame room — deployed 2026-11-20 and proven
  end to end on Windows (frames flowing from the HP). No deploy is
  pending for the personal pack; a fresh blank-pack deploy ships the
  frame room in the same single deploy.
- **One live feed at a time:** run only one agent's feed at a time.
  Three agents feeding at once would exceed the Cloudflare free tier.
- **Honest limits:** the Linux v1.3.4 agent is
  code-verified only — it has not run on real hardware. The Deck
  screenshot chain is unproven on a real Deck, Wayland included, and
  `xdotool` is X11-only.

## What changed in v1.3.2 (agents + relay)

- **`install` command:** mirrors `uninstall` — same validation,
  prechecks (tool present, already-installed short-circuit), audit-log
  before running, async started + completion acks, verify-after-install,
  never trusts exit codes. Kinds: Windows `winget`/`MSI`/`EXE` (MSI/EXE
  take a validated path/URL; optional args for EXE; EXE with no name is
  honestly unverifiable and reports failed even on installer exit 0);
  Linux `brew`/`flatpak`/`pacman` (no apt).
- **Windows steam registry fix:** a steam uninstall now removes the
  Programs-and-Features registry key from both roots (including
  Wow6432Node), reads both back, and the final ok requires folder +
  appmanifest + registry ALL gone. MSI/AppX untouched.
- **Windows install — fixed in v1.3.3:** the relay's install
  allow-list now includes `winget` and `exe`, and the relay carries
  `path`/`url`/`args` through to the agent, so Windows installs of
  kinds `winget`/`msi`/`exe` work end to end. `steam`/`appx` install is
  not supported by the Windows agent (its install kinds are
  `winget`/`msi`/`exe` only). Install works end to end today for
  Windows and Linux. See any platform `SETUP.md` for the
  full note.

## What changed in v1.3.1 (all platforms)

- **Command queue:** the relay holds a FIFO queue (max 10, 400
  `queue_full`) instead of one overwritable slot. The agent posts
  `/doctor/received` immediately after seeing a command, before
  executing it. If the receipt fails, the agent does NOT execute
  that cycle — it retries on the next poll.
- **Ack hygiene:** agents sanitize ack strings to ASCII and cap
  fields; the relay never 400s on ack content (bad JSON is salvaged
  into a minimal `ack_unparseable` ack). A repair result can never
  be silently lost again.
- **Uninstall command:** `steam | msi | appx | app | brew |
  flatpak | pacman`. Every agent checks for running processes first
  and refuses cleanly (`target_running`) instead of failing halfway.
- **Adaptive polling:** 1s while a command is active, 10s when idle,
  heartbeat every ~60s. Idle ≈ 10,000 Cloudflare requests/day, down
  from ~86,000 at a flat 1s poll.
- **Exec blocklist:** `format` / `wipe` now match as whole words, so
  "Information" no longer false-blocks. Desktop `.lnk` deletes need
  an explicit `owner_override` on the exec command — and only for
  `.lnk` files under a Desktop folder.
- **Repair never silently no-ops:** Windows sets the restore-point
  frequency to 0 and accepts a restore point from the last 24h as
  the snapshot.
- **Screenshot:** Windows capture rewritten to raw Win32 GDI BitBlt
  (no `CopyFromScreen`) so Defender no longer flags it as an Empire
  screenshot tool. Same interface (JPEG ≤200 KB in the ack).

## Verification status — read honestly

- **Relay v1.4.0 + v1.3.3 patch + v1.3.4 frame room:** deployed and proven live end to end
  (session request → phone buzz with the app closed → approve → command
  accepted → agent exec; live-feed frames flowing from the HP).
- **Windows v1.3.0** was live-verified on a real HP laptop, and
  **Windows v1.3.4** was proven live there too (live-feed frames
  flowing from the HP, 2026-11-20).
  **Linux v1.3.4 agent is code-verified only** until run on real
  hardware: hashes, py_compile checks, banned-literal grep zero,
  `node --check` on the merged relay, `bash -n` on the scripts.
- **Linux / Steam Deck:** never run on a real Deck. `py_compile` +
  `bash -n` only; no container runtime on the build machine, so no
  container smoke test either. The Deck TEST-PLAN.md is the first
  real run.
- **Android:** the doctor APK is not in this blank pack at all (baked-in
  relay URL — see above). The v1.2 APK ships only in the personal FULL
  pack and has NEVER run on a real phone; v1.1.1 proved live on a real
  phone (first report reached the relay 2026-11-19). The phone
  TEST-PLAN.md is v1.2's first real run.
- **The rescue ISO** stays as-is, QEMU-only, never verified on real
  hardware. It is 310 MB, so this pack carries a pointer file in
  `iso/`, not the ISO itself.

## Two things to flag to the owner

1. **Linux `sudo -n pacman` exception.** The Linux agent never uses
   sudo — except for one documented case: a `pacman` uninstall runs
   `sudo -n pacman` only when BOTH gates pass (root filesystem
   writable AND working passwordless sudo). Both gates refuse by
   default on a stock Steam Deck, where root is read-only. See
   `linux/SETUP.md` Step 3.
2. **Android app's baked-in relay URL.** The Android doctor APK (v1.2) still
   points at its original relay (baked in, shipped as built, not
   rebuilt). Do not use it as your own doctor app until a future build
   makes the URL a setting. See `android/ANDROID-RELAY-CAVEAT.md`. The
   ADB host tool touches no relay and is unaffected. The **Authenticator
   app does NOT have this problem**: its relay URL is entered at runtime
   in the app, never baked in — an APK built from `authenticator/` is
   blank-safe.

## Rules that never change

- Show-first / ok-gate: every fix is proposed in chat first and runs
  only after the owner says go to that exact fix. The app approval
  unlocks the SESSION — it does not approve any single fix.
- **Chat go is the root of trust for sessions:** a session is only
  legitimate if the owner told their Muse in chat first. A surprise
  session means it wasn't us — stop and verify with the owner in chat
  before acting on any approval.
- No reboot, shutdown, wipe, format, or reinstall without the
  owner's explicit ok for that named step.
- No lock-screen / password bypass, no saved-credential digging, no
  other people's machines, no iPhones, ever.
- Never delete user documents or photos.
- Nothing in this pack is priced, published, or sent anywhere.

## Personal pack differences

The personal FULL pack is the same layout, except: the relay is already
deployed and live (do not re-deploy from the pack), the token is already
held by the owner's Muse, the Authenticator app is already installed and
paired, and every platform's `relay-config.json` is already filled in
(verify only — never restate the URL). The personal FULL pack DOES
include the Android doctor v1.2 APK in `android/` (the blank pack does
not). Its `windows/relay/` folder does not carry the v1.4.0 auth deploy
files, so a re-deploy is not covered by the personal pack — the owner's
Muse holds the project files. Each platform's personal `SETUP.md` is
the guide for that pack.
