# KUROdoctor v1.3.2 agent + v1.4.0 relay — Linux / SteamOS (Steam Deck) SETUP

Guide for another Muse instance setting this up for its owner.
Plain steps, exact file names, and how to verify each step worked.
Agent v1.3.2; the relay is v1.4.0 (token + Authenticator
app approval — see below).

## What this is

A doctor agent for a Steam Deck. It runs in Desktop Mode from Konsole,
phones home to the owner's Cloudflare relay, sends a blind diagnostic
sweep first (drive health, disk space, startup items, processes,
temperatures, pending updates, boot time, background malware scan),
then polls for commands from Muse and runs them. It works entirely
from the owner's HOME directory: no system writes, no package installs,
no sudo for its own operation. iPhones are excluded — this agent never
touches one, ever.

## Files in this pack (`linux/`)

| File | What it is |
|---|---|
| `kuro-doctor-agent-linux-1.3.2.py` | The agent (stdlib-only Python 3, version "1.3.2") |
| `repair-linux.py` | The Linux repair module (snapshot-first; the agent calls into it) |
| `kurodoctor-start-1.3.2.sh` | The launcher |
| `relay-config.json` | `{"relay_url": ""}` — blank until the owner fills it in |
| `SETUP.md` | This file |
| `TEST-PLAN.md` | The one-page test plan for the owner on the Deck |

## What to ask the owner for

Ask for these four things before deploying anything. Do not guess them,
do not use another owner's values:

1. **Their Cloudflare worker URL** — the full `https://...` address of
   their doctor relay worker. This goes in `relay-config.json` as
   `relay_url`. There is no fallback URL in the agent; a blank URL
   makes the agent print a plain message and exit cleanly (exit 2).
2. **Worker name** — the name of the worker in their Cloudflare dashboard.
3. **Account ID** — their Cloudflare account ID.
4. **KV namespace ID** — the ID of the KV namespace bound to the worker
   (keys used: `doctor:latest`, `doctor:queue`, `doctor:ack`,
   `doctor:screenshot`).

Also confirm: **is the v1.4.0 relay deployed?** Agent and relay must
move together — a v1.3.0-or-older agent against a v1.3.2 relay runs only
the first queued command (it never sends `/doctor/received`).

**v1.4.0 relay authentication — the two factors.** The relay (deployed
from the Windows blank pack's `relay/` folder, or the FULL blank
pack's `windows/relay/`) needs BOTH before it accepts a command:
(1) the Muse-held write token — every `POST /doctor/command` must
carry header `X-Doctor-Token` matching the worker secret
`DOCTOR_TOKEN`, or the relay answers `401 bad_token`. The token
lives only with the owner's Muse — never in this pack, never shown
to the owner. (2) An unlocked session — the owner approves a session
in the KUROdoctor Authenticator app (included in this pack as
`KUROdoctor-Authenticator-1.1.apk` — install it on the owner's
Android phone first; the pairing guide is in the separate
`KUROdoctor-Authenticator-BLANK.zip`'s `SETUP.md`), or
the relay answers `423 locked`. An unlock lasts 8 hours. If no
authenticator device is paired at all, the relay runs token-only
(safety valve) so a fresh setup is never bricked before pairing.

## Steps

### 1. Fill in the relay URL

Edit `relay-config.json` in the pack and set `relay_url` to the owner's
worker URL. Keep the `_comment` key — JSON has no comments, that key
is the explanation.

Verify: `cat relay-config.json` shows the full `https://...` URL and
valid JSON (`python3 -m json.tool relay-config.json` prints it back).

### 2. Copy the pack to the Deck

On the Deck: switch to **Desktop Mode**, open **Konsole**, and copy the
whole `linux/` folder into the home directory, e.g. `~/kurodoctor/`.
All four files must sit together in the same folder — the agent looks
for `relay-config.json` and `repair-linux.py` next to itself.

### 3. Sudo password — only if the owner wants pacman uninstalls

By default the agent never uses sudo and refuses anything that needs a
system write (the SteamOS root filesystem is read-only). If the owner
wants the `pacman` uninstall path to work, they must first set a sudo
password in Konsole:

```
passwd
```

Do not set it for them and do not assume it exists. Without it, pacman
uninstalls refuse loudly with `sudo_unavailable` — that is the agent
working as designed, not a bug.

### 4. Run the launcher

In Konsole, from the pack folder:

```
cd ~/kurodoctor
chmod +x kurodoctor-start-1.3.2.sh
./kurodoctor-start-1.3.2.sh
```

What the agent should print (stderr log lines):

```
KUROdoctor agent v1.3.2 starting, relay=https://...
steamos=true root_readonly=true home=/home/deck
sending report: model=... steamos=true root_readonly=true disks=[...] smart=...
report delivered
polling https://.../doctor/command -- 1s while active, 10s idle; heartbeat every 60s
```

`report delivered` is the success line. If the relay URL is blank, the
agent instead prints a plain message saying to set it and exits with
code 2 — that is also correct behaviour, just unfinished setup.

### 5. Smoke-test the relay with curl

From any machine (not the Deck), with the worker URL in `$RELAY` and
the Muse-held token in `$DOCTOR_TOKEN` (command posts without the
token header get `401 bad_token`; with a device paired and no
approved session they get `423 locked`):

```bash
# 1. Queue a ping command (expect ok:true, an id, and position 1)
curl -s -X POST "$RELAY/doctor/command" \
  -H 'Content-Type: application/json' \
  -H "X-Doctor-Token: $DOCTOR_TOKEN" \
  -d '{"cmd":"ping"}'
# Expected: {"ok":true,"id":"...","position":1}

# 2. Read the latest report (expect the agent's boot report JSON)
curl -s "$RELAY/doctor/report"
# Expected: JSON with "agent":"kuro-doctor", "version":"1.3.2",
# "sweep" with 8 sections (smart, disk_space, startup_items,
# processes, temps, pending_updates, boot_time, malware_scan)

# 3. Read the latest ack after the agent polls (expect pong)
curl -s "$RELAY/doctor/ack"
# Expected: {"id":"...","done":true,"result":{"pong":true}}
```

If step 1 returns `400 queue_full`, the queue already holds 10
commands — wait for the agent to drain it, don't force more in.
If step 2 returns 404, no report has landed yet — check the agent's
log lines on the Deck.

### 6. Verify the queue/receipt flow once

Queue one `exec` (harmless), then watch the ack:

```bash
curl -s -X POST "$RELAY/doctor/command" \
  -H 'Content-Type: application/json' \
  -H "X-Doctor-Token: $DOCTOR_TOKEN" \
  -d '{"cmd":"exec","command":"uname -a","timeout_s":30}'
```

Expected: a `started` ack first (`done:true, started:true,
status:"running"`), then a completion ack carrying the `uname -a`
output. If only the `started` ack ever appears, the job path is
broken — report it, don't re-queue blindly.

## Steam Deck notes (design truths, not workarounds)

- **Read-only root:** SteamOS mounts `/` read-only. The agent checks
  `/proc/mounts` and refuses anything needing a system write. It never
  runs `steamos-readonly disable` itself.
- **pacman, not apt:** the repair module (`repair-linux.py`) is
  apt-based. On Arch/SteamOS, `system_files` repair reports honestly
  that it cannot install packages and returns a read-only
  `pacman -Qu` listing instead. `startup`, `temp`, and
  `defender_scan` (clamscan quarantine — MOVE, never delete) work the
  same on Arch.
- **Screenshot chain:** grim → scrot → import → xwd, first one
  present wins. Desktop Mode is X11, so scrot/import are the likely
  ones. If none is installed the agent returns
  `screenshot_unavailable` loudly — it never installs anything.
- **Mouse/type:** need `xdotool`. If it is missing the agent returns
  `unavailable` loudly — never installed, never silent.
- **Polling math:** 1s while active, 10s while idle, heartbeat every
  60s. Idle ≈ 8,640 polls + 1,440 heartbeats ≈ 10,000 requests/day
  (vs ~86,000/day at 1s polling nonstop).

## What was NOT verified here

- No run on a real Steam Deck (no device in this build session).
- No live relay call (never call the live relay from the build).
- No screenshot / mouse / type on real hardware.
- No container smoke test — neither docker nor podman exists on the
  build VM. Verification here was disk-only: `py_compile`, `bash -n`,
  banned-literal grep, no-hardcoded-URL grep, baseline hash checks.
