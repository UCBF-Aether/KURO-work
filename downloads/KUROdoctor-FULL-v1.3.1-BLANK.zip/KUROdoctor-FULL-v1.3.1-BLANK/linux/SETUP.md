# KUROdoctor — SETUP (Linux / SteamOS, bring-your-own-Cloudflare)

**Who this is for:** you are a Muse helping your owner set up KUROdoctor
on their Linux PC or Steam Deck. The owner dropped this pack into you —
read this file top to bottom, do one step, verify it, then move on.
Nothing here points at anyone else's Cloudflare: every value below comes
from the owner's own account. Do not guess any value. If a step's output
does not match what this file says it should be, stop and report what you
actually saw.

**Versions in this pack:** Linux agent v1.3.4, relay v1.4.0 (token +
Authenticator approval) over the v1.3.3 remote-control patch + the v1.3.4
live-feed frame room, over the v1 doctor channel, Authenticator app v1.1.

## What KUROdoctor is

A doctor for the owner's machine. An agent runs on it, phones home to the
owner's own Cloudflare Worker (the relay), and the owner's Muse sends it
commands: checkup, clean, repair, deep exam, uninstall, install. The agent
goes in blind — it runs a diagnostic sweep first (drive health, disk space,
startup items, processes, temperatures, pending updates, boot time,
background malware scan) and finds problems on its own. Every fix is shown
first in chat and runs only after the owner says go to that exact fix.
Nothing is ever fixed silently. It works entirely from the owner's HOME
directory: no system writes, no package installs, no sudo for its own
operation. iPhones are excluded — this agent never touches one, ever.

## What this pack contains

| File | What it is |
|---|---|
| `SETUP.md` | This file. Start here. |
| `KUROdoctor-Authenticator-1.1.apk` | The Authenticator app, ready to install on the owner's Android phone. Install it first, then pair it (Step 2). No building needed. |
| `kuro-doctor-agent-linux-1.3.4.py` | The agent (stdlib-only Python 3, version "1.3.4"). |
| `repair-linux.py` | The Linux repair module (snapshot-first; the agent calls into it). |
| `kurodoctor-start-1.3.4.sh` | The launcher. Run it in Desktop Mode from Konsole on a Deck. |
| `relay-config.json` | The relay URL goes here. Ships blank (`{"relay_url": ""}`). |
| `TEST-PLAN.md` | The one-page test plan for the first run on the Deck. |

**This pack has no `relay/` folder.** The relay deploy files live in the
Windows pack's `relay/` folder (or the FULL pack's `windows/relay/`).
Deploy once from there (Step 1), then paste the same worker URL into this
pack's `relay-config.json`.

## What to ask the owner for (ask before you start)

You need four values from the owner's Cloudflare account. Ask for them
one at a time, in this order, and tell the owner where each one lives:

1. **Cloudflare account ID** — dashboard: open dash.cloudflare.com, the
   account ID is the 32-hex-character segment in the URL, or under the
   account menu top-right.
2. **API token** — dashboard: My Profile → API Tokens → Create Token.
   It needs **Workers Scripts:Edit** and **Workers KV Storage:Edit**.
   The owner pastes the token value to you once; never ask them to post
   it anywhere public, and never write it into any file in this pack.
3. **Worker name** — the owner picks one, e.g. `kurodoctor`. Their
   worker URL becomes `https://<name>.<subdomain>.workers.dev`.
4. **KV namespace ID** — dashboard: Workers & Pages → KV → Create a
   namespace (name it anything, e.g. `kurodoctor`). Copy the namespace
   ID it shows after creation.

Do not proceed until you have all four. Do not guess any of them.

## Step 1 — Deploy the relay

**Get the owner's explicit go first.** This replaces the named worker's
script and stores a secret + a KV value on their account. The deploy
script refuses to run without the approval gate (see below).

Deploy from the Windows pack's `relay/` folder (or the FULL pack's
`windows/relay/`) — the files are
`deploy-remote-endpoints-v1.4.0-blank.sh`, `deploy-worker-blank.py`,
`worker-base-blank.js`, `worker-auth-patch-v1.4.0-blank.js`,
`worker-remote-patch-v1.3.3-blank.js`, `worker-doctor-patch-blank.js`,
`set-worker-secret-blank.py`, `kv-put-blank.py`.

**What the script does, in order:**

- **Step 0 — secrets first.** It stores the DOCTOR_TOKEN as a worker
  secret and the pairing code in KV key `doctor:session:pairing`. If
  either PUT fails, the script aborts BEFORE uploading the worker
  (fail closed — never ship a worker whose token is not stored).
- **Steps 1–2 — merge.** It copies `worker-base-blank.js`, then inserts
  the three patches before the base worker's fallback line, in this
  order: **auth (v1.4.0) first, then remote control (v1.3.3), then the
  v1 doctor channel**. Order matters: the auth guard's
  `POST /doctor/command` handler runs first and returns `401`/`423`
  on failure, or falls through to the v1.3.3 handler on success.
- **Step 3 — verify.** It runs `node --check` on the merged file and
  greps that every doctor endpoint, KV key, command, repair function,
  uninstall/install kind, and auth error is present, and that the auth
  patch sits before the v1.3.3 patch. Any missing piece aborts the deploy.
- **Step 4 — deploy.** It uploads the merged worker with
  `deploy-worker-blank.py`, which also enables the workers.dev subdomain
  for the worker. The merged file is written to `relay/build/` (staging
  only).

**Run it** from the `relay/` folder, with the four values as environment
variables and the approval gate as a fifth:

```sh
cd relay
CLOUDFLARE_ACCOUNT_ID=<owner's account id> \
CLOUDFLARE_API_TOKEN=<owner's token> \
KURODOCTOR_WORKER_NAME=<owner's worker name> \
KURODOCTOR_KV_NAMESPACE_ID=<owner's KV namespace id> \
KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1 \
./deploy-remote-endpoints-v1.4.0-blank.sh
```

**Two things the script prints once — handle them exactly as follows:**

- **DOCTOR_TOKEN** — a random 32-byte hex token (64 hex characters).
  Generated by the script unless `DOCTOR_TOKEN` is passed in as an
  environment variable. Stored as a worker secret. **Save it where you
  keep secrets. Never write it into any file in this pack, any doc, or
  any chat the owner might share. The owner never sees or types it.**
  The script also saves it to `relay/.doctor-token` (chmod 600) in your
  copy — never share that file. It is the Muse-held write token: every
  `POST /doctor/command` must carry it as header `X-Doctor-Token`, or
  the relay answers `401 bad_token`. If the token is ever lost, re-run
  the deploy: unless `DOCTOR_TOKEN` is passed in, a fresh token is
  generated and stored, and the old one stops working.
- **Pairing code** — 12 random hex characters, stored in KV key
  `doctor:session:pairing`. **Give it to the owner once** so they can
  pair the Authenticator app (Step 2). It is used once, then thrown
  away. Never write it into any file in this pack.

**Safety facts the deploying Muse must know:**

- Treat the worker URL as sensitive until this deploy finishes. The
  URL alone cannot post a command once v1.4.0 is live (a command post
  needs the token AND an unlocked session — see Step 2), but the agent
  poll (`GET /doctor/command`) and the report read
  (`GET /doctor/latest`) are unauthenticated by design. Never post the
  URL anywhere public.
- The token + the Authenticator tap are what make the relay safe. The
  token proves a command came from the owner's Muse; the tap proves the
  owner approved the session. Neither alone is enough once a device is
  paired.
- **Migration rule:** this blank worker has no Durable Objects, so the
  deploy sends no migrations. If you ever deploy onto an existing
  worker that already has Durable Object classes registered, never
  re-send a migration for an already-registered class — the API answers
  HTTP 400 code 10074. Omit migrations on redeploys; a genuinely new
  Durable Object class needs its own one-time migration.
- **Subdomain:** `deploy-worker-blank.py` enables the workers.dev
  subdomain as part of the deploy. If the worker URL answers 404 after
  a deploy, check the subdomain is enabled for the worker before
  assuming anything else is wrong.

**Verify it worked:** the script prints each step, then `DONE.` and
`Your worker URL is https://<name>.<subdomain>.workers.dev`. Then
smoke-test the relay from any terminal (curl is enough — no agent
needed yet). Replace `<url>` with the worker URL, and use the token
from above as `$DOCTOR_TOKEN` on command posts. Command posts need the
token header; `GET /doctor/command` (the agent poll) does not.

```sh
curl <url>/doctor/latest
curl <url>/doctor/screenshot
curl -X POST <url>/doctor/command -H "X-Doctor-Token: $DOCTOR_TOKEN" -d '{"cmd":"ping"}'
curl -X POST <url>/doctor/command -d '{"cmd":"ping"}'
curl -X POST <url>/doctor/command -H "X-Doctor-Token: $DOCTOR_TOKEN" -d '{"cmd":"bogus"}'
curl -X POST <url>/doctor/command -H "X-Doctor-Token: $DOCTOR_TOKEN" -d '{"cmd":"exec","command":"mimikatz"}'
```

**Success looks like this:**

- `/doctor/latest` → `404` with `no_report` (nothing has reported yet).
- `/doctor/screenshot` → `404` with `no_screenshot`.
- `{"cmd":"ping"}` WITH the token → `200` with `ok:true` and a `position`.
- `{"cmd":"ping"}` WITHOUT the token → `401` with `bad_token`.
- `{"cmd":"bogus"}` with the token → `400` with `unknown_cmd`.
- `{"cmd":"exec","command":"mimikatz"}` with the token → `400` with `blocked`.

If the token-carrying ping returns `ok:true`, the relay is live and the
queue works. A device is not paired yet, so this is the token-only
safety valve (Step 2) — expected at this point. Then clean the test
command out of the queue before the agent starts: `GET <url>/doctor/command`
shows the queued ping; `POST <url>/doctor/received` with its `id` removes it.

If the script stops with `ERROR:` naming a missing variable, set that
variable and run it again. If it stops with
`STOP: ... PENDING THE OWNER'S APPROVAL`, the approval gate is not set —
get the owner's go, then re-run with `KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1`.
Nothing is uploaded until all checks pass.

## Step 2 — The token + pairing the Authenticator app

**The token (recap, so nothing is missed):** created in Step 1, stored
as the worker secret `DOCTOR_TOKEN`, saved by you where you keep secrets
(and in `relay/.doctor-token`, chmod 600, in your copy only). It lives
only with the owner's Muse — never in this pack, never shown to the
owner, never typed by the owner. Every `POST /doctor/command` carries
it as header `X-Doctor-Token`. No agent ever needs the token (agents
only poll and report).

**The Authenticator app v1.1** (`KUROdoctor-Authenticator-1.1.apk`, at
the root of this pack) is the approval half of v1.4.0. One job: receive
a session-approval request and let the owner tap **Approve** or
**Deny**. No location, no SOS, no family features, no Firebase, no
push server — it polls the relay every 5 seconds (outbound only, same
pattern as the doctor agent). The relay URL is entered at RUNTIME in
the app, never baked in — that is what makes the APK safe to ship in
this pack. The app stores only the relay URL the owner typed and the
device key the relay issued at pairing, in its private preferences. It
never holds the DOCTOR_TOKEN, any password, location, or contact. The
pairing code is used once and never stored.

**Pair it:**

1. The owner installs the APK on their Android phone (allow "install
   unknown apps" for the file manager once). On Android 13 and newer
   it asks once to allow notifications — tap **Allow**, or the phone
   cannot buzz when a session is requested with the app closed (the
   app still works while open, it just cannot alert). The only other
   permission it declares is INTERNET, granted at install.
2. You give the owner the **relay URL** (Step 1) and the **pairing
   code** (printed once by the deploy script).
3. The owner opens the app, pastes the relay URL into **Relay URL**
   (the full address, including its scheme) and the pairing code into
   **Pairing code**, and taps **Pair**. The relay returns a device key
   the app stores locally (endpoint `POST /doctor/session/pair`).

**Verify it worked:** the app shows "Paired with your relay" and
`Session: LOCKED`. A small persistent notification ("Watching for
session requests") appears and stays while the app is paired. The
background watch (v1.1) starts right away: a foreground service keeps
polling `GET /doctor/session/pending` every 5 seconds with the app
closed and raises a LOCAL notification (sound + vibration, Approve/Deny
buttons on it) the moment a pending session appears. It restarts after
a phone reboot (only if paired) and stops on unpair or relay change.

**If pairing fails**, the screen says why: "Relay answered 401" means
the pairing code is wrong (ask your Muse for the code again — it was
printed once at deploy; if it was already used, or the deploy was
re-run since, ask for a fresh deploy printout); "Could not reach the
relay" means the URL is wrong or the phone has no connection.

**Changing relay / unpairing:** changing the relay URL clears the
device key and goes back to the pairing screen with the old URL
prefilled — pair again with the new relay's pairing code. Unpairing
removes the relay URL and device key from the phone; the relay keeps
the device key on its side until cleared there, and an unpaired phone
simply stops polling, so it can never approve anything.

**Building from source (only if the owner wants to, not needed for
setup):** the app's source + build script live in the separate
Authenticator blank pack (`build_authenticator.sh`; needs the Android
SDK build-tools 34.0.0 + platform android-34 and JDK 17; output
`delivery/KUROdoctor-Authenticator-1.1.apk`; signing uses a
`debug.keystore` next to the script, generated on first build if
absent, or the path in `$KURODOCTOR_KEYSTORE`).

**Safety valve (so setup can never brick itself):** until the first
device is paired, the relay runs in token-only mode — commands need
only the token. Once a device is paired, commands need BOTH the token
AND an unlocked session. If the owner ever loses the phone, work in
token-only mode is possible only after the pairing is cleared on the
relay side — ask the owner's Muse; do not try to edit the relay by hand.

## Step 3 — Run the agent on the device

**First, point the agent at the relay.** File: `relay-config.json`.
It ships blank:

```json
{"relay_url": ""}
```

Open it and put the worker URL from Step 1 in `relay_url`. Keep the
`_comment` key — JSON has no comments, that key is the explanation.
Verify: `cat relay-config.json` shows the full `https://...` URL and
valid JSON (`python3 -m json.tool relay-config.json` prints it back).
If the agent is ever run with a blank `relay_url`, it prints a plain
message saying to set it and exits with code 2. That message means the
URL is not in the file yet — not that anything is broken.

**Copy the pack to the machine.** On a Steam Deck: switch to **Desktop
Mode**, open **Konsole**, and copy the whole pack folder into the home
directory, e.g. `~/kurodoctor/`. All files must sit together in the same
folder — the agent looks for `relay-config.json` and `repair-linux.py`
next to itself.

**Sudo password — only if the owner wants pacman uninstalls.** By
default the agent never uses sudo and refuses anything that needs a
system write (the SteamOS root filesystem is read-only). If the owner
wants the `pacman` uninstall path to work, they must first set a sudo
password in Konsole (`passwd`). Do not set it for them and do not assume
it exists. Without it, pacman uninstalls refuse loudly with
`sudo_unavailable` — that is the agent working as designed, not a bug.

**Run the launcher.** In Konsole, from the pack folder:

```sh
cd ~/kurodoctor
chmod +x kurodoctor-start-1.3.4.sh
./kurodoctor-start-1.3.4.sh
```

**What a healthy boot looks like** (stderr log lines):

```text
KUROdoctor agent v1.3.4 starting, relay=https://...
steamos=true root_readonly=true home=/home/deck
sending report: model=... steamos=true root_readonly=true disks=[...] smart=...
report delivered
polling https://.../doctor/command -- 1s while active, 10s idle; heartbeat every 60s
```

`report delivered` is the success line. If the relay URL is blank, the
agent instead prints a plain message saying to set it and exits with
code 2 — that is also correct behaviour, just unfinished setup.

**One honest limit:** the Linux agent does NOT queue a report locally
if the relay is unreachable — the report lives only in the agent window,
and closing the window loses it. (The Android doctor app does queue
locally; the Windows/Linux agents do not.)

**Steam Deck notes (design truths, not workarounds):**

- **Read-only root:** SteamOS mounts `/` read-only. The agent checks
  `/proc/mounts` and refuses anything needing a system write. It never
  runs `steamos-readonly disable` itself.
- **pacman, not apt:** the repair module (`repair-linux.py`) is
  apt-based. On Arch/SteamOS, `system_files` repair reports honestly
  that it cannot install packages and returns a read-only `pacman -Qu`
  listing instead. `startup`, `temp`, and `defender_scan` (clamscan
  quarantine — MOVE, never delete) work the same on Arch.
- **Screenshot chain:** grim → scrot → import → xwd, first one
  present wins. Desktop Mode is X11, so scrot/import are the likely
  ones. If none is installed the agent returns `screenshot_unavailable`
  loudly — it never installs anything.
- **Mouse/type:** need `xdotool`. If it is missing the agent returns
  `unavailable` loudly — never installed, never silent.

## Step 4 — First live test

Do this only after the owner has said in chat that you are in a session
(see "Chat go is the root of trust" in the rules below). Never request a
session the owner did not ask for in chat first.

1. **Request a session.** With the token header:
   `POST <url>/doctor/session/request` with body `{}`. Success:
   `{pending:true, session_id:"..."}`. The pending request lives 1 hour.
   Rate limit: 3 session requests per hour — a 4th returns `429`
   (see the failure table).
2. **The phone buzzes.** The Authenticator app raises a notification
   (sound + vibration), even with the app closed, with Approve/Deny
   buttons on it. Tapping the notification opens the app, which shows
   the same request. The owner taps **Approve** or **Deny**.
   Approve unlocks the session for 8 hours. Deny clears the request
   and the session stays locked. The app's status line always shows the
   truth: `Session: LOCKED` or `Session: UNLOCKED`.
3. **Send a ping.** With the token header:
   `POST <url>/doctor/command -d '{"cmd":"ping"}'`. Success:
   `{"ok":true,"id":"...","position":1}`. (Before pairing this worked
   token-only; now that a device is paired, it returns `423 locked`
   until the session is approved.)
4. **Read the ack.** `GET <url>/doctor/ack`. Success:
   `{"id":"...","done":true,"result":{"pong":true}}` — the agent saw
   the ping and answered it. Post one command at a time and wait for
   its ack before posting the next.
5. **Ask for the machine.** With the token header:
   `POST <url>/doctor/command -d '{"cmd":"sysinfo"}'`, then read the
   ack. Success: a report with real values (OS, CPU, RAM, disks), not
   an error. Then the doctor is live. A session unlock lasts 8 hours;
   the next session needs a fresh tap in the app.

**Smoke-test the queue/receipt flow once** (from any machine, token
header on command posts):

```sh
curl -s -X POST "$RELAY/doctor/command" \
  -H 'Content-Type: application/json' \
  -H "X-Doctor-Token: $DOCTOR_TOKEN" \
  -d '{"cmd":"exec","command":"uname -a","timeout_s":30}'
```

Expected: a `started` ack first (`done:true, started:true,
status:"running"`), then a completion ack carrying the `uname -a`
output. If only the `started` ack ever appears, the job path is
broken — report it, don't re-queue blindly. `GET $RELAY/doctor/report`
returns the agent's boot report JSON (`agent: kuro-doctor`,
`version: 1.3.4`, `sweep` with 8 sections: smart, disk_space,
startup_items, processes, temps, pending_updates, boot_time,
malware_scan).

**If a step fails:**

| Symptom | Cause | Fix |
|---|---|---|
| Command post `401 bad_token` | Token missing, wrong, or never stored | Use the token from Step 1; if the secret was never stored, re-run the deploy |
| Command post `423 locked` | No session approved yet (device paired) | Request a session (step 1 above), approve it in the app |
| Session request `429` | Rate limit: 3 session requests/hour used | Wait; a pending request lives 1 hour, an unlock 8 hours — do not hammer requests |
| Command post `400 queue_full` | The relay queue already holds 10 commands | Wait for the agent to drain it; do not force more in |
| Command post `400 unknown_cmd` | Command not in the allow-list | Check the name against the command list in the Windows pack's `docs/remote-control.md` |
| Command post `400 blocked` | Relay blocklist hit a credential-tool word | Reword the command; the blocklist lives on the relay only |
| Command post `400 bad_kind` / `bad_target` | Bad uninstall/install kind or target | See the install section below; kinds and name rules are enforced at the relay |
| `no relay URL is set` (exit 2) | `relay-config.json` still blank | Step 3 — paste the worker URL in |
| No boot report on the relay (`404 no_report`) | Agent not running, wrong URL, or no internet | Agent window still open? URL in `relay-config.json` correct? Connection up? Run the launcher again |
| Agent acks `target_running` on uninstall | The game/app is still running | Close it first, then send the uninstall again |
| Pairing: "Relay answered 401" | Wrong pairing code | Ask your Muse for the code printed once at deploy; a used code needs a fresh deploy printout (note: a fresh deploy also rotates the token unless `DOCTOR_TOKEN` is passed in) |
| Pairing: "Could not reach the relay" | Wrong URL or no connection | Check the URL, check the connection |
| Approve tapped, session still LOCKED | The request expired (1 hour) or was denied | Request a fresh session |
| No buzz on a session request | Notification permission off, or battery optimization killed the watch service | Settings → Apps → KUROdoctor Authenticator → Notifications ON; Battery → Unrestricted; the persistent "Watching" notification disappearing is the tell the service stopped — open the app once while paired to restart it |
| Deploy script `STOP: ... APPROVAL` | Approval gate unset | Owner's go, then `KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1` |
| Deploy script `ERROR: ... is not set` | A Cloudflare value missing | Ask the owner for that value (top of this file) |

## Standing rules — these never change

- **Two factors, both required:** the token proves a command came from
  Muse; the app tap proves the owner approved the session. A post with
  no token gets `401`; a post with a token but a locked session gets
  `423`. Neither factor alone is enough once a device is paired.
- **Show-first / ok-gate:** every fix is proposed in chat first and
  runs only after the owner says go to that exact fix. Never run a
  fix the owner has not ok'd by name. The app approval unlocks the
  SESSION — it does not approve any single fix.
- **Chat go is the root of trust for sessions:** a session is only
  legitimate if the owner told their Muse in chat first. A surprise
  session — a pending or approved session the owner's Muse did not
  request after the owner's chat go — means it wasn't us. Stop and
  verify with the owner in chat before acting on any approval.
- **Never delete user documents or photos.** Desktop shortcut deletes
  (`.lnk` files only, Windows) need the `owner_override` flag on the
  exec command — see the Windows pack's `docs/remote-control.md`.
- **No reboot, shutdown, wipe, format, or reinstall** without the
  owner's explicit ok for that named step.
- **No lock-screen or password bypass, no saved-credential digging,
  no other people's machines, no iPhones, ever.**
- **No remote action without an audit entry.** Every action is written
  to an audit log on the machine — what was run, when, and what came
  back. Never type into a password or login field.
- **Polling:** 1s while a command is active, 10s when idle, heartbeat
  every ~60s. Idle costs about 10,000 Cloudflare requests/day, well
  under the 100,000 free cap.
- **Agent and relay move together:** a v1.3.0-or-older agent against a
  v1.3.3 relay runs only the first queued command and then stalls (it
  never sends the receipt that pops the queue).

## The install command (v1.3.2)

`install` mirrors `uninstall` exactly: same relay validation, same
prechecks (tool present, already-installed short-circuit), audit-log
entry before running, async started + completion acks, verify-after-
install, never trusts exit codes alone. A failed verification reports
`status: failed` even when the installer exited 0. An EXE install with
no name is honestly unverifiable and reports failed even on installer
exit 0.

**Relay validation:** `kind` is required, one of
`steam | msi | appx | app | brew | flatpak | pacman | winget | exe`.
`name` is optional but, when present, must be a string ≤200 chars with no
backslash, no slash, and no `..`. `appid` is optional, an integer,
steam only. `path` / `url` are msi/exe only, never winget; `args` is
exe only. Winget requires a `name`; msi/exe require a `path` or `url`.
Anything else gets `400 bad_kind` / `400 bad_target`. The relay stores
and passes through `path`, `url`, and `args` for msi/exe installs.

**Per platform (agent side):**

- **Linux (this pack):** kinds `brew | flatpak | pacman`, by name. No
  apt. On a Steam Deck the pacman path runs `sudo -n pacman` only when
  BOTH gates pass (root filesystem writable AND working passwordless
  sudo) — both refuse by default on a stock Deck, where root is
  read-only.
- **Windows:** agent kinds are `winget | msi | exe`. Winget installs by
  name (`winget list` precheck + verify); MSI installs an `.msi` file
  (path or URL); EXE runs an `.exe` installer (path or URL, optional
  `args` string, e.g. `/S` — without args the installer runs as-is and
  may show its wizard). EXE has no reliable precheck and skips it.
- **Mac:** kind `brew` only, by name.

**Windows install — fixed in v1.3.3:** Windows install now works end
to end for `winget | msi | exe`. The relay accepts all three kinds
and passes `path`, `url`, and `args` through to the agent (msi/exe
take a `path` or `url`; exe takes optional `args`; winget installs by
name only). `steam` / `appx` install is NOT supported by the Windows
agent — its install kinds are `winget | msi | exe` only, so a
`steam`/`appx` install request passes the relay but is refused by
the agent. Install works end to end today for Windows
(`winget`/`msi`/`exe`), Linux (`brew`/`flatpak`/`pacman` by name), and
Mac (`brew` by name).

**Linux kind asymmetry (kept as designed):** install is
`brew`/`flatpak`/`pacman` while uninstall is `flatpak`/`pacman`/`app`
(brew is install-only, app is uninstall-only).

**The Windows steam registry fix (v1.3.2):** a steam uninstall now
removes the Programs-and-Features registry key from both roots
(including Wow6432Node), reads both back (`verify_registry_gone`), and
the final ok requires folder + appmanifest + registry ALL gone. MSI
and AppX removals are unchanged (they do proper removals). Note: a
steam uninstall now FAILS when the registry entry cannot be removed
(e.g. a non-admin run) even though folder + manifest are gone — steam
uninstalls effectively need admin when a registry entry exists.

## What changed in v1.3.4

- **Type focuses its window first:** the `type` command now accepts an
  optional `process` field (for example `"notepad++"` on Windows, or a
  process name on this machine). When it is given, the agent focuses
  that program's window (via `xdotool`) before typing, so typed text
  lands in the right window instead of wherever focus happened to be.
- **Live-feed frame sender:** the agent now sends change-only screen
  frames to the relay — at most 1 frame per 5 seconds, and only when
  the screen actually changed. Frames go to a new relay room
  (`DoctorFrameRoom`, a SQLite-backed Durable Object: free-tier,
  in-memory only, zero KV writes), readable at `GET /doctor/frame`.
- **The live feed ships in the pack's single deploy.** The deploy
  script in the Windows pack's `relay/` folder already merges the
  v1.3.4 patch + frame room — deploy once (Step 1) and the feed works;
  there is no second v1.3.4 deploy to wait for. The relay is v1.4.0
  auth + v1.3.3 patch + v1.3.4 frame room once that deploy has run,
  and the feed was already proven live end to end on Windows (frames
  flowing from the HP).
- **One live feed at a time:** run only one agent's feed at a time.
  Three agents feeding at once would exceed the Cloudflare free tier.
- **Honest limits:** the Deck screenshot chain (grim → scrot → import
  → xwd) has never been proven on a real Deck, Wayland included — if
  no frames post, report that, don't work around it silently.
  `xdotool` (mouse/type + window focus) is X11-only.

## Honest verification status

- The relay (v1.4.0 auth + v1.3.3 patch + v1.3.4 frame room) and the
  Authenticator loop (request → phone buzz with the app closed →
  approve → command accepted → agent exec) were proven live end to
  end against the Linux agent, and the live feed was proven end to
  end on Windows (frames flowing from the HP). The v1.3.4 Linux agent
  itself has never run on a real Steam Deck — report what you actually
  see at each step, not what should happen.
- The repair module never silently no-ops: the Linux repair is
  snapshot-first (manifest + backup, stops if it cannot be written);
  every repair writes an audit entry + before/after JSON.
- `exec` output is capped at 20 KB, timeout default 60s (clamp 1–300).
  `format` / `wipe` match as whole words in the blocklist, so
  "Information" no longer false-blocks.
- Nothing in this pack is priced, published, or sent anywhere.
