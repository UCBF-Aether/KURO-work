#!/usr/bin/env bash
# KUROdoctor v1.3.4 -- Linux / SteamOS (Steam Deck) launcher.
# Run this in Desktop Mode, from Konsole. It checks python3 and the
# agent file, then runs the agent from the home directory.
# The agent works entirely from $HOME: no system writes, no package
# installs, no sudo. iPhones are excluded -- this agent never touches
# one, ever.
set -u

# Resolve the agent folder FIRST, before changing directory: dirname
# of $0 is relative to where the launcher was started from.
AGENT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT="$AGENT_DIR/kuro-doctor-agent-linux-1.3.4.py"
CONFIG="$AGENT_DIR/relay-config.json"

cd "$HOME" || exit 1

echo "KUROdoctor v1.3.4 (Linux / SteamOS) -- starting..."
echo "Agent folder: $AGENT_DIR"

if ! command -v python3 >/dev/null 2>&1; then
    echo "KUROdoctor: python3 was not found on this machine."
    echo "SteamOS Desktop Mode normally has python3 already. If yours does"
    echo "not, install it first, then run this launcher again."
    echo "Report NOT saved -- it did not reach the relay."
    exit 1
fi

if [ ! -f "$AGENT" ]; then
    echo "KUROdoctor: the agent file was not found:"
    echo "  $AGENT"
    echo "Copy the whole linux folder (agent, repair-linux.py,"
    echo "relay-config.json, this launcher) into your home directory"
    echo "and run the launcher from there."
    echo "Report NOT saved -- it did not reach the relay."
    exit 1
fi

if [ ! -f "$CONFIG" ]; then
    echo "KUROdoctor: relay-config.json was not found next to the agent."
    echo "It must sit in the same folder as the agent file."
    echo "Report NOT saved -- it did not reach the relay."
    exit 1
fi

# The agent itself prints a plain-language message and exits cleanly
# (exit code 2) when relay_url is blank in relay-config.json.
python3 "$AGENT" "$@"
STATUS=$?

if [ $STATUS -eq 2 ]; then
    echo "KUROdoctor stopped: the relay address is not set yet."
    echo "Open relay-config.json, put your Cloudflare worker URL in"
    echo "\"relay_url\", save it, and run this launcher again."
    echo "Report NOT saved -- it did not reach the relay."
elif [ $STATUS -ne 0 ]; then
    echo "KUROdoctor stopped with exit code $STATUS."
    echo "Report NOT saved -- it did not reach the relay."
else
    echo "KUROdoctor stopped cleanly."
fi
exit $STATUS
