#!/usr/bin/env bash
# deploy-remote-endpoints-v1.4.0-blank.sh — deploy the KUROdoctor v1.4.0
# relay authentication onto YOUR OWN Cloudflare Worker.
#
# This is the bring-your-own-Cloudflare deploy. It contains NO hardcoded
# account ID, worker name, subdomain, relay URL, or KV namespace ID —
# every one of those comes from environment variables, and the script
# refuses to run with a clear error naming any missing one:
#   CLOUDFLARE_ACCOUNT_ID       your Cloudflare account ID (32 hex chars)
#   CLOUDFLARE_API_TOKEN        an API token with Workers Scripts:Edit
#                               and Workers KV Storage:Edit
#   KURODOCTOR_WORKER_NAME      the name for your worker, e.g. "kurodoctor"
#   KURODOCTOR_KV_NAMESPACE_ID  the ID of a KV namespace you created
#                               (dashboard: Workers & Pages -> KV)
# The upload itself is done by relay/deploy-worker-blank.py, which
# re-checks the same four variables and also enables the workers.dev
# subdomain for the worker.
#
# v1.4.0 vs v1.3.1: TWO factors, both checked on POST /doctor/command
# only. No agent changes — the agent never posts commands, so it
# needs no token and no update. No codes, no SMS, no email: the ONLY
# session-unlock path is the KUROdoctor Authenticator app tap
# (Approve).
#
#   1. MUSE-HELD WRITE TOKEN (the base lock). POST /doctor/command
#      must carry header X-Doctor-Token matching the worker secret
#      DOCTOR_TOKEN (missing/wrong/unconfigured -> 401 bad_token).
#      The token lives ONLY with your Muse — never on any device,
#      never in any pack. Your Muse never shows it to you and you
#      never type it. This script generates it (or takes it from
#      DOCTOR_TOKEN), stores it as a worker secret, saves it to
#      relay/.doctor-token (chmod 600, in YOUR copy of this pack —
#      never share that file), and prints it ONCE for your Muse to
#      keep. Your Muse needs it for every command post.
#   2. AUTHENTICATOR APP APPROVAL (the owner approval). The
#      Authenticator app on your phone polls the relay; you tap
#      Approve (or Deny). POST /doctor/session/request (token
#      required) creates a pending approval in KV
#      doctor:session:pending. POST /doctor/session/decision
#      (device key required) approves it: the relay sets KV
#      doctor:session:unlocked (8h TTL). POST /doctor/command then
#      needs BOTH a valid token AND an unlocked session (else 423
#      locked).
#      SAFETY VALVE: if no authenticator device is paired at all,
#      POST /doctor/command requires only the token (token-only
#      mode), so a fresh setup is never bricked before pairing.
#      Once a device is paired, both factors are required.
#
# PAIRING: this script generates a pairing code (12 random hex
# characters), stores it in KV key doctor:session:pairing, and prints
# it ONCE for your Muse to give you. You paste the relay URL +
# pairing code into the Authenticator app; the app registers a device
# key with the relay (POST /doctor/session/pair) and stores it
# locally. The pairing code is never stored in any pack or doc —
# only in KV, and printed once here.
#
# Any secret/KV PUT that fails aborts the deploy BEFORE the worker is
# uploaded (fail closed — never ship a worker whose token is not stored).
#
# ██████████████████████████████████████████████████████████████████████
#   PENDING THE OWNER'S APPROVAL — DO NOT RUN THIS SCRIPT YET.
#   It deploys to the LIVE worker named by KURODOCTOR_WORKER_NAME.
#   Running it replaces that worker's script. Get the owner's
#   explicit go first, then set KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1
#   to unlock it.
# ██████████████████████████████████████████████████████████████████████
#
# What it does (all read-only until the final deploy step):
#   0. Stores the DOCTOR_TOKEN worker secret + the pairing code in KV.
#   1. Copies relay/worker-base-blank.js — the minimal base worker
#      (CORS + json() helpers + fallback line, no doctor code, no
#      Durable Objects, no account values).
#   2. Inserts relay/worker-auth-patch-v1.4.0-blank.js BEFORE
#      relay/worker-remote-patch-v1.3.3-blank.js BEFORE
#      relay/worker-doctor-patch-blank.js (v1), all before the final
#      fallback line
#      (`return new Response("kurodoctor blank worker ok", ...)`).
#      ORDER MATTERS: the auth guard's POST /doctor/command handler
#      runs FIRST and returns 401/423 on failure, or falls through
#      to the v1.3.3 handler on success.
#   3. Verifies the merged file: node --check, plus grep checks that
#      every doctor endpoint, KV key, and command is present, that
#      the credential-tool blocklist (all five patterns + 400
#      `blocked`) is present, that the auth routes/keys/errors are
#      present, and that the auth patch sits before the v1.3.3 patch.
#   4. Deploys the merged file via relay/deploy-worker-blank.py
#      (--script <merged file>), which also enables the workers.dev
#      subdomain for the worker. No Durable Object migration is
#      involved — the blank worker has no Durable Objects.
#
# The merged worker is written to ./build/worker-remote-merged-v1.4.0-blank.js
# (staging only — never into any other directory).
set -euo pipefail

if [ "${KURO_DOCTOR_AUTH_DEPLOY_APPROVED:-}" != "1" ]; then
  echo "STOP: deploy-remote-endpoints-v1.4.0-blank.sh is PENDING THE OWNER'S APPROVAL." >&2
  echo "Do not run this until the owner gives an explicit go." >&2
  echo "When approved, run: KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1 ./deploy-remote-endpoints-v1.4.0-blank.sh" >&2
  exit 1
fi

for var in CLOUDFLARE_ACCOUNT_ID CLOUDFLARE_API_TOKEN KURODOCTOR_WORKER_NAME KURODOCTOR_KV_NAMESPACE_ID; do
  if [ -z "${!var:-}" ]; then
    echo "ERROR: environment variable $var is not set." >&2
    echo "Set all four before deploying:" >&2
    echo "  CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_API_TOKEN," >&2
    echo "  KURODOCTOR_WORKER_NAME, KURODOCTOR_KV_NAMESPACE_ID" >&2
    echo "See SETUP.md for where each value comes from." >&2
    exit 1
  fi
done

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MERGED="$SCRIPT_DIR/build/worker-remote-merged-v1.4.0-blank.js"
BASE="$SCRIPT_DIR/worker-base-blank.js"
PATCH_AUTH="$SCRIPT_DIR/worker-auth-patch-v1.4.0-blank.js"
PATCH_V133="$SCRIPT_DIR/worker-remote-patch-v1.3.3-blank.js"
PATCH_V1="$SCRIPT_DIR/worker-doctor-patch-blank.js"
UPLOADER="$SCRIPT_DIR/deploy-worker-blank.py"
SET_SECRET="$SCRIPT_DIR/set-worker-secret-blank.py"
KV_PUT="$SCRIPT_DIR/kv-put-blank.py"
TOKEN_FILE="$SCRIPT_DIR/.doctor-token"
FALLBACK='    return new Response("kurodoctor blank worker ok", { headers: cors });'

mkdir -p "$SCRIPT_DIR/build"

# put_secret NAME — stores one worker secret, reading the value from
# the same-named environment variable (never from argv). Aborts the
# whole deploy if the secret PUT fails.
put_secret() {
  local name="$1"
  python3 "$SET_SECRET" --name "$name" --from-env "$name"
  local rc=$?
  if [ "$rc" -ne 0 ]; then
    echo "ERROR: storing secret $name failed — aborting before any worker upload." >&2
    exit 1
  fi
}

# put_kv KEY ENV_VAR — writes one KV value, reading it from the named
# environment variable. Aborts the whole deploy if the KV PUT fails.
put_kv() {
  local key="$1" envvar="$2"
  python3 "$KV_PUT" --key "$key" --from-env "$envvar"
  local rc=$?
  if [ "$rc" -ne 0 ]; then
    echo "ERROR: writing KV key $key failed — aborting before any worker upload." >&2
    exit 1
  fi
}

echo "== 0. Store worker secret (DOCTOR_TOKEN) + pairing code in KV =="
# --- DOCTOR_TOKEN: env > generate. ---
TOKEN_PRINTED=0
if [ -n "${DOCTOR_TOKEN:-}" ]; then
  echo "   DOCTOR_TOKEN: read from DOCTOR_TOKEN env (not printed)."
else
  DOCTOR_TOKEN="$(openssl rand -hex 32)"
  export DOCTOR_TOKEN
  printf '%s' "$DOCTOR_TOKEN" > "$TOKEN_FILE"
  chmod 600 "$TOKEN_FILE"
  echo "   DOCTOR_TOKEN: generated and saved to $TOKEN_FILE (chmod 600)."
  TOKEN_PRINTED=1
fi
put_secret "DOCTOR_TOKEN"
if [ "$TOKEN_PRINTED" = "1" ]; then
  echo "   *** DOCTOR_TOKEN (print once — save it where your Muse keeps secrets; it is never printed again): $DOCTOR_TOKEN"
fi
unset DOCTOR_TOKEN
# --- Pairing code: env > generate. Stored in KV, printed once. ---
if [ -n "${PAIRING_CODE:-}" ]; then
  echo "   Pairing code: read from PAIRING_CODE env (not printed)."
else
  PAIRING_CODE="$(openssl rand -hex 6)"
  export PAIRING_CODE
  echo "   Pairing code: generated."
fi
put_kv "doctor:session:pairing" "PAIRING_CODE"
echo "   *** PAIRING CODE (print once — give it to the owner for the Authenticator app; it is never printed again): $PAIRING_CODE"
unset PAIRING_CODE

echo "== 1. Copy base worker (read-only source) =="
cp "$BASE" "$MERGED"
echo "   copied $BASE -> $MERGED"

echo "== 2. Insert v1.4.0 auth patch, then v1.3.3, then v1, before the fallback =="
grep -Fq "$FALLBACK" "$MERGED" || {
  echo "ERROR: fallback line not found in worker-base-blank.js — base worker changed, aborting." >&2
  exit 1
}
# Auth first (its POST /doctor/command guard runs before the v1.3.3
# handler and falls through on success), v1.3.3 second, v1 third.
{
  echo "// ---- KUROdoctor v1.4.0: relay auth (merged from worker-auth-patch-v1.4.0-blank.js) ----"
  cat "$PATCH_AUTH"
  echo "// ---- end KUROdoctor v1.4.0 ----"
  echo "// ---- KUROdoctor v1.3.3: remote control (merged from worker-remote-patch-v1.3.3-blank.js) ----"
  cat "$PATCH_V133"
  echo "// ---- end KUROdoctor v1.3.3 ----"
  echo "// ---- KUROdoctor v1: doctor channel (merged from worker-doctor-patch-blank.js) ----"
  cat "$PATCH_V1"
  echo "// ---- end KUROdoctor v1 ----"
} > "$SCRIPT_DIR/build/patch-block-auth-v1.4.0-blank.js"
python3 - "$MERGED" "$SCRIPT_DIR/build/patch-block-auth-v1.4.0-blank.js" <<'PYEOF'
import sys
merged_path, patch_path = sys.argv[1], sys.argv[2]
with open(merged_path) as f:
    merged = f.read()
with open(patch_path) as f:
    patch = f.read()
fallback = '    return new Response("kurodoctor blank worker ok", { headers: cors });'
assert merged.count(fallback) == 1, "fallback line must appear exactly once"
merged = merged.replace(fallback, patch + "\n" + fallback)
with open(merged_path, "w") as f:
    f.write(merged)
print("   patches inserted (v1.4.0 auth before v1.3.3 before v1)")
PYEOF

echo "== 3. Verify merged worker =="
node --check "$MERGED" && echo "   node --check: OK"
# Every doctor endpoint must be present...
for route in '"/doctor/report"' '"/doctor/latest"' '"/doctor/command"' '"/doctor/ack"' '"/doctor/screenshot"' '"/doctor/received"' '"/doctor/session/request"' '"/doctor/session/pair"' '"/doctor/session/pending"' '"/doctor/session/decision"' '"/doctor/session/status"'; do
  grep -Fq "$route" "$MERGED" || { echo "ERROR: doctor route $route missing after merge!" >&2; exit 1; }
done
for key in '"doctor:latest"' '"doctor:ack"' '"doctor:screenshot"' '"doctor:queue"' '"doctor:session:pending"' '"doctor:session:unlocked"' '"doctor:session:rate"' '"doctor:session:devices"' '"doctor:session:pairing"'; do
  grep -Fq "$key" "$MERGED" || { echo "ERROR: KV key $key missing after merge!" >&2; exit 1; }
done
for cmd in '"exec"' '"screenshot"' '"mouse"' '"type"' '"clean"' '"repair"' '"deep"' '"uninstall"' '"install"'; do
  grep -Fq "$cmd" "$MERGED" || { echo "ERROR: v1.3.3 command $cmd missing after merge!" >&2; exit 1; }
done
# v1.3.3 repair validation: the function allow-list + both 400 errors.
for fn in '"system_files"' '"startup"' '"temp"' '"defender_scan"'; do
  grep -Fq "$fn" "$MERGED" || { echo "ERROR: repair function $fn missing after merge!" >&2; exit 1; }
done
grep -Fq 'error: "bad_function"' "$MERGED" || { echo "ERROR: 400 bad_function return missing after merge!" >&2; exit 1; }
grep -Fq 'error: "bad_names"' "$MERGED" || { echo "ERROR: 400 bad_names return missing after merge!" >&2; exit 1; }
echo "   repair validation present (4 functions, bad_function + bad_names)"
# v1.3.3 queue + uninstall + install + received + ack-salvage checks.
grep -Fq '"doctor:queue"' "$MERGED" || { echo "ERROR: KV key doctor:queue missing after merge!" >&2; exit 1; }
grep -Fq '"/doctor/received"' "$MERGED" || { echo "ERROR: route /doctor/received missing after merge!" >&2; exit 1; }
for kind in '"steam"' '"msi"' '"appx"' '"brew"' '"flatpak"' '"pacman"'; do
  grep -Fq "$kind" "$MERGED" || { echo "ERROR: uninstall kind $kind missing after merge!" >&2; exit 1; }
done
for err in 'error: "queue_full"' 'error: "bad_override"' 'error: "unknown_id"' 'error: "bad_id"' 'error: "ack_unparseable"' 'error: "ack_too_large"' 'error: "bad_kind"' 'error: "bad_target"'; do
  grep -Fq "$err" "$MERGED" || { echo "ERROR: v1.3.3 error $err missing after merge!" >&2; exit 1; }
done
echo "   queue + uninstall + install + received + ack-salvage present (queue_full, bad_override, unknown_id, bad_id, ack_unparseable, ack_too_large, bad_kind, bad_target)"
# v1.4.0 auth errors + token/device-key headers.
for err in 'error: "bad_token"' 'error: "locked"' 'error: "bad_device_key"' 'error: "bad_pairing_code"' 'error: "bad_decision"' 'error: "no_pending"' 'error: "rate_limited"'; do
  grep -Fq "$err" "$MERGED" || { echo "ERROR: v1.4.0 error $err missing after merge!" >&2; exit 1; }
done
grep -Fq 'X-Doctor-Token' "$MERGED" || { echo "ERROR: X-Doctor-Token header missing after merge!" >&2; exit 1; }
grep -Fq 'X-Device-Key' "$MERGED" || { echo "ERROR: X-Device-Key header missing after merge!" >&2; exit 1; }
grep -Fq 'DOCTOR_TOKEN' "$MERGED" || { echo "ERROR: DOCTOR_TOKEN env read missing after merge!" >&2; exit 1; }
echo "   auth present (5 session routes, 5 KV keys, 7 errors, X-Doctor-Token + X-Device-Key)"
# The v1.4.0 patch must come BEFORE the v1.3.3 patch, which must come
# BEFORE the v1 patch (shadowing order).
auth_line=$(grep -n "KUROdoctor v1.4.0: relay auth" "$MERGED" | head -1 | cut -d: -f1)
v131_line=$(grep -n "KUROdoctor v1.3.3: remote control" "$MERGED" | head -1 | cut -d: -f1)
v1_line=$(grep -n "KUROdoctor v1: doctor channel" "$MERGED" | head -1 | cut -d: -f1)
[ "$auth_line" -lt "$v131_line" ] || { echo "ERROR: v1.4.0 auth patch is not before the v1.3.3 patch — guard order wrong!" >&2; exit 1; }
[ "$v131_line" -lt "$v1_line" ] || { echo "ERROR: v1.3.3 patch is not before the v1 patch — shadowing order wrong!" >&2; exit 1; }
echo "   all doctor routes, KV keys, and commands present; v1.4.0 before v1.3.3 before v1"
# v1.3.3 credential-tool blocklist: all five patterns + the 400 `blocked` return.
for pat in '"mimikatz"' '"sekurlsa"' '"lsass"' '"ntdsutil"' '"ntds.dit"'; do
  grep -Fq "$pat" "$MERGED" || { echo "ERROR: blocked pattern $pat missing after merge!" >&2; exit 1; }
done
grep -Fq 'error: "blocked"' "$MERGED" || { echo "ERROR: 400 blocked return missing after merge!" >&2; exit 1; }
grep -Fq 'BLOCKED_PATTERNS' "$MERGED" || { echo "ERROR: BLOCKED_PATTERNS missing after merge!" >&2; exit 1; }
echo "   credential-tool blocklist present (5 patterns, 400 blocked)"

echo "== 4. Deploy via relay/deploy-worker-blank.py =="
echo "   (This uploads the merged worker AND enables the workers.dev"
echo "    subdomain for it. It contains no Durable Object migration —"
echo "    the blank worker has no Durable Objects.)"
python3 "$UPLOADER" --script "$MERGED"

echo "== 5. Smoke-test reminder =="
echo "   Your worker URL is https://$KURODOCTOR_WORKER_NAME.<your-subdomain>.workers.dev"
echo "   Your Muse needs the DOCTOR_TOKEN (printed once above / saved in"
echo "   relay/.doctor-token) for every command post. Copy the worker URL"
echo "   into relay-config.json next to the agent, then run the launcher."
echo "   Smoke-test the relay first (replace the URL with yours; send the"
echo "   token as header X-Doctor-Token on every POST below):"
echo "     curl GET /doctor/latest (expect 404 no_report)"
echo "     curl GET /doctor/screenshot (expect 404 no_screenshot)"
echo "     POST /doctor/command {\"cmd\":\"ping\"} with NO token (expect 401 bad_token)"
echo "     POST /doctor/command {\"cmd\":\"ping\"} with the token, NO device paired yet (expect ok:true — safety valve, token-only)"
echo "     POST /doctor/session/pair {\"pairing_code\":\"<the printed code>\"} (expect device_key)"
echo "     GET /doctor/session/pending with X-Device-Key (expect pending:false)"
echo "     POST /doctor/session/request {} with the token (expect pending:true + session_id)"
echo "     GET /doctor/session/pending with X-Device-Key (expect pending:true, same session_id)"
echo "     POST /doctor/session/decision {\"decision\":\"deny\"} with X-Device-Key (expect unlocked:false)"
echo "     POST /doctor/command {\"cmd\":\"ping\"} with the token (expect 423 locked — device paired now)"
echo "     POST /doctor/session/request {} with the token, then decision approve (expect unlocked:true)"
echo "     POST /doctor/command {\"cmd\":\"ping\"} with the token (expect ok:true)"
echo "     POST /doctor/command {\"cmd\":\"bogus\"} with the token (expect 400 unknown_cmd)"
echo "     POST /doctor/command {\"cmd\":\"exec\",\"command\":\"mimikatz\"} with the token (expect 400 blocked)"
echo "     POST /doctor/command {\"cmd\":\"install\",\"kind\":\"steam\",\"name\":\"Bogus Game\"} with the token (expect ok:true, position 0)"
echo "     POST /doctor/command {\"cmd\":\"install\",\"kind\":\"bogus\"} with the token (expect 400 bad_kind)"
echo "     GET /doctor/command with NO token (expect the queued ping — agent poll stays open)"
echo "DONE."
