# KUROdoctor v1.3.2 agent + v1.4.0 relay — Windows, bring-your-own-Cloudflare

A doctor for your Windows PC. An agent runs on the PC, phones home
to **your own** Cloudflare Worker, and your Muse sends it commands
(checkup, clean, repair, uninstall, install). Every fix is shown first and
runs only after you say go to that exact fix. Nothing is ever fixed
silently.

**This pack contains no one else's Cloudflare values.** The relay URL
is blank until you put yours in. There is no fallback to anyone
else's worker anywhere in these files.

**The Authenticator is included in this pack.** Install
`KUROdoctor-Authenticator-1.1.apk` (at the root of this pack) on
your Android phone first — it is the ready-to-install app, no
building needed. The v1.4.0 relay needs both: a Muse-held token
proves a command came from your Muse, and your tap in the
Authenticator app proves you approved the session. (The app's
source + build instructions live in the separate
`KUROdoctor-Authenticator-BLANK.zip` for anyone who wants to build
it themselves.)

## Start here

Read `SETUP.md`. It is written for your Muse: it tells your Muse
exactly what to ask you for (your Cloudflare worker URL, worker
name, account ID, KV namespace ID), how to deploy the relay, how to
smoke-test it, and how to verify each step worked.

## What is in this pack

| File | What it is |
|---|---|
| `KUROdoctor-Authenticator-1.1.apk` | The Authenticator app, ready to install on your Android phone — install it first, then pair it (SETUP.md Step 2). No building needed. |
| `SETUP.md` | Setup guide for your Muse — start here. |
| `agent/kuro-doctor-agent-v1.3.2.ps1` | The agent (PowerShell, no admin rights needed, no install). |
| `agent/kuro-doctor-remote-screen.ps1` | Screen capture / mouse / type (called by the agent). |
| `agent/relay-config.json` | Your relay URL goes here. Blank until you fill it in. |
| `entry/KUROdoctor-Start-v1.3.2.bat` | Double-click to run the agent. |
| `repair/repair-windows.ps1` | The repair module the agent calls. |
| `relay/worker-base-blank.js` | Minimal base worker for your Cloudflare account. |
| `relay/worker-auth-patch-v1.4.0-blank.js` | The v1.4.0 auth patch (token + app approval). |
| `relay/worker-remote-patch-v1.3.2-blank.js` | The v1.3.1 doctor-channel patch. |
| `relay/worker-doctor-patch-blank.js` | The v1 doctor-channel patch. |
| `relay/deploy-worker-blank.py` | Uploads the merged worker to your account. |
| `relay/deploy-remote-endpoints-v1.4.0-blank.sh` | Merges base + patches, checks, deploys, stores the token + pairing code. |
| `relay/set-worker-secret-blank.py` | Stores the DOCTOR_TOKEN worker secret. |
| `relay/kv-put-blank.py` | Stores the pairing code in KV. |
| `docs/remote-control.md` | The full command contract (queue, ack, uninstall, install, owner override). |

## Rules that never change

- Two factors, both required: the token proves a command came from
  your Muse; your tap in the Authenticator app proves you approved
  the session. A post with no token gets `401`; a post with a token
  but a locked session gets `423`.
- Show-first / ok-gate: every fix is proposed in chat first and runs
  only after you say go to that exact fix.
- No reboot, shutdown, wipe, format, or reinstall without your
  explicit ok for that named step.
- No lock-screen / password bypass, no saved-credential digging, no
  other people's machines, no iPhones, ever.
- Never delete your documents or photos. Desktop shortcut deletes
  (`.lnk` files only) need an explicit `owner_override` — see
  `docs/remote-control.md`.
- Polling: 1s while a command is active, 10s when idle, heartbeat
  every ~60s. Idle costs about 10,000 Cloudflare requests/day, well
  under the 100,000 free cap.

## Verification status — read honestly

This pack is code-verified only. It has never run against a live
relay or a real PC until you run it. Report what you actually see at
each step of SETUP.md, not what should happen.
