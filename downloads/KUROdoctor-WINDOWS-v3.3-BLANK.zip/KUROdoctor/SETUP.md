# KUROdoctor — SETUP (bring-your-own-Cloudflare, Windows)

**Who this is for:** you are a Muse helping your owner set up KUROdoctor
on their Windows PC. The owner drops this pack into their Muse and you
walk them through it. Nothing here points at anyone else's Cloudflare —
every value below comes from the owner's own account.

**What KUROdoctor is, in one line:** a doctor for the owner's PC. An
agent runs on the PC, phones home to the owner's own Cloudflare Worker,
and the owner's Muse sends it commands (checkup, clean, repair,
uninstall, install). Every fix is shown first and runs only after the owner says
go to that exact fix. Nothing is ever fixed silently.

**The Authenticator is included in this pack.** Install
`KUROdoctor-Authenticator-1.1.apk` (at the root of this pack) on the
owner's Android phone first — it is the ready-to-install app, no
building needed. The relay in v1.4.0 needs both: the token proves a
command came from Muse, and the owner's tap in the Authenticator app
proves the owner approved the session. (The app's source + build
instructions live in the separate `KUROdoctor-Authenticator-BLANK.zip`
for anyone who wants to build it themselves.) Set the relay up first
(Step 1), then pair the app (Step 2).

## What to ask the owner for (ask before you start)

You need four values from the owner's Cloudflare account. Ask for them
one at a time, in this order, and tell the owner where each one lives:

1. **Cloudflare account ID** — dashboard: open dash.cloudflare.com, the
   account ID is the 32-hex-character segment in the URL, or under the
   account menu top-right.
2. **API token** — dashboard: My Profile → API Tokens → Create Token.
   It needs **Workers Scripts:Edit** and **Workers KV Storage:Edit**.
   The owner pastes the token value to you once; never ask them to post
   it anywhere public, and never write it into any file in this pack.
3. **Worker name** — the owner picks one, e.g. `kurodoctor`. Their
   worker URL becomes `https://<name>.<subdomain>.workers.dev`.
4. **KV namespace ID** — dashboard: Workers & Pages → KV → Create a
   namespace (name it anything, e.g. `kurodoctor`). Copy the namespace
   ID it shows after creation.

Do not proceed until you have all four. Do not guess any of them.

## Step 1 — Deploy the relay (on the owner's computer)

Files: `relay/deploy-remote-endpoints-v1.4.0-blank.sh`,
`relay/deploy-worker-blank.py`, `relay/worker-base-blank.js`,
`relay/worker-auth-patch-v1.4.0-blank.js`,
`relay/worker-remote-patch-v1.3.2-blank.js`,
`relay/worker-doctor-patch-blank.js`,
`relay/set-worker-secret-blank.py`, `relay/kv-put-blank.py`.

The deploy script merges the base worker with the three patch files
(auth first, then remote control, then the v1 doctor channel), checks
the result with `node --check`, then uploads it with
`deploy-worker-blank.py` and enables the workers.dev subdomain.

It also creates the two v1.4.0 secrets, and prints each one ONCE:

- **DOCTOR_TOKEN** — a random 32-byte hex token, stored as a worker
  secret. It is the Muse-held write token: every `POST
  /doctor/command` must carry it as header `X-Doctor-Token`, or the
  relay answers `401 bad_token`. **Save it where you keep secrets
  and never write it into any file in this pack, any doc, or any
  chat the owner might share. The owner never sees or types it.**
  The script also saves it to `relay/.doctor-token` (chmod 600) in
  your copy — never share that file.
- **Pairing code** — 12 random hex characters, stored in KV key
  `doctor:session:pairing`. **Give it to the owner once** so they
  can pair the Authenticator app (Step 2). It is used once, then
  thrown away. Never write it into any file in this pack.

Run it from the `relay/` folder, with the owner's explicit go first
(it replaces the worker's script and stores a secret + a KV value).
The four values go in as environment variables, and the approval
gate is a fifth:

```sh
cd relay
CLOUDFLARE_ACCOUNT_ID=<owner's account id> \
CLOUDFLARE_API_TOKEN=<owner's token> \
KURODOCTOR_WORKER_NAME=<owner's worker name> \
KURODOCTOR_KV_NAMESPACE_ID=<owner's KV namespace id> \
KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1 \
./deploy-remote-endpoints-v1.4.0-blank.sh
```

**Verify it worked:** the script prints each step, then `DONE.` and
`Your worker URL is https://<name>.<subdomain>.workers.dev`. If it
stops with `ERROR:` naming a missing variable, set that variable and
run it again. If it stops with `STOP: ... PENDING THE OWNER'S
APPROVAL`, the approval gate is not set — get the owner's go, then
re-run with `KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1`. Nothing is
uploaded until all checks pass. If a secret or KV PUT fails, the
script aborts BEFORE uploading the worker — fix the credential and
re-run.

## Step 2 — Pair the Authenticator app

File: `KUROdoctor-Authenticator-1.1.apk`, included at the root of
this pack — install it on the owner's Android phone. (The app's
source + build instructions live in the separate
`KUROdoctor-Authenticator-BLANK.zip`.) The owner installs the app,
then:

1. You give the owner the **relay URL** (Step 1) and the **pairing
   code** (printed once by the deploy script).
2. The owner opens the app, pastes both, taps **Pair**. The relay
   returns a device key the app stores locally.
3. The app now polls the relay every 5 seconds while open.

**Verify it worked:** the app shows "Paired with your relay" and
`Session: LOCKED`. Until the first pairing, the relay runs in
token-only mode (safety valve) so setup can never brick itself.
Once a device is paired, commands need BOTH the token AND an
unlocked session.

## Step 3 — Smoke-test the relay (before touching the PC agent)

Replace `<url>` with the worker URL from Step 1. Run these from any
terminal (curl is enough — no agent needed yet). Command posts need
the token header; `GET /doctor/command` (the agent poll) does not.

```sh
curl <url>/doctor/latest
curl <url>/doctor/screenshot
curl -X POST <url>/doctor/command -H "X-Doctor-Token: $DOCTOR_TOKEN" -d '{"cmd":"ping"}'
curl -X POST <url>/doctor/command -d '{"cmd":"ping"}'
curl -X POST <url>/doctor/command -H "X-Doctor-Token: $DOCTOR_TOKEN" -d '{"cmd":"bogus"}'
curl -X POST <url>/doctor/command -H "X-Doctor-Token: $DOCTOR_TOKEN" -d '{"cmd":"exec","command":"mimikatz"}'
```

**Success looks like this:**
- `/doctor/latest` → `404` with `no_report` (nothing has reported yet).
- `/doctor/screenshot` → `404` with `no_screenshot`.
- `{"cmd":"ping"}` WITH the token → `200` with `ok:true` and a `position`.
- `{"cmd":"ping"}` WITHOUT the token → `401` with `bad_token`.
- `{"cmd":"bogus"}` with the token → `400` with `unknown_cmd`.
- `{"cmd":"exec","command":"mimikatz"}` with the token → `400` with `blocked`.

If the token-carrying ping returns `ok:true`, the relay is live and
the queue works. Then clean the test command out of the queue before
the agent starts: `GET <url>/doctor/command` shows the queued ping;
`POST <url>/doctor/received` with its `id` removes it.

**Session smoke test (after pairing, Step 2):** with a device paired,
a token-carrying ping now returns `423 locked` until the owner
approves a session in the app. Request one with the token
(`POST <url>/doctor/session/request` → `{pending:true, session_id}`),
approve it in the app, and the next ping returns `ok:true`. If the
owner taps Deny, the session stays locked and pings stay `423`.

## Step 4 — Point the agent at the relay

File: `agent/relay-config.json`. It ships blank:

```json
{"relay_url": ""}
```

Open it and put the worker URL from Step 1 in `relay_url`, e.g.
`https://kurodoctor.<subdomain>.workers.dev`. Save it. That is the
only file the owner edits by hand.

**Verify it worked:** if the agent is ever run with a blank
`relay_url`, it prints `KUROdoctor: no relay URL is set.` and exits
with code 2. That message means the URL is not in the file yet — not
that anything is broken.

## Step 5 — Run the agent (on the owner's Windows PC)

File: `entry/KUROdoctor-Start-v1.3.2.bat`. The owner double-clicks it.
It runs `agent/kuro-doctor-agent-v1.3.2.ps1` (PowerShell, no admin
rights needed, no install). Keep the window open while the doctor works;
closing it stops the doctor.

**Verify it worked:** the window prints
`KUROdoctor agent v1.3.2 starting, relay=<the worker URL>` and
`polling <url>/doctor/command: 1s while active, 10s when idle`.
Within a minute the owner's Muse should see the boot report arrive
on the relay (`GET <url>/doctor/latest` returns it). If the window
says the doctor is not reachable, check the internet connection and
the URL in `relay-config.json`, then run the launcher again.

## Step 6 — First commands (from the owner's Muse)

Every command post carries the token header. The owner approves a
session in the Authenticator app first (Step 2 / Step 3), then send
these to confirm the loop end to end:

1. `{"cmd":"ping"}` → the agent acks it. Success: the ack shows up
   on `GET <url>/doctor/ack`.
2. `{"cmd":"sysinfo"}` → the agent reports the PC (OS, CPU, RAM,
   disks). Success: a report with real values, not an error.

Then the doctor is live. The full command list (exec, screenshot,
mouse, type, clean, repair, deep, uninstall, install) is in
`docs/remote-control.md`. A session unlock lasts 8 hours; the next
session needs a fresh tap in the app.

## Rules that never change

- **Two factors, both required:** the token proves a command came
  from Muse; the app tap proves the owner approved the session.
  A post with no token gets `401`; a post with a token but a locked
  session gets `423`. Neither factor alone is enough once a device
  is paired.
- **Show-first / ok-gate:** every fix is proposed in chat first and
  runs only after the owner says go to that exact fix. Never run a
  fix the owner has not ok'd by name. The app approval unlocks the
  SESSION — it does not approve any single fix.
- **No reboot, shutdown, wipe, format, or reinstall** without the
  owner's explicit ok for that named step.
- **No lock-screen or password bypass, no saved-credential digging,
  no other people's machines, no iPhones, ever.**
- **Never delete user documents or photos.** Desktop shortcut
  deletes (`.lnk` files only) need the `owner_override` flag on the
  exec command — see `docs/remote-control.md`.
- **Polling:** 1s while a command is active, 10s when idle, heartbeat
  every ~60s. Idle costs about 10,000 Cloudflare requests/day, well
  under the 100,000 free cap.
- **This pack is code-verified only.** It has never run against a
  live relay or a real PC until the owner runs it — report what you
  actually see at each step, not what should happen.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `no relay URL is set` | `relay-config.json` still blank | Step 4 — paste the worker URL in |
| `doctor is not reachable` | Wrong URL, or no internet | Check the URL, check the connection |
| Deploy script `STOP: ... APPROVAL` | Approval gate unset | Owner's go, then `KURO_DOCTOR_AUTH_DEPLOY_APPROVED=1` |
| Deploy script `ERROR: ... is not set` | A Cloudflare value missing | Ask the owner for that value (top of this file) |
| Command post `401 bad_token` | Token missing, wrong, or not stored | Use the token from Step 1; re-run the deploy if the secret was never stored |
| Command post `423 locked` | No session approved yet | Request a session, approve it in the Authenticator app |
| Smoke test `blocked` on a normal command | Relay blocklist hit a credential-tool word | Reword the command; the blocklist lives on the relay only |
| Agent acks `target_running` on uninstall | The game/app is still running | Close it first, then send the uninstall again |
